# v0.3.6 Validation Notes — Controller Detection Restored + Log-Spam Fixed

Date: 2026-05-25

Release URL:
https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01/releases/tag/controller-support-v0.3.6-detection-restored-logspam-fixed

Engine build:
`research/controller-api-investigation @ a76a36b9b18910f225a9cb8a4c42f920e14b33de`

Installer:
`Install_BAR_Controller_Support_v0.3.6_SAFE_LIVE.bat`

## What was fixed after the previous bible

The previous working custom Recoil engine had two separate follow-up issues:

1. High-frequency controller input logs (`ButtonDown`, `ButtonUp`, `AxisMotion`) caused severe log spam.
2. The first log-spam-fixed release, v0.3.5, accidentally regressed controller startup detection because the final Patch 4 SDL startup scan path was missing from `ControllerInput.cpp`.

v0.3.6 fixes both:

- Restores Patch 4 SDL joystick/gamecontroller initialization and startup scanning.
- Keeps `CONTROLLER_INPUT_LOG_EVENTS` as a default-off compile-time gate.
- Gates only the high-frequency `ButtonDown`, `ButtonUp`, and `AxisMotion` logs.
- Preserves lifecycle logs for initialization, scan, connect, remove, remap, and warnings/errors.

## Validation from v0.3.6 `infolog.txt`

The test log confirmed the correct engine was active:

```text
Spring Engine Version: a76a36b research/controller-api-investigation
```

The test log confirmed the camera cardinal-lock fix was active:

```text
CamSpringLockCardinalDirections = 0
```

The test log confirmed restored SDL controller startup detection:

```text
[ControllerInput] SDL joystick/gamecontroller subsystem initialized
[ControllerInput] SDL_NumJoysticks at init: 3
[ControllerInput] Scanning existing SDL joysticks: count=3
[ControllerInput] SDL game controller available: deviceId=0 name=Controller (Xbox One For Windows)
[ControllerInput] Controller device added: deviceId=0
[ControllerInput] Controller connected: deviceId=0 instanceId=0 name=Controller (Xbox One For Windows)
```

The log also showed non-controller vJoy devices were skipped safely:

```text
[ControllerInput] SDL joystick available but not game controller: deviceId=1 name=vJoy Device
[ControllerInput] Skipping existing non-game-controller device: deviceId=1
[ControllerInput] SDL joystick available but not game controller: deviceId=2 name=vJoy Device
[ControllerInput] Skipping existing non-game-controller device: deviceId=2
```

The test log did not show the previous flood of `ButtonDown`, `ButtonUp`, or `AxisMotion` event logs, indicating the high-frequency log gate worked as intended.

## Current known-good public test release

Use v0.3.6 as the current good public test release.

Do not use v0.3.5 except as a historical regression marker.
