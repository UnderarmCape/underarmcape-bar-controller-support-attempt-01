# BAR Controller Bindings UI Prototype

Standalone browser prototype for a future Steam-Input-style binding menu for BAR Xbox Controller Support v0.3.7.

This is intentionally outside the BAR game files. It does not modify Recoil, BAR LuaUI, or the active gameplay widget.

## Run

This prototype has no runtime dependencies. If `npm` is available, use:

```powershell
npm run dev
```

If `npm` is not available, run the dependency-free dev server directly with Node:

```powershell
node dev-server.mjs
```

Then open the Vite URL, usually:

```text
http://127.0.0.1:5173/
```

Build check:

```powershell
npm run build
```

or directly:

```powershell
node build.mjs
```

## Keyboard Controls

- Arrow Up / Down: move selected action
- Arrow Left / Right: switch category
- Enter: open rebind capture modal
- Escape: close modal or close the prototype menu
- R: reset selected binding
- Delete: clear selected binding

When the capture modal is open, arrow keys are captured as mock D-pad inputs instead of navigating categories.

## Mock Controller Input Mapping

- A key -> `A`
- B key -> `B`
- X key -> `X`
- Y key -> `Y`
- Q key -> `LB`
- E key -> `RB`
- Z key -> `LT`
- C key -> `RT`
- Backspace -> `Back/View`
- M key -> `Menu/Start`
- Arrow Up -> `D-pad Up`
- Arrow Down -> `D-pad Down`
- Arrow Left -> `D-pad Left`
- Arrow Right -> `D-pad Right`

## What Is Mocked

This prototype stores bindings in browser memory only. It does not talk to BAR, Recoil, Steam Input, or the Lua widget.

Bindings keep both a display label, such as `Right Stick Y`, and a canonical `controlId`, such as `rightStickY`. Controller highlights and conflict detection use `controlId` values instead of substring matching, which avoids false matches like `Right Stick Y` lighting up the face-button `Y`.

Conflict handling is implemented for UX testing:

- Enter = Replace
- D = Allow Duplicate
- Escape = Cancel

## Future LuaUI Mapping

The JavaScript is organized around render/state functions intended to map cleanly to a future BAR LuaUI widget named something like `gui_controller_bindings_ui.lua`:

- `renderHeader`
- `renderTabs`
- `renderControllerOverview`
- `renderActionList`
- `renderDetailsPanel`
- `renderFooterHints`
- `renderRebindModal`
- `renderConflictModal`
- `setSelectedCategory`
- `setSelectedAction`
- `startRebindCapture`
- `applyBinding`

The future LuaUI widget should call the stable API exposed by `gui_controller_camera_test.lua`:

- `WG.BARControllerSupport.GetBindingDefinitions`
- `WG.BARControllerSupport.GetBinding`
- `WG.BARControllerSupport.SetBinding`
- `WG.BARControllerSupport.ResetBinding`
- `WG.BARControllerSupport.ResetAllBindings`
- `WG.BARControllerSupport.GetPressedBindingInput`
- `WG.BARControllerSupport.IsInputPressed`
- `WG.BARControllerSupport.IsInputDown`
- `WG.BARControllerSupport.SetBindingUIOpen`
- `WG.BARControllerSupport.IsBindingUIOpen`

## Gameplay Reminder

The real controller gameplay logic remains in `gui_controller_camera_test.lua`.

The latest gameplay baseline includes working queue removal from commit:

```text
fe61330f8ffc1c08b779a1573f27e445827f1520
```
