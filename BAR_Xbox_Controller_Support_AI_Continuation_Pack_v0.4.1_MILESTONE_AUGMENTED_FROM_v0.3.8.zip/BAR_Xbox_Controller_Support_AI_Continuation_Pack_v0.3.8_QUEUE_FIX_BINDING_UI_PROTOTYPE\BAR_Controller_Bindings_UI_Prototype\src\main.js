import { bindingCategories, mockKeyboardToController } from "./bindingsManifest.js";

const app = document.querySelector("#app");

const state = {
  menuOpen: true,
  selectedCategoryIndex: 0,
  selectedActionIndex: 0,
  captureActionId: null,
  conflict: null,
  toast: "Ready",
  categories: cloneCategories(bindingCategories),
  defaults: snapshotDefaults(bindingCategories)
};

function cloneCategories(categories) {
  return categories.map((category) => ({
    ...category,
    actions: category.actions.map((action) => ({
      ...action,
      controlIds: action.controlIds ? [...action.controlIds] : undefined
    }))
  }));
}

function snapshotDefaults(categories) {
  const defaults = {};
  categories.forEach((category) => {
    category.actions.forEach((action) => {
      defaults[action.id] = {
        binding: action.binding,
        controlId: action.controlId || "",
        controlIds: action.controlIds ? [...action.controlIds] : undefined
      };
    });
  });
  return defaults;
}

function selectedCategory() {
  return state.categories[state.selectedCategoryIndex];
}

function selectedAction() {
  return selectedCategory().actions[state.selectedActionIndex];
}

function allActions() {
  return state.categories.flatMap((category) =>
    category.actions.map((action) => ({ ...action, categoryId: category.id, categoryLabel: category.label }))
  );
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function bindingChip(binding, extraClass = "") {
  const label = binding || "Unbound";
  return `<span class="binding-chip ${binding ? "" : "empty"} ${extraClass}">${escapeHtml(label)}</span>`;
}

function normalizeInput(input) {
  if (!input) {
    return { binding: "", controlId: "", controlIds: [] };
  }
  if (typeof input === "string") {
    return { binding: input, controlId: "", controlIds: [] };
  }

  const controlIds = Array.isArray(input.controlIds)
    ? input.controlIds.filter(Boolean)
    : input.controlId
      ? [input.controlId]
      : [];

  return {
    binding: input.binding || "",
    controlId: input.controlId || controlIds[controlIds.length - 1] || "",
    controlIds
  };
}

function setActionInput(action, input) {
  const nextInput = normalizeInput(input);
  action.binding = nextInput.binding;
  action.controlId = nextInput.controlId;
  if (nextInput.controlIds.length > 1) {
    action.controlIds = [...nextInput.controlIds];
  } else {
    delete action.controlIds;
  }
}

function actionControlIds(action, includeStickParents = true) {
  const ids = new Set();
  if (Array.isArray(action.controlIds)) {
    action.controlIds.forEach((controlId) => {
      if (controlId) {
        ids.add(controlId);
      }
    });
  }
  if (action.controlId) {
    ids.add(action.controlId);
  }

  if (includeStickParents) {
    if (ids.has("leftStickX") || ids.has("leftStickY")) {
      ids.add("leftStick");
    }
    if (ids.has("rightStickX") || ids.has("rightStickY")) {
      ids.add("rightStick");
    }
  }

  return ids;
}

function actionConflictControlIds(action) {
  const ids = actionControlIds(action, false);
  if (ids.has("leftStickX") || ids.has("leftStickY")) {
    ids.delete("leftStick");
  }
  if (ids.has("rightStickX") || ids.has("rightStickY")) {
    ids.delete("rightStick");
  }
  return ids;
}

function controlKeyFromIds(ids) {
  return [...ids].filter(Boolean).sort().join("+");
}

function actionControlKey(action) {
  return controlKeyFromIds(actionConflictControlIds(action));
}

function inputControlKey(input) {
  const normalized = normalizeInput(input);
  return controlKeyFromIds(new Set(normalized.controlIds.length ? normalized.controlIds : [normalized.controlId]));
}

function renderHeader() {
  return `
    <header class="app-header">
      <div>
        <h1>BAR Controller Bindings</h1>
        <p>Xbox Controller Support v0.3.7</p>
      </div>
      <div class="status-pill">${escapeHtml(state.toast)}</div>
    </header>
  `;
}

function renderTabs() {
  return `
    <nav class="tabs" aria-label="Binding categories">
      ${state.categories.map((category, index) => `
        <button class="tab ${index === state.selectedCategoryIndex ? "active" : ""}" data-category-index="${index}">
          ${escapeHtml(category.label)}
        </button>
      `).join("")}
    </nav>
  `;
}

function renderControllerButton(controlId, label, className, activeControlIds) {
  const active = activeControlIds.has(controlId);
  return `<div class="controller-node ${className} ${active ? "active" : ""}" data-control-id="${escapeHtml(controlId)}" data-input="${escapeHtml(label)}">${escapeHtml(label)}</div>`;
}

function renderControllerOverview() {
  const action = selectedAction();
  const activeBinding = action.binding || "";
  const activeControlIds = actionControlIds(action);
  return `
    <section class="controller-panel panel">
      <div class="panel-title">
        <span>Controller Overview</span>
        ${bindingChip(activeBinding, "large")}
      </div>
      <div class="controller-shell" aria-label="Mock Xbox controller diagram">
        ${renderControllerButton("lt", "LT", "trigger trigger-left", activeControlIds)}
        ${renderControllerButton("rt", "RT", "trigger trigger-right", activeControlIds)}
        ${renderControllerButton("lb", "LB", "shoulder shoulder-left", activeControlIds)}
        ${renderControllerButton("rb", "RB", "shoulder shoulder-right", activeControlIds)}
        ${renderControllerButton("backView", "Back/View", "system-button back-button", activeControlIds)}
        ${renderControllerButton("menuStart", "Menu/Start", "system-button start-button", activeControlIds)}
        ${renderControllerButton("leftStick", "Left Stick", "stick left-stick", activeControlIds)}
        ${renderControllerButton("rightStick", "Right Stick", "stick right-stick", activeControlIds)}
        ${renderControllerButton("rightStickX", "Right Stick X", "stick-label right-stick-x", activeControlIds)}
        ${renderControllerButton("rightStickY", "Right Stick Y", "stick-label right-stick-y", activeControlIds)}
        <div class="dpad">
          ${renderControllerButton("dpadUp", "D-pad Up", "dpad-button dpad-up", activeControlIds)}
          ${renderControllerButton("dpadLeft", "D-pad Left", "dpad-button dpad-left", activeControlIds)}
          ${renderControllerButton("dpadRight", "D-pad Right", "dpad-button dpad-right", activeControlIds)}
          ${renderControllerButton("dpadDown", "D-pad Down", "dpad-button dpad-down", activeControlIds)}
        </div>
        <div class="face-buttons">
          ${renderControllerButton("y", "Y", "face y-button", activeControlIds)}
          ${renderControllerButton("x", "X", "face x-button", activeControlIds)}
          ${renderControllerButton("b", "B", "face b-button", activeControlIds)}
          ${renderControllerButton("a", "A", "face a-button", activeControlIds)}
        </div>
      </div>
    </section>
  `;
}

function renderActionList() {
  const category = selectedCategory();
  return `
    <section class="action-list panel">
      <div class="panel-title">
        <span>${escapeHtml(category.label)}</span>
        <span>${category.actions.length} actions</span>
      </div>
      <div class="action-rows">
        ${category.actions.map((action, index) => `
          <button class="action-row ${index === state.selectedActionIndex ? "selected" : ""}" data-action-index="${index}">
            <span class="action-label">${escapeHtml(action.label)}</span>
            ${bindingChip(action.binding)}
          </button>
        `).join("")}
      </div>
    </section>
  `;
}

function renderDetailsPanel() {
  const action = selectedAction();
  const defaultBinding = state.defaults[action.id]?.binding || "Unbound";
  const controlKey = actionControlKey(action);
  const conflicts = controlKey
    ? allActions().filter((candidate) => candidate.id !== action.id && actionControlKey(candidate) === controlKey)
    : [];

  return `
    <aside class="details panel">
      <div class="panel-title">
        <span>Selected Action</span>
        <span>${escapeHtml(selectedCategory().label)}</span>
      </div>
      <h2>${escapeHtml(action.label)}</h2>
      <div class="detail-binding">
        <span>Current</span>
        ${bindingChip(action.binding, "large")}
      </div>
      <div class="detail-grid">
        <span>Action ID</span><strong>${escapeHtml(action.id)}</strong>
        <span>Control ID</span><strong>${escapeHtml(controlKey || "None")}</strong>
        <span>Default</span><strong>${escapeHtml(defaultBinding)}</strong>
        <span>Conflict</span><strong>${conflicts.length ? escapeHtml(conflicts.map((item) => item.label).join(", ")) : "None"}</strong>
      </div>
      <p>${escapeHtml(action.description || "No description yet.")}</p>
      <div class="details-actions">
        <button data-command="rebind">Rebind</button>
        <button data-command="reset">Reset</button>
        <button data-command="clear">Clear</button>
      </div>
    </aside>
  `;
}

function renderFooterHints() {
  return `
    <footer class="footer-hints">
      <span>A/Enter Rebind</span>
      <span>X/R Reset</span>
      <span>B/Esc Back</span>
      <span>LB/RB or &larr;/&rarr; Category</span>
      <span>Delete Clear</span>
    </footer>
  `;
}

function renderRebindModal() {
  if (!state.captureActionId) {
    return "";
  }
  const action = findActionById(state.captureActionId);
  return `
    <div class="modal-layer">
      <div class="modal">
        <p class="modal-kicker">Rebind Action</p>
        <h2>${escapeHtml(action.label)}</h2>
        <div class="detail-binding">
          <span>Current</span>
          ${bindingChip(action.binding, "large")}
        </div>
        <p class="capture-prompt">Press a controller input</p>
        <p class="modal-note">Keyboard keys are mapped to mock controller inputs for this prototype.</p>
        <div class="mock-map">
          <span>A/B/X/Y keys</span>
          <span>Q/E = LB/RB</span>
          <span>Z/C = LT/RT</span>
          <span>Backspace = Back/View</span>
          <span>Arrows = D-pad</span>
        </div>
      </div>
    </div>
  `;
}

function renderConflictModal() {
  if (!state.conflict) {
    return "";
  }
  const binding = state.conflict.input?.binding || "";
  return `
    <div class="modal-layer">
      <div class="modal conflict">
        <p class="modal-kicker">Binding Conflict</p>
        <h2>This input is already assigned to ${escapeHtml(state.conflict.existingAction.label)}.</h2>
        <p>${bindingChip(binding, "large")} is being assigned to ${escapeHtml(state.conflict.targetAction.label)}.</p>
        <div class="modal-options">
          <button data-conflict="replace">Replace</button>
          <button data-conflict="duplicate">Allow Duplicate</button>
          <button data-conflict="cancel">Cancel</button>
        </div>
        <p class="modal-note">Enter = Replace | D = Allow Duplicate | Escape = Cancel</p>
      </div>
    </div>
  `;
}

function renderClosedMenu() {
  return `
    <main class="closed-screen">
      <div class="panel closed-panel">
        <h1>BAR Controller Bindings</h1>
        <p>Menu closed. Press Enter to reopen this prototype.</p>
      </div>
    </main>
  `;
}

function renderApp() {
  if (!state.menuOpen) {
    app.innerHTML = renderClosedMenu();
    return;
  }

  app.innerHTML = `
    <main class="app-shell">
      ${renderHeader()}
      ${renderTabs()}
      <section class="main-grid">
        ${renderControllerOverview()}
        ${renderActionList()}
        ${renderDetailsPanel()}
      </section>
      ${renderFooterHints()}
      ${renderRebindModal()}
      ${renderConflictModal()}
    </main>
  `;
}

function setSelectedCategory(index) {
  const count = state.categories.length;
  state.selectedCategoryIndex = ((index % count) + count) % count;
  state.selectedActionIndex = Math.min(state.selectedActionIndex, selectedCategory().actions.length - 1);
  state.toast = `Category: ${selectedCategory().label}`;
  renderApp();
}

function setSelectedAction(index) {
  const count = selectedCategory().actions.length;
  state.selectedActionIndex = ((index % count) + count) % count;
  state.toast = selectedAction().label;
  renderApp();
}

function startRebindCapture() {
  state.captureActionId = selectedAction().id;
  state.toast = "Listening for input";
  renderApp();
}

function findActionById(actionId) {
  for (const category of state.categories) {
    const action = category.actions.find((item) => item.id === actionId);
    if (action) {
      return action;
    }
  }
  return null;
}

function findBindingConflict(input, actionId) {
  const controlKey = inputControlKey(input);
  if (!controlKey) {
    return null;
  }
  return allActions().find((action) => action.id !== actionId && actionControlKey(action) === controlKey);
}

function applyBinding(actionId, input, options = {}) {
  const action = findActionById(actionId);
  if (!action) {
    return;
  }

  const nextInput = normalizeInput(input);
  const conflict = nextInput.binding ? findBindingConflict(nextInput, actionId) : null;
  if (conflict && !options.allowDuplicate && !options.replace) {
    state.captureActionId = null;
    state.conflict = {
      targetAction: action,
      existingAction: findActionById(conflict.id),
      input: nextInput
    };
    state.toast = "Conflict detected";
    renderApp();
    return;
  }

  if (conflict && options.replace) {
    const oldAction = findActionById(conflict.id);
    if (oldAction) {
      setActionInput(oldAction, null);
    }
  }

  setActionInput(action, nextInput);
  state.captureActionId = null;
  state.conflict = null;
  state.toast = nextInput.binding ? `${action.label}: ${nextInput.binding}` : `${action.label}: cleared`;
  renderApp();
}

function resetSelectedBinding() {
  const action = selectedAction();
  setActionInput(action, state.defaults[action.id]);
  state.toast = `${action.label} reset`;
  renderApp();
}

function clearSelectedBinding() {
  const action = selectedAction();
  setActionInput(action, null);
  state.toast = `${action.label} cleared`;
  renderApp();
}

function keyToMockInput(event) {
  return mockKeyboardToController[event.key] || mockKeyboardToController[String(event.key).toLowerCase()];
}

function handleConflictKey(event) {
  if (!state.conflict) {
    return false;
  }

  if (event.key === "Enter") {
    applyBinding(state.conflict.targetAction.id, state.conflict.input, { replace: true });
  } else if (event.key.toLowerCase() === "d") {
    applyBinding(state.conflict.targetAction.id, state.conflict.input, { allowDuplicate: true });
  } else if (event.key === "Escape") {
    state.conflict = null;
    state.toast = "Conflict cancelled";
    renderApp();
  }
  return true;
}

function handleCaptureKey(event) {
  if (!state.captureActionId) {
    return false;
  }

  if (event.key === "Escape") {
    state.captureActionId = null;
    state.toast = "Capture cancelled";
    renderApp();
    return true;
  }

  const input = keyToMockInput(event);
  if (input) {
    applyBinding(state.captureActionId, input);
    return true;
  }

  state.toast = `No mock mapping for ${event.key}`;
  renderApp();
  return true;
}

function handleKeyboard(event) {
  if (!state.menuOpen) {
    if (event.key === "Enter") {
      state.menuOpen = true;
      state.toast = "Menu opened";
      renderApp();
    }
    return;
  }

  if (handleConflictKey(event) || handleCaptureKey(event)) {
    event.preventDefault();
    return;
  }

  if (event.key === "ArrowUp") {
    setSelectedAction(state.selectedActionIndex - 1);
  } else if (event.key === "ArrowDown") {
    setSelectedAction(state.selectedActionIndex + 1);
  } else if (event.key === "ArrowLeft") {
    setSelectedCategory(state.selectedCategoryIndex - 1);
  } else if (event.key === "ArrowRight") {
    setSelectedCategory(state.selectedCategoryIndex + 1);
  } else if (event.key.toLowerCase() === "q") {
    setSelectedCategory(state.selectedCategoryIndex - 1);
  } else if (event.key.toLowerCase() === "e") {
    setSelectedCategory(state.selectedCategoryIndex + 1);
  } else if (event.key === "Enter" || event.key.toLowerCase() === "a") {
    startRebindCapture();
  } else if (event.key === "Escape") {
    state.menuOpen = false;
    renderApp();
  } else if (event.key.toLowerCase() === "r" || event.key.toLowerCase() === "x") {
    resetSelectedBinding();
  } else if (event.key.toLowerCase() === "b") {
    state.menuOpen = false;
    renderApp();
  } else if (event.key === "Delete") {
    clearSelectedBinding();
  }

  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Enter", "Escape", "Delete"].includes(event.key) || ["a", "b", "e", "q", "r", "x"].includes(event.key.toLowerCase())) {
    event.preventDefault();
  }
}

function handleClick(event) {
  const tab = event.target.closest("[data-category-index]");
  const row = event.target.closest("[data-action-index]");
  const command = event.target.closest("[data-command]");
  const conflict = event.target.closest("[data-conflict]");

  if (tab) {
    setSelectedCategory(Number(tab.dataset.categoryIndex));
  } else if (row) {
    setSelectedAction(Number(row.dataset.actionIndex));
  } else if (command?.dataset.command === "rebind") {
    startRebindCapture();
  } else if (command?.dataset.command === "reset") {
    resetSelectedBinding();
  } else if (command?.dataset.command === "clear") {
    clearSelectedBinding();
  } else if (conflict?.dataset.conflict === "replace") {
    applyBinding(state.conflict.targetAction.id, state.conflict.input, { replace: true });
  } else if (conflict?.dataset.conflict === "duplicate") {
    applyBinding(state.conflict.targetAction.id, state.conflict.input, { allowDuplicate: true });
  } else if (conflict?.dataset.conflict === "cancel") {
    state.conflict = null;
    state.toast = "Conflict cancelled";
    renderApp();
  }
}

window.addEventListener("keydown", handleKeyboard);
app.addEventListener("click", handleClick);

renderApp();
