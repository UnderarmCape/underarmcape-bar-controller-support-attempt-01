import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const requiredFunctions = [
  "renderHeader",
  "renderTabs",
  "renderControllerOverview",
  "renderActionList",
  "renderDetailsPanel",
  "renderFooterHints",
  "renderRebindModal",
  "renderConflictModal",
  "setSelectedCategory",
  "setSelectedAction",
  "startRebindCapture",
  "applyBinding"
];

const mainSource = await readFile(resolve("src/main.js"), "utf8");
const missing = requiredFunctions.filter((name) => !mainSource.includes(`function ${name}`));
if (missing.length > 0) {
  throw new Error(`Missing required prototype functions: ${missing.join(", ")}`);
}

await rm(resolve("dist"), { recursive: true, force: true });
await mkdir(resolve("dist"), { recursive: true });
await cp(resolve("src"), resolve("dist/src"), { recursive: true });
await cp(resolve("index.html"), resolve("dist/index.html"));
await writeFile(resolve("dist/README.txt"), "Static build for BAR Controller Bindings UI Prototype.\n");

console.log("Build validation passed.");
console.log("Wrote dist/");
