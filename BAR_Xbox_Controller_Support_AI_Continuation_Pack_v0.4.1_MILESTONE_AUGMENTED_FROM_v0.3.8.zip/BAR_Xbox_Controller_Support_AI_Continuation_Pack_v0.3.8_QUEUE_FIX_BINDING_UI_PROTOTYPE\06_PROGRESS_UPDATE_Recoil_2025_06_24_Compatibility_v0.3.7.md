# Recoil 2025.06.24 Compatibility Patch - v0.3.7

**Date:** 2026-05-29

## Summary

The BAR Xbox Controller Support prototype has been validated against upstream RecoilEngine tag `2025.06.24`. This milestone rebases the reviewed PR #2985 controller input Lua API onto the newer RecoilEngine base and publishes a BAR-side v0.3.7 installer that can install the matching compatibility engine release.

Local live testing passed: the updated installer completed successfully, BAR launched, the Xbox controller was detected, controller input worked correctly, all controller tests passed, and no further engine or Lua compatibility issue was observed.

`gui_controller_camera_test.lua` did not need changes for this milestone because the PR #2985 Lua API compatibility layer remained intact.

## Why This Patch Was Needed

The earlier PR #2985 reviewed API test engine was built from commit `fb438d6e2fd1d41e96048ee87ca652c8c4e45cf6`. BAR testing then moved to the newer upstream RecoilEngine tag `2025.06.24`, also referred to as `recoil_2025.06.24`.

The controller backend patch needed to be replayed onto that newer engine base while preserving the reviewed API shape:

- `Spring.GetAvailableControllers()`
- `Spring.GetControllerState(instanceID)`
- `instanceID`
- `deviceID`
- `name`
- `buttons`
- `axes`
- 1-indexed Lua arrays for `buttons` and `axes`

The BAR widget already supports both the reviewed PR #2985 API shape and the older prototype assumptions, so no Lua widget patch was required.

## Recoil Compatibility Branch

```text
Recoil fork: UnderarmCape/controllersupport-RecoilEngine-attempt-01
New upstream target: 2025.06.24
Compatibility branch: controller-api-recoil-2025-06-24-compat
Final workflow/source commit: a0fa874a732efbabc1b656985c048bcc7dcfaaaf
Successful workflow run ID: 26508345543
```

The compatibility branch preserves:

- SDL controller startup scan
- controller hotplug add/remove/remap handling
- Lua polling behavior
- default-off high-frequency `ButtonDown`, `ButtonUp`, and `AxisMotion` logging
- no input-event log spam in normal gameplay

## Recoil Engine Release

```text
Release tag: controller-support-recoil-2025-06-24-compat
Release title: BAR Controller Support Engine - Recoil 2025.06.24 Compatibility Build
Engine asset: recoil_2025.06.24-controller-support-pr2985-win64.zip
Engine asset URL: https://github.com/UnderarmCape/controllersupport-RecoilEngine-attempt-01/releases/download/controller-support-recoil-2025-06-24-compat/recoil_2025.06.24-controller-support-pr2985-win64.zip
Engine asset SHA256: a6a0686270152943b6967b7ade01d379e83dd0c3596a8f9e6a882898a764eb64
```

## Installer Fix

The first v0.3.7 installer failed before downloading/staging because it still hardcoded the older stock BAR engine folder:

```bat
set "ENGINE_SLOT=recoil_2025.06.19"
```

That was wrong for Recoil 2025.06.24 compatibility testing.

The validated installer now:

- auto-detects valid `recoil_*` engine folders under `%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\engine`
- prefers `recoil_2025.06.24` if present
- otherwise selects the newest valid `recoil_*` folder containing `spring.exe`
- recalculates `DST_ENGINE`, `STAGE_ENGINE`, and `ENGINE_BACKUP` from the detected slot
- no longer fails just because `recoil_2025.06.19` is missing
- keeps safe staging and backup behavior
- keeps live console output and log file output

Before replacing the active engine, it verifies the staged engine contains:

- `spring.exe`
- `spring-headless.exe`
- `spring-dedicated.exe`
- `unitsync.dll`
- `SDL2.dll`
- `base\`

Zip-root detection remains robust. The installer searches the extracted folder tree recursively for `spring.exe` and treats the containing folder as the engine root only if the required files are present.

## BAR-Side Release

```text
Release tag: controller-support-v0.3.7-recoil-2025-06-24-compat
Release title: BAR Xbox Controller Support v0.3.7 - Recoil 2025.06.24 Compatibility
Installer: Install_BAR_Controller_Support_v0.3.7_RECOIL_2025_06_24_COMPAT.bat
Continuation pack: BAR_Xbox_Controller_Support_AI_Continuation_Pack_v0.3.7_RECOIL_2025_06_24_COMPAT.zip
```

The release documents that Recoil 2025.06.24 compatibility is supported, the installer pulls the engine from `controller-support-recoil-2025-06-24-compat`, and local live testing passed successfully.

## Validated Local Test Result

Manual live test result reported by the user:

- updated v0.3.7 installer worked perfectly
- BAR launched successfully
- Xbox controller was detected
- controller input worked correctly
- all controller tests passed
- no further engine or Lua compatibility issue was observed

## Current Source-of-Truth Status

- v0.3.6 remains the last broadly stable historical public prototype checkpoint.
- PR #2985 remains the upstream RecoilEngine API adoption path.
- v0.3.7 is the validated Recoil 2025.06.24 compatibility package for local BAR controller testing.
- `gui_controller_camera_test.lua` remains compatible and was not changed for v0.3.7.