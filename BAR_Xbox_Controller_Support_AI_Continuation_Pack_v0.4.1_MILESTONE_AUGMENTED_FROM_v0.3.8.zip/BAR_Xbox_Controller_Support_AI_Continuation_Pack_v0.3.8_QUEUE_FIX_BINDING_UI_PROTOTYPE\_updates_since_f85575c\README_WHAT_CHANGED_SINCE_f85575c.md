# Updates Since v0.3.8 Anchor Commit (f85575c)

This additive update folder contains all the modifications, release assets, installers, and git logs tracking the evolution of the Beyond All Reason (BAR) Xbox Controller Support project from the v0.3.8 Bible release to the current **v0.4.1 Milestone Build**.

---

## 1. Preserving Project History
* **Original Integrity**: This continuation pack preserves the original v0.3.8 Bible ZIP contents exactly. 
* **Zero Modification**: No original files from the v0.3.8 ZIP were modified, renamed, or deleted. They remain fully intact at their original paths to act as a historical and functional baseline.
* **Additive Directory**: All newer documents, code updates, installers, and diffs are organized cleanly inside this `_updates_since_f85575c/` directory to prevent any name collisions.

---

## 2. Milestone Metadata
* **Anchor Commit**: `f85575c` (Release v0.3.7 Recoil 2025.06.24 compatibility installer and docs)
* **Current HEAD Commit**: `3c29c928` (Clarify v0.4.1 engine install procedure)
* **Current Branch**: `controller-support-current-master-engine-shim`

---

## 3. Major Changes Since v0.3.8 Anchor
* **v0.4.1 Presets System**: Added native `Balanced RTS` and `Build-First Commander` button configurations inside the Bindings UI for one-click setup.
* **Split Queue Removal**:
  * **Left Stick Click (L3)**: Deletes the current/next queued command.
  * **Right Stick Click (R3)**: Deletes the last queued command.
  * *Queue removal is fully active even during build placements!*
* **RT Append Queue Modifier**: Activating **RT** simulates the keyboard's **Shift** key, allowing queuing of move, build, or unit commands without interrupting active orders.
* **Do Next / Insert Front Command (RB / Y)**: Prepend urgent commands to the front of the queue.
* **RB Build Radial Fix**: Factory and blueprint radial menus now open correctly from the preset-bound button (**RB** or **Y**).
* **LB Grid & Pattern Controls**:
  * Holding **LB** during placement locks coordinates to the grid.
  * Tapping **LB** during placement cycles through layout patterns.
  * **RB** pattern-cycling has been disabled to prevent accidental command triggers.
* **Append Placements**: Fully enabled `RT + A` and `RT + X` queuing for construction and combat placements.
* **Layer Redesigns**:
  * **Command Layer (Back/View)**: Toggle graphical command overlay and tactical shortcuts.
  * **Group Layer (Start/Menu)**: Manage unit groups with smart auto-grouping behaviors.
* **Same-Type / Future Unit Grouping**: Assigning groups can now mirror same-type units and auto-add future produced units of the same definition.
* **Corrected Installation Documentation**: Rewritten to emphasize that the mod **REQUIRES** the custom controller-enabled engine to function, correcting prior widget-only implications.

---

## 4. Current Known Issue
* **Commander Focus Shortcut**: The `Back/View + A + A` shortcut used to instantly focus and select your Commander unit is currently ignored or unreliable in the gameplay input shim. This is a documented limitation and will be fixed in a future hotfix. All other features on the Command Layer function normally.

---

## 5. Required Install Order
1. **Engine**: Run the custom engine installer `Install_BAR_Controller_Support_v0.3.7_RECOIL_2025_06_24_COMPAT.bat` inside the `installers/required_engine_installer/` directory to download and set up the custom recoil engine.
2. **v0.4.1 Widgets**: Once completed, copy the updated widget files (`gui_controller_camera_test.lua` and `gui_controller_bindings_ui.lua`) from the `current_files/luaui/Widgets/` directory and paste them into your active widgets folder, choosing to replace/overwrite files.
3. **BAR Launcher**: Go to **Settings > Developer**, choose **Beyond All Reason Dev** in the Singleplayer dropdown, and configure your controller presets.

---

## 6. Update Folder Directory Mapping

* **`README_WHAT_CHANGED_SINCE_f85575c.md`**: (This file) Overview of milestone changes and install instructions.
* **`git/`**: Technical delta files tracking git commits, changes, and diffs:
  * `changed_files_name_status_f85575c_to_HEAD.txt`: Staged files name list.
  * `commit_log_f85575c_to_HEAD.txt`: Commit logs from `f85575c` to `HEAD`.
  * `full_diff_f85575c_to_HEAD.diff`: Unabridged repository diff.
  * `widget_diff_f85575c_to_HEAD.diff`: Focused widget diff for widgets folder.
* **`current_files/`**: Contains the latest v0.4.1 widgets.
* **`release_docs/`**: Corrected install guides, checklists, and release notes for the public milestone.
* **`installers/`**: Staged non-admin engine installer and widget-only installer batch scripts.
* **`release_assets/`**: Staged release packages (`BAR_Xbox_Controller_Support_v0.4.1_MILESTONE.zip` and the pre-alpha continuation pack).
