const control = {
  a: { binding: "A", controlId: "a" },
  b: { binding: "B", controlId: "b" },
  x: { binding: "X", controlId: "x" },
  y: { binding: "Y", controlId: "y" },
  lb: { binding: "LB", controlId: "lb" },
  rb: { binding: "RB", controlId: "rb" },
  lt: { binding: "LT", controlId: "lt" },
  rt: { binding: "RT", controlId: "rt" },
  backView: { binding: "Back/View", controlId: "backView" },
  menuStart: { binding: "Menu/Start", controlId: "menuStart" },
  leftStick: { binding: "Left Stick", controlId: "leftStick" },
  leftStickX: { binding: "Left Stick X", controlId: "leftStickX" },
  leftStickY: { binding: "Left Stick Y", controlId: "leftStickY" },
  rightStick: { binding: "Right Stick", controlId: "rightStick" },
  rightStickX: { binding: "Right Stick X", controlId: "rightStickX" },
  rightStickY: { binding: "Right Stick Y", controlId: "rightStickY" },
  dpadUp: { binding: "D-pad Up", controlId: "dpadUp" },
  dpadDown: { binding: "D-pad Down", controlId: "dpadDown" },
  dpadLeft: { binding: "D-pad Left", controlId: "dpadLeft" },
  dpadRight: { binding: "D-pad Right", controlId: "dpadRight" }
};

function action(id, label, input, description, extra = {}) {
  return {
    id,
    action: id,
    label,
    binding: input.binding,
    controlId: input.controlId,
    description,
    ...extra
  };
}

function combo(id, label, binding, controlIds, description, extra = {}) {
  return {
    id,
    action: id,
    label,
    binding,
    controlId: controlIds[controlIds.length - 1],
    controlIds,
    description,
    ...extra
  };
}

export const bindingCategories = [
  {
    id: "core",
    label: "Core",
    actions: [
      action("select", "Select / Confirm", control.a, "Select hovered units, confirm radial choices, and accept primary UI actions."),
      action("cancel", "Cancel / Clear", control.b, "Cancel current modes, close menus, or clear selection in normal play."),
      action("smartAction", "Smart Action", control.x, "Context-sensitive order. Tap for smart action, hold for path or line behavior."),
      action("buildRadial", "Build / Factory Menu", control.y, "Open the build radial for constructors or factory radial for factories."),
      action("queueModifier", "Queue Modifier", control.lt, "Shift-style queue modifier for command confirmation and placement."),
      action("commandLayer", "Command Modifier", control.rt, "Opens the tactical command layer for move, fight, reclaim, repair, and related commands."),
      action("controlGroupModifier", "Control Group Modifier", control.rb, "Hold RB to enter controller control-group mode."),
      action("pitchModifier", "Pitch / Idle Type Modifier", control.lb, "Hold LB to access camera pitch and idle-type modifier behavior.")
    ]
  },
  {
    id: "camera",
    label: "Camera",
    actions: [
      action("cameraPan", "Camera Pan", control.leftStick, "Pan the camera across the battlefield."),
      action("cameraPanX", "Camera Pan X Axis", control.leftStickX, "Horizontal pan input from the left stick."),
      action("cameraPanY", "Camera Pan Y Axis", control.leftStickY, "Vertical pan input from the left stick."),
      action("cameraRotate", "Rotate Camera", control.rightStickX, "Rotate the camera horizontally."),
      action("cameraZoom", "Zoom Camera", control.rightStickY, "Zoom the camera while not using the pitch modifier."),
      action("cameraPitchModifier", "Camera Pitch Modifier", control.lb, "Hold LB to access camera pitch / tilt behavior."),
      combo("cameraPitch", "Camera Pitch / Tilt", "LB + Right Stick Y", ["lb", "rightStick", "rightStickY"], "Hold LB and move Right Stick Y to pitch or tilt the camera."),
      action("cameraBoost", "Camera Speed Boost", control.lt, "Use LT as a camera pan/zoom boost when not confirming commands.")
    ]
  },
  {
    id: "build",
    label: "Build",
    actions: [
      action("buildMenu", "Build / Factory Menu", control.y, "Open constructor build options or factory queue controls."),
      action("radialSelect", "Radial Select", control.a, "Select the highlighted radial item."),
      action("radialCancel", "Radial Cancel", control.b, "Cancel or close the current radial."),
      action("radialQuick", "Radial Quick Place", control.x, "Quick-place a radial item when supported."),
      action("radialClose", "Radial Close", control.y, "Close the current radial."),
      action("radialPrevPage", "Radial Previous Page", control.lb, "Move to the previous radial page or category."),
      action("radialNextPage", "Radial Next Page", control.rb, "Move to the next radial page or category."),
      combo("factoryAddFive", "Factory Add Five", "LT + A", ["lt", "a"], "Add five units from the factory radial."),
      combo("factoryRemoveFive", "Factory Remove Five", "LT + B", ["lt", "b"], "Remove five units from the factory radial.")
    ]
  },
  {
    id: "placement",
    label: "Placement",
    actions: [
      action("place", "Confirm Placement", control.a, "Place the current building and exit placement when appropriate."),
      action("placeStay", "Place and Stay", control.x, "Place the current building and keep placement active when supported."),
      action("cancelPlacement", "Cancel Placement", control.b, "Cancel current build placement."),
      action("rotateBuildingLeft", "Rotate Building Left", control.dpadLeft, "Rotate building facing left."),
      action("rotateBuildingRight", "Rotate Building Right", control.dpadRight, "Rotate building facing right."),
      action("spacingUp", "Increase Spacing", control.dpadUp, "Increase build spacing during placement."),
      action("spacingDown", "Decrease Spacing", control.dpadDown, "Decrease build spacing during placement."),
      action("patternPrev", "Previous Pattern", control.lb, "Cycle to the previous placement pattern."),
      action("patternNext", "Next Pattern", control.rb, "Cycle to the next placement pattern."),
      combo("queuePlacement", "Queue Placement", "LT + A", ["lt", "a"], "Queue placement confirmation like Shift."),
      combo("queueFrontPlacement", "Queue Front Placement", "RT + A", ["rt", "a"], "Use RT during placement when supported to prepend build commands.")
    ]
  },
  {
    id: "tactical",
    label: "Tactical",
    actions: [
      combo("openTactical", "Open Tactical Radial", "RT + Y", ["rt", "y"], "Open contextual tactical commands for selected units."),
      action("tacticalSelect", "Tactical Select", control.a, "Confirm highlighted tactical radial command."),
      action("tacticalCancel", "Tactical Cancel", control.b, "Cancel the tactical radial."),
      action("tacticalClose", "Tactical Close", control.y, "Close the tactical radial."),
      action("commandUp", "Command Guard / Patrol", control.dpadUp, "RT layer D-pad Up command slot."),
      action("commandDown", "Command Reclaim", control.dpadDown, "RT layer D-pad Down command slot."),
      action("commandLeft", "Command Cycle Previous", control.dpadLeft, "RT layer previous command or selection cycle."),
      action("commandRight", "Command Cycle Next", control.dpadRight, "RT layer next command or selection cycle."),
      combo("fightLine", "Fight Line / Attack Move", "RT + X Hold", ["rt", "x"], "Hold smart action in the command layer to start line behavior."),
      combo("stopSelected", "Stop Selected Units", "RT + B", ["rt", "b"], "Stop selected units from the command layer.")
    ]
  },
  {
    id: "queue",
    label: "Queue",
    actions: [
      action(
        "removeQueuedCommand",
        "Remove Queue Item / LT=Last",
        control.backView,
        "Back/View removes the current or next queued unit command. LT + Back/View removes the last queued command. This matches the working v0.3.7 behavior from commit fe61330f8ffc1c08b779a1573f27e445827f1520."
      ),
      combo("removeLastQueuedCommand", "Remove Last Queue Item", "LT + Back/View", ["lt", "backView"], "Remove the last queued command for selected units."),
      action("queueModifierQueue", "Queue Commands", control.lt, "Hold LT while confirming commands to append them instead of replacing the current queue."),
      action("queueFront", "Queue Front Placement", control.rt, "Use RT during placement when supported to prepend build commands.")
    ]
  },
  {
    id: "idle-groups",
    label: "Idle / Groups",
    actions: [
      action("idleBuilder", "Cycle Idle Builder", control.dpadUp, "Cycle toward available idle builders or nearby utility selections."),
      action("idlePrev", "Previous Idle Unit", control.dpadLeft, "Cycle to the previous idle unit."),
      action("idleNext", "Next Idle Unit", control.dpadRight, "Cycle to the next idle unit."),
      combo("idleTypePrev", "Previous Idle Type", "LB + D-pad Left", ["lb", "dpadLeft"], "Cycle to the previous idle unit type group."),
      combo("idleTypeNext", "Next Idle Type", "LB + D-pad Right", ["lb", "dpadRight"], "Cycle to the next idle unit type group."),
      action("groupSlotUp", "Next Group Slot", control.dpadUp, "Move to the next controller control-group slot while RB is held."),
      action("groupSlotDown", "Previous Group Slot", control.dpadDown, "Move to the previous controller control-group slot while RB is held."),
      action("groupRecallOrAssign", "Recall / Assign Group", control.dpadLeft, "Tap to recall. Hold to assign all owned units of the current type while RB is held."),
      action("groupClear", "Clear Group", control.b, "Clear the active controller control-group slot while RB is held."),
      action("controlGroupModifier", "Control Group Modifier", control.rb, "Hold RB to show and use controller control groups.")
    ]
  },
  {
    id: "advanced",
    label: "Advanced",
    actions: [
      action("openBindingsMenu", "Open Bindings Menu", control.menuStart, "Future entry point for this standalone UI once ported back into BAR LuaUI."),
      action("commanderFocusModifier", "Commander Focus Modifier", control.backView, "Back/View combined with double-tap A focuses the Commander in the current widget."),
      combo("debugPanel", "Debug Panel", "Page Up", [], "Keyboard-only debug panel toggle in the current prototype widget.", { controlId: "" }),
      combo("helpOverlay", "Help Overlay", "Page Down", [], "Keyboard-only help overlay toggle in the current prototype widget.", { controlId: "" }),
      combo("settingsMenu", "Controller Settings", "End", [], "Keyboard-only settings UI toggle in the current prototype widget.", { controlId: "" }),
      combo("resetSettings", "Reset Controller Settings", "Home", [], "Keyboard-only reset to controller code defaults.", { controlId: "" })
    ]
  }
];

export const mockKeyboardToController = {
  a: { binding: "A", controlId: "a" },
  b: { binding: "B", controlId: "b" },
  x: { binding: "X", controlId: "x" },
  y: { binding: "Y", controlId: "y" },
  q: { binding: "LB", controlId: "lb" },
  e: { binding: "RB", controlId: "rb" },
  z: { binding: "LT", controlId: "lt" },
  c: { binding: "RT", controlId: "rt" },
  Backspace: { binding: "Back/View", controlId: "backView" },
  m: { binding: "Menu/Start", controlId: "menuStart" },
  ArrowUp: { binding: "D-pad Up", controlId: "dpadUp" },
  ArrowDown: { binding: "D-pad Down", controlId: "dpadDown" },
  ArrowLeft: { binding: "D-pad Left", controlId: "dpadLeft" },
  ArrowRight: { binding: "D-pad Right", controlId: "dpadRight" }
};
