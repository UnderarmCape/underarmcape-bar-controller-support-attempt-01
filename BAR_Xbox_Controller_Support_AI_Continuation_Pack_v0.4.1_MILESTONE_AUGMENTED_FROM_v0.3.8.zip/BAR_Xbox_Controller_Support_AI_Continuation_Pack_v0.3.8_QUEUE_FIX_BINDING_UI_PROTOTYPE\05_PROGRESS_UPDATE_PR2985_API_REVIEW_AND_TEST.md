# PR #2985 Reviewed Controller API Test Update - fb438d6

Date: 2026-05-26

## Upstream Recoil PR

PR:
https://github.com/beyond-all-reason/RecoilEngine/pull/2985

Title:
`Gamepad support: add SDL controller input polling API for LuaUI`

Purpose:
Provide an engine-side SDL controller input polling API for LuaUI.

The PR adds:

- SDL controller/gamepad detection.
- Startup controller scan.
- Controller add/remove/remap handling.
- Controller state tracking.
- `Spring.GetAvailableControllers()`.
- `Spring.GetControllerState(instanceID)`.
- Default-off gating for `ButtonDown`, `ButtonUp`, and `AxisMotion` log spam.

## Recoil Fork And Commits

Fork:
`UnderarmCape/controllersupport-RecoilEngine-attempt-01`

Main PR branch:
`pr/controller-input-lua-api`

Important commits:

- `369b865ca3`: initial clean PR branch commit.
- `f6061febba`: addressed controller API review feedback.
- `8e97f5424997af957f1851eb1d4a498c243bd75a`: docs-only Lua API return documentation cleanup.

## Sprunk Review Feedback Addressed

- Changed `Id` naming to `ID` where relevant.
- Made Lua `buttons` and `axes` arrays 1-indexed.
- Removed the unhelpful "keyed by SDL id" wording.
- Simplified `FreeInstance()` to take no parameter.
- Changed controller-state lookup to `std::optional`.
- Replaced magic `16` and `32` array sizes with `SDL_CONTROLLER_AXIS_MAX` and `SDL_CONTROLLER_BUTTON_MAX`.
- Refactored duplicated state/snapshot structs into public `ControllerState` plus private `TrackedControllerState`.
- Updated new file headers to refer to Recoil.
- Removed the whitespace-only `MouseHandler.cpp` change.
- Clarified Lua API return docs without inline table definition syntax.

## Reviewed Lua API Shape

- `Spring.GetAvailableControllers()` returns a 1-indexed array of controller info tables with `instanceID`, `deviceID`, and `name`.
- `Spring.GetControllerState(instanceID)` returns a controller state table with `instanceID`, `name`, `buttons`, and `axes`.
- `buttons` and `axes` are 1-indexed Lua arrays in SDL controller enum order.

## Reviewed API Test Engine

Engine commit:
`fb438d6e2fd1d41e96048ee87ca652c8c4e45cf6`

Artifact branch:
`build/pr-controller-input-lua-api-artifact`

Release:
https://github.com/UnderarmCape/controllersupport-RecoilEngine-attempt-01/releases/tag/controller-engine-pr2985-review-api-test-fb438d6

Engine ZIP:
`recoil-controller-amd64-windows-fb438d6e2fd1d41e96048ee87ca652c8c4e45cf6.zip`

Engine ZIP URL:
https://github.com/UnderarmCape/controllersupport-RecoilEngine-attempt-01/releases/download/controller-engine-pr2985-review-api-test-fb438d6/recoil-controller-amd64-windows-fb438d6e2fd1d41e96048ee87ca652c8c4e45cf6.zip

Validated status:

- Compiled successfully through GitHub Actions.
- Installed successfully.
- Launched BAR successfully.
- Detected the Xbox controller.
- Preserved SDL startup scan.
- Preserved controller add/remove/reconnect handling.
- Preserved default-off `ButtonDown` / `ButtonUp` / `AxisMotion` log-spam gating.
- No new engine behavior issue found.

## BAR Widget Compatibility Fix

The BAR LuaUI widget initially loaded but live controller input did not work against the reviewed PR API. It showed the API and controller name, while axes, triggers, button state, and controller-input mode remained inactive.

Root cause:
The widget was still polling older field/index assumptions.

Fix in `gui_controller_camera_test.lua`:

- Controller discovery resolves `controller.instanceID or controller.instanceId`.
- State polling uses the resolved instance ID.
- `GetAxis` reads reviewed 1-based arrays with fallback to older indexing.
- `GetButton` reads reviewed 1-based arrays with fallback to older indexing.
- Raw API telemetry was added: `Raw state`, `Raw axes`, and `Raw buttons`.
- Touched Unicode collapse glyphs were replaced with ASCII `[-]` / `[+]`.
- The widget file is valid UTF-8 without BOM.
- `luac -p` passed.

Status:
After this widget patch, controller input worked again in-game with the reviewed PR API engine build.

## BAR-Side PR2985 API Test Release

Tag:
`controller-support-pr2985-api-test-fb438d6`

Title:
`BAR Controller Support PR #2985 API Test - fb438d6`

Purpose:
BAR-side test release for validating the reviewed Recoil PR #2985 controller API in-game.

Expected assets:

- `gui_controller_camera_test.lua`
- `Install_BAR_Controller_Support_PR2985_API_TEST_fb438d6_SAFE_LIVE.bat`
- `BAR_Xbox_Controller_Support_AI_Continuation_Pack_PR2985_API_TEST_fb438d6.zip`

## Camera And Log Status

Camera snapping remains config-only:

```text
CamSpringLockCardinalDirections = 0
```

No Recoil camera patch is needed.

Input log spam remains fixed: `ButtonDown`, `ButtonUp`, and `AxisMotion` logs remain behind default-off `CONTROLLER_INPUT_LOG_EVENTS`.

## Current Source-Of-Truth Status

- v0.3.6 remains the last stable public prototype release.
- PR #2985 is the upstream RecoilEngine PR for engine-side controller API adoption.
- `fb438d6` is the reviewed API test engine build, not the stable public release.
- The BAR widget now supports both older v0.3.6-style assumptions and the reviewed PR API shape.
- Next major work is waiting for maintainer feedback on PR #2985 and preparing BAR-side widget work after or if the engine API path is accepted.
