import { createReadStream, existsSync, watch } from "node:fs";
import { stat } from "node:fs/promises";
import { createServer } from "node:http";
import { extname, join, normalize, resolve } from "node:path";

const root = resolve(process.argv.includes("--dist") ? "dist" : ".");
const port = Number(process.env.PORT || 5173);
const clients = new Set();

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

function isInsideRoot(filePath) {
  const relative = normalize(filePath).replace(normalize(root), "");
  return !relative.startsWith("..");
}

function sendReload() {
  for (const client of clients) {
    client.write("event: reload\ndata: reload\n\n");
  }
}

function liveReloadSnippet() {
  return `
<script>
  new EventSource('/__reload').addEventListener('reload', () => location.reload());
</script>`;
}

async function serveFile(request, response) {
  const url = new URL(request.url, "http://127.0.0.1");
  let filePath = decodeURIComponent(url.pathname);
  if (filePath === "/") {
    filePath = "index.html";
  } else {
    filePath = filePath.replace(/^\/+/, "");
  }
  filePath = resolve(join(root, filePath));
  if (!isInsideRoot(filePath)) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }
  if (!existsSync(filePath) || !(await stat(filePath)).isFile()) {
    response.writeHead(404);
    response.end("Not found");
    return;
  }

  const ext = extname(filePath);
  response.setHeader("Content-Type", mimeTypes[ext] || "application/octet-stream");
  if (ext === ".html" && !process.argv.includes("--dist")) {
    let html = "";
    createReadStream(filePath, "utf8")
      .on("data", (chunk) => { html += chunk; })
      .on("end", () => response.end(html.replace("</body>", `${liveReloadSnippet()}</body>`)));
    return;
  }
  createReadStream(filePath).pipe(response);
}

const server = createServer((request, response) => {
  if (request.url === "/__reload") {
    response.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive"
    });
    response.write("\n");
    clients.add(response);
    request.on("close", () => clients.delete(response));
    return;
  }
  serveFile(request, response).catch((error) => {
    response.writeHead(500);
    response.end(String(error));
  });
});

if (!process.argv.includes("--dist")) {
  watch(resolve("index.html"), sendReload);
  watch(resolve("src"), { recursive: true }, sendReload);
}

server.listen(port, "127.0.0.1", () => {
  console.log(`BAR controller bindings prototype: http://127.0.0.1:${port}/`);
});
