READ ME FIRST — BAR XBOX CONTROLLER SUPPORT AI CONTINUATION PACK

Purpose of this ZIP:
This ZIP is a ready-to-upload context packet for continuing the Beyond All Reason Xbox Controller Support project in a fresh ChatGPT/Codex/Antigravity chat. It is meant to reduce repeated explanation when the AI has no memory of the project.

Source priority:
1. Read 01_PRIMARY_SOURCE_OF_TRUTH_Project_Bible.md first. It is the main project handoff and primary source of truth.
2. Treat final standalone code shown inside the project bible as authoritative unless newer final source files are separately uploaded by the user.
3. Read 04_PROGRESS_UPDATE_v0.3.6_Detection_Restored_LogSpam_Fixed.md for the latest validated state after the original bible.
4. Read 02_SUPPORTING_WORKLOG_Antigravity_Recovery_Walkthrough.md and 03_SUPPORTING_WORKLOG_Codex_Widget_Engine_Worklog.md only as supporting historical context.
5. Do not treat risky rewrites, discarded experiments, or temporary agent changes from the worklogs as final code unless they match the project bible or a final standalone source file.
6. If there is a conflict, prefer the project bible over the worklogs.

LATEST API TEST UPDATE -- PR #2985 REVIEWED API / fb438d6

Read 05_PROGRESS_UPDATE_PR2985_API_REVIEW_AND_TEST.md after the primary bible and v0.3.6 progress update.

The upstream Recoil controller API adoption PR is:
https://github.com/beyond-all-reason/RecoilEngine/pull/2985

The reviewed API test engine is:
fb438d6e2fd1d41e96048ee87ca652c8c4e45cf6

Matching Recoil test release:
https://github.com/UnderarmCape/controllersupport-RecoilEngine-attempt-01/releases/tag/controller-engine-pr2985-review-api-test-fb438d6

Matching BAR test release tag:
controller-support-pr2985-api-test-fb438d6

Important current status:
- v0.3.6 remains the last stable public prototype release and its history is preserved below.
- PR #2985 is the upstream RecoilEngine API adoption path.
- fb438d6 is a reviewed-API test engine build, not the stable public release.
- The reviewed API uses instanceID/deviceID and 1-indexed Lua buttons/axes arrays.
- The BAR widget now supports both the reviewed API shape and older v0.3.6-style assumptions.
- Live controller input was restored in-game after updating the widget compatibility accessors.
- Camera cardinal snapping remains fixed by config with CamSpringLockCardinalDirections = 0.
- ButtonDown/ButtonUp/AxisMotion event logging remains gated off by default in the engine.

New release/test assets in this pack:
- 05_PROGRESS_UPDATE_PR2985_API_REVIEW_AND_TEST.md
- gui_controller_camera_test.lua
- Install_BAR_Controller_Support_PR2985_API_TEST_fb438d6_SAFE_LIVE.bat



LATEST UPDATE — v0.3.6 VALIDATED GOOD

As of 2026-05-25, the current good public test release is:

controller-support-v0.3.6-detection-restored-logspam-fixed

Release URL:
https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01/releases/tag/controller-support-v0.3.6-detection-restored-logspam-fixed

Important status:
- v0.3.6 is installed and validated working.
- Recoil engine version in the test log: a76a36b research/controller-api-investigation.
- Controller detection is restored.
- Xbox controller input works again.
- ButtonDown/ButtonUp/AxisMotion log spam is gated behind CONTROLLER_INPUT_LOG_EVENTS and is not present in normal logs.
- Camera snapping near 0/90/180/270/360 degrees is resolved through config, not engine code.
- The active config line is CamSpringLockCardinalDirections = 0 in %LOCALAPPDATA%\Programs\Beyond-All-Reason\data\springsettings.cfg.

v0.3.5 note:
- v0.3.5 should be treated as superseded/bad because it installed and launched but regressed controller startup detection.

Additional file in this updated pack:
- 04_PROGRESS_UPDATE_v0.3.6_Detection_Restored_LogSpam_Fixed.md
- Install_BAR_Controller_Support_v0.3.6_SAFE_LIVE.bat

Project summary:
This project is a two-part Xbox controller support prototype for Beyond All Reason.

Part 1 — Recoil Engine backend:
- Adds SDL joystick/gamecontroller initialization.
- Detects Xbox controllers.
- Handles USB/Bluetooth connection and hotplug/reconnect behavior.
- Tracks button and axis state.
- Exposes controller state to Lua through polling APIs:
  - Spring.GetAvailableControllers()
  - Spring.GetControllerState(instanceId)

Part 2 — BAR LuaUI widget:
- The main widget is gui_controller_camera_test.lua.
- It polls the Recoil controller API.
- It maps Xbox controller inputs into BAR gameplay behavior.
- It handles camera movement, virtual reticle targeting, A-button selection, debug UI, and experimental command/build/menu behavior where present in the final code.

Critical distinction:
The current Recoil implementation exposes controller state through polling-style Lua read functions. It does not currently provide immediate Lua call-ins such as ControllerButtonDown or ControllerAxisMotion.

Project status:
This is a working, end-to-end playable prototype. It is AI-assisted early-development code. It is not official BAR support, not official Recoil support, and not production-ready. Future work should focus on review, cleanup, maintainability, and safe upstream adoption.

Known important warnings:
- Avoid reintroducing old risky rewrite states from the worklogs.
- Reduce or remove controller input log spam before further testing.
- Be careful with common/constants.lua. Earlier work had constants-file issues; later recovery work protected this file.
- Check Lua syntax with: luac -p luaui/Widgets/gui_controller_camera_test.lua
- Check whitespace/diff issues with: git diff --check
- Before modifying code, identify the authoritative source file and explain the likely impact.

Recommended first action for a fresh AI chat:
Summarize the project from 01_PRIMARY_SOURCE_OF_TRUTH_Project_Bible.md, then ask the user what specific task to do next. Do not rewrite code until the task is clear.


Camera snapping / 90-degree magnetization status:
Resolved by config. This was not caused by the controller mod. It is default Recoil Spring camera behavior controlled by CamSpringLockCardinalDirections. Set CamSpringLockCardinalDirections = 0 in %LOCALAPPDATA%\Programs\Beyond-All-Reason\data\springsettings.cfg for smooth controller and mouse/keyboard camera rotation. Do not patch gui_controller_camera_test.lua or Recoil camera source first for this issue.
