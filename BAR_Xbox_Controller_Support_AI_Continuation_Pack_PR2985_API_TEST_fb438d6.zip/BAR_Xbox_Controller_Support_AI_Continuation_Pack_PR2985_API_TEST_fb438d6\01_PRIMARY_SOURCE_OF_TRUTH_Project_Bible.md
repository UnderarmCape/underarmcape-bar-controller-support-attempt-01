# Beyond All Reason Xbox Controller Support Project Bible

**Document purpose:** This is the master Markdown bible for the Beyond All Reason Xbox Controller Support prototype. It consolidates the handoff document, standalone final source files, installer notes, and development chat archive index into one developer-readable reference.

**Generated from uploaded archive:** `batch upload.zip`

**Authority rule used in this bible:**

1. `BAR_Xbox_Controller_Support_Developer_Handoff_Draft_With_Install.md` is the main narrative base.
2. The standalone source files in the archive are treated as final code authority where present.
3. Raw `BAR-CS-*.md` chat files are treated as historical context unless they contain unique information not represented in the final handoff or standalone files.
4. This project is described as an AI-assisted working prototype, not official BAR support and not production-ready upstream code.



---

## Current Upstream API Test Update -- Recoil PR #2985 / fb438d6

**Date:** 2026-05-26

This update is a reviewed API compatibility test layered on top of the v0.3.6 stable prototype history. It does not replace or remove the validated v0.3.6 release record below.

**Upstream Recoil PR:**

```text
https://github.com/beyond-all-reason/RecoilEngine/pull/2985
Gamepad support: add SDL controller input polling API for LuaUI
```

The PR provides the engine-side SDL controller polling API for LuaUI: controller discovery, startup scan, add/remove/remap handling, state tracking, `Spring.GetAvailableControllers()`, `Spring.GetControllerState(instanceID)`, and default-off gating for high-frequency `ButtonDown`, `ButtonUp`, and `AxisMotion` logs.

**Recoil fork and PR commits:**

```text
Repository: UnderarmCape/controllersupport-RecoilEngine-attempt-01
Branch: pr/controller-input-lua-api
369b865ca3  initial clean PR branch commit
f6061febba  addressed controller API review feedback
8e97f5424997af957f1851eb1d4a498c243bd75a  docs-only Lua API return documentation cleanup
```

Sprunk's review feedback addressed the `ID` naming, 1-indexed Lua arrays, documentation wording, no-argument `FreeInstance()`, `std::optional` state lookup, SDL array-size constants, tracked/public state structure, Recoil file headers, and the incidental `MouseHandler.cpp` whitespace change.

**Reviewed Lua API shape:**

- `Spring.GetAvailableControllers()` returns a 1-indexed array of controller info tables with `instanceID`, `deviceID`, and `name`.
- `Spring.GetControllerState(instanceID)` returns a controller state table with `instanceID`, `name`, `buttons`, and `axes`.
- `buttons` and `axes` are 1-indexed Lua arrays in SDL controller enum order.

**Reviewed API test engine:**

```text
Commit: fb438d6e2fd1d41e96048ee87ca652c8c4e45cf6
Branch: build/pr-controller-input-lua-api-artifact
Release: https://github.com/UnderarmCape/controllersupport-RecoilEngine-attempt-01/releases/tag/controller-engine-pr2985-review-api-test-fb438d6
```

This build compiled through GitHub Actions, installed successfully, launched BAR, detected the Xbox controller, preserved the startup scan and reconnect path, and retained default-off input-event log gating.

**BAR widget compatibility fix:**

The BAR widget initially loaded against the reviewed engine but did not receive usable live input because it continued polling older field/index assumptions. `gui_controller_camera_test.lua` was updated to resolve `controller.instanceID or controller.instanceId`, poll using that resolved ID, read reviewed 1-indexed axes/buttons with legacy fallback, and display raw state/axis/button telemetry. Touched collapse markers are ASCII `[-]` / `[+]`; the file validates as UTF-8 without BOM and passes `luac -p`.

After this widget update, controller input worked again in-game with the reviewed PR API engine.

**BAR test release:**

```text
Tag: controller-support-pr2985-api-test-fb438d6
Title: BAR Controller Support PR #2985 API Test - fb438d6
Assets: gui_controller_camera_test.lua
        Install_BAR_Controller_Support_PR2985_API_TEST_fb438d6_SAFE_LIVE.bat
        BAR_Xbox_Controller_Support_AI_Continuation_Pack_PR2985_API_TEST_fb438d6.zip
```

Camera snapping remains a config-only fix through `CamSpringLockCardinalDirections = 0`; no Recoil camera patch is needed. v0.3.6 remains the last stable public prototype release, while PR #2985 / fb438d6 is the current upstream API compatibility test path.

See `05_PROGRESS_UPDATE_PR2985_API_REVIEW_AND_TEST.md` for a compact continuation-ready record of this milestone.

---

## Latest Validated Update — v0.3.6 Detection Restored + Log-Spam Fixed

**Date:** 2026-05-25

**Current good public test release:**

```text
controller-support-v0.3.6-detection-restored-logspam-fixed
```

**Release URL:**

```text
https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01/releases/tag/controller-support-v0.3.6-detection-restored-logspam-fixed
```

**Installer:**

```text
Install_BAR_Controller_Support_v0.3.6_SAFE_LIVE.bat
```

**Engine artifact:**

```text
recoil-controller-amd64-windows-a76a36b9b18910f225a9cb8a4c42f920e14b33de.zip
```

**Engine source commit:**

```text
controllersupport-RecoilEngine-attempt-01
research/controller-api-investigation @ a76a36b9b18910f225a9cb8a4c42f920e14b33de
```

### What changed after the original bible

The original bible identified two immediate cleanup targets: controller input log spam and camera 90-degree/cardinal snapping. Both have now been resolved for local/public testing.

1. **Controller input log spam fixed:** `ButtonDown`, `ButtonUp`, and `AxisMotion` lifecycle-event spam is gated behind the default-off compile-time flag `CONTROLLER_INPUT_LOG_EVENTS`. Button and axis state updates remain unconditional.
2. **Controller startup detection restored:** v0.3.5 accidentally regressed startup detection by missing the final Patch 4 SDL startup scan path. v0.3.6 restores `SDL_InitSubSystem`, startup joystick count logging, `ScanExistingControllers()`, and existing-controller opening through `HandleDeviceAdded()`.
3. **Camera snapping resolved by config:** no Recoil camera engine patch was needed. Setting `CamSpringLockCardinalDirections = 0` in `springsettings.cfg` removes the default Spring camera cardinal-direction lock for smoother mouse/keyboard and controller rotation.
4. **Installer updated:** the v0.3.6 installer downloads the v0.3.6 engine artifact and applies `CamSpringLockCardinalDirections = 0`.

### v0.3.5 regression note

Do not treat v0.3.5 as the current working release. It installed and launched, and it contained the input-event log gate, but it lost the Patch 4 startup detection path. The test log for v0.3.5 showed only:

```text
[ControllerInput] Initialized SDL controller input handler
```

and did not show SDL subsystem initialization, joystick count, startup scan, or controller connection. v0.3.6 supersedes it.

### v0.3.6 validation log summary

The v0.3.6 test log confirmed the active engine and camera config:

```text
Spring Engine Version: a76a36b research/controller-api-investigation
CamSpringLockCardinalDirections = 0
```

It also confirmed restored controller detection:

```text
[ControllerInput] SDL joystick/gamecontroller subsystem initialized
[ControllerInput] SDL_NumJoysticks at init: 3
[ControllerInput] Scanning existing SDL joysticks: count=3
[ControllerInput] Controller connected: deviceId=0 instanceId=0 name=Controller (Xbox One For Windows)
```

The same log did not show the previous high-frequency `ButtonDown`, `ButtonUp`, or `AxisMotion` spam.

---

## 1. Executive Summary

This project is a two-part Xbox controller support prototype for **Beyond All Reason**.

Part one is a modified **Recoil Engine controller backend**. It initializes SDL joystick/gamecontroller support, scans connected controllers, handles SDL controller events, tracks controller state, and exposes controller state to Lua.

Part two is a **BAR LuaUI controller widget**, centered on `gui_controller_camera_test.lua`. That widget polls the Recoil controller API and turns controller state into BAR gameplay behavior, including camera movement, reticle targeting, selection, command experiments, build/menu experiments, debug UI, and controller-focused UX.

The prototype is best described as **working, end-to-end, playable, and early development**. It should not be described as official BAR support, maintainer-approved support, or production-ready Recoil code. It needs review by experienced Recoil, BAR LuaUI, C++, and RTS UX developers before any upstream adoption.

---

## 2. Current Project Status

### Confirmed or strongly documented working features

The uploaded handoff and standalone files support the following project status:

- Xbox controller detection through Recoil.
- USB-C Xbox controller connection support.
- Bluetooth Xbox controller connection support.
- SDL joystick/gamecontroller subsystem initialization in `CControllerInput`.
- Startup scanning of existing SDL joystick/gamecontroller devices.
- SDL controller hotplug/reconnect event handling.
- SDL controller button and axis state tracking.
- Lua polling API exposure through `Spring.GetAvailableControllers()` and `Spring.GetControllerState(instanceId)`.
- BAR LuaUI controller polling through `gui_controller_camera_test.lua`.
- Left-stick camera panning.
- Right-stick camera rotation/zoom/pitch behavior.
- Left trigger fast camera/boost behavior.
- Virtual center reticle and reticle world targeting.
- A-button controller reticle selection and area-selection behavior.
- Movable/resizable debug panel and controller debug summaries.
- Controller settings/tuning UI hooks.
- Build menu, tactical menu, placement, drag-command, factory queue, control group, idle unit, bookmark, and visual feedback systems in the standalone Lua widget.

### Experimental or review-needed features

The following areas are present or discussed but should be treated as prototype quality:

- Radial build menu and build placement flows.
- Tactical command menu and command-layer behavior.
- Factory queue/progress display behavior.
- Drag commands, build grids, line commands, and area commands.
- Custom controller rebinding/settings UI.
- Multiplayer safety and widget architecture.
- Controller lifecycle ownership in `CMouseHandler::InitStatic()` and `KillStatic()`.
- SDL cleanup, remap, disconnect, and edge-case handling.
- Camera snapping / 90-degree magnetization: resolved by setting `CamSpringLockCardinalDirections = 0` in `springsettings.cfg`.
- Log spam from `ButtonDown`, `ButtonUp`, and especially `AxisMotion` logging: resolved in v0.3.6 by default-off `CONTROLLER_INPUT_LOG_EVENTS` gating.
- v0.3.5 controller detection regression: resolved in v0.3.6 by restoring Patch 4 `SDL_InitSubSystem` and `ScanExistingControllers()` startup path.

---

## 3. Source of Truth

### Main narrative base

`BAR_Xbox_Controller_Support_Developer_Handoff_Draft_With_Install.md`

This file is preserved later in this bible as the verbatim original handoff. It is also summarized and reorganized in the main sections of this bible.

### Final standalone source/code authority

The uploaded archive contains these standalone files and they are treated as the final source authority where they conflict with older chat history:

- `ControllerInput.cpp`
- `ControllerInput.h`
- `CMakeLists.txt`
- `MouseHandler.cpp`
- `LuaUnsyncedRead.cpp`
- `LuaUnsyncedRead.h`
- `gui_controller_camera_test.lua`
- `Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat`

### Recoil Engine side

Known from the handoff:

```text
Repository: UnderarmCape/controllersupport-RecoilEngine-attempt-01
Verified engine commit: d5c8a21e2704a4dd16c1d0e3e9abe7527dd5f5d5
Commit title: Include SDL init header for controller subsystem
Known milestone release: controller-detection-v0.1
Engine artifact: recoil-controller-amd64-windows-d5c8a21e2704a4dd16c1d0e3e9abe7527dd5f5d5.zip
```

### BAR LuaUI side

Known from the handoff:

```text
Repository: UnderarmCape/underarmcape-bar-controller-support-attempt-01
Branch: controller-support-current-master-engine-shim
Main widget file: luaui/Widgets/gui_controller_camera_test.lua
```

### Installer

```text
Installer file: Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat
Target BAR install path: %LOCALAPPDATA%\Programs\Beyond-All-Reason
Target engine slot: data\engine
ecoil_2025.06.19
```

---

## 4. Architecture Overview

### A. Recoil Engine backend

The Recoil Engine side owns the hardware/input foundation:

- Initialize `SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER`.
- Enable SDL controller and joystick event state.
- Register an SDL event handler through Recoil `InputHandler`.
- Scan existing joysticks/controllers on startup.
- Open SDL game controllers.
- Store controller state by SDL joystick instance ID.
- Update button and axis arrays when SDL events arrive.
- Expose controller list and controller state snapshots through Lua read functions.

### B. BAR LuaUI widget

The BAR LuaUI side owns BAR-specific gameplay meaning:

- Poll `Spring.GetAvailableControllers()`.
- Poll `Spring.GetControllerState(instanceId)`.
- Map SDL button/axis IDs to Xbox-style names.
- Apply deadzones, curves, trigger normalization, and smoothing.
- Drive camera pan, zoom, rotation, and pitch.
- Maintain a virtual reticle and world target.
- Handle selection, area selection, smart actions, build menu, tactical menu, placement, control groups, idle cycling, and debug feedback.

### Event/data flow

```text
SDL controller event
  -> Recoil InputHandler
  -> CControllerInput::HandleSDLControllerEvent
  -> controllersByInstanceId state update
  -> CControllerInput::ControllerStateSnapshot
  -> LuaUnsyncedRead
  -> Spring.GetAvailableControllers / Spring.GetControllerState
  -> gui_controller_camera_test.lua
  -> BAR gameplay behavior
```

### Polling vs event call-ins

The current implementation is a **polling API**. Lua asks the engine for controller state each frame. It does **not** currently expose immediate Lua call-ins such as `ControllerButtonDown` or `ControllerAxisMotion`.

---

## 5. File-by-File Recoil Engine Modification Bible

### 5.1 `rts/System/Input/ControllerInput.h`

**Standalone final file present:** yes, `ControllerInput.h`.

This new header defines the controller input singleton, state snapshot structure, controller state tracking structure, SDL event handling entry point, and helper methods for device add/remove/remap/button/axis events.

Primary additions:

- `CControllerInput` class.
- `ControllerStateSnapshot` public struct for safe Lua-facing read snapshots.
- `GetAvailableControllers()`.
- `GetControllerState(int instanceId, ControllerStateSnapshot& state)`.
- `HandleSDLControllerEvent(const SDL_Event& event)`.
- global `extern CControllerInput* controllerInput`.

The complete final file is preserved in the appendix.

### 5.2 `rts/System/Input/ControllerInput.cpp`

**Standalone final file present:** yes, `ControllerInput.cpp`.

This new implementation file owns the SDL controller backend. Its key Patch 4 behavior is the constructor initialization of SDL joystick/gamecontroller subsystems before device scanning:

````cpp
CControllerInput::CControllerInput()
{
	if (SDL_InitSubSystem(SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER) != 0) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to initialize SDL joystick/gamecontroller subsystem: %s", SDL_GetError());
	} else {
		LOG_L(L_INFO, "[ControllerInput] SDL joystick/gamecontroller subsystem initialized");
	}

	SDL_GameControllerEventState(SDL_ENABLE);
	SDL_JoystickEventState(SDL_ENABLE);

	inputCon = input.AddHandler([this](const SDL_Event& event) {
		return this->HandleSDLControllerEvent(event);
	});

	LOG_L(L_INFO, "[ControllerInput] SDL_NumJoysticks at init: %d", SDL_NumJoysticks());
	ScanExistingControllers();

	LOG_L(L_INFO, "[ControllerInput] Initialized SDL controller input handler");
````


The file also:

- Registers an input handler with Recoil `input.AddHandler`.
- Calls `ScanExistingControllers()` at startup.
- Handles `SDL_CONTROLLERDEVICEADDED`, `SDL_CONTROLLERDEVICEREMOVED`, `SDL_CONTROLLERDEVICEREMAPPED`, `SDL_CONTROLLERBUTTONDOWN`, `SDL_CONTROLLERBUTTONUP`, and `SDL_CONTROLLERAXISMOTION`.
- Stores state in `controllersByInstanceId`.
- Closes open SDL game controllers during destruction/removal.
- Provides no-op headless implementations under `#else`.

The complete final file is preserved in the appendix.

### 5.3 `rts/System/CMakeLists.txt`

**Standalone final file present:** yes, `CMakeLists.txt`.

The controller backend is compiled into the engine by adding `Input/ControllerInput.cpp` to the system common source list:

````cmake

if (TRACY_PROFILE_MEMORY)
	set(memoryProfileSource "${CMAKE_CURRENT_SOURCE_DIR}/TraceMemory.cpp")
endif()

# This list was created using this *nix shell command:
# > find . -name "*.cpp" -or -name "*.c" | sort
# Then Sound/ stuff was removed, because it is now a separate static lib.

make_global_var(sources_engine_System_common
		"${CMAKE_CURRENT_SOURCE_DIR}/AABB.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/AIScriptHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Color.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigLocater.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigSource.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigVariable.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/CRC.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/EventClient.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/EventHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/GlobalConfig.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Info.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/ControllerInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/InputHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/KeyInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/MouseInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/CregLoadSaveHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/Demo.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/DemoReader.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/DemoRecorder.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/LoadSaveHandler.cpp"
````


The complete uploaded `CMakeLists.txt` is preserved in the appendix.

### 5.4 `rts/Game/UI/MouseHandler.cpp`

**Standalone final file present:** yes, `MouseHandler.cpp`.

This file initializes and frees the controller input singleton alongside mouse input. The include addition appears near the top of the file:

````cpp
 /* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#include "MouseHandler.h"

#include "CommandColors.h"
#include "System/Input/ControllerInput.h"
#include "InputReceiver.h"
#include "GuiHandler.h"
````


The static lifecycle integration appears here:

````cpp

void CMouseHandler::InitStatic()
{
	RECOIL_DETAILED_TRACY_ZONE;
	assert(mouse == nullptr);
	assert(mouseInput == nullptr);
	assert(controllerInput == nullptr);

	mouseInput = IMouseInput::GetInstance(configHandler->GetBool("MouseRelativeModeWarp"));
	controllerInput = CControllerInput::GetInstance();
	mouse = new CMouseHandler();
}
void CMouseHandler::KillStatic()
{
	RECOIL_DETAILED_TRACY_ZONE;
	spring::SafeDelete(mouse);
	CControllerInput::FreeInstance(controllerInput);
	IMouseInput::FreeInstance(mouseInput);
}
````


This is functional but review-needed. A future Recoil maintainer may prefer controller lifecycle ownership in a broader input manager rather than `CMouseHandler`.

The complete uploaded `MouseHandler.cpp` is preserved in the appendix.

### 5.5 `rts/Lua/LuaUnsyncedRead.h`

**Standalone final file present:** yes, `LuaUnsyncedRead.h`.

This header declares the two new Lua read functions:

````cpp
		static int GetGameSpeed(lua_State* L);
		static int GetGameState(lua_State* L);

		static int GetMouseButtonsPressed(lua_State* L);
		static int GetMouseState(lua_State* L);
		static int GetMouseCursor(lua_State* L);
		static int GetMouseStartPosition(lua_State* L);
		static int GetAvailableControllers(lua_State* L);
		static int GetControllerState(lua_State* L);

		static int GetKeyFromScanSymbol(lua_State* L);
		static int GetKeyState(lua_State* L);
		static int GetModKeyState(lua_State* L);
		static int GetPressedKeys(lua_State* L);
````


The complete uploaded `LuaUnsyncedRead.h` is preserved in the appendix.

### 5.6 `rts/Lua/LuaUnsyncedRead.cpp`

**Standalone final file present:** yes, `LuaUnsyncedRead.cpp`.

This file includes the controller input header:

````cpp
#include "Game/UI/Groups/Group.h"
#include "Game/UI/Groups/GroupHandler.h"
#include "Net/Protocol/NetProtocol.h" // NETMSG_*
#include "System/TimeProfiler.h"
#include "System/Config/ConfigHandler.h"
#include "System/Config/ConfigVariable.h"
#include "System/Input/ControllerInput.h"
#include "System/Input/KeyInput.h"
#include "System/LoadSave/DemoReader.h"
#include "System/Log/DefaultFilter.h"
````


It registers the two Lua functions with the unsynced read API:

````cpp
	REGISTER_LUA_CFUNC(GetBuildSpacing);
	REGISTER_LUA_CFUNC(GetGatherMode);
	REGISTER_LUA_CFUNC(GetActivePage);

	REGISTER_LUA_CFUNC(GetMouseButtonsPressed);
	REGISTER_LUA_CFUNC(GetMouseState);
	REGISTER_LUA_CFUNC(GetMouseCursor);
	REGISTER_LUA_CFUNC(GetMouseStartPosition);
	REGISTER_LUA_CFUNC(GetAvailableControllers);
	REGISTER_LUA_CFUNC(GetControllerState);

	REGISTER_LUA_CFUNC(GetKeyFromScanSymbol);
	REGISTER_LUA_CFUNC(GetKeyState);
	REGISTER_LUA_CFUNC(GetModKeyState);
	REGISTER_LUA_CFUNC(GetPressedKeys);
````


The final controller Lua implementation appears as a controller input section:

````cpp
 * Controller Input
 * @section controllerinput
******************************************************************************/

static void PushControllerInfo(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, 0, 3);
	HSTR_PUSH_NUMBER(L, "instanceId", controller.instanceId);
	HSTR_PUSH_NUMBER(L, "deviceId", controller.deviceId);
	HSTR_PUSH_STRING(L, "name", controller.name);
}

static void PushControllerButtons(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, static_cast<int>(controller.buttons.size()), 0);

	for (size_t buttonId = 0; buttonId < controller.buttons.size(); ++buttonId) {
		lua_pushnumber(L, controller.buttons[buttonId]);
		lua_rawseti(L, -2, static_cast<int>(buttonId));
	}
}

static void PushControllerAxes(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, static_cast<int>(controller.axes.size()), 0);

	for (size_t axisId = 0; axisId < controller.axes.size(); ++axisId) {
		lua_pushnumber(L, controller.axes[axisId]);
		lua_rawseti(L, -2, static_cast<int>(axisId));
	}
}

static void PushControllerState(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, 0, 4);
	HSTR_PUSH_NUMBER(L, "instanceId", controller.instanceId);
	HSTR_PUSH_STRING(L, "name", controller.name);

	HSTR_PUSH(L, "buttons");
	PushControllerButtons(L, controller);
	lua_rawset(L, -3);

	HSTR_PUSH(L, "axes");
	PushControllerAxes(L, controller);
	lua_rawset(L, -3);
}

/***
 *
 * @function Spring.GetAvailableControllers
 * @return { instanceId: number, deviceId: number, name: string }[] controllers
 */
int LuaUnsyncedRead::GetAvailableControllers(lua_State* L)
{
	if (controllerInput == nullptr) {
		lua_createtable(L, 0, 0);
		return 1;
	}

	const auto controllers = controllerInput->GetAvailableControllers();
	lua_createtable(L, static_cast<int>(controllers.size()), 0);

	for (size_t i = 0; i < controllers.size(); ++i) {
		PushControllerInfo(L, controllers[i]);
		lua_rawseti(L, -2, static_cast<int>(i + 1));
	}

	return 1;
}

/***
 *
 * @function Spring.GetControllerState
 * @param instanceId number
 * @return table? controllerState with 0-based `buttons` and `axes` tables keyed by SDL id
 */
int LuaUnsyncedRead::GetControllerState(lua_State* L)
{
	if (controllerInput == nullptr)
		return 0;

	const int instanceId = luaL_checkint(L, 1);

	CControllerInput::ControllerStateSnapshot controller;
	if (!controllerInput->GetControllerState(instanceId, controller))
		return 0;

	PushControllerState(L, controller);
````


The complete uploaded `LuaUnsyncedRead.cpp` is preserved in the appendix.

---

## 6. BAR LuaUI Widget Bible

### `luaui/Widgets/gui_controller_camera_test.lua`

**Standalone final file present:** yes, `gui_controller_camera_test.lua`.

The uploaded standalone Lua file is treated as the final authority for the BAR gameplay/controller layer. It is significantly larger and more feature-rich than the early description in the handoff.

### Widget role

`gui_controller_camera_test.lua` is the main controller gameplay layer. It consumes the Recoil controller polling API, maps SDL controller state into Xbox-style named inputs, and implements camera, reticle, selection, command, build, debug, and tuning behavior.

The widget metadata states:

````lua
--------------------------------------------------------------------------------
-- SECTION: Widget info and Spring/gl references
--------------------------------------------------------------------------------
local widget = widget ---@type Widget

function widget:GetInfo()
	return {
		name = "Controller Camera Test",
		desc = "Prototype Xbox controller left-stick camera panning",
		author = "Kailil / Codex",
		date = "2026-05-22",
		license = "GNU GPL, v2 or later",
		layer = 0,
		enabled = false,
````


Note that the uploaded final widget has `enabled = false` in its widget info. That means the file itself is present, but a developer/tester should verify how the branch enables or loads it in the actual BAR environment.

### Controller API usage

At the top of the file, the widget caches the Recoil controller API functions:

````lua
end

local spGetAvailableControllers = Spring.GetAvailableControllers
local spGetControllerState = Spring.GetControllerState
local spGetCameraState = Spring.GetCameraState
local spSetCameraState = Spring.SetCameraState
local spGetCameraVectors = Spring.GetCameraVectors
local spGetGroundHeight = Spring.GetGroundHeight
local spGetMouseState = Spring.GetMouseState
local spGetViewGeometry = Spring.GetViewGeometry
````


The polling helpers use protected calls:

````lua
	end
end

local function pollFirstController()
	local ok, controllers = pcall(spGetAvailableControllers)
	if not ok then
		controllerName = "GetAvailableControllers failed"
		controllerInstanceId = nil
		return nil
	end

	local controller = getFirstController(controllers)
	if not controller then
		controllerName = "none"
		controllerInstanceId = nil
		return nil
	end

	controllerName = tostring(controller.name or "unknown")
	controllerInstanceId = controller.instanceId
	return controller
end

local function pollControllerState(instanceId)
	if instanceId == nil then
		return nil
	end

	local ok, state = pcall(spGetControllerState, instanceId)
	if not ok or type(state) ~= "table" then
		return nil
	end

	return state
end
````


The widget initializes by checking whether both controller API functions exist:

````lua

function widget:Initialize()
	apiAvailable = type(spGetAvailableControllers) == "function" and type(spGetControllerState) == "function"
	ControllerCameraTestEnsureBindings()
	updateScreenCenter(spGetViewGeometry())
	ensureDebugPanelInitialized()
end
````


The per-frame update path calls `ControllerCameraTestUpdateControllerFrame(dt)` from `widget:Update(dt)`:

````lua
function ControllerCameraTestUpdateControllerFrame(dt)
	local state = ControllerCameraTestBeginControllerUpdate(dt)
	if not state then
		return
	end

	ControllerCameraTestUpdateControllerAxesAndButtons(state)
	ControllerCameraTestUpdateControllerModeAndCommandLayer(dt)
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestBuildMenu.open then
		ControllerCameraTestUpdateRadialStickSelection()
	end
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestTacticalMenu.open then
		ControllerCameraTestUpdateTacticalStickSelection()
	end
	ControllerCameraTestUpdateCameraControls(dt)
	updateReticleWorldTarget()
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestDragCommand.active then
		pcall(ControllerCameraTestUpdateDragPreview)
	end
	if controllerMode and reticleVisible and type(spWarpMouse) == "function" then spWarpMouse(screenCenterX, screenCenterY) end
end

function widget:Update(dt)
	ControllerCameraTestUpdateControllerFrame(dt)
end

function ControllerCameraTestNormalizeKeyName(value)
	return string.lower(tostring(value or "")):gsub("[%s_%-]", "")
end
````


### Xbox button and axis mapping

The widget preserves SDL-style 0-based IDs and maps them into Xbox-style names:

````lua
local XboxController = {
	axes = {
		leftStickX = 0,
		leftStickY = 1,
		rightStickX = 2,
		rightStickY = 3,
		leftTrigger = 4,
		rightTrigger = 5,
	},
	axisLabels = {
		leftStickX = "Left Stick X",
		leftStickY = "Left Stick Y",
		rightStickX = "Right Stick X",
		rightStickY = "Right Stick Y",
		leftTrigger = "LT",
		rightTrigger = "RT",
	},
	axisOrder = {
		"leftStickX",
		"leftStickY",
		"rightStickX",
		"rightStickY",
		"leftTrigger",
		"rightTrigger",
	},
	buttons = {
		A = 0,
		a = 0,
		B = 1,
		b = 1,
		X = 2,
		x = 2,
		Y = 3,
		y = 3,
		back = 4,
		view = 4,
		["Back/View"] = 4,
		guide = 5,
		start = 6,
		menu = 6,
		["Start/Menu"] = 6,
		leftStick = 7,
		leftStickClick = 7,
		["Left Stick Click"] = 7,
		rightStick = 8,
		rightStickClick = 8,
		["Right Stick Click"] = 8,
		LB = 9,
		lb = 9,
		leftBumper = 9,
		RB = 10,
		rb = 10,
		rightBumper = 10,
		dpadUp = 11,
		["D-pad Up"] = 11,
		dpadDown = 12,
		["D-pad Down"] = 12,
		dpadLeft = 13,
		["D-pad Left"] = 13,
		dpadRight = 14,
		["D-pad Right"] = 14,
	},
	buttonLabels = {
		[0] = "A",
		[1] = "B",
		[2] = "X",
		[3] = "Y",
		[4] = "Back/View",
		[5] = "Guide",
		[6] = "Start/Menu",
		[7] = "Left Stick Click",
		[8] = "Right Stick Click",
		[9] = "LB",
		[10] = "RB",
		[11] = "D-pad Up",
		[12] = "D-pad Down",
		[13] = "D-pad Left",
		[14] = "D-pad Right",
	},
	buttonOrder = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 },
	commandLayerButtonOrder = { 0, 1, 2, 3, 9, 10, 11, 12, 13, 14 },
	previewButtonOrder = { 0, 1, 2, 3, 4, 6, 9, 10, 11, 12, 13, 14 },
	normalPreviewLabels = {
		[0] = "A = Select / hold area / double-tap same visible type",
		[1] = "B = Clear Selection",
		[2] = "X = Smart Action (Move/Build/Attack)",
		[3] = "Y = Controller Build Menu",
		[4] = "Back/View = Commander-focus modifier / reserved",
		[6] = "Start/Menu = Reserved",
		[9] = "LB = Camera pitch; LB+D-pad L/R idle type",
		[10] = "RB = Hold control-group mode",
		[11] = "D-pad Up = Camera bookmark Up",
		[12] = "D-pad Down = Camera bookmark Down",
		[13] = "D-pad Left = Previous idle unit",
		[14] = "D-pad Right = Next idle unit",
	},
	commandPreviewLabels = {
		[0] = "RT + A = Reserved / select-all disabled",
		[1] = "RT + B = Stop selected units",
		[2] = "RT + X = Attack / Attack-move",
		[3] = "RT + Y = Tactical command menu",
		[9] = "RT + LB = Previous selected unit/type",
````


Key axis mapping:

```text
leftStickX = 0
leftStickY = 1
rightStickX = 2
rightStickY = 3
leftTrigger = 4
rightTrigger = 5
```

Key button mapping:

```text
A = 0
B = 1
X = 2
Y = 3
Back/View = 4
Guide = 5
Start/Menu = 6
Left Stick Click = 7
Right Stick Click = 8
LB = 9
RB = 10
D-pad Up = 11
D-pad Down = 12
D-pad Left = 13
D-pad Right = 14
```

### Gameplay systems present in the standalone widget

The standalone widget contains state tables and functions for:

- controller command debug;
- build menu and radial categories;
- build placement and pattern/spacing/facing behavior;
- drag commands and preview points;
- area selection;
- tactical menu;
- unit cycling;
- camera bookmarks;
- idle unit cycling;
- control groups;
- visual feedback markers;
- placement popups;
- input smoothing;
- settings/debug/help UI;
- custom action bindings;
- camera pan, zoom, rotation, and pitch;
- reticle drawing and world targeting;
- mouse warping to keep the real cursor centered when in controller mode.

### Known widget weaknesses and review targets

The widget is feature-rich but monolithic. Recommended refactor targets:

- Split Xbox mapping, polling, settings, reticle, camera, selection, build menu, tactical menu, placement, and debug UI into smaller modules/files.
- Separate “input reading” from “gameplay command decisions.”
- Make debug logging and debug drawing configurable.
- Verify multiplayer safety of command issuing and selection behavior.
- Verify assumptions about SDL button/axis IDs across platforms and controller connection modes.
- Verify `enabled = false` loading behavior in the target BAR branch.
- Review all fallback paths around build placement and native command preview behavior.

The complete final widget is preserved in the appendix.

---

## 7. Lua API Contract

### `Spring.GetAvailableControllers()`

Expected behavior:

```lua
local controllers = Spring.GetAvailableControllers()
```

Expected return:

```lua
{
  {
    instanceId = number,
    deviceId = number,
    name = string,
  },
  ...
}
```

Implementation details:

- Returns an empty table if `controllerInput == nullptr`.
- Uses a normal Lua array-style table for controllers.
- Controller entries are inserted with `lua_rawseti(..., i + 1)`, so the controller list is 1-based.

### `Spring.GetControllerState(instanceId)`

Expected behavior:

```lua
local state = Spring.GetControllerState(instanceId)
```

Expected return:

```lua
{
  instanceId = number,
  name = string,
  buttons = {
    [0] = number,
    [1] = number,
    ...
  },
  axes = {
    [0] = number,
    [1] = number,
    ...
  },
}
```

Or returns nothing/nil if:

- `controllerInput == nullptr`; or
- no controller exists for the requested `instanceId`.

### Indexing note

The controller list returned by `GetAvailableControllers()` is 1-based. The `buttons` and `axes` tables returned by `GetControllerState(instanceId)` preserve SDL IDs and are 0-based. This is intentional in the current implementation, but it should be reviewed because Lua developers may expect arrays to begin at 1.

### Polling model

This is a polling API. Lua reads current controller state. There are no current immediate controller event call-ins such as:

```lua
function widget:ControllerButtonDown(...)
function widget:ControllerAxisMotion(...)
```

---

## 8. Installation and Testing Bible

The current validated installer file is:

```text
Install_BAR_Controller_Support_v0.3.6_SAFE_LIVE.bat
```

Historical note: older archive text may mention `Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat` or `v0.3.5`. Use v0.3.6 as the current good public test installer.

It installs both halves of the prototype:

1. Custom Recoil Engine build with the controller backend.
2. BAR LuaUI branch containing `gui_controller_camera_test.lua` and compatibility shim.

### Expected local paths

```text
BAR install folder:
%LOCALAPPDATA%\Programs\Beyond-All-Reason

BAR data folder:
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data

Target engine slot:
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\engine
ecoil_2025.06.19
```

### Requirements

```text
Windows
Beyond All Reason installed normally
Git for Windows available in PATH
PowerShell available
Internet access for GitHub downloads/clones
```

### Installer behavior

The handoff describes the staged installer flow as:

```text
1. Checks that the BAR install folder, data folder, and stock engine slot exist.
2. Checks that Git and PowerShell are available.
3. Stops BAR/Recoil-related processes.
4. Creates a temporary working folder.
5. Downloads or copies the custom controller engine ZIP.
6. Extracts the engine ZIP.
7. Verifies the extracted engine contains spring.exe, unitsync.dll, and base/.
8. Clones the BAR controller-support branch into a staging folder.
9. Verifies the BAR branch contains gui_controller_camera_test.lua.
10. Verifies the BAR branch contains the controller-support engine compatibility shim.
11. Clones BYAR Chobby into a staging folder.
12. Backs up the existing stock engine, BAR.sdd, and BYAR Chobby.sdd.
13. Moves the staged BAR.sdd and BYAR Chobby.sdd into place.
14. Swaps the staged custom engine into the active recoil_2025.06.19 engine slot.
15. Enables dev mode by creating devmode.txt.
16. Applies the camera smooth-rotation config: `CamSpringLockCardinalDirections = 0`.
17. Clears stale cache/state files.
18. Performs final verification.
19. Leaves a log file on the Desktop.
```

### Engine artifact

```text
recoil-controller-amd64-windows-a76a36b9b18910f225a9cb8a4c42f920e14b33de.zip
```

Release tag:

```text
controller-support-v0.3.6-detection-restored-logspam-fixed
```

The installer tries to download it from the GitHub release. If download fails, the fallback is to manually place that ZIP beside the `.bat` file and rerun the installer.

### BAR branch installed

```text
Repository:
https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01.git

Branch:
controller-support-current-master-engine-shim

Installed into:
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\games\BAR.sdd
```

The installer checks for:

```text
luaui\Widgets\gui_controller_camera_test.lua
common\constants.lua
```

### Chobby dependency

The installer stages and installs BYAR Chobby from:

```text
https://github.com/beyond-all-reason/BYAR-Chobby.git
```

into:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\games\BYAR Chobby.sdd
```

### How to run

```bat
Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat
```

Recommended testing procedure:

```text
1. Close Beyond All Reason and any running Recoil/Spring processes.
2. Put Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat somewhere easy to find.
3. Double-click the batch file, or run it from Command Prompt.
4. Let the installer finish.
5. Keep the window open if there is an error and review the printed log path.
```

### After installation

```text
1. Plug in an Xbox controller by USB.
2. Launch Beyond All Reason.
3. Go to Settings > Developer.
4. Set Singleplayer to: Beyond All Reason Dev.
5. Click Skirmish.
6. Start a local match.
```

### Log verification

The handoff suggests checking BAR `infolog.txt` with:

```bat
findstr /i "Spring Engine Version ControllerInput Xbox constants.lua Fatal" "%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\infolog.txt"
```

Healthy signs include:

```text
Spring Engine Version: d5c8a21 research/controller-api-2025-06-19
Controller connected: Xbox ...
```

### Backup location

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\controller-support-cleaninstall-backups
```

### Installer caution

The installer is a practical test helper, not a final official distribution method. Developers should replace it with standard Recoil/BAR development or release processes if the project is upstreamed.

The complete final uploaded installer batch file is preserved in the appendix.

---

## 9. Development Timeline and Chat Archive Index

| File | Phase | Purpose / takeaway | Authority type |
|---|---|---|---|
| `BAR-CS-001_2026-05-20_research-setup_recoil-bar-deep-research-prompt_raw-chat.md` | Initial research setup | Defines the first deep-research prompt for Recoil Engine, Spring lineage, BAR, LuaUI, and Xbox controller feasibility. Historical context/research prompt. | Historical/context unless noted |
| `BAR-CS-001B_2026-05-20_prompt-setup_halo-wars-rts-control-research_raw-chat.md` | Halo Wars research prompt setup | Creates the focused research prompt for Halo Wars 1/2 gamepad RTS controls. Historical UX research setup. | Historical/context unless noted |
| `BAR-CS-002_2026-05-20_reference_halo-wars-gamepad-rts-controls_raw-chat.md` | Halo Wars reference research | Reference material on console RTS control philosophy, camera movement, selection, radial menus, and controller UX. Historical/research context. | Historical/context unless noted |
| `BAR-CS-003_2026-05-20_research-report_bar-recoil-controller-feasibility_raw-chat.md` | BAR/Recoil feasibility report | Practical feasibility report for adding controller support through Recoil and BAR LuaUI. Useful design context; not final code authority. | Historical/context unless noted |
| `BAR-CS-004_2026-05-20_setup_bar-luaui-diagnostics-recoil-api-decision_raw-chat.md` | Recoil API setup and diagnostics | Large implementation/troubleshooting record for LuaUI diagnostics and the decision to expose controller state through Recoil API polling. Historical context and possible code history. | Historical/context unless noted |
| `BAR-CS-005_2026-05-22_implementation_radial-build-menu-factory-queue-grid-drag-control-groups_raw-chat.md` | LuaUI implementation phase | Documents the larger BAR widget feature work: radial build menu, factory queue, grid placement, drag commands, control groups, and UX polish. Historical context; standalone Lua file is final authority. | Historical/context unless noted |
| `BAR-CS-006_2026-05-23_recovery-report_controller-support-incident-postmortem.md` | Recovery/postmortem | Postmortem and recovery notes after project instability or broken state. Historical risk/context document. | Historical/context unless noted |
| `BAR-CS-007_2026-05-23_recovery-execution_restore-stable-build-engine-install_raw-chat.md` | Recovery execution and installer | Documents restore/stable build work and installer development. Important installer context; standalone batch file and handoff are final authorities. | Historical/context unless noted |
| `BAR-CS-008_2026-05-24_extraction_recoil-engine-modification-summary_raw-chat.md` | Engine modification extraction | Summarizes Recoil engine modifications and adoption path. Important narrative context; standalone C++/header files are final authority. | Historical/context unless noted |
| `BAR-CS-009_2026-05-24_prompt-setup_recoil-engine-patch-4-code-handoff_raw-chat.md` | Patch 4 handoff prompt | Prompt setup for extracting exact Patch 4 controller engine changes. Historical prompt/context. | Historical/context unless noted |
| `BAR-CS-010_2026-05-24_code-handoff_recoil-engine-xbox-controller-patch-4_raw-chat.md` | Patch 4 code handoff | Focused handoff for Recoil Patch 4 code. Useful corroborating context, but standalone C++ files and main handoff are final authorities. | Historical/context unless noted |
| `BAR-CS-011_2026-05-25_planning_log-spam-cleanup-camera-rotation-investigation_raw-chat.md` | Next-step cleanup planning | Planning notes for removing controller log spam and investigating camera rotation snapping. Correction: the camera snapping behavior also occurs with mouse-and-keyboard controls, so it should be treated as inherited default BAR/Recoil camera behavior rather than a controller-mod regression. | Historical/context unless noted |
| `bar_recoil_controller_support_extracted_summary.md` | Extracted project summary | Short extracted summary of the project and controller-support file set. Useful orientation; not final source code authority. | Historical/context unless noted |


---

## 10. Confirmed Final Code vs Historical Code

Use this rule when reading the archive:

- The handoff Markdown is the main narrative base.
- The standalone source files are the final code authority if present.
- Raw chat Markdown files are historical context unless they contain information not found elsewhere.
- Any code that appears outdated, superseded, or contradicted by a standalone final file should be marked as historical and not final.

### Final authority files present in this archive

```text
ControllerInput.h
ControllerInput.cpp
CMakeLists.txt
MouseHandler.cpp
LuaUnsyncedRead.h
LuaUnsyncedRead.cpp
gui_controller_camera_test.lua
Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat
```

### Important conflict rule

If a chat log says one thing and the standalone source file says another, treat the standalone source file as authoritative for code. Treat the chat log as explanation of how the project got there.

---

## 11. Known Issues and Review Targets

### Engine-side review targets

- `ButtonDown`, `ButtonUp`, and `AxisMotion` log spam was fixed in v0.3.6 by gating only those high-frequency event logs behind default-off `CONTROLLER_INPUT_LOG_EVENTS`.
- Keep lifecycle logs enabled for initialization, startup scan, connect, remove, remap, and warnings/errors.
- `CControllerInput` lifecycle is currently tied to `CMouseHandler::InitStatic()` / `KillStatic()`. This works for the prototype but should be reviewed by Recoil maintainers.
- SDL controller shutdown/remap/disconnect behavior should be hardened.
- SDL mapping stability should be tested across USB, Bluetooth, Windows, Linux, Steam Deck, and different controller firmware versions.
- Lua `buttons` and `axes` tables are 0-based, while controller list entries are 1-based. This should be documented or normalized.
- The current API is read-only polling. Developers should decide whether event/call-in APIs are needed later.

### BAR LuaUI review targets

- `gui_controller_camera_test.lua` is very large and should likely be split into smaller files or modules.
- Input mapping, gameplay actions, debug UI, settings UI, and rendering are currently combined in one widget.
- Multiplayer safety of all command paths should be reviewed.
- Build placement, command preview, drag commands, and fallback behavior should be reviewed against current BAR LuaUI expectations.
- Controller settings/rebinding should be made maintainable and user-friendly.
- The uploaded widget has `enabled = false`; verify how it is enabled in the test branch.
- Camera rotation snapping near 0/90/180/270/360 degrees is resolved for testing by setting `CamSpringLockCardinalDirections = 0`. This is default Recoil Spring camera behavior, not a controller-widget bug.

---

## 12. Recommended Next Steps

### A. Immediate cleanup

1. Treat v0.3.6 as the current good public test release and v0.3.5 as superseded/bad.
2. Verify that all standalone final source files match the v0.3.6 branch intended for developer review.
3. Add concise API docs for `Spring.GetAvailableControllers()` and `Spring.GetControllerState(instanceId)`.
4. Test USB, Bluetooth, startup-connected, hotplug, reconnect, and disconnect paths.
5. Verify whether the Lua widget is intentionally `enabled = false` or should be enabled by branch/config.

### Camera snapping / 90-degree magnetization — resolved by config

The camera snapping or “magnetization” near 0/90/180/270/360 degrees is not caused by the Xbox controller mod.

It is default Recoil Spring camera behavior controlled by:

```text
CamSpringLockCardinalDirections
```

For smoother controller and mouse/keyboard camera rotation, set:

```text
CamSpringLockCardinalDirections = 0
```

in:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\springsettings.cfg
```

The v0.3.6 installer applies this setting automatically. No Recoil camera engine patch is required for this issue.

### B. Engine cleanup

1. Review whether `CControllerInput` should be owned by a broader Recoil input manager instead of `CMouseHandler`.
2. Review `SDL_InitSubSystem` / SDL shutdown responsibilities.
3. Add named/normalized controller mappings or document that raw SDL IDs are intentionally exposed.
4. Consider controller event/call-in support only after the polling API is stable.
5. Add tests or diagnostics that do not spam logs.

### C. BAR LuaUI cleanup

1. Split `gui_controller_camera_test.lua` into maintainable modules if BAR's widget structure allows it.
2. Separate input polling and mapping from gameplay behavior.
3. Separate camera/reticle/selection systems from build/tactical/placement systems.
4. Add safer debug settings and a lower-noise default UI.
5. Review command issuing behavior for multiplayer and spectator safety.
6. Rework settings and rebinding UI into a maintainable user-facing design.

### D. Upstream adoption path

1. Keep the current fork as proof that end-to-end controller support can run.
2. Prepare a focused Recoil PR for the controller backend only.
3. Prepare a separate BAR PR for LuaUI gameplay/controller behavior only.
4. Ask Recoil maintainers to review API shape, lifecycle ownership, SDL handling, and naming.
5. Ask BAR maintainers to review UX, widget architecture, settings, and multiplayer safety.
6. Avoid describing the prototype as official support until maintainers approve and merge it.

---


## Release / Build History Update

### v0.3.4 — Previous working baseline

v0.3.4 was the earlier successful installer/build state. It worked end-to-end but still had high-frequency controller input event log spam.

### v0.3.5 — Superseded regression build

v0.3.5 introduced the default-off `CONTROLLER_INPUT_LOG_EVENTS` gate for `ButtonDown`, `ButtonUp`, and `AxisMotion`, but it accidentally lost the final Patch 4 controller startup detection path. The engine launched, but the controller was not detected. Do not use this as the current good release.

### v0.3.6 — Current good public test release

v0.3.6 restores the Patch 4 SDL controller startup detection path and keeps the v0.3.5 log-spam gate. It is validated by `infolog.txt` showing:

```text
Spring Engine Version: a76a36b research/controller-api-investigation
[ControllerInput] SDL joystick/gamecontroller subsystem initialized
[ControllerInput] SDL_NumJoysticks at init: 3
[ControllerInput] Scanning existing SDL joysticks: count=3
[ControllerInput] Controller connected: deviceId=0 instanceId=0 name=Controller (Xbox One For Windows)
```

The same validation did not show high-frequency `ButtonDown`, `ButtonUp`, or `AxisMotion` spam.

## 13. Glossary

**Recoil Engine** — The RTS engine used by Beyond All Reason, descended from the Spring RTS engine lineage.

**BAR** — Beyond All Reason, the RTS game that this controller-support prototype targets.

**LuaUI** — BAR/Recoil's unsynced Lua user-interface/widget layer. It is where game UI and client-side input behavior can be implemented.

**SDL_GameController** — SDL's higher-level controller abstraction for gamepad devices with standardized button/axis semantics.

**SDL_Joystick** — SDL's lower-level joystick device abstraction. SDL game controllers are backed by joystick instances.

**Controller instanceId** — SDL joystick instance ID for a currently opened device. This is used by the prototype as the stable lookup key while the device is connected.

**Controller deviceId** — SDL device index used when opening or scanning devices. Device IDs can differ from instance IDs and should not be treated as the same concept.

**Polling API** — An API style where Lua asks the engine for the current state each frame, rather than receiving an immediate callback when input happens.

**Call-in/event API** — An API style where Lua receives immediate event callbacks, such as a hypothetical `ControllerButtonDown` or `ControllerAxisMotion`.

**Widget** — A LuaUI script that adds client-side behavior or UI in BAR/Recoil.

**Chobby** — BAR's lobby/frontend layer used as part of the tested install environment.

**devmode** — BAR development mode enabled by creating `devmode.txt`, allowing the installed `BAR.sdd` dev game folder to be used for local testing.

---

## 14. Original Handoff Document, Preserved Verbatim

The following section preserves the uploaded base handoff document exactly as text, except for being nested under this bible heading.

# Beyond All Reason Xbox Controller Support Mod — Developer Handoff

## 1. Purpose of This Handoff

This handoff is intended to help experienced Recoil Engine and Beyond All Reason developers review, fork, clean up, improve, and potentially adopt a working Xbox controller support implementation.

This project is not just a code archive. It is a two-part early-development controller support mod:

1. A **Recoil Engine controller backend** that initializes SDL joystick/gamecontroller support, tracks live Xbox controller state, and exposes controller state to Lua.
2. A **BAR LuaUI controller widget** named `gui_controller_camera_test.lua` that consumes the Recoil controller API and implements the actual in-game controller behavior.

The current implementation is functional in its early-development state, but it was generated through AI-assisted coding. It should be treated as working prototype code that needs experienced developer review before any official adoption.

---

## 2. Requested Developer Help

The goal is for this work to be picked up by someone with stronger Recoil Engine, BAR LuaUI, C++, or RTS UI/UX experience and turned into something maintainable.

Specifically, developer help is requested for:

- reviewing the Recoil Engine controller backend;
- reviewing the BAR LuaUI controller widget architecture;
- deciding what belongs in Recoil Engine versus BAR LuaUI;
- cleaning up AI-generated code;
- improving SDL controller lifecycle handling;
- improving controller mapping, rebinding, and settings;
- reducing debug/log spam;
- hardening hotplug and disconnect behavior;
- improving UI prompts and controller feedback;
- validating multiplayer safety and maintainability;
- deciding whether this should become an upstream Recoil feature, an official BAR feature, or both.

This handoff is written to make that takeover easier.

---

## Original Development Chat Archive

This project was created through an extended AI-assisted development workflow. I am including the original ChatGPT project/chat archive for developers who want more context on how the Recoil Engine modification and BAR LuaUI controller widget were built.

The archive includes the original implementation discussion, troubleshooting, build attempts, GitHub Actions workflow decisions, Patch 4 controller initialization breakthrough, and LuaUI controller support development.

If you have questions about why a file was modified or how a specific implementation decision happened, this archive may provide additional context.

Archive link:
https://chatgpt.com/g/g-p-6a0d9d7c98e08191a323d80d3ad8b116-controller-support-in-beyond-all-reason/project


## 3. Source of Truth

### Recoil Engine side

```text
Repository: UnderarmCape/controllersupport-RecoilEngine-attempt-01
Verified engine commit: d5c8a21e2704a4dd16c1d0e3e9abe7527dd5f5d5
Commit title: Include SDL init header for controller subsystem
Known milestone release: controller-detection-v0.1
```

This commit is the verified Patch 4 engine state. It contains the final Recoil-side controller input implementation used for this handoff.

### BAR LuaUI side

```text
Repository: UnderarmCape/underarmcape-bar-controller-support-attempt-01
Branch: underarmcape/bar-controller-support-attempt-01
Main widget file: luaui/Widgets/gui_controller_camera_test.lua
```

The BAR LuaUI widget is the second half of the mod. It consumes the Recoil API through:

```lua
Spring.GetAvailableControllers()
Spring.GetControllerState(instanceId)
```

and translates controller state into BAR gameplay controls.

---

## 4. Project Status

### Working Recoil Engine features

- Xbox controller detection works.
- USB-C controller connection works.
- Bluetooth controller connection works.
- SDL joystick/gamecontroller subsystem initialization works.
- Existing connected controllers are scanned on startup.
- Controller hotplug/reconnect behavior works.
- Axis motion, button down, and button up events work.
- Lua polling API works:
  - `Spring.GetAvailableControllers()`
  - `Spring.GetControllerState(instanceId)`
- BAR LuaUI can poll the controller state.

### Working BAR LuaUI controller features

The BAR LuaUI side uses `gui_controller_camera_test.lua` as the main controller widget. The original project state documents the widget as the active gameplay/controller layer, with features including:

- Xbox controller polling through `Spring.GetAvailableControllers()`.
- Live controller state through `Spring.GetControllerState(instanceId)`.
- Readable Xbox mapping layer for axes/buttons.
- Left stick camera panning.
- Fast camera modifier.
- RT command layer preview.
- Virtual center reticle.
- Reticle world targeting.
- Movable/resizable/word-wrapped debug panel.
- A-button reticle selection.
- Unit selection through the controller reticle.
- Selection accuracy independent of the real mouse cursor.
- Ongoing command, selection, build, tactical menu, control group, and debug systems inside the widget.

The current implementation should be described as **end-to-end playable controller support in early development**, not as polished upstream-ready code.

---

## 5. Two-Part Architecture

### Part A — Recoil Engine Controller Backend

The Recoil Engine modification is responsible for the hardware/input foundation:

```text
SDL controller subsystem initialization
SDL joystick subsystem initialization
controller startup scan
controller hotplug/reconnect handling
button and axis state tracking
Lua read API exposure
```

The engine side does not decide what the controller means in BAR gameplay. It only makes controller state available to Lua.

### Part B — BAR LuaUI Controller Widget

The BAR widget is responsible for actual gameplay behavior:

```text
controller polling
Xbox input mapping
camera movement
virtual reticle
selection
orders
command layer behavior
build/menu experiments
visual/debug feedback
```

This split matters because Recoil should remain a general engine input layer, while BAR LuaUI should own BAR-specific gameplay decisions.

---

## 6. How This Engine Mod Was Made

The engine mod began as an attempt to make Recoil Engine detect and expose Xbox controller input natively instead of faking keyboard/mouse input.

The main design decision was to treat controller input as a sibling to keyboard and mouse input. Recoil already has input systems under:

```text
rts/System/Input/InputHandler.cpp
rts/System/Input/KeyInput.cpp
rts/System/Input/MouseInput.cpp
```

So the controller backend was added under:

```text
rts/System/Input/ControllerInput.h
rts/System/Input/ControllerInput.cpp
```

The implementation intentionally avoids pretending controller buttons are keyboard keys. Xbox A, B, triggers, sticks, and D-pad input should stay controller input and be interpreted by BAR LuaUI later.

The misleading file name `GameControllerTextInput.cpp` was not used. In this engine context, “GameController” there refers to the game/text input controller, not a physical Xbox controller. Physical SDL controller device handling belongs in `rts/System/Input`.

The controller singleton is initialized from `CMouseHandler::InitStatic()` because that is part of the existing UI/input startup path. This makes the controller input singleton available before Lua attempts to read controller state. It is cleaned up in `CMouseHandler::KillStatic()`.

Lua exposure was added through `LuaUnsyncedRead` because the first engine API is read-only state polling:

```lua
Spring.GetAvailableControllers()
Spring.GetControllerState(instanceId)
```

Those functions let BAR LuaUI discover connected controllers and read button/axis snapshots.

The key Patch 4 breakthrough was SDL subsystem initialization. Earlier controller code existed, but SDL was not reporting the connected controller. Patch 4 fixed this by initializing the SDL joystick and gamecontroller subsystems inside the non-headless `CControllerInput` constructor before scanning devices:

```cpp
SDL_InitSubSystem(SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER)
```

After that fix, Recoil successfully initialized SDL controller support and received live Xbox controller input.

---

## 7. How the Engine Mod Was Compiled

After the engine code was added, I initially tried to compile the modified Recoil Engine locally on Windows. I did not know enough about the Recoil Windows build process to get the local build working cleanly. After running into too many local setup issues, I gave up on the local Windows build path.

Instead, I moved the compilation process to GitHub Actions.

GitHub Actions became the working build-verification path for this engine mod. The modified Recoil branch was compiled in CI instead of relying on my local Windows environment.


---

## 7A. Installing and Testing the Two-Part Mod

This section explains how a developer or tester can install the working controller-support build before reviewing or modifying the code.

The easiest test path is the included Windows batch installer:

```text
Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat
```

This installer was created to reduce manual setup mistakes. It installs both halves of the controller support mod:

1. the custom Recoil Engine build with the controller backend; and
2. the BAR LuaUI branch that contains `gui_controller_camera_test.lua`.

### What the installer expects

The installer assumes a normal Windows BAR install at:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason
```

It also expects the standard BAR data folder at:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data
```

The installer targets this engine slot:

```text
data\engine\recoil_2025.06.19
```

Requirements:

```text
Windows
Beyond All Reason installed normally
Git for Windows available in PATH
PowerShell available
Internet access for GitHub downloads/clones
```

### What the installer does

The installer is intentionally staged and conservative.

It performs these major steps:

```text
1. Checks that the BAR install folder, data folder, and stock engine slot exist.
2. Checks that Git and PowerShell are available.
3. Stops BAR/Recoil-related processes.
4. Creates a temporary working folder.
5. Downloads or copies the custom controller engine ZIP.
6. Extracts the engine ZIP.
7. Verifies the extracted engine contains spring.exe, unitsync.dll, and base/.
8. Clones the BAR controller-support branch into a staging folder.
9. Verifies the BAR branch contains gui_controller_camera_test.lua.
10. Verifies the BAR branch contains the controller-support engine compatibility shim.
11. Clones BYAR Chobby into a staging folder.
12. Backs up the existing stock engine, BAR.sdd, and BYAR Chobby.sdd.
13. Moves the staged BAR.sdd and BYAR Chobby.sdd into place.
14. Swaps the staged custom engine into the active recoil_2025.06.19 engine slot.
15. Enables dev mode by creating devmode.txt.
16. Applies the camera smooth-rotation config: `CamSpringLockCardinalDirections = 0`.
17. Clears stale cache/state files.
18. Performs final verification.
19. Leaves a log file on the Desktop.
```

The installer is called `SAFE_LIVE` because it stages and verifies files before replacing the active engine. It also creates backups before moving the custom engine into the active slot.

### Engine artifact used by the installer

The installer uses this engine artifact name:

```text
recoil-controller-amd64-windows-d5c8a21e2704a4dd16c1d0e3e9abe7527dd5f5d5.zip
```

The installer tries to download it from the GitHub release first.

If the download fails, the fallback is to manually place that ZIP file in the same folder as the `.bat` file and run the installer again.

### BAR branch installed by the installer

The installer clones this BAR repository and branch:

```text
Repository:
https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01.git

Branch:
controller-support-current-master-engine-shim
```

This branch is installed into:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\games\BAR.sdd
```

The installer checks that this file exists after staging:

```text
luaui\Widgets\gui_controller_camera_test.lua
```

It also checks for the controller-support compatibility shim in:

```text
common\constants.lua
```

### Chobby installed by the installer

The installer also stages and installs BYAR Chobby from:

```text
https://github.com/beyond-all-reason/BYAR-Chobby.git
```

into:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\games\BYAR Chobby.sdd
```

### How to run the installer

Recommended test procedure:

```text
1. Close Beyond All Reason and any running Recoil/Spring processes.
2. Put Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat somewhere easy to find.
3. Double-click the batch file, or run it from Command Prompt.
4. Let the installer finish.
5. Keep the window open if there is an error and review the printed log path.
```

If running from Command Prompt, use:

```bat
Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat
```

The installer automatically opens a live console session and writes a Desktop log named like:

```text
BAR_Controller_Install_v0.3.4_SAFE_LIVE_<timestamp>.log
```

### After installation

After the installer reports `INSTALL COMPLETE`, test the mod like this:

```text
1. Plug in an Xbox controller by USB.
2. Launch Beyond All Reason.
3. Go to Settings > Developer.
4. Set Singleplayer to: Beyond All Reason Dev.
5. Click Skirmish.
6. Start a local match.
```

After the match loads, the installer suggests checking the BAR infolog with:

```bat
findstr /i "Spring Engine Version ControllerInput Xbox constants.lua Fatal" "%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\infolog.txt"
```

Healthy signs include log lines similar to:

```text
Spring Engine Version: d5c8a21 research/controller-api-2025-06-19
Controller connected: Xbox ...
```

### Backup location

The installer writes backups under:

```text
%LOCALAPPDATA%\Programs\Beyond-All-Reason\data\controller-support-cleaninstall-backups
```

This backup folder is important. If a tester needs to restore the previous install manually, this is where the previous engine, BAR.sdd, and BYAR Chobby.sdd backups should be located.

### Notes for developers reviewing the installer

The installer is not meant to be the final official installation method. It is a practical test helper for developers and modders who want to try the working controller-support branch quickly.

Before official adoption, maintainers would likely replace this with a cleaner development/test setup or integrate the work through normal Recoil/BAR build and release processes.

The installer is still useful because it documents the complete working runtime combination:

```text
custom Recoil controller engine
+ BAR.sdd controller-support branch
+ BYAR Chobby
+ devmode enabled
+ cache/state cleared
```

That combination is the tested environment for the early controller-support mod.


---

## 8. Final Patch 4 Engine Flow

```text
SDL controller event
  -> InputHandler callback
  -> CControllerInput::HandleSDLControllerEvent
  -> controllersByInstanceId state update
  -> LuaUnsyncedRead snapshot API
  -> BAR LuaUI polling through Spring.GetAvailableControllers / Spring.GetControllerState
  -> gui_controller_camera_test.lua gameplay/controller layer
```

---

## 9. What This Does Not Mean

This work should not be described as final official support yet.

The current implementation is:

```text
working
playable/end-to-end
AI-coded
early development
in need of review
not upstream-polished yet
```

It should not be oversold as:

```text
production-ready
maintainer-approved
official BAR support
final Recoil controller API
finished controller UX
```

---

## 10. Known Weaknesses and Review Targets

Developers reviewing this should pay special attention to:

- whether `CMouseHandler::InitStatic()` is the right lifecycle location;
- whether `CControllerInput` should be owned by another engine input manager;
- whether controller APIs should remain polling-based or add event/call-in support;
- whether controller axes/buttons should be normalized into named inputs;
- whether SDL controller mappings are stable across USB, Bluetooth, Windows, Linux, and Steam Deck;
- whether hotplug/reconnect cleanup is robust enough;
- whether AxisMotion logging needs to be gated or removed;
- whether Lua state serialization should use 0-based or 1-based button/axis tables;
- whether the current BAR widget should be split, refactored, or kept as one file;
- whether the current gameplay behavior is multiplayer-safe;
- whether controller settings/rebinding should be handled in BAR, Recoil, or both.

---

## 11. Recommended Path Toward Official Adoption

A realistic path toward official adoption would likely look like this:

1. Keep the current fork/branch as the working proof that the idea runs.
2. Have a Recoil developer review the engine-side controller backend.
3. Have a BAR LuaUI developer review `gui_controller_camera_test.lua`.
4. Decide what API Recoil should officially expose.
5. Clean up or replace the AI-generated C++ code as needed.
6. Clean up or split the Lua widget as needed.
7. Create a focused Recoil Engine pull request for controller input support.
8. Create a separate BAR pull request for the LuaUI controller gameplay layer.
9. Iterate based on maintainer review.
10. Merge only the parts maintainers agree are maintainable and aligned with project direction.

The current fork does not need to be merged exactly as-is to be successful. If it gives maintainers or contributors a working base to fork, clean up, or redesign, it has done its job.

---

## 12. Final Patch 4 Recoil Engine Code

The following sections preserve the verified final Patch 4 Recoil Engine code state.

## `rts/System/Input/ControllerInput.h`

```cpp
/* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#pragma once

#include <SDL_events.h>
#include <SDL_gamecontroller.h>

#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "System/Input/InputHandler.h"

class CControllerInput
{
public:
	static CControllerInput* GetInstance();
	static void FreeInstance(CControllerInput* controllerInput);

	CControllerInput();
	~CControllerInput();

	struct ControllerStateSnapshot {
		int deviceId = -1;
		int instanceId = -1;
		std::string name;

		std::array<std::int16_t, 16> axes = {};
		std::array<std::uint8_t, 32> buttons = {};
	};

	std::vector<ControllerStateSnapshot> GetAvailableControllers() const;
	bool GetControllerState(int instanceId, ControllerStateSnapshot& state) const;

	bool HandleSDLControllerEvent(const SDL_Event& event);

private:
	struct ControllerState {
		int deviceId = -1;
		int instanceId = -1;
		std::string name;

		SDL_GameController* gameController = nullptr;

		std::array<std::int16_t, 16> axes = {};
		std::array<std::uint8_t, 32> buttons = {};
	};

	static ControllerStateSnapshot MakeControllerStateSnapshot(const ControllerState& state);

	void LogAvailableController(int deviceId) const;
	void ScanExistingControllers();
	void HandleDeviceAdded(int deviceId);
	void HandleDeviceRemoved(int instanceId);
	void HandleDeviceRemapped(int instanceId);
	void HandleButtonDown(int instanceId, int buttonId, std::uint8_t value);
	void HandleButtonUp(int instanceId, int buttonId, std::uint8_t value);
	void HandleAxisMotion(int instanceId, int axisId, std::int16_t value);

private:
	InputHandler::HandlerTokenT inputCon;
	std::unordered_map<int, ControllerState> controllersByInstanceId;
};

extern CControllerInput* controllerInput;
```

---

## `rts/System/Input/ControllerInput.cpp`

```cpp
/* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#include "ControllerInput.h"

#include "System/Input/InputHandler.h"
#include "System/Log/ILog.h"

#ifndef HEADLESS
#include <SDL.h>
#include <SDL_events.h>
#include <SDL_error.h>
#include <SDL_gamecontroller.h>
#include <SDL_joystick.h>
#endif

CControllerInput* controllerInput = nullptr;

CControllerInput* CControllerInput::GetInstance()
{
	if (controllerInput == nullptr) {
		controllerInput = new CControllerInput();
	}

	return controllerInput;
}

void CControllerInput::FreeInstance(CControllerInput* controllerInputPtr)
{
	if (controllerInputPtr == controllerInput) {
		delete controllerInput;
		controllerInput = nullptr;
	}
}

CControllerInput::ControllerStateSnapshot CControllerInput::MakeControllerStateSnapshot(const ControllerState& state)
{
	ControllerStateSnapshot snapshot;
	snapshot.deviceId = state.deviceId;
	snapshot.instanceId = state.instanceId;
	snapshot.name = state.name;
	snapshot.axes = state.axes;
	snapshot.buttons = state.buttons;

	return snapshot;
}

std::vector<CControllerInput::ControllerStateSnapshot> CControllerInput::GetAvailableControllers() const
{
	std::vector<ControllerStateSnapshot> controllers;
	controllers.reserve(controllersByInstanceId.size());

	for (const auto& controllerIt : controllersByInstanceId) {
		controllers.push_back(MakeControllerStateSnapshot(controllerIt.second));
	}

	return controllers;
}

bool CControllerInput::GetControllerState(int instanceId, ControllerStateSnapshot& state) const
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return false;
	}

	state = MakeControllerStateSnapshot(controllerIt->second);
	return true;
}

#ifndef HEADLESS

CControllerInput::CControllerInput()
{
	if (SDL_InitSubSystem(SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER) != 0) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to initialize SDL joystick/gamecontroller subsystem: %s", SDL_GetError());
	} else {
		LOG_L(L_INFO, "[ControllerInput] SDL joystick/gamecontroller subsystem initialized");
	}

	SDL_GameControllerEventState(SDL_ENABLE);
	SDL_JoystickEventState(SDL_ENABLE);

	inputCon = input.AddHandler([this](const SDL_Event& event) {
		return this->HandleSDLControllerEvent(event);
	});

	LOG_L(L_INFO, "[ControllerInput] SDL_NumJoysticks at init: %d", SDL_NumJoysticks());
	ScanExistingControllers();

	LOG_L(L_INFO, "[ControllerInput] Initialized SDL controller input handler");
}

CControllerInput::~CControllerInput()
{
	for (auto& controllerIt : controllersByInstanceId) {
		auto& state = controllerIt.second;

		if (state.gameController != nullptr) {
			SDL_GameControllerClose(state.gameController);
			state.gameController = nullptr;
		}
	}

	controllersByInstanceId.clear();

	LOG_L(L_INFO, "[ControllerInput] Shutting down SDL controller input handler");
}

bool CControllerInput::HandleSDLControllerEvent(const SDL_Event& event)
{
	switch (event.type) {
		case SDL_CONTROLLERDEVICEADDED: {
			HandleDeviceAdded(event.cdevice.which);
		} break;

		case SDL_CONTROLLERDEVICEREMOVED: {
			HandleDeviceRemoved(event.cdevice.which);
		} break;

		case SDL_CONTROLLERDEVICEREMAPPED: {
			HandleDeviceRemapped(event.cdevice.which);
		} break;

		case SDL_CONTROLLERBUTTONDOWN: {
			HandleButtonDown(event.cbutton.which, event.cbutton.button, event.cbutton.state);
		} break;

		case SDL_CONTROLLERBUTTONUP: {
			HandleButtonUp(event.cbutton.which, event.cbutton.button, event.cbutton.state);
		} break;

		case SDL_CONTROLLERAXISMOTION: {
			HandleAxisMotion(event.caxis.which, event.caxis.axis, event.caxis.value);
		} break;

		default:
			break;
	}

	return false;
}

void CControllerInput::LogAvailableController(int deviceId) const
{
	if (SDL_IsGameController(deviceId)) {
		const char* name = SDL_GameControllerNameForIndex(deviceId);
		LOG_L(L_INFO, "[ControllerInput] SDL game controller available: deviceId=%d name=%s", deviceId, name != nullptr ? name : "unknown");
		return;
	}

	const char* name = SDL_JoystickNameForIndex(deviceId);
	LOG_L(L_INFO, "[ControllerInput] SDL joystick available but not game controller: deviceId=%d name=%s", deviceId, name != nullptr ? name : "unknown");
}

void CControllerInput::ScanExistingControllers()
{
	const int joystickCount = SDL_NumJoysticks();
	LOG_L(L_INFO, "[ControllerInput] Scanning existing SDL joysticks: count=%d", joystickCount);

	for (int deviceId = 0; deviceId < joystickCount; ++deviceId) {
		LogAvailableController(deviceId);

		if (SDL_IsGameController(deviceId)) {
			HandleDeviceAdded(deviceId);
			continue;
		}

		LOG_L(L_INFO, "[ControllerInput] Skipping existing non-game-controller device: deviceId=%d", deviceId);
	}
}

void CControllerInput::HandleDeviceAdded(int deviceId)
{
	LOG_L(L_INFO, "[ControllerInput] Controller device added: deviceId=%d", deviceId);
	LogAvailableController(deviceId);

	if (!SDL_IsGameController(deviceId)) {
		LOG_L(L_INFO, "[ControllerInput] Ignoring non-game-controller device: deviceId=%d", deviceId);
		return;
	}

	SDL_GameController* gameController = SDL_GameControllerOpen(deviceId);
	if (gameController == nullptr) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to open SDL game controller: deviceId=%d error=%s", deviceId, SDL_GetError());
		return;
	}

	SDL_Joystick* joystick = SDL_GameControllerGetJoystick(gameController);
	const int instanceId = joystick != nullptr ? SDL_JoystickInstanceID(joystick) : -1;

	if (instanceId < 0) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to get joystick instance id: deviceId=%d", deviceId);
		SDL_GameControllerClose(gameController);
		return;
	}

	ControllerState state;
	state.deviceId = deviceId;
	state.instanceId = instanceId;

	const char* name = SDL_GameControllerName(gameController);
	state.name = name != nullptr ? name : "unknown";
	state.gameController = gameController;

	auto existingIt = controllersByInstanceId.find(instanceId);
	if (existingIt != controllersByInstanceId.end() && existingIt->second.gameController != nullptr) {
		SDL_GameControllerClose(existingIt->second.gameController);
	}

	controllersByInstanceId[instanceId] = state;

	LOG_L(L_INFO, "[ControllerInput] Controller connected: deviceId=%d instanceId=%d name=%s", deviceId, instanceId, state.name.c_str());
}

void CControllerInput::HandleDeviceRemoved(int instanceId)
{
	LOG_L(L_INFO, "[ControllerInput] Controller device removed: instanceId=%d", instanceId);

	auto it = controllersByInstanceId.find(instanceId);
	if (it == controllersByInstanceId.end()) {
		return;
	}

	LOG_L(L_INFO, "[ControllerInput] Removed tracked controller: instanceId=%d name=%s", instanceId, it->second.name.c_str());

	if (it->second.gameController != nullptr) {
		SDL_GameControllerClose(it->second.gameController);
		it->second.gameController = nullptr;
	}

	controllersByInstanceId.erase(it);
}

void CControllerInput::HandleDeviceRemapped(int instanceId)
{
	LOG_L(L_INFO, "[ControllerInput] Controller remapped: instanceId=%d", instanceId);
}

void CControllerInput::HandleButtonDown(int instanceId, int buttonId, std::uint8_t value)
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return;
	}

	auto& state = controllerIt->second;

	if (buttonId >= 0 && buttonId < static_cast<int>(state.buttons.size())) {
		state.buttons[buttonId] = value;
	}

	LOG_L(L_INFO, "[ControllerInput] ButtonDown: instanceId=%d buttonId=%d value=%u", instanceId, buttonId, static_cast<unsigned int>(value));
}

void CControllerInput::HandleButtonUp(int instanceId, int buttonId, std::uint8_t value)
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return;
	}

	auto& state = controllerIt->second;

	if (buttonId >= 0 && buttonId < static_cast<int>(state.buttons.size())) {
		state.buttons[buttonId] = value;
	}

	LOG_L(L_INFO, "[ControllerInput] ButtonUp: instanceId=%d buttonId=%d value=%u", instanceId, buttonId, static_cast<unsigned int>(value));
}

void CControllerInput::HandleAxisMotion(int instanceId, int axisId, std::int16_t value)
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return;
	}

	auto& state = controllerIt->second;

	if (axisId >= 0 && axisId < static_cast<int>(state.axes.size())) {
		state.axes[axisId] = value;
	}

	LOG_L(L_INFO, "[ControllerInput] AxisMotion: instanceId=%d axisId=%d value=%d", instanceId, axisId, static_cast<int>(value));
}

#else

CControllerInput::CControllerInput() = default;
CControllerInput::~CControllerInput() = default;

bool CControllerInput::HandleSDLControllerEvent(const SDL_Event&)
{
	return false;
}

void CControllerInput::LogAvailableController(int) const {}
void CControllerInput::ScanExistingControllers() {}
void CControllerInput::HandleDeviceAdded(int) {}
void CControllerInput::HandleDeviceRemoved(int) {}
void CControllerInput::HandleDeviceRemapped(int) {}
void CControllerInput::HandleButtonDown(int, int, std::uint8_t) {}
void CControllerInput::HandleButtonUp(int, int, std::uint8_t) {}
void CControllerInput::HandleAxisMotion(int, int, std::int16_t) {}

#endif
```

---

## `rts/Game/UI/MouseHandler.cpp`

### Include added

```cpp
#include "System/Input/ControllerInput.h"
```

### Final `InitStatic()` / `KillStatic()` integration

```cpp
void CMouseHandler::InitStatic()
{
	RECOIL_DETAILED_TRACY_ZONE;
	assert(mouse == nullptr);
	assert(mouseInput == nullptr);
	assert(controllerInput == nullptr);

	mouseInput = IMouseInput::GetInstance(configHandler->GetBool("MouseRelativeModeWarp"));
	controllerInput = CControllerInput::GetInstance();
	mouse = new CMouseHandler();
}
void CMouseHandler::KillStatic()
{
	RECOIL_DETAILED_TRACY_ZONE;
	spring::SafeDelete(mouse);
	CControllerInput::FreeInstance(controllerInput);
	IMouseInput::FreeInstance(mouseInput);
}
```

---

## `rts/System/CMakeLists.txt`

Final source-list addition:

```cmake
"${CMAKE_CURRENT_SOURCE_DIR}/Input/ControllerInput.cpp"
```

Context:

```cmake
make_global_var(sources_engine_System_common
		"${CMAKE_CURRENT_SOURCE_DIR}/AABB.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/AIScriptHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Color.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigLocater.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigSource.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigVariable.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/CRC.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/EventClient.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/EventHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/GlobalConfig.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Info.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/ControllerInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/InputHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/KeyInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/MouseInput.cpp"
```

---

## `rts/Lua/LuaUnsyncedRead.h`

Final declarations added under the mouse state/read functions:

```cpp
static int GetAvailableControllers(lua_State* L);
static int GetControllerState(lua_State* L);
```

Context:

```cpp
		static int GetMouseButtonsPressed(lua_State* L);
		static int GetMouseState(lua_State* L);
		static int GetMouseCursor(lua_State* L);
		static int GetMouseStartPosition(lua_State* L);
		static int GetAvailableControllers(lua_State* L);
		static int GetControllerState(lua_State* L);

		static int GetKeyFromScanSymbol(lua_State* L);
		static int GetKeyState(lua_State* L);
		static int GetModKeyState(lua_State* L);
```

---

## `rts/Lua/LuaUnsyncedRead.cpp`

### Include added

```cpp
#include "System/Input/ControllerInput.h"
```

### Lua registration entries

```cpp
	REGISTER_LUA_CFUNC(GetAvailableControllers);
	REGISTER_LUA_CFUNC(GetControllerState);
```

Context:

```cpp
	REGISTER_LUA_CFUNC(GetMouseButtonsPressed);
	REGISTER_LUA_CFUNC(GetMouseState);
	REGISTER_LUA_CFUNC(GetMouseCursor);
	REGISTER_LUA_CFUNC(GetMouseStartPosition);
	REGISTER_LUA_CFUNC(GetAvailableControllers);
	REGISTER_LUA_CFUNC(GetControllerState);

	REGISTER_LUA_CFUNC(GetKeyFromScanSymbol);
	REGISTER_LUA_CFUNC(GetKeyState);
	REGISTER_LUA_CFUNC(GetModKeyState);
```

### Final controller Lua read implementation

```cpp
/******************************************************************************
 * Controller Input
 * @section controllerinput
******************************************************************************/

static void PushControllerInfo(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, 0, 3);
	HSTR_PUSH_NUMBER(L, "instanceId", controller.instanceId);
	HSTR_PUSH_NUMBER(L, "deviceId", controller.deviceId);
	HSTR_PUSH_STRING(L, "name", controller.name);
}

static void PushControllerButtons(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, static_cast<int>(controller.buttons.size()), 0);

	for (size_t buttonId = 0; buttonId < controller.buttons.size(); ++buttonId) {
		lua_pushnumber(L, controller.buttons[buttonId]);
		lua_rawseti(L, -2, static_cast<int>(buttonId));
	}
}

static void PushControllerAxes(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, static_cast<int>(controller.axes.size()), 0);

	for (size_t axisId = 0; axisId < controller.axes.size(); ++axisId) {
		lua_pushnumber(L, controller.axes[axisId]);
		lua_rawseti(L, -2, static_cast<int>(axisId));
	}
}

static void PushControllerState(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, 0, 4);
	HSTR_PUSH_NUMBER(L, "instanceId", controller.instanceId);
	HSTR_PUSH_STRING(L, "name", controller.name);

	HSTR_PUSH(L, "buttons");
	PushControllerButtons(L, controller);
	lua_rawset(L, -3);

	HSTR_PUSH(L, "axes");
	PushControllerAxes(L, controller);
	lua_rawset(L, -3);
}

/***
 *
 * @function Spring.GetAvailableControllers
 * @return { instanceId: number, deviceId: number, name: string }[] controllers
 */
int LuaUnsyncedRead::GetAvailableControllers(lua_State* L)
{
	if (controllerInput == nullptr) {
		lua_createtable(L, 0, 0);
		return 1;
	}

	const auto controllers = controllerInput->GetAvailableControllers();
	lua_createtable(L, static_cast<int>(controllers.size()), 0);

	for (size_t i = 0; i < controllers.size(); ++i) {
		PushControllerInfo(L, controllers[i]);
		lua_rawseti(L, -2, static_cast<int>(i + 1));
	}

	return 1;
}

/***
 *
 * @function Spring.GetControllerState
 * @param instanceId number
 * @return table? controllerState with 0-based `buttons` and `axes` tables keyed by SDL id
 */
int LuaUnsyncedRead::GetControllerState(lua_State* L)
{
	if (controllerInput == nullptr)
		return 0;

	const int instanceId = luaL_checkint(L, 1);

	CControllerInput::ControllerStateSnapshot controller;
	if (!controllerInput->GetControllerState(instanceId, controller))
		return 0;

	PushControllerState(L, controller);
	return 1;
}
```


---

## 15. Appendix: Full Final Code

This appendix preserves the final standalone code files uploaded in the archive. These files are the final code authority where they conflict with historical chat logs.

### 15.1 `ControllerInput.h`

````cpp
/* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#pragma once

#include <SDL_events.h>
#include <SDL_gamecontroller.h>

#include <array>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "System/Input/InputHandler.h"

class CControllerInput
{
public:
	static CControllerInput* GetInstance();
	static void FreeInstance(CControllerInput* controllerInput);

	CControllerInput();
	~CControllerInput();

	struct ControllerStateSnapshot {
		int deviceId = -1;
		int instanceId = -1;
		std::string name;

		std::array<std::int16_t, 16> axes = {};
		std::array<std::uint8_t, 32> buttons = {};
	};

	std::vector<ControllerStateSnapshot> GetAvailableControllers() const;
	bool GetControllerState(int instanceId, ControllerStateSnapshot& state) const;

	bool HandleSDLControllerEvent(const SDL_Event& event);

private:
	struct ControllerState {
		int deviceId = -1;
		int instanceId = -1;
		std::string name;

		SDL_GameController* gameController = nullptr;

		std::array<std::int16_t, 16> axes = {};
		std::array<std::uint8_t, 32> buttons = {};
	};

	static ControllerStateSnapshot MakeControllerStateSnapshot(const ControllerState& state);

	void LogAvailableController(int deviceId) const;
	void ScanExistingControllers();
	void HandleDeviceAdded(int deviceId);
	void HandleDeviceRemoved(int instanceId);
	void HandleDeviceRemapped(int instanceId);
	void HandleButtonDown(int instanceId, int buttonId, std::uint8_t value);
	void HandleButtonUp(int instanceId, int buttonId, std::uint8_t value);
	void HandleAxisMotion(int instanceId, int axisId, std::int16_t value);

private:
	InputHandler::HandlerTokenT inputCon;
	std::unordered_map<int, ControllerState> controllersByInstanceId;
};

extern CControllerInput* controllerInput;
````


### 15.2 `ControllerInput.cpp`

````cpp
/* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#include "ControllerInput.h"

#include "System/Input/InputHandler.h"
#include "System/Log/ILog.h"

#ifndef HEADLESS
#include <SDL.h>
#include <SDL_events.h>
#include <SDL_error.h>
#include <SDL_gamecontroller.h>
#include <SDL_joystick.h>
#endif

CControllerInput* controllerInput = nullptr;

CControllerInput* CControllerInput::GetInstance()
{
	if (controllerInput == nullptr) {
		controllerInput = new CControllerInput();
	}

	return controllerInput;
}

void CControllerInput::FreeInstance(CControllerInput* controllerInputPtr)
{
	if (controllerInputPtr == controllerInput) {
		delete controllerInput;
		controllerInput = nullptr;
	}
}

CControllerInput::ControllerStateSnapshot CControllerInput::MakeControllerStateSnapshot(const ControllerState& state)
{
	ControllerStateSnapshot snapshot;
	snapshot.deviceId = state.deviceId;
	snapshot.instanceId = state.instanceId;
	snapshot.name = state.name;
	snapshot.axes = state.axes;
	snapshot.buttons = state.buttons;

	return snapshot;
}

std::vector<CControllerInput::ControllerStateSnapshot> CControllerInput::GetAvailableControllers() const
{
	std::vector<ControllerStateSnapshot> controllers;
	controllers.reserve(controllersByInstanceId.size());

	for (const auto& controllerIt : controllersByInstanceId) {
		controllers.push_back(MakeControllerStateSnapshot(controllerIt.second));
	}

	return controllers;
}

bool CControllerInput::GetControllerState(int instanceId, ControllerStateSnapshot& state) const
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return false;
	}

	state = MakeControllerStateSnapshot(controllerIt->second);
	return true;
}

#ifndef HEADLESS

CControllerInput::CControllerInput()
{
	if (SDL_InitSubSystem(SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER) != 0) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to initialize SDL joystick/gamecontroller subsystem: %s", SDL_GetError());
	} else {
		LOG_L(L_INFO, "[ControllerInput] SDL joystick/gamecontroller subsystem initialized");
	}

	SDL_GameControllerEventState(SDL_ENABLE);
	SDL_JoystickEventState(SDL_ENABLE);

	inputCon = input.AddHandler([this](const SDL_Event& event) {
		return this->HandleSDLControllerEvent(event);
	});

	LOG_L(L_INFO, "[ControllerInput] SDL_NumJoysticks at init: %d", SDL_NumJoysticks());
	ScanExistingControllers();

	LOG_L(L_INFO, "[ControllerInput] Initialized SDL controller input handler");
}

CControllerInput::~CControllerInput()
{
	for (auto& controllerIt : controllersByInstanceId) {
		auto& state = controllerIt.second;

		if (state.gameController != nullptr) {
			SDL_GameControllerClose(state.gameController);
			state.gameController = nullptr;
		}
	}

	controllersByInstanceId.clear();

	LOG_L(L_INFO, "[ControllerInput] Shutting down SDL controller input handler");
}

bool CControllerInput::HandleSDLControllerEvent(const SDL_Event& event)
{
	switch (event.type) {
		case SDL_CONTROLLERDEVICEADDED: {
			HandleDeviceAdded(event.cdevice.which);
		} break;

		case SDL_CONTROLLERDEVICEREMOVED: {
			HandleDeviceRemoved(event.cdevice.which);
		} break;

		case SDL_CONTROLLERDEVICEREMAPPED: {
			HandleDeviceRemapped(event.cdevice.which);
		} break;

		case SDL_CONTROLLERBUTTONDOWN: {
			HandleButtonDown(event.cbutton.which, event.cbutton.button, event.cbutton.state);
		} break;

		case SDL_CONTROLLERBUTTONUP: {
			HandleButtonUp(event.cbutton.which, event.cbutton.button, event.cbutton.state);
		} break;

		case SDL_CONTROLLERAXISMOTION: {
			HandleAxisMotion(event.caxis.which, event.caxis.axis, event.caxis.value);
		} break;

		default:
			break;
	}

	return false;
}

void CControllerInput::LogAvailableController(int deviceId) const
{
	if (SDL_IsGameController(deviceId)) {
		const char* name = SDL_GameControllerNameForIndex(deviceId);
		LOG_L(L_INFO, "[ControllerInput] SDL game controller available: deviceId=%d name=%s", deviceId, name != nullptr ? name : "unknown");
		return;
	}

	const char* name = SDL_JoystickNameForIndex(deviceId);
	LOG_L(L_INFO, "[ControllerInput] SDL joystick available but not game controller: deviceId=%d name=%s", deviceId, name != nullptr ? name : "unknown");
}

void CControllerInput::ScanExistingControllers()
{
	const int joystickCount = SDL_NumJoysticks();
	LOG_L(L_INFO, "[ControllerInput] Scanning existing SDL joysticks: count=%d", joystickCount);

	for (int deviceId = 0; deviceId < joystickCount; ++deviceId) {
		LogAvailableController(deviceId);

		if (SDL_IsGameController(deviceId)) {
			HandleDeviceAdded(deviceId);
			continue;
		}

		LOG_L(L_INFO, "[ControllerInput] Skipping existing non-game-controller device: deviceId=%d", deviceId);
	}
}

void CControllerInput::HandleDeviceAdded(int deviceId)
{
	LOG_L(L_INFO, "[ControllerInput] Controller device added: deviceId=%d", deviceId);
	LogAvailableController(deviceId);

	if (!SDL_IsGameController(deviceId)) {
		LOG_L(L_INFO, "[ControllerInput] Ignoring non-game-controller device: deviceId=%d", deviceId);
		return;
	}

	SDL_GameController* gameController = SDL_GameControllerOpen(deviceId);
	if (gameController == nullptr) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to open SDL game controller: deviceId=%d error=%s", deviceId, SDL_GetError());
		return;
	}

	SDL_Joystick* joystick = SDL_GameControllerGetJoystick(gameController);
	const int instanceId = joystick != nullptr ? SDL_JoystickInstanceID(joystick) : -1;

	if (instanceId < 0) {
		LOG_L(L_WARNING, "[ControllerInput] Failed to get joystick instance id: deviceId=%d", deviceId);
		SDL_GameControllerClose(gameController);
		return;
	}

	ControllerState state;
	state.deviceId = deviceId;
	state.instanceId = instanceId;

	const char* name = SDL_GameControllerName(gameController);
	state.name = name != nullptr ? name : "unknown";
	state.gameController = gameController;

	auto existingIt = controllersByInstanceId.find(instanceId);
	if (existingIt != controllersByInstanceId.end() && existingIt->second.gameController != nullptr) {
		SDL_GameControllerClose(existingIt->second.gameController);
	}

	controllersByInstanceId[instanceId] = state;

	LOG_L(L_INFO, "[ControllerInput] Controller connected: deviceId=%d instanceId=%d name=%s", deviceId, instanceId, state.name.c_str());
}

void CControllerInput::HandleDeviceRemoved(int instanceId)
{
	LOG_L(L_INFO, "[ControllerInput] Controller device removed: instanceId=%d", instanceId);

	auto it = controllersByInstanceId.find(instanceId);
	if (it == controllersByInstanceId.end()) {
		return;
	}

	LOG_L(L_INFO, "[ControllerInput] Removed tracked controller: instanceId=%d name=%s", instanceId, it->second.name.c_str());

	if (it->second.gameController != nullptr) {
		SDL_GameControllerClose(it->second.gameController);
		it->second.gameController = nullptr;
	}

	controllersByInstanceId.erase(it);
}

void CControllerInput::HandleDeviceRemapped(int instanceId)
{
	LOG_L(L_INFO, "[ControllerInput] Controller remapped: instanceId=%d", instanceId);
}

void CControllerInput::HandleButtonDown(int instanceId, int buttonId, std::uint8_t value)
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return;
	}

	auto& state = controllerIt->second;

	if (buttonId >= 0 && buttonId < static_cast<int>(state.buttons.size())) {
		state.buttons[buttonId] = value;
	}

	LOG_L(L_INFO, "[ControllerInput] ButtonDown: instanceId=%d buttonId=%d value=%u", instanceId, buttonId, static_cast<unsigned int>(value));
}

void CControllerInput::HandleButtonUp(int instanceId, int buttonId, std::uint8_t value)
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return;
	}

	auto& state = controllerIt->second;

	if (buttonId >= 0 && buttonId < static_cast<int>(state.buttons.size())) {
		state.buttons[buttonId] = value;
	}

	LOG_L(L_INFO, "[ControllerInput] ButtonUp: instanceId=%d buttonId=%d value=%u", instanceId, buttonId, static_cast<unsigned int>(value));
}

void CControllerInput::HandleAxisMotion(int instanceId, int axisId, std::int16_t value)
{
	auto controllerIt = controllersByInstanceId.find(instanceId);
	if (controllerIt == controllersByInstanceId.end()) {
		return;
	}

	auto& state = controllerIt->second;

	if (axisId >= 0 && axisId < static_cast<int>(state.axes.size())) {
		state.axes[axisId] = value;
	}

	LOG_L(L_INFO, "[ControllerInput] AxisMotion: instanceId=%d axisId=%d value=%d", instanceId, axisId, static_cast<int>(value));
}

#else

CControllerInput::CControllerInput() = default;
CControllerInput::~CControllerInput() = default;

bool CControllerInput::HandleSDLControllerEvent(const SDL_Event&)
{
	return false;
}

void CControllerInput::LogAvailableController(int) const {}
void CControllerInput::ScanExistingControllers() {}
void CControllerInput::HandleDeviceAdded(int) {}
void CControllerInput::HandleDeviceRemoved(int) {}
void CControllerInput::HandleDeviceRemapped(int) {}
void CControllerInput::HandleButtonDown(int, int, std::uint8_t) {}
void CControllerInput::HandleButtonUp(int, int, std::uint8_t) {}
void CControllerInput::HandleAxisMotion(int, int, std::int16_t) {}

#endif
````


### 15.3 `CMakeLists.txt`

````cmake

if (TRACY_PROFILE_MEMORY)
	set(memoryProfileSource "${CMAKE_CURRENT_SOURCE_DIR}/TraceMemory.cpp")
endif()

# This list was created using this *nix shell command:
# > find . -name "*.cpp" -or -name "*.c" | sort
# Then Sound/ stuff was removed, because it is now a separate static lib.

make_global_var(sources_engine_System_common
		"${CMAKE_CURRENT_SOURCE_DIR}/AABB.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/AIScriptHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Color.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigLocater.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigSource.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Config/ConfigVariable.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/CRC.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/EventClient.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/EventHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/GlobalConfig.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Info.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/ControllerInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/InputHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/KeyInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Input/MouseInput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/CregLoadSaveHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/Demo.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/DemoReader.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/DemoRecorder.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/LoadSaveHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LoadSave/LuaLoadSaveHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/LogOutput.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Main.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Math/SpringDampers.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Math/NURBS.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Matrix44f.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Quaternion.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Misc/RectangleOverlapHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Misc/SpringTime.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Object.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/GameLoadThread.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Option.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Clipboard.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/errorhandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Misc.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/ScopedFileLock.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/SDL1_keysym.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Watchdog.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/WindowManagerHelper.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Rectangle.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/SafeVector.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/SafeCStrings.c"
		"${CMAKE_CURRENT_SOURCE_DIR}/SplashScreen.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/SpringApp.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/StartScriptGen.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/DumpState.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/DumpHistory.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/FPUCheck.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/Logger.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/SHA512.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/SyncChecker.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/SyncDebugger.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/SyncedFloat3.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/backtrace.c"
		"${CMAKE_CURRENT_SOURCE_DIR}/Sync/get_executable_name.c"
		"${CMAKE_CURRENT_SOURCE_DIR}/TdfParser.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Threading/ThreadPool.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/TimeProfiler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/TimeUtil.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Transform.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/UriParser.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/StringUtil.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/type2.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/float3.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/float4.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/SpringMath.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/SpringMem.cpp"
		"${memoryProfileSource}"
	)
if    (NO_CREG)
	make_global_var(sources_engine_System_creg )
else  (NO_CREG)
	make_global_var(sources_engine_System_creg
			"${CMAKE_CURRENT_SOURCE_DIR}/creg/SerializeLuaState.cpp"
			"${CMAKE_CURRENT_SOURCE_DIR}/creg/Serializer.cpp"
			"${CMAKE_CURRENT_SOURCE_DIR}/creg/VarTypes.cpp"
			"${CMAKE_CURRENT_SOURCE_DIR}/creg/creg.cpp"
			"${CMAKE_CURRENT_SOURCE_DIR}/creg/creg_runtime_tests.cpp"
		)
endif (NO_CREG)
make_global_var(sources_engine_System_FileSystem
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/ArchiveNameResolver.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/ArchiveLoader.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/ArchiveScanner.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/CacheDir.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/DataDirLocater.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/DataDirsAccess.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/FileFilter.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/FileHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/FileSystem.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/FileSystemAbstraction.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/FileSystemInitializer.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/GZFileHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/Misc.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/RapidHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/SimpleParser.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/FileSystem/VFSHandler.cpp"
	)
make_global_var(sources_engine_System_Log
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/Backend.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/DefaultFilter.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/DefaultFormatter.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/FramePrefixer.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/LogSinkHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/LogUtil.c"
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/TracySink.cpp"
	)
make_global_var(sources_engine_System_Log_sinkStream
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/StreamSink.cpp"
	)
make_global_var(sources_engine_System_Log_sinkConsole
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/ConsoleSink.cpp"
	)
make_global_var(sources_engine_System_Log_sinkFile
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/FileSink.cpp"
	)
make_global_var(sources_engine_System_Log_sinkOutputDebugString
		"${CMAKE_CURRENT_SOURCE_DIR}/Log/OutputDebugStringSink.cpp"
	)

# Warning: sources_engine_System_Platform_* is not used by spring-dedicated
set(sources_engine_System_Platform_Linux
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/CrashHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/Hardware.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/SoLib.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/MessageBox.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/WindowManagerHelper.cpp"
	)
set(sources_engine_System_Platform_Mac
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/Hardware.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/SoLib.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Mac/MessageBox.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Mac/CrashHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Mac/WindowManagerHelper.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/ThreadSupport.cpp"
	)
set(sources_engine_System_Platform_Windows
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/CrashHandler.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/Hardware.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/MessageBox.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/seh.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/WinVersion.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/WindowManagerHelper.cpp"
	)

set(sources_engine_System_Threading_Mac
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Mac/Signal.cpp"
	)
set(sources_engine_System_Threading_Linux
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/CpuTopology.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/Futex.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/ThreadSupport.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Linux/SoLib.cpp"
	)
set(sources_engine_System_Threading_Windows
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/CpuTopology.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/CriticalSection.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/Future.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Win/DllLib.cpp"
	)


if(CMAKE_VERSION VERSION_GREATER 3.1.2)
	target_sources(platform_sources
		PRIVATE
			${sources_engine_System_Platform_Windows}
			${sources_engine_System_Platform_Linux}
			${sources_engine_System_Platform_Mac}
			${sources_engine_System_Threading_Windows}
			${sources_engine_System_Threading_Linux}
			${sources_engine_System_Threading_Mac}
		)
endif()

set(sources_engine_System_Threading
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/CpuID.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/Threading.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/ThreadAffinityGuard.cpp"
		"${CMAKE_CURRENT_SOURCE_DIR}/Platform/SharedLib.cpp"
	)

set(sources_engine_System
		${sources_engine_System_common}
		${sources_engine_System_creg}
		${sources_engine_System_FileSystem}
		${sources_engine_System_Log}
		${sources_engine_System_Log_sinkConsole}
		${sources_engine_System_Log_sinkFile}
	)


### only use the target platform related directory
if     (APPLE)
	make_global_var(sources_engine_System_Threading ${sources_engine_System_Threading} ${sources_engine_System_Threading_Mac})
	make_global_var(sources_engine_System
			${sources_engine_System}
			${sources_engine_System_Platform_Mac}
			${sources_engine_System_Threading}
		)
elseif (UNIX)
	make_global_var(sources_engine_System_Threading ${sources_engine_System_Threading} ${sources_engine_System_Threading_Linux})
	make_global_var(sources_engine_System
			${sources_engine_System}
			${sources_engine_System_Platform_Linux}
			${sources_engine_System_Threading}
		)

elseif (WIN32)
	make_global_var(sources_engine_System_Threading ${sources_engine_System_Threading} ${sources_engine_System_Threading_Windows})
	make_global_var(sources_engine_System
			${sources_engine_System}
			${sources_engine_System_Log_sinkOutputDebugString}
			${sources_engine_System_Platform_Windows}
			${sources_engine_System_Threading}
		)
else()
	make_global_var(sources_engine_System
			${sources_engine_System}
			${sources_engine_System_Threading}
		)
endif  ()


add_subdirectory(FileSystem)
add_subdirectory(Net)
````


### 15.4 `MouseHandler.cpp`

````cpp
 /* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#include "MouseHandler.h"

#include "CommandColors.h"
#include "System/Input/ControllerInput.h"
#include "InputReceiver.h"
#include "GuiHandler.h"
#include "MiniMap.h"
#include "MouseCursor.h"
#include "TooltipConsole.h"
#include "Game/CameraHandler.h"
#include "Game/Camera.h"
#include "Game/Game.h"
#include "Game/GlobalUnsynced.h"
#include "Game/InMapDraw.h"
#include "Game/SelectedUnitsHandler.h"
#include "Game/TraceRay.h"
#include "Game/Camera/CameraController.h"
#include "Game/Players/Player.h"
#include "Game/Players/PlayerHandler.h"
#include "Game/UI/UnitTracker.h"
#include "Lua/LuaInputReceiver.h"
#include "Map/Ground.h"
#include "Rendering/GlobalRendering.h"
#include "Rendering/Fonts/glFont.h"
#include "Rendering/GL/myGL.h"
#include "Rendering/GL/RenderBuffers.h"
#include "Rendering/GL/SubState.h"
#include "Rendering/Textures/Bitmap.h"
#include "Sim/Features/Feature.h"
#include "Sim/Units/Unit.h"
#include "Game/UI/Groups/Group.h"
#include "System/Config/ConfigHandler.h"
#include "System/EventHandler.h"
#include "System/Exceptions.h"
#include "System/FastMath.h"
#include "System/SpringMath.h"
#include "System/SafeUtil.h"
#include "System/StringUtil.h"
#include "System/Input/KeyInput.h"
#include "System/Input/MouseInput.h"
#include "Rml/Backends/RmlUi_Backend.h"

#include "System/Misc/TracyDefs.h"

#include <algorithm>

// can't be up there since those contain conflicting definitions
#include <SDL_mouse.h>
#include <SDL_events.h>
#include <SDL_keycode.h>

using namespace GL::State;


CONFIG(bool, HardwareCursor).defaultValue(false).description("Sets hardware mouse cursor rendering. If you have a low framerate, your mouse cursor will seem \"laggy\". Setting hardware cursor will render the mouse cursor separately from spring and the mouse will behave normally. Note, not all GPU drivers support it in fullscreen mode!");
CONFIG(bool, InvertMouse).defaultValue(false);
CONFIG(bool, MouseRelativeModeWarp).defaultValue(true);
CONFIG(bool, MiniMapMouseWheel).defaultValue(false).description("Whether MiniMap responds to MouseWheel events");

CONFIG(float, CrossSize).defaultValue(12.0f);
CONFIG(float, CrossAlpha).defaultValue(0.5f);
CONFIG(float, CrossMoveScale).defaultValue(1.0f);

CONFIG(float, DoubleClickTime).defaultValue(200.0f).description("Double click time in milliseconds.");
CONFIG(float, ScrollWheelSpeed).defaultValue(-25.0f).minimumValue(-255.f).maximumValue(255.f);

CONFIG(float, MouseDragScrollThreshold).defaultValue(0.3f);
CONFIG(int, MouseDragSelectionThreshold).defaultValue(4).description("Distance in pixels which the mouse must be dragged to trigger a selection box.");
CONFIG(int, MouseDragCircleCommandThreshold).defaultValue(4).description("Distance in pixels which the mouse must be dragged to trigger a circular area command.");
CONFIG(int, MouseDragBoxCommandThreshold).defaultValue(16).description("Distance in pixels which the mouse must be dragged to trigger a rectangular area command.");
CONFIG(int, MouseDragFrontCommandThreshold).defaultValue(30).description("Distance in pixels which the mouse must be dragged to trigger a formation front command.");

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMouseHandler* mouse = nullptr;

static CInputReceiver*& activeReceiver = CInputReceiver::GetActiveReceiverRef();


CMouseHandler::CMouseHandler()
{
	const int2 viewMouseCenter = GetViewMouseCenter();

	lastx = viewMouseCenter.x;
	lasty = viewMouseCenter.y;

	UpdateCursorCameraDir();

#ifndef __APPLE__
	hardwareCursor = configHandler->GetBool("HardwareCursor");
#endif

	crossSize      = configHandler->GetFloat("CrossSize");
	crossAlpha     = configHandler->GetFloat("CrossAlpha");
	crossMoveScale = configHandler->GetFloat("CrossMoveScale") * 0.005f;

	doubleClickTime = configHandler->GetFloat("DoubleClickTime") / 1000.0f;

	ConfigUpdate();

	configHandler->NotifyOnChange(this, {
		"MiniMapMouseWheel",
		"MouseDragScrollThreshold",
		"MouseDragSelectionThreshold",
		"MouseDragBoxCommandThreshold",
		"MouseDragCircleCommandThreshold",
		"MouseDragFrontCommandThreshold",
		"InvertMouse",
		"ScrollWheelSpeed",
	});
}

CMouseHandler::~CMouseHandler()
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (hwHideCursor)
		SDL_ShowCursor(SDL_ENABLE);

	configHandler->RemoveObserver(this);
}


void CMouseHandler::InitStatic()
{
	RECOIL_DETAILED_TRACY_ZONE;
	assert(mouse == nullptr);
	assert(mouseInput == nullptr);
	assert(controllerInput == nullptr);

	mouseInput = IMouseInput::GetInstance(configHandler->GetBool("MouseRelativeModeWarp"));
	controllerInput = CControllerInput::GetInstance();
	mouse = new CMouseHandler();
}
void CMouseHandler::KillStatic()
{
	RECOIL_DETAILED_TRACY_ZONE;
	spring::SafeDelete(mouse);
	CControllerInput::FreeInstance(controllerInput);
	IMouseInput::FreeInstance(mouseInput);
}

void CMouseHandler::ReloadCursors()
{
	RECOIL_DETAILED_TRACY_ZONE;
	const CMouseCursor::HotSpot mCenter  = CMouseCursor::Center;
	const CMouseCursor::HotSpot mTopLeft = CMouseCursor::TopLeft;

	activeCursorIdx = -1;

	loadedCursors.clear();
	loadedCursors.reserve(32);
	// null-cursor; always lives at index 0
	loadedCursors.emplace_back();

	cursorCommandMap.clear();
	cursorCommandMap.reserve(32);
	cursorFileMap.clear();
	cursorFileMap.reserve(32);
	activeCursorName.clear();
	queuedCursorName.clear();

	cursorCommandMap["none"] = loadedCursors.size() - 1;
	cursorFileMap["null"] = loadedCursors.size() - 1;

	AssignMouseCursor("",             "cursornormal",     mTopLeft, false);

	AssignMouseCursor("Area attack",  "cursorareaattack", mCenter,  false);
	AssignMouseCursor("Area attack",  "cursorattack",     mCenter,  false); // backup

	AssignMouseCursor("Attack",       "cursorattack",     mCenter,  false);
	AssignMouseCursor("AttackBad",    "cursorattackbad",  mCenter,  false);
	AssignMouseCursor("AttackBad",    "cursorattack",     mCenter,  false); // backup
	AssignMouseCursor("BuildBad",     "cursorbuildbad",   mCenter,  false);
	AssignMouseCursor("BuildGood",    "cursorbuildgood",  mCenter,  false);
	AssignMouseCursor("Capture",      "cursorcapture",    mCenter,  false);
	AssignMouseCursor("Centroid",     "cursorcentroid",   mCenter,  false);

	AssignMouseCursor("DeathWait",    "cursordwatch",     mCenter,  false);
	AssignMouseCursor("DeathWait",    "cursorwait",       mCenter,  false); // backup

	AssignMouseCursor("ManualFire",   "cursormanfire",    mCenter,  false);
	AssignMouseCursor("ManualFire",   "cursordgun",       mCenter,  false); // backup (backward compatibility)
	AssignMouseCursor("ManualFire",   "cursorattack",     mCenter,  false); // backup

	AssignMouseCursor("Fight",        "cursorfight",      mCenter,  false);
	AssignMouseCursor("Fight",        "cursorattack",     mCenter,  false); // backup

	AssignMouseCursor("GatherWait",   "cursorgather",     mCenter,  false);
	AssignMouseCursor("GatherWait",   "cursorwait",       mCenter,  false); // backup

	AssignMouseCursor("Guard",        "cursordefend",     mCenter,  false);
	AssignMouseCursor("Load units",   "cursorpickup",     mCenter,  false);
	AssignMouseCursor("Move",         "cursormove",       mCenter,  false);
	AssignMouseCursor("Patrol",       "cursorpatrol",     mCenter,  false);
	AssignMouseCursor("Reclaim",      "cursorreclamate",  mCenter,  false);
	AssignMouseCursor("Repair",       "cursorrepair",     mCenter,  false);

	AssignMouseCursor("Resurrect",    "cursorrevive",     mCenter,  false);
	AssignMouseCursor("Resurrect",    "cursorrepair",     mCenter,  false); // backup

	AssignMouseCursor("Restore",      "cursorrestore",    mCenter,  false);
	AssignMouseCursor("Restore",      "cursorrepair",     mCenter,  false); // backup

	AssignMouseCursor("SelfD",        "cursorselfd",      mCenter,  false);

	AssignMouseCursor("SquadWait",    "cursornumber",     mCenter,  false);
	AssignMouseCursor("SquadWait",    "cursorwait",       mCenter,  false); // backup

	AssignMouseCursor("TimeWait",     "cursortime",       mCenter,  false);
	AssignMouseCursor("TimeWait",     "cursorwait",       mCenter,  false); // backup

	AssignMouseCursor("Unload units", "cursorunload",     mCenter,  false);
	AssignMouseCursor("Wait",         "cursorwait",       mCenter,  false);

	// the default cursor must exist
	const auto defCursorIt = cursorCommandMap.find("");

	if (defCursorIt == cursorCommandMap.end()) {
		throw content_error(
			"Unable to load default cursor. Check that you have the required\n"
			"content packages installed in your Spring \"base/\" directory.\n");
	}

	activeCursorIdx = defCursorIt->second;
}

void CMouseHandler::WindowEnter()
{
	RECOIL_DETAILED_TRACY_ZONE;
	offscreen = false;
}

void CMouseHandler::WindowLeave()
{
	RECOIL_DETAILED_TRACY_ZONE;
	offscreen = true;

	const int2 viewMouseCenter = GetViewMouseCenter();

	lastx = viewMouseCenter.x;
	lasty = viewMouseCenter.y;
}


/******************************************************************************/

void CMouseHandler::MouseMove(int x, int y, int dx, int dy)
{
	RECOIL_DETAILED_TRACY_ZONE;
	// FIXME: don't update if locked?
	lastx = x;
	// Origin for mousecursor on internal coordinates is top border of view screen
	lasty = y - globalRendering->viewWindowOffsetY;

	UpdateCursorCameraDir();

	// switching to MMB-mode while user is moving mouse can generate
	// a spurious event in the opposite direction (if cursor happens
	// to pass the center pixel) which would cause a camera position
	// jump, so always ignore one SDL_MOUSEMOTION after entering it
	dx *= (1 - ignoreMove);
	dy *= (1 - ignoreMove);

	ignoreMove = false;

	// calculating deltas (scroll{x,y} = last{x,y} - screenCenter.{x,y})
	// is not required when using relative motion mode, can add directly
	scrollx += (dx * hideCursor);
	scrolly += (dy * hideCursor);

	if (locked) {
		camHandler->GetCurrentController().MouseMove(float3(dx, dy, invertMouse ? -1.0f : 1.0f));
		return;
	}

	const int movedPixels = (int)fastmath::sqrt_sse(float(dx*dx + dy*dy));
	buttons[SDL_BUTTON_LEFT ].movement += movedPixels;
	buttons[SDL_BUTTON_RIGHT].movement += movedPixels;

	if (game != nullptr && !game->IsGameOver())
		playerHandler.Player(gu->myPlayerNum)->currentStats.mousePixels += movedPixels;

	/* Only want to give a mouse event to RmlUI if the mouse isn't currently performing a drag.
	 * Otherwise box selections get stuck when the mouse goes over an Rml element.
	 * Flags that ButtonPressed() checks are not set when clicking on Rml element. */
	if (!ButtonPressed() && RmlGui::ProcessMouseMove(x, lasty, dx, dy, activeButtonIdx)) {
		return;
	}

	if (activeReceiver != nullptr)
		activeReceiver->MouseMove(x, lasty, dx, dy, activeButtonIdx);

	if (inMapDrawer != nullptr && inMapDrawer->IsDrawMode())
		inMapDrawer->MouseMove(x, lasty, dx, dy, activeButtonIdx);

	if (buttons[SDL_BUTTON_MIDDLE].pressed && (activeReceiver == nullptr)) {
		camHandler->GetCurrentController().MouseMove(float3(dx, dy, invertMouse ? -1.0f : 1.0f));
		if (!camHandler->GetActiveCamera()->GetMovState()[CCamera::MOVE_STATE_RTT]) {
			unitTracker.Disable();
		}
		return;
	}
}


void CMouseHandler::MousePress(int x, int y, int button)
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (button > NUM_BUTTONS)
		return;

	// Origin for mousecursor on internal coordinates is lower border of view screen
	y = y - globalRendering->viewWindowOffsetY;

	if (game != nullptr && !game->IsGameOver())
		playerHandler.Player(gu->myPlayerNum)->currentStats.mouseClicks++;

	if (RmlGui::ProcessMousePress(x, y, button)) {
		return;
	}

	activeButtonIdx = button;
	ButtonPressEvt& bp = buttons[activeButtonIdx];
	bp.chorded  = (buttons[SDL_BUTTON_LEFT].pressed || buttons[SDL_BUTTON_RIGHT].pressed);
	bp.pressed  = true;
	bp.time     = gu->gameTime;
	bp.x        = x;
	bp.y        = y;
	bp.camPos   = camera->GetPos();
	bp.dir      = (dir = GetCursorCameraDir(x, y));
	bp.movement = 0;

	pressedBitMask |= 1 << button;

	if (activeReceiver != nullptr && activeReceiver->MousePress(x, y, button))
		return;

	if (inMapDrawer != nullptr && inMapDrawer->IsDrawMode()) {
		inMapDrawer->MousePress(x, y, button);
		return;
	}

	if (button == SDL_BUTTON_MIDDLE && locked)
		return;

	if (luaInputReceiver->MousePress(x, y, button)) {
		if (activeReceiver == nullptr)
			activeReceiver = luaInputReceiver;
		return;
	}

	if (game != nullptr && !game->hideInterface) {
		for (CInputReceiver* recv: CInputReceiver::GetReceivers()) {
			if (recv != nullptr && recv->MousePress(x, y, button)) {
				if (activeReceiver == nullptr)
					activeReceiver = recv;

				return;
			}
		}

	}

	auto activeControllerReceiver = (activeController == nullptr) ? nullptr : activeController->GetInputReceiver();
	if (button >= ACTION_BUTTON_MIN && activeControllerReceiver && activeControllerReceiver->MousePress(x, y, button)) {
		activeReceiver = activeControllerReceiver;
		return;
	}

	if (game != nullptr && !game->hideInterface) {
		// skip guihandler in this case
		return;
	}

	if (guihandler != nullptr && guihandler->MousePress(x, y, button)) {
		if (activeReceiver == nullptr)
			activeReceiver = guihandler; // for default (rmb) commands
	}
}

/**
 * GetSelectionBoxVertices
 *  returns the vertices of the SelectionBox in (cam->right, cam->up)-space
 */
bool CMouseHandler::GetSelectionBoxVertices(float3& bl, float3& br, float3& tl, float3& tr) const
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (activeReceiver != nullptr)
		return false;

	if (RmlGui::IsMouseInteractingWith()) {
		return false;
	}

	if (gu->fpsMode)
		return false;

	if (inMapDrawer != nullptr && inMapDrawer->IsDrawMode())
		return false;

	const ButtonPressEvt& bp = buttons[SDL_BUTTON_LEFT];

	if (!bp.pressed)
		return false;
	if (bp.chorded)
		return false;
	if (bp.movement <= dragSelectionThreshold)
		return false;

	float2 topRight, bttmLeft;

	GetSelectionBoxCoeff(bp.camPos, bp.dir, camera->GetPos(), dir, topRight, bttmLeft);

	// do not let the rectangle verts be clipped
	const float dirScale = camera->GetNearPlaneDist() * 2.0f;

	const float3 xmin   = camera->GetRight() * bttmLeft.x;
	const float3 xmax   = camera->GetRight() * topRight.x;
	const float3 ymin   = camera->GetUp()    * bttmLeft.y;
	const float3 ymax   = camera->GetUp()    * topRight.y;

	bl = camera->GetPos() + (xmin + ymin + camera->GetForward()) * dirScale;
	tr = camera->GetPos() + (xmax + ymax + camera->GetForward()) * dirScale;
	br = camera->GetPos() + (xmax + ymin + camera->GetForward()) * dirScale;
	tl = camera->GetPos() + (xmin + ymax + camera->GetForward()) * dirScale;

	return true;
}
/**
 * GetSelectionBoxCoeff
 *  returns the topright & bottomleft corner positions of the SelectionBox in (cam->right, cam->up)-space
 */
void CMouseHandler::GetSelectionBoxCoeff(
	const float3& pos1,
	const float3& dir1,
	const float3& pos2,
	const float3& dir2,
	float2& topright,
	float2& bttmleft
) {
	const float maxDist = camera->GetFarPlaneDist() * 1.4f;

	float pos1Dist = CGround::LineGroundCol(pos1, pos1 + dir1 * maxDist, false);
	float pos2Dist = CGround::LineGroundCol(pos2, pos2 + dir2 * maxDist, false);

	if (pos1Dist < 0.0f)
		pos1Dist = maxDist;
	if (pos2Dist < 0.0f)
		pos2Dist = maxDist;

	const float3 gpos1 = pos1 + dir1 * pos1Dist;
	const float3 gpos2 = pos2 + dir2 * pos2Dist;

	const float3 cdir1 = (gpos1 - camera->GetPos()).ANormalize();
	const float3 cdir2 = (gpos2 - camera->GetPos()).ANormalize();

	float cdir1_fw = cdir1.dot(camera->GetDir());
	float cdir2_fw = cdir2.dot(camera->GetDir());

	// prevent DivByZero
	cdir1_fw = std::max(std::fabs(cdir1_fw), 0.001f) * std::copysign(1.0f, cdir1_fw);
	cdir2_fw = std::max(std::fabs(cdir2_fw), 0.001f) * std::copysign(1.0f, cdir2_fw);

	// one corner of the rectangle
	topright.x = cdir1.dot(camera->GetRight()) / cdir1_fw;
	topright.y = cdir1.dot(camera->GetUp())    / cdir1_fw;

	// opposite corner
	bttmleft.x = cdir2.dot(camera->GetRight()) / cdir2_fw;
	bttmleft.y = cdir2.dot(camera->GetUp())    / cdir2_fw;

	// sort coeff so topright really is the topright corner
	if (topright.x < bttmleft.x) std::swap(topright.x, bttmleft.x);
	if (topright.y < bttmleft.y) std::swap(topright.y, bttmleft.y);
}


void CMouseHandler::MouseRelease(int x, int y, int button)
{
	RECOIL_DETAILED_TRACY_ZONE;
	const CUnit *_lastClicked = lastClicked;
	lastClicked = nullptr;

	if (button > NUM_BUTTONS)
		return;

	// Origin for mousecursor on internal coordinates is lower border of view screen
	y = y - globalRendering->viewWindowOffsetY;

	dir = GetCursorCameraDir(x, y);

	buttons[button].pressed = false;
	pressedBitMask &= ~(1 << button);

	if (inMapDrawer != nullptr && inMapDrawer->IsDrawMode()) {
		inMapDrawer->MouseRelease(x, y, button);
		return;
	}

	if (RmlGui::ProcessMouseRelease(x, y, button)) {
		return;
	}

	if (activeReceiver != nullptr) {
		activeReceiver->MouseRelease(x, y, button);

		if (!buttons[SDL_BUTTON_LEFT].pressed && !buttons[SDL_BUTTON_MIDDLE].pressed && !buttons[SDL_BUTTON_RIGHT].pressed)
			activeReceiver = nullptr;

		return;
	}

	if (button >= ACTION_BUTTON_MIN && activeController != nullptr && activeController->MouseRelease(x, y, button)) {
		return;
	}

	// Switch camera mode on a middle click that wasn't a middle mouse drag scroll.
	// the latter is determined by the time the mouse was held down:
	// switch (dragScrollThreshold)
	//   <= means a camera mode switch
	//    > means a drag scroll
	if (button == SDL_BUTTON_MIDDLE) {
		if (buttons[SDL_BUTTON_MIDDLE].time > (gu->gameTime - dragScrollThreshold))
			ToggleMiddleClickScroll();
		return;
	}

	if (gu->fpsMode)
		return;
	// outside game, neither guiHandler nor quadField exist and TraceRay would crash
	if (guihandler == nullptr)
		return;

	if ((button == SDL_BUTTON_LEFT) && !buttons[button].chorded) {
		ButtonPressEvt& bp = buttons[SDL_BUTTON_LEFT];

		if (!KeyInput::GetKeyModState(KMOD_SHIFT) && !KeyInput::GetKeyModState(KMOD_CTRL) && selectedUnitsHandler.GetBoxSelectionHandledByEngine())
			selectedUnitsHandler.ClearSelected();

		if (bp.movement > dragSelectionThreshold && selectedUnitsHandler.GetBoxSelectionHandledByEngine()) {
			// select box
			float2 topright;
			float2 bttmleft;

			GetSelectionBoxCoeff(bp.camPos, bp.dir, camera->GetPos(), dir, topright, bttmleft);

			// GetSelectionBoxCoeff returns us the corner pos, but we want to do a inview frustum check.
			// To do so we need the frustum planes (= plane normal + plane offset).
			float3 norm1 =  camera->GetUp();
			float3 norm2 = -camera->GetUp();
			float3 norm3 =  camera->GetRight();
			float3 norm4 = -camera->GetRight();

			#define signf(x) ((x > 0.0f) ? 1.0f : -1.0f)
			if (topright.y != 0.0f) norm1 = (camera->GetDir() * signf(-topright.y)) + (camera->GetUp()    / math::fabs(topright.y));
			if (bttmleft.y != 0.0f) norm2 = (camera->GetDir() * signf( bttmleft.y)) - (camera->GetUp()    / math::fabs(bttmleft.y));
			if (topright.x != 0.0f) norm3 = (camera->GetDir() * signf(-topright.x)) + (camera->GetRight() / math::fabs(topright.x));
			if (bttmleft.x != 0.0f) norm4 = (camera->GetDir() * signf( bttmleft.x)) - (camera->GetRight() / math::fabs(bttmleft.x));

			const float4 plane1(norm1, -(norm1.dot(camera->GetPos())));
			const float4 plane2(norm2, -(norm2.dot(camera->GetPos())));
			const float4 plane3(norm3, -(norm3.dot(camera->GetPos())));
			const float4 plane4(norm4, -(norm4.dot(camera->GetPos())));

			selectedUnitsHandler.HandleUnitBoxSelection(plane1, plane2, plane3, plane4);
		} else {
			const CUnit* unit = nullptr;
			const CFeature* feature = nullptr;

			TraceRay::GuiTraceRay(camera->GetPos(), dir, camera->GetFarPlaneDist() * 1.4f, nullptr, unit, feature, false);
			lastClicked = unit;

			const bool selectType = (bp.lastRelease >= (gu->gameTime - doubleClickTime) && unit == _lastClicked);

			selectedUnitsHandler.HandleSingleUnitClickSelection(const_cast<CUnit*>(unit), true, selectType);
		}

		bp.lastRelease = gu->gameTime;
	}
}

bool CMouseHandler::ButtonPressed()
{
	return pressedBitMask > 0;
}

void CMouseHandler::MouseWheel(float delta)
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (RmlGui::ProcessMouseWheel(delta)) {
		return;
	}

	if (eventHandler.MouseWheel(delta > 0.0f, delta))
		return;

	if (miniMapMouseWheel && (minimap != nullptr) && minimap->IsInside(mouse->lastx, mouse->lasty)) {
		minimap->MouseWheel(delta > 0.0f, delta);
		return;
	}

	camHandler->GetCurrentController().MouseWheelMove(delta * scrollWheelSpeed);
}


void CMouseHandler::DrawSelectionBox() const
{
	RECOIL_DETAILED_TRACY_ZONE;
	float3 btLeft, btRight, tpLeft, tpRight;

	if (!GetSelectionBoxVertices(btLeft, btRight, tpLeft, tpRight))
		return;

	auto& rb = RenderBuffer::GetTypedRenderBuffer<VA_TYPE_C>();
	auto& sh = rb.GetShader();

	rb.AddVertices({
		{btLeft , cmdColors.mouseBox},
		{btRight, cmdColors.mouseBox},
		{tpRight, cmdColors.mouseBox},
		{tpLeft , cmdColors.mouseBox},
	});

	auto state = GL::SubState(
		DepthTest(GL_FALSE),
		Blending(GL_TRUE),
		BlendFunc((GLenum)cmdColors.MouseBoxBlendSrc(), (GLenum)cmdColors.MouseBoxBlendDst()),
		LineWidth(cmdColors.MouseBoxLineWidth()));

	sh.Enable();

	rb.DrawArrays(GL_LINE_LOOP);

	sh.Disable();
}

int2 CMouseHandler::GetViewMouseCenter() const
{
	return {
		globalRendering->viewPosX + (globalRendering->viewSizeX >> 1),
		                            (globalRendering->viewSizeY >> 1)
	};
}

float3 CMouseHandler::GetCursorCameraDir(int x, int y) const { return (hideCursor? camera->GetDir() : camera->CalcPixelDir(x, y)); }
float3 CMouseHandler::GetWorldMapPos() const
{
	const float3 cameraPos = camera->GetPos();
	const float3 cursorVec = dir * camera->GetFarPlaneDist() * 1.4f;

	const float dist = CGround::LineGroundCol(cameraPos, cameraPos + cursorVec, false);

	if (dist < 0.0f)
		return -OnesVector;

	return ((cameraPos + dir * dist).cClampInBounds());
}

// CALLINFO:
// LuaUnsyncedRead::GetCurrentTooltip
// CTooltipConsole::Draw --> CMouseHandler::GetCurrentTooltip
std::string CMouseHandler::GetCurrentTooltip() const
{
	if (!offscreen) {
		std::string s;

		if (luaInputReceiver->IsAbove(lastx, lasty)) {
			s = luaInputReceiver->GetTooltip(lastx, lasty);

			if (!s.empty())
				return s;
		}

		for (CInputReceiver* recv: CInputReceiver::GetReceivers()) {
			if (recv == nullptr)
				continue;
			if (!recv->IsAbove(lastx, lasty))
				continue;

			s = recv->GetTooltip(lastx, lasty);

			if (!s.empty())
				return s;
		}
	}

	// outside game, neither guiHandler nor quadField exist and TraceRay would crash
	if (guihandler == nullptr)
		return "";

	const std::string& buildTip = guihandler->GetBuildTooltip();

	if (!buildTip.empty())
		return buildTip;

	const float range = camera->GetFarPlaneDist() * 1.4f;
	float dist = 0.0f;

	const CUnit* unit = nullptr;
	const CFeature* feature = nullptr;

	{
		dist = TraceRay::GuiTraceRay(camera->GetPos(), dir, range, nullptr, unit, feature, true, false, true);

		if (unit    != nullptr) return CTooltipConsole::MakeUnitString(unit);
		if (feature != nullptr) return CTooltipConsole::MakeFeatureString(feature);
	}

	const string selTip = selectedUnitsHandler.GetTooltip();

	if (!selTip.empty())
		return selTip;

	if (dist <= range)
		return CTooltipConsole::MakeGroundString(camera->GetPos() + (dir * dist));

	return "";
}


void CMouseHandler::Update()
{
	RECOIL_DETAILED_TRACY_ZONE;
	// Rml is very polite about asking for changes to the cursor
	// so let's make sure it's not ignored!
	if (RmlGui::IsMouseInteractingWith())
		// if the cursor string is empty, then Rml is cedeing control of it
		if (auto& rmlCursor = RmlGui::GetMouseCursor(); !rmlCursor.empty())
			queuedCursorName = rmlCursor;

	SetCursor(queuedCursorName);

	if (!hideCursor) {
		mouse->UpdateCursorCameraDir();

		return;
	}

	const int2 viewMouseCenter = GetViewMouseCenter();

	// smoothly decay scroll{x,y} to zero s.t the cursor arrows
	// indicate magnitude and direction of mouse movement while
	// MMB-scrolling
	scrollx *= 0.9f;
	scrolly *= 0.9f;
	lastx = viewMouseCenter.x;
	lasty = viewMouseCenter.y;

	UpdateCursorCameraDir();

	if (!globalRendering->active)
		return;

	mouseInput->SetPos(viewMouseCenter);
}


void CMouseHandler::WarpMouse(int x, int y)
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (locked)
		return;

	lastx = x + globalRendering->viewPosX;
	lasty = y;

	mouseInput->SetWarpPos({lastx, lasty});
}


void CMouseHandler::ShowMouse()
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (!hideCursor)
		return;

	hideCursor = false;

	SDL_SetRelativeMouseMode(SDL_FALSE);

	// don't use SDL_ShowCursor here since it would cause flickering with hwCursor
	// (by switching between default cursor and later the real one, e.g. `attack`)
	// instead update state and cursor at the same time
	ToggleHwCursor(hardwareCursor);


}

void CMouseHandler::HideMouse()
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (hideCursor)
		return;

	hideCursor = true;
	hwHideCursor = true;

	SDL_ShowCursor(SDL_DISABLE);
	// signal that we are only interested in relative motion events when MMB-scrolling
	// this way the mouse position will never change so it is also unnecessary to call
	// SDL_WarpMouseInWindow and handle the associated wart of filtering motion events
	// technically supersedes SDL_ShowCursor as well
	SDL_SetRelativeMouseMode(SDL_TRUE);

	const int2 viewMouseCenter = GetViewMouseCenter();

	scrollx = 0.0f;
	scrolly = 0.0f;
	lastx = viewMouseCenter.x;
	lasty = viewMouseCenter.y;

	mouseInput->SetWMMouseCursor(nullptr);
	mouseInput->SetPos(viewMouseCenter);
}


void CMouseHandler::ToggleMiddleClickScroll()
{
	RECOIL_DETAILED_TRACY_ZONE;
	if (locked) {
		ShowMouse();
	} else {
		HideMouse();
	}

	locked = !locked;
	mmbScroll = !mmbScroll;
	ignoreMove = mmbScroll;
}


void CMouseHandler::ToggleHwCursor(bool enable)
{
	RECOIL_DETAILED_TRACY_ZONE;
	if ((hardwareCursor = enable)) {
		hwHideCursor = true;
	} else {
		mouseInput->SetWMMouseCursor(nullptr);
		SDL_ShowCursor(SDL_DISABLE);
	}

	// force hardware cursor rebinding, otherwise we get a standard b&w cursor
	activeCursorName = "none";
}


/******************************************************************************/

void CMouseHandler::ChangeCursor(const std::string& cmdName, const float scale)
{
	RECOIL_DETAILED_TRACY_ZONE;
	queuedCursorName = cmdName;
	cursorScale = scale;
}


void CMouseHandler::SetCursor(const std::string& cmdName, const bool forceRebind)
{
	RECOIL_DETAILED_TRACY_ZONE;
	if ((activeCursorName == cmdName) && !forceRebind)
		return;

	const auto it = cursorCommandMap.find(activeCursorName = cmdName);

	if (it != cursorCommandMap.end()) {
		activeCursorIdx = it->second;
	} else {
		activeCursorIdx = cursorCommandMap[""];
	}

	if (!hardwareCursor || hideCursor)
		return;

	if ((hwHideCursor = !loadedCursors[activeCursorIdx].IsHWValid())) {
		SDL_ShowCursor(SDL_DISABLE);
		mouseInput->SetWMMouseCursor(nullptr);
	} else {
		loadedCursors[activeCursorIdx].BindHwCursor(); // calls SDL_ShowCursor(SDL_ENABLE);
	}
}


void CMouseHandler::UpdateCursors()
{
	RECOIL_DETAILED_TRACY_ZONE;
	// we update all cursors (for the command queue icons)
	for (const auto& element: cursorFileMap) {
		loadedCursors[element.second].Update();
	}
}


void CMouseHandler::UpdateCursorCameraDir()
{
	RECOIL_DETAILED_TRACY_ZONE;
	dir = GetCursorCameraDir(lastx, lasty);
}


void CMouseHandler::DrawScrollCursor(TypedRenderBuffer<VA_TYPE_C>& rb) const
{
	RECOIL_DETAILED_TRACY_ZONE;
	const float scaleL = math::fabs(std::min(0.0f, scrollx)) * crossMoveScale + 1.0f;
	const float scaleT = math::fabs(std::min(0.0f, scrolly)) * crossMoveScale + 1.0f;
	const float scaleR = math::fabs(std::max(0.0f, scrollx)) * crossMoveScale + 1.0f;
	const float scaleB = math::fabs(std::max(0.0f, scrolly)) * crossMoveScale + 1.0f;

	rb.AddVertex({{ 0.00f * scaleT,  1.00f * scaleT, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.33f * scaleT,  0.66f * scaleT, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{-0.33f * scaleT,  0.66f * scaleT, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{ 0.00f * scaleB, -1.00f * scaleB, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.33f * scaleB, -0.66f * scaleB, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{-0.33f * scaleB, -0.66f * scaleB, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{-1.00f * scaleL,  0.00f * scaleL, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{-0.66f * scaleL,  0.33f * scaleL, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{-0.66f * scaleL, -0.33f * scaleL, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{ 1.00f * scaleR,  0.00f * scaleR, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.66f * scaleR,  0.33f * scaleR, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.66f * scaleR, -0.33f * scaleR, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{-0.33f * scaleT,  0.66f * scaleT, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.33f * scaleT,  0.66f * scaleT, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{ 0.00f         ,  0.00f         , 0.0f}, {0.2f, 0.2f, 0.2f,       0.0f}});

	rb.AddVertex({{-0.33f * scaleB, -0.66f * scaleB, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.33f * scaleB, -0.66f * scaleB, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{ 0.00f         ,  0.00f,          0.0f}, {0.2f, 0.2f, 0.2f,       0.0f}});

	rb.AddVertex({{-0.66f * scaleL,  0.33f * scaleL, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{-0.66f * scaleL, -0.33f * scaleL, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{ 0.00f         ,  0.00f         , 0.0f}, {0.2f, 0.2f, 0.2f,       0.0f}});

	rb.AddVertex({{ 0.66f * scaleR, -0.33f * scaleR, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});
	rb.AddVertex({{ 0.66f * scaleR,  0.33f * scaleR, 0.0f}, {1.0f, 1.0f, 1.0f, crossAlpha}});

	rb.AddVertex({{ 0.00f         ,  0.00f         , 0.0f}, {0.2f, 0.2f, 0.2f,       0.0f}});

	// center dot
	rb.AddVertex({{-crossSize * 0.03f,  crossSize * 0.03f, 0.0f}, {1.0f, 1.0f, 1.0f, 1.2f * crossAlpha}});
	rb.AddVertex({{-crossSize * 0.03f, -crossSize * 0.03f, 0.0f}, {1.0f, 1.0f, 1.0f, 1.2f * crossAlpha}});
	rb.AddVertex({{ crossSize * 0.03f, -crossSize * 0.03f, 0.0f}, {1.0f, 1.0f, 1.0f, 1.2f * crossAlpha}});

	rb.AddVertex({{ crossSize * 0.03f, -crossSize * 0.03f, 0.0f}, {1.0f, 1.0f, 1.0f, 1.2f * crossAlpha}});
	rb.AddVertex({{ crossSize * 0.03f,  crossSize * 0.03f, 0.0f}, {1.0f, 1.0f, 1.0f, 1.2f * crossAlpha}});
	rb.AddVertex({{-crossSize * 0.03f,  crossSize * 0.03f, 0.0f}, {1.0f, 1.0f, 1.0f, 1.2f * crossAlpha}});

	rb.DrawArrays(GL_TRIANGLES);
}


void CMouseHandler::DrawFPSCursor(TypedRenderBuffer<VA_TYPE_C>& rb) const
{
	RECOIL_DETAILED_TRACY_ZONE;
	constexpr int stepNumHalf = 2;

	const float wingHalf = math::PI * 0.111111f;
	const float step = wingHalf / stepNumHalf;

	for (float angle = 0.0f; angle < math::TWOPI; angle += (math::TWOPI * 0.333333f)) {
		for (int i = -stepNumHalf; i < stepNumHalf; i++) {
			rb.AddVertex({{0.1f * fastmath::sin(angle                 ), 0.1f * fastmath::cos(angle                 ), 0.0f}, {1.0f, 1.0f, 1.0f, 0.5f}});
			rb.AddVertex({{0.8f * fastmath::sin(angle + (i    ) * step), 0.8f * fastmath::cos(angle + (i    ) * step), 0.0f}, {1.0f, 1.0f, 1.0f, 0.5f}});
			rb.AddVertex({{0.8f * fastmath::sin(angle + (i + 1) * step), 0.8f * fastmath::cos(angle + (i + 1) * step), 0.0f}, {1.0f, 1.0f, 1.0f, 0.5f}});
		}
	}

	rb.Submit(GL_TRIANGLES);
}


void CMouseHandler::DrawCursor()
{
	RECOIL_DETAILED_TRACY_ZONE;
	assert(activeCursorIdx != -1);

	if (guihandler != nullptr)
		guihandler->DrawCentroidCursor();

	if (locked) {
		// draw procedural cursor if center-locked
		if (crossSize > 0.0f) {
			const float xscale = crossSize * globalRendering->pixelX;
			const float yscale = crossSize * globalRendering->pixelY;

			glPushMatrix();
			glTranslatef(0.5f - globalRendering->pixelX * 0.5f, 0.5f - globalRendering->pixelY * 0.5f, 0.0f);
			glScalef(xscale, yscale, 1.0f);

			auto& rb = RenderBuffer::GetTypedRenderBuffer<VA_TYPE_C>();
			auto& sh = rb.GetShader();

			sh.Enable();

			if (gu->fpsMode) {
				DrawFPSCursor(rb);
			} else {
				DrawScrollCursor(rb);
			}

			sh.Disable();

			glPopMatrix();
		}

		return;
	}

	if (hideCursor)
		return;

	if (hardwareCursor && loadedCursors[activeCursorIdx].IsHWValid()) {
		loadedCursors[activeCursorIdx].UpdateHwCursor();
		return;
	}

	// draw the 'software' cursor
	if (cursorScale >= 0.0f) {
		loadedCursors[activeCursorIdx].Draw(lastx, lasty, cursorScale);
		return;
	}

	// hovered minimap, show default cursor and draw `special` cursor scaled-down bottom right of the default one
	const size_t normalCursorIndex = cursorFileMap["cursornormal"];

	if (normalCursorIndex == 0) {
		loadedCursors[activeCursorIdx].Draw(lastx, lasty, -cursorScale);
		return;
	}

	CMouseCursor& normalCursor = loadedCursors[normalCursorIndex];
	normalCursor.Draw(lastx, lasty, 1.0f);

	if (activeCursorIdx == normalCursorIndex)
		return;

	loadedCursors[activeCursorIdx].Draw(lastx + normalCursor.GetMaxSizeX(), lasty + normalCursor.GetMaxSizeY(), -cursorScale);
}


bool CMouseHandler::AssignMouseCursor(
	const std::string& cmdName,
	const std::string& fileName,
	CMouseCursor::HotSpot hotSpot,
	bool overwrite
) {
	RECOIL_DETAILED_TRACY_ZONE;
	const auto  cmdIt = cursorCommandMap.find(cmdName);
	const auto fileIt = cursorFileMap.find(fileName);

	const bool haveCmd  = ( cmdIt != cursorCommandMap.end());
	const bool haveFile = (fileIt != cursorFileMap.end());

	// already assigned a cursor for this command
	if (haveCmd && !overwrite)
		return false;

	// cursor is already loaded but not assigned, reuse it
	if (haveFile) {
		cursorCommandMap[cmdName] = fileIt->second;
		return true;
	}

	const size_t numLoadedCursors = loadedCursors.size();
	const size_t commandCursorIdx = haveCmd? cmdIt->second: numLoadedCursors + 1;

	// assign the new cursor and remap indices
	loadedCursors.emplace_back(fileName, hotSpot);

	// a loaded cursor can be invalid, but if so the command will not be mapped to it
	// allows Lua code to replace the cursor by a valid one later and do reassignment
	// cursorCommandMap[cmdName] = (loadedCursors[numLoadedCursors].IsValid())? numLoadedCursors: commandCursorIdx;
	cursorFileMap[fileName] = numLoadedCursors;

	if (loadedCursors[numLoadedCursors].IsValid())
		cursorCommandMap[cmdName] = numLoadedCursors;

	// switch to the null-cursor if our active one is being (re)assigned
	if (activeCursorIdx == commandCursorIdx)
		SetCursor("none", true);

	return (loadedCursors[numLoadedCursors].IsValid());
}

bool CMouseHandler::ReplaceMouseCursor(
	const string& oldName,
	const string& newName,
	CMouseCursor::HotSpot hotSpot
) {
	RECOIL_DETAILED_TRACY_ZONE;
	const auto fileIt = cursorFileMap.find(oldName);

	if (fileIt == cursorFileMap.end())
		return false;

	const auto* loadedCursor = loadedCursors.data() + fileIt->second;

	if (newName == loadedCursor->GetName() && hotSpot == loadedCursor->GetHotSpot()) //same
		return true;

	CMouseCursor newCursor = CMouseCursor(newName, hotSpot);

	// replace here so SetCursor() operates with new CMouseCursor() object
	// hold on the destruction of old CMouseCursor() in this place. Otherwise bad things will happen.
	std::swap(loadedCursors.at(fileIt->second), newCursor);

	// update current cursor if necessary
	if (activeCursorIdx == fileIt->second)
		SetCursor(activeCursorName, true);

	newCursor = {}; //now it's safe to kill old cursor
	return (loadedCursors[activeCursorIdx].IsValid());
}


/******************************************************************************/

void CMouseHandler::ConfigNotify(const std::string& key, const std::string& value)
{
	RECOIL_DETAILED_TRACY_ZONE;
	ConfigUpdate();
}

void CMouseHandler::ConfigUpdate()
{
	RECOIL_DETAILED_TRACY_ZONE;
	dragScrollThreshold = configHandler->GetFloat("MouseDragScrollThreshold");
	dragSelectionThreshold = configHandler->GetInt("MouseDragSelectionThreshold");
	dragBoxCommandThreshold = configHandler->GetInt("MouseDragBoxCommandThreshold");
	dragCircleCommandThreshold = configHandler->GetInt("MouseDragCircleCommandThreshold");
	dragFrontCommandThreshold = configHandler->GetInt("MouseDragFrontCommandThreshold");
	invertMouse = configHandler->GetBool("InvertMouse");
	miniMapMouseWheel = configHandler->GetBool("MiniMapMouseWheel");
	scrollWheelSpeed = configHandler->GetFloat("ScrollWheelSpeed");
}
````


### 15.5 `LuaUnsyncedRead.h`

````cpp
/* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#ifndef LUA_UNSYNCED_INFO_H
#define LUA_UNSYNCED_INFO_H

struct lua_State;


class LuaUnsyncedRead {
	friend class CLuaIntro;

	public:
		static bool PushEntries(lua_State* L);

	public:
		static int IsReplay(lua_State* L);
		static int GetReplayLength(lua_State* L);

		static int GetGameName(lua_State* L);
		static int GetMenuName(lua_State* L);

		static int GetProfilerTimeRecord(lua_State* L);
		static int GetProfilerRecordNames(lua_State* L);

		static int GetLuaMemUsage(lua_State* L);
		static int GetVidMemUsage(lua_State* L);

		static int GetDrawFrame(lua_State* L);
		static int GetFrameTimeOffset(lua_State* L);
		static int GetGameSecondsInterpolated(lua_State* L);
		static int GetLastUpdateSeconds(lua_State* L);
		static int GetVideoCapturingMode(lua_State* L);

		static int GetNumDisplays(lua_State* L);
		static int GetViewGeometry(lua_State* L);
		static int GetDualViewGeometry(lua_State* L);
		static int GetWindowGeometry(lua_State* L);
		static int GetWindowDisplayMode(lua_State* L);
		static int GetScreenGeometry(lua_State* L);
		static int GetMiniMapGeometry(lua_State* L);
		static int GetMiniMapDualScreen(lua_State* L);
		static int GetMiniMapRotation(lua_State* L);

		static int GetSelectionBox(lua_State* L);
		static int IsAboveMiniMap(lua_State* L);

		static int IsAABBInView(lua_State* L);
		static int IsSphereInView(lua_State* L);

		static int IsUnitAllied(lua_State* L);
		static int IsUnitInView(lua_State* L);
		static int IsUnitVisible(lua_State* L);
		static int IsUnitIcon(lua_State* L);
		static int IsUnitSelected(lua_State* L);

		static int GetUnitLuaDraw(lua_State* L);
		static int GetUnitNoDraw(lua_State* L);
		static int GetUnitEngineDrawMask(lua_State* L);
		static int GetUnitNoMinimap(lua_State* L);
		static int GetUnitNoGroup(lua_State* L);
		static int GetUnitNoSelect(lua_State* L);
		static int GetUnitAlwaysUpdateMatrix(lua_State* L);
		static int GetUnitDrawFlag(lua_State* L);

		static int GetUnitSelectionVolumeData(lua_State* L);

		static int GetFeatureLuaDraw(lua_State* L);
		static int GetFeatureNoDraw(lua_State* L);
		static int GetFeatureEngineDrawMask(lua_State* L);
		static int GetFeatureAlwaysUpdateMatrix(lua_State* L);
		static int GetFeatureDrawFlag(lua_State* L);

		static int GetFeatureSelectionVolumeData(lua_State* L);

		static int GetUnitTransformMatrix(lua_State* L);
		static int GetFeatureTransformMatrix(lua_State* L);

		static int GetUnitViewPosition(lua_State* L);

		static int GetVisibleUnits(lua_State* L);
		static int GetVisibleFeatures(lua_State* L);
		static int GetVisibleProjectiles(lua_State* L);

		static int GetRenderUnits(lua_State* L);
		static int GetRenderUnitsDrawFlagChanged(lua_State* L);
		static int GetRenderFeatures(lua_State* L);
		static int GetRenderFeaturesDrawFlagChanged(lua_State* L);

		static int ClearUnitsPreviousDrawFlag(lua_State* L);
		static int ClearFeaturesPreviousDrawFlag(lua_State* L);

		static int GetUnitsInScreenRectangle(lua_State* L);
		static int GetFeaturesInScreenRectangle(lua_State* L);

		static int GetTeamColor(lua_State* L);
		static int GetTeamOrigColor(lua_State* L);

		static int GetLocalPlayerID(lua_State* L);
		static int GetLocalTeamID(lua_State* L);
		static int GetLocalAllyTeamID(lua_State* L);
		static int GetSpectatingState(lua_State* L);

		static int GetSelectedUnits(lua_State* L);
		static int GetSelectedUnitsSorted(lua_State* L);
		static int GetSelectedUnitsCounts(lua_State* L);
		static int GetSelectedUnitsCount(lua_State* L);
		static int GetBoxSelectionByEngine(lua_State* L);

		static int IsGUIHidden(lua_State* L);
		static int HaveShadows(lua_State* L);
		static int HaveAdvShading(lua_State* L);
		static int GetWaterMode(lua_State* L);
		static int GetMapDrawMode(lua_State* L);
		static int GetMapSquareTexture(lua_State* L);

		static int GetLosViewColors(lua_State* L);

		static int GetNanoProjectileParams(lua_State* L);

		static int GetCameraNames(lua_State* L);
		static int GetCameraState(lua_State* L);
		static int GetCameraPosition(lua_State* L);
		static int GetCameraDirection(lua_State* L);
		static int GetCameraRotation(lua_State* L);
		static int GetCameraFOV(lua_State* L);
		static int GetCameraVectors(lua_State* L);
		static int WorldToScreenCoords(lua_State* L);
		static int TraceScreenRay(lua_State* L);
		static int GetPixelDir(lua_State* L);

		static int GetTimer(lua_State* L);
		static int GetTimerMicros(lua_State* L);
		static int GetFrameTimer(lua_State* L);
		static int DiffTimers(lua_State* L);

		static int GetDrawSeconds(lua_State* L);

		static int GetSoundStreamTime(lua_State* L);
		static int GetSoundEffectParams(lua_State* L);
		static int GetSoundDevices(lua_State* L);

		static int GetFPS(lua_State* L);
		static int GetGameSpeed(lua_State* L);
		static int GetGameState(lua_State* L);

		static int GetMouseButtonsPressed(lua_State* L);
		static int GetMouseState(lua_State* L);
		static int GetMouseCursor(lua_State* L);
		static int GetMouseStartPosition(lua_State* L);
		static int GetAvailableControllers(lua_State* L);
		static int GetControllerState(lua_State* L);

		static int GetKeyFromScanSymbol(lua_State* L);
		static int GetKeyState(lua_State* L);
		static int GetModKeyState(lua_State* L);
		static int GetPressedKeys(lua_State* L);
		static int GetPressedScans(lua_State* L);
		static int GetInvertQueueKey(lua_State* L);

		static int GetClipboard(lua_State* L);

		static int GetActiveCommand(lua_State* L);
		static int GetDefaultCommand(lua_State* L);
		static int GetActiveCmdDescs(lua_State* L);
		static int GetActiveCmdDesc(lua_State* L);
		static int GetCmdDescIndex(lua_State* L);

		static int GetGatherMode(lua_State* L);

		static int GetBuildFacing(lua_State* L);
		static int GetBuildSpacing(lua_State* L);

		static int GetActivePage(lua_State* L);

		static int GetLastMessagePositions(lua_State* L);

		static int GetConsoleBuffer(lua_State* L);
		static int GetCurrentTooltip(lua_State* L);
		static int IsUserWriting(lua_State* L);

		static int GetKeyCode(lua_State* L);
		static int GetKeySymbol(lua_State* L);
		static int GetScanSymbol(lua_State* L);
		static int GetKeyBindings(lua_State* L);
		static int GetActionHotKeys(lua_State* L);

		static int GetGroupList(lua_State* L);
		static int GetSelectedGroup(lua_State* L);

		static int GetUnitGroup(lua_State* L);

		static int GetGroupUnits(lua_State* L);
		static int GetGroupUnitsSorted(lua_State* L);
		static int GetGroupUnitsCounts(lua_State* L);
		static int GetGroupUnitsCount(lua_State* L);

		static int GetPlayerRoster(lua_State* L);
		static int GetPlayerTraffic(lua_State* L);
		static int GetPlayerStatistics(lua_State* L);

		static int GetDrawSelectionInfo(lua_State* L);

		static int GetConfigParams(lua_State* L);
		static int GetConfigInt(lua_State* L);
		static int GetConfigFloat(lua_State* L);
		static int GetConfigString(lua_State* L);
		static int GetLogSections(lua_State* L);

		static int GetAllGroundDecals(lua_State* L);
		static int GetGroundDecalMiddlePos(lua_State* L);
		static int GetGroundDecalQuadPos(lua_State* L);
		static int GetGroundDecalSizeAndHeight(lua_State* L);
		static int GetGroundDecalRotation(lua_State* L);
		static int GetGroundDecalTexture(lua_State* L);
		static int GetGroundDecalTextures(lua_State* L);
		static int GetGroundDecalTextureParams(lua_State* L);
		static int GetGroundDecalAlpha(lua_State* L);
		static int GetGroundDecalNormal(lua_State* L);
		static int GetGroundDecalTint(lua_State* L);
		static int GetGroundDecalMisc(lua_State* L);
		static int GetGroundDecalCreationFrame(lua_State* L);
		static int GetGroundDecalType(lua_State* L);
		static int GetGroundDecalOwner(lua_State* L);
		static int GetGroundDecalGlowParams(lua_State* L);
		static int GetGroundDecalUserData(lua_State* L);

		static int UnitIconGetDraw(lua_State* L);
		static int GetUnitIconData(lua_State* L);
		static int GetIconData(lua_State* L);
		static int GetAllIconDataArray(lua_State* L);

		static int GetSyncedGCInfo(lua_State* L);

		static int SolveNURBSCurve(lua_State* L);
};


#endif /* LUA_UNSYNCED_INFO_H */
````


### 15.6 `LuaUnsyncedRead.cpp`

````cpp
/* This file is part of the Spring engine (GPL v2 or later), see LICENSE.html */

#include "LuaUnsyncedRead.h"

#include "LuaConfig.h"
#include "LuaInclude.h"
#include "LuaHandle.h"
#include "LuaHashString.h"
#include "LuaUtils.h"
#include "LuaRules.h"
#include "Game/Camera.h"
#include "Game/CameraHandler.h"
#include "Game/Game.h"
#include "Game/GameHelper.h"
#include "Game/GameSetup.h"
#include "Game/GlobalUnsynced.h"
#include "Game/IVideoCapturing.h"
#include "Game/Players/Player.h"
#include "Game/Players/PlayerHandler.h"
#include "Game/SelectedUnitsHandler.h"
#include "Game/TraceRay.h"
#include "Game/Camera/CameraController.h"
#include "Game/UI/GuiHandler.h"
#include "Game/UI/InfoConsole.h"
#include "Game/UI/KeyCodes.h"
#include "Game/UI/ScanCodes.h"
#include "Game/UI/KeySet.h"
#include "Game/UI/KeyBindings.h"
#include "Game/UI/MiniMap.h"
#include "Game/UI/MouseHandler.h"
#include "Game/UI/PlayerRoster.h"
#include "Map/BaseGroundDrawer.h"
#include "Map/BaseGroundTextures.h"
#include "Map/Ground.h"
#include "Map/ReadMap.h"
#include "Menu/LuaMenuController.h"
#include "Net/GameServer.h"
#include "Rendering/GlobalRendering.h"
#include "Rendering/GlobalRenderingInfo.h"
#include "Rendering/ShadowHandler.h"
#include "Rendering/Units/UnitDrawer.h"
#include "Rendering/Env/IWater.h"
#include "Rendering/Env/IGroundDecalDrawer.h"
#include "Rendering/Env/Particles/Classes/NanoProjectile.h"
#include "Rendering/Map/InfoTexture/IInfoTextureHandler.h"
#include "Rendering/Units/UnitDrawer.h"
#include "Rendering/Features/FeatureDrawer.h"
#include "Rendering/IconHandler.h"
#include "Sim/Features/Feature.h"
#include "Sim/Features/FeatureDef.h"
#include "Sim/Features/FeatureHandler.h"
#include "Sim/Misc/LosHandler.h"
#include "Sim/Misc/ModInfo.h"
#include "Sim/Misc/TeamHandler.h"
#include "Sim/Misc/QuadField.h"
#include "Sim/Projectiles/Projectile.h"
#include "Sim/Units/Unit.h"
#include "Sim/Units/UnitHandler.h"
#include "Sim/Units/UnitDefHandler.h"
#include "Sim/Units/CommandAI/CommandDescription.h"
#include "Game/UI/Groups/Group.h"
#include "Game/UI/Groups/GroupHandler.h"
#include "Net/Protocol/NetProtocol.h" // NETMSG_*
#include "System/TimeProfiler.h"
#include "System/Config/ConfigHandler.h"
#include "System/Config/ConfigVariable.h"
#include "System/Input/ControllerInput.h"
#include "System/Input/KeyInput.h"
#include "System/LoadSave/DemoReader.h"
#include "System/Log/DefaultFilter.h"
#include "System/Platform/SDL1_keysym.h"
#include "System/Platform/Misc.h"
#include "System/Sound/ISound.h"
#include "System/Sound/ISoundChannels.h"
#include "System/StringUtil.h"
#include "System/Misc/SpringTime.h"
#include "System/ScopedResource.h"
#include "System/Math/NURBS.h"

#if !defined(HEADLESS) && !defined(NO_SOUND)
	#include "System/Sound/OpenAL/EFX.h"
	#include "System/Sound/OpenAL/EFXPresets.h"
#endif

#include <cctype>
#include <algorithm>

#include <SDL_keyboard.h>
#include <SDL_clipboard.h>
#include <SDL_keycode.h>
#include <SDL_mouse.h>


/******************************************************************************
 * Callouts to get state
 *
 * @see rts/Lua/LuaUnsyncedRead.cpp
******************************************************************************/

bool LuaUnsyncedRead::PushEntries(lua_State* L)
{
	REGISTER_LUA_CFUNC(IsReplay);
	REGISTER_LUA_CFUNC(GetReplayLength);

	REGISTER_LUA_CFUNC(GetGameName);
	REGISTER_LUA_CFUNC(GetMenuName);

	REGISTER_LUA_CFUNC(GetProfilerTimeRecord);
	REGISTER_LUA_CFUNC(GetProfilerRecordNames);

	REGISTER_LUA_CFUNC(GetLuaMemUsage);
	REGISTER_LUA_CFUNC(GetVidMemUsage);

	REGISTER_LUA_CFUNC(GetDrawFrame);
	REGISTER_LUA_CFUNC(GetFrameTimeOffset);
	REGISTER_LUA_CFUNC(GetGameSecondsInterpolated);
	REGISTER_LUA_CFUNC(GetLastUpdateSeconds);
	REGISTER_LUA_CFUNC(GetVideoCapturingMode);

	REGISTER_LUA_CFUNC(GetNumDisplays);
	REGISTER_LUA_CFUNC(GetViewGeometry);
	REGISTER_LUA_CFUNC(GetDualViewGeometry);
	REGISTER_LUA_CFUNC(GetWindowGeometry);
	REGISTER_LUA_CFUNC(GetWindowDisplayMode);
	REGISTER_LUA_CFUNC(GetScreenGeometry);
	REGISTER_LUA_CFUNC(GetMiniMapGeometry);
	REGISTER_LUA_CFUNC(GetMiniMapDualScreen);
	REGISTER_LUA_CFUNC(GetMiniMapRotation);
	REGISTER_LUA_CFUNC(GetSelectionBox);
	REGISTER_LUA_CFUNC(IsAboveMiniMap);
	REGISTER_LUA_CFUNC(IsGUIHidden);

	REGISTER_LUA_CFUNC(IsAABBInView);
	REGISTER_LUA_CFUNC(IsSphereInView);

	REGISTER_LUA_CFUNC(IsUnitAllied);
	REGISTER_LUA_CFUNC(IsUnitInView);
	REGISTER_LUA_CFUNC(IsUnitVisible);
	REGISTER_LUA_CFUNC(IsUnitIcon);
	REGISTER_LUA_CFUNC(IsUnitSelected);

	REGISTER_LUA_CFUNC(GetUnitLuaDraw);
	REGISTER_LUA_CFUNC(GetUnitNoDraw);
	REGISTER_LUA_CFUNC(GetUnitEngineDrawMask);
	REGISTER_LUA_CFUNC(GetUnitNoMinimap);
	REGISTER_LUA_CFUNC(GetUnitNoGroup);
	REGISTER_LUA_CFUNC(GetUnitNoSelect);
	REGISTER_LUA_CFUNC(GetUnitAlwaysUpdateMatrix);
	REGISTER_LUA_CFUNC(GetUnitDrawFlag);
	REGISTER_LUA_CFUNC(GetUnitSelectionVolumeData);
	REGISTER_LUA_CFUNC(GetFeatureLuaDraw);
	REGISTER_LUA_CFUNC(GetFeatureNoDraw);
	REGISTER_LUA_CFUNC(GetFeatureEngineDrawMask);
	REGISTER_LUA_CFUNC(GetFeatureAlwaysUpdateMatrix);
	REGISTER_LUA_CFUNC(GetFeatureDrawFlag);
	REGISTER_LUA_CFUNC(GetFeatureSelectionVolumeData);

	REGISTER_LUA_CFUNC(GetUnitTransformMatrix);
	REGISTER_LUA_CFUNC(GetFeatureTransformMatrix);

	REGISTER_LUA_CFUNC(GetUnitViewPosition);

	REGISTER_LUA_CFUNC(GetVisibleUnits);
	REGISTER_LUA_CFUNC(GetVisibleFeatures);
	REGISTER_LUA_CFUNC(GetVisibleProjectiles);

	REGISTER_LUA_CFUNC(GetRenderUnits);
	REGISTER_LUA_CFUNC(GetRenderUnitsDrawFlagChanged);
	REGISTER_LUA_CFUNC(GetRenderFeatures);
	REGISTER_LUA_CFUNC(GetRenderFeaturesDrawFlagChanged);

	REGISTER_LUA_CFUNC(ClearUnitsPreviousDrawFlag);
	REGISTER_LUA_CFUNC(ClearFeaturesPreviousDrawFlag);

	REGISTER_LUA_CFUNC(GetUnitsInScreenRectangle);
	REGISTER_LUA_CFUNC(GetFeaturesInScreenRectangle);

	REGISTER_LUA_CFUNC(GetTeamColor);
	REGISTER_LUA_CFUNC(GetTeamOrigColor);

	REGISTER_LUA_CFUNC(GetLocalPlayerID);
	REGISTER_LUA_CFUNC(GetLocalTeamID);
	REGISTER_LUA_CFUNC(GetLocalAllyTeamID);

	// aliases
	REGISTER_NAMED_LUA_CFUNC("GetMyPlayerID", GetLocalPlayerID);
	REGISTER_NAMED_LUA_CFUNC("GetMyTeamID", GetLocalTeamID);
	REGISTER_NAMED_LUA_CFUNC("GetMyAllyTeamID", GetLocalAllyTeamID);

	REGISTER_LUA_CFUNC(GetSpectatingState);

	REGISTER_LUA_CFUNC(GetSelectedUnits);
	REGISTER_LUA_CFUNC(GetSelectedUnitsSorted);
	REGISTER_LUA_CFUNC(GetSelectedUnitsCounts);
	REGISTER_LUA_CFUNC(GetSelectedUnitsCount);
	REGISTER_LUA_CFUNC(GetBoxSelectionByEngine);

	REGISTER_LUA_CFUNC(HaveShadows);
	REGISTER_LUA_CFUNC(HaveAdvShading);
	REGISTER_LUA_CFUNC(GetWaterMode);
	REGISTER_LUA_CFUNC(GetMapDrawMode);
	REGISTER_LUA_CFUNC(GetMapSquareTexture);

	REGISTER_LUA_CFUNC(GetLosViewColors);

	REGISTER_LUA_CFUNC(GetNanoProjectileParams);

	REGISTER_LUA_CFUNC(GetCameraNames);
	REGISTER_LUA_CFUNC(GetCameraState);
	REGISTER_LUA_CFUNC(GetCameraPosition);
	REGISTER_LUA_CFUNC(GetCameraDirection);
	REGISTER_LUA_CFUNC(GetCameraRotation);
	REGISTER_LUA_CFUNC(GetCameraFOV);
	REGISTER_LUA_CFUNC(GetCameraVectors);
	REGISTER_LUA_CFUNC(WorldToScreenCoords);
	REGISTER_LUA_CFUNC(TraceScreenRay);
	REGISTER_LUA_CFUNC(GetPixelDir);

	REGISTER_LUA_CFUNC(GetTimer);
	REGISTER_LUA_CFUNC(GetTimerMicros);
	REGISTER_LUA_CFUNC(GetFrameTimer);
	REGISTER_LUA_CFUNC(DiffTimers);

	REGISTER_LUA_CFUNC(GetDrawSeconds);

	REGISTER_LUA_CFUNC(GetSoundDevices);
	REGISTER_LUA_CFUNC(GetSoundStreamTime);
	REGISTER_LUA_CFUNC(GetSoundEffectParams);

	REGISTER_LUA_CFUNC(GetFPS);
	REGISTER_LUA_CFUNC(GetGameSpeed);
	REGISTER_LUA_CFUNC(GetGameState);

	REGISTER_LUA_CFUNC(GetActiveCommand);
	REGISTER_LUA_CFUNC(GetDefaultCommand);
	REGISTER_LUA_CFUNC(GetActiveCmdDescs);
	REGISTER_LUA_CFUNC(GetActiveCmdDesc);
	REGISTER_LUA_CFUNC(GetCmdDescIndex);
	REGISTER_LUA_CFUNC(GetBuildFacing);
	REGISTER_LUA_CFUNC(GetBuildSpacing);
	REGISTER_LUA_CFUNC(GetGatherMode);
	REGISTER_LUA_CFUNC(GetActivePage);

	REGISTER_LUA_CFUNC(GetMouseButtonsPressed);
	REGISTER_LUA_CFUNC(GetMouseState);
	REGISTER_LUA_CFUNC(GetMouseCursor);
	REGISTER_LUA_CFUNC(GetMouseStartPosition);
	REGISTER_LUA_CFUNC(GetAvailableControllers);
	REGISTER_LUA_CFUNC(GetControllerState);

	REGISTER_LUA_CFUNC(GetKeyFromScanSymbol);
	REGISTER_LUA_CFUNC(GetKeyState);
	REGISTER_LUA_CFUNC(GetModKeyState);
	REGISTER_LUA_CFUNC(GetPressedKeys);
	REGISTER_LUA_CFUNC(GetPressedScans);
	REGISTER_LUA_CFUNC(GetInvertQueueKey);

	REGISTER_LUA_CFUNC(GetClipboard);

	REGISTER_LUA_CFUNC(GetKeyCode);
	REGISTER_LUA_CFUNC(GetKeySymbol);
	REGISTER_LUA_CFUNC(GetScanSymbol);
	REGISTER_LUA_CFUNC(GetKeyBindings);
	REGISTER_LUA_CFUNC(GetActionHotKeys);

	REGISTER_LUA_CFUNC(GetLastMessagePositions);
	REGISTER_LUA_CFUNC(GetConsoleBuffer);
	REGISTER_LUA_CFUNC(GetCurrentTooltip);
	REGISTER_LUA_CFUNC(IsUserWriting);

	REGISTER_LUA_CFUNC(GetUnitGroup);
	REGISTER_LUA_CFUNC(GetGroupList);
	REGISTER_LUA_CFUNC(GetSelectedGroup);
	REGISTER_LUA_CFUNC(GetGroupUnits);
	REGISTER_LUA_CFUNC(GetGroupUnitsSorted);
	REGISTER_LUA_CFUNC(GetGroupUnitsCounts);
	REGISTER_LUA_CFUNC(GetGroupUnitsCount);

	REGISTER_LUA_CFUNC(GetPlayerRoster);
	REGISTER_LUA_CFUNC(GetPlayerTraffic);
	REGISTER_LUA_CFUNC(GetPlayerStatistics);

	REGISTER_LUA_CFUNC(GetDrawSelectionInfo);

	REGISTER_LUA_CFUNC(GetConfigParams);
	REGISTER_LUA_CFUNC(GetConfigInt);
	REGISTER_LUA_CFUNC(GetConfigFloat);
	REGISTER_LUA_CFUNC(GetConfigString);
	REGISTER_LUA_CFUNC(GetLogSections);

	REGISTER_LUA_CFUNC(GetAllGroundDecals);
	REGISTER_LUA_CFUNC(GetGroundDecalMiddlePos);
	REGISTER_LUA_CFUNC(GetGroundDecalQuadPos);
	REGISTER_LUA_CFUNC(GetGroundDecalSizeAndHeight);
	REGISTER_LUA_CFUNC(GetGroundDecalRotation);
	REGISTER_LUA_CFUNC(GetGroundDecalTexture);
	REGISTER_LUA_CFUNC(GetGroundDecalTextures);
	REGISTER_LUA_CFUNC(GetGroundDecalTextureParams);
	REGISTER_LUA_CFUNC(GetGroundDecalAlpha);
	REGISTER_LUA_CFUNC(GetGroundDecalNormal);
	REGISTER_LUA_CFUNC(GetGroundDecalTint);
	REGISTER_LUA_CFUNC(GetGroundDecalMisc);
	REGISTER_LUA_CFUNC(GetGroundDecalCreationFrame);
	REGISTER_LUA_CFUNC(GetGroundDecalOwner);
	REGISTER_LUA_CFUNC(GetGroundDecalType);
	REGISTER_LUA_CFUNC(GetGroundDecalGlowParams);
	REGISTER_LUA_CFUNC(GetGroundDecalUserData);

	REGISTER_LUA_CFUNC(UnitIconGetDraw);
	REGISTER_LUA_CFUNC(GetUnitIconData);
	REGISTER_LUA_CFUNC(GetIconData);
	REGISTER_LUA_CFUNC(GetAllIconDataArray);

	REGISTER_LUA_CFUNC(GetSyncedGCInfo);
	REGISTER_LUA_CFUNC(SolveNURBSCurve);

	return true;
}




/******************************************************************************/
/******************************************************************************/
//
//  Parsing helpers
//

static inline CUnit* ParseUnit(lua_State* L, const char* caller, int index)
{
	if (!lua_isnumber(L, index)) {
		luaL_error(L, "%s(): unitID not a number", caller);
		return nullptr;
	}

	CUnit* unit = unitHandler.GetUnit(lua_toint(L, index));

	if (unit == nullptr)
		return nullptr;

	const int readAllyTeam = CLuaHandle::GetHandleReadAllyTeam(L);

	if (readAllyTeam < 0)
		return CLuaHandle::GetHandleFullRead(L) ? unit : nullptr;

	if ((unit->losStatus[readAllyTeam] & (LOS_INLOS | LOS_INRADAR)) == 0)
		return nullptr;

	return unit;
}

static inline CFeature* ParseFeature(lua_State* L, const char* caller, int index)
{
	if (!lua_isnumber(L, index)) {
		luaL_error(L, "%s(): Bad featureID", caller);
		return nullptr;
	}

	CFeature* feature = featureHandler.GetFeature(lua_toint(L, index));

	if (CLuaHandle::GetHandleFullRead(L))
		return feature;

	const int readAllyTeam = CLuaHandle::GetHandleReadAllyTeam(L);

	if (readAllyTeam < 0)
		return nullptr;
	if (feature == nullptr)
		return nullptr;
	if (feature->IsInLosForAllyTeam(readAllyTeam))
		return feature;

	return nullptr;
}




static int GetSolidObjectLuaDraw(lua_State* L, const CSolidObject* obj)
{
	if (obj == nullptr)
		return 0;

	lua_pushboolean(L, obj->luaDraw);
	return 1;
}

static int GetSolidObjectNoDraw(lua_State* L, const CSolidObject* obj)
{
	if (obj == nullptr)
		return 0;

	lua_pushboolean(L, obj->noDraw);
	return 1;
}

static int GetSolidObjectEngineDrawMask(lua_State* L, const CSolidObject* obj)
{
	if (obj == nullptr)
		return 0;

	lua_pushinteger(L, obj->engineDrawMask);
	return 1;
}

static int GetSolidObjectSelectionVolume(lua_State* L, const CSolidObject* obj)
{
	if (obj == nullptr)
		return 0;

	return LuaUtils::PushColVolData(L, &obj->selectionVolume);
}



template <typename T>
static void PushNumberContainerAsArray(lua_State* const L, const T &v)
{
	lua_createtable(L, v.size(), 0);
	for (size_t i = 0; const auto &x : v) {
		lua_pushnumber(L, x);
		lua_rawseti(L, -2, ++i);
	}
}

template <typename T>
static size_t PushUnitListSortedByDef(lua_State *const L, const T &units)
{
	using unitDefID_t = int;
	using unitID_t = int;

	std::map <unitDefID_t, std::vector <unitID_t>> unitsByDef;

	for (const auto unitID : units)
		unitsByDef[unitHandler.GetUnit(unitID)->unitDef->id].push_back(unitID);

	lua_createtable(L, 0, unitsByDef.size());

	for (const auto & [unitDefID, unitIDs] : unitsByDef) {
		assert(!unitIDs.empty());

		PushNumberContainerAsArray(L, unitIDs);
		lua_rawseti(L, -2, unitDefID);
	}

	return unitsByDef.size();
}

template <typename T>
static size_t PushSparseUnitTallyByDef(lua_State *const L, const T &v)
{
	std::vector <size_t> counts (unitDefHandler->NumUnitDefs() + 1, 0);
	size_t numDefKeys = 0;
	for (const int unitID: v)
		if (!counts[unitHandler.GetUnit(unitID)->unitDef->id]++)
			numDefKeys++;

	lua_createtable(L, 0, numDefKeys);
	for (size_t i = 0; i < counts.size(); ++i) {
		if (counts[i] == 0)
			continue;

		lua_pushnumber(L, counts[i]);
		lua_rawseti(L, -2, i);
	}

	return numDefKeys;
}


/******************************************************************************
 * Replay
 * @section replay
******************************************************************************/

/***
 *
 * @function Spring.IsReplay
 *
 * @return boolean? isReplay
 */
int LuaUnsyncedRead::IsReplay(lua_State* L)
{
	lua_pushboolean(L, gameSetup->hostDemo);
	return 1;
}


/***
 *
 * @function Spring.GetReplayLength
 *
 * @return number? timeInSeconds
 */
int LuaUnsyncedRead::GetReplayLength(lua_State* L)
{
	if (gameServer != nullptr && gameServer->GetDemoReader()) {
		lua_pushnumber(L, gameServer->GetDemoReader()->GetFileHeader().gameTime);
		return 1;
	}
	return 0;
}

/******************************************************************************
 * Game/Menu Name
 * @section gamename
******************************************************************************/

/***
 *
 * @function Spring.GetGameName
 *
 * @return string name
 */
int LuaUnsyncedRead::GetGameName(lua_State* L)
{
	lua_pushstring(L, modInfo.humanNameVersioned.c_str());
	return 1;
}

/***
 *
 * @function Spring.GetMenuName
 *
 * @return string name name .. version from Modinfo.lua. E.g. "Spring: 1944 test-5640-ac2d15b".
 */
int LuaUnsyncedRead::GetMenuName(lua_State* L)
{
	lua_pushstring(L, luaMenuController->GetMenuName().c_str());
	return 1;
}


/******************************************************************************
 * Profiling
 * @section profiling
******************************************************************************/


/***
 *
 * @function Spring.GetProfilerTimeRecord
 *
 * @param profilerName string
 * @param frameData boolean? (Default: `false`)
 *
 * @return number total in ms
 * @return number current in ms
 * @return number max_dt
 * @return number time_pct
 * @return number peak_pct
 * @return table<number,number>? frameData Table where key is the frame index and value is duration.
 */
int LuaUnsyncedRead::GetProfilerTimeRecord(lua_State* L)
{
	const CTimeProfiler::TimeRecord& record = CTimeProfiler::GetInstance().GetTimeRecord(lua_tostring(L, 1));

	int numRet = 5;
	lua_pushnumber(L, record.total.toMilliSecsf());
	lua_pushnumber(L, record.current.toMilliSecsf());
	lua_pushnumber(L, record.stats.x); // max-dt
	lua_pushnumber(L, record.stats.y); // time-%
	lua_pushnumber(L, record.stats.z); // peak-%

	if (luaL_optboolean(L, 2, false)) {
		for (size_t i = 0; i < record.frames.size(); i++) {
			lua_pushnumber(L, i + 1); // key
			lua_pushnumber(L, record.frames[i].toMilliSecsf()); // val
			lua_rawset(L, -3);
		}
		++numRet;
	}

	return numRet;
}

/***
 *
 * @function Spring.GetProfilerRecordNames
 *
 * @return string[] profilerNames
 */
int LuaUnsyncedRead::GetProfilerRecordNames(lua_State* L)
{
	const auto& sortedProfiles = CTimeProfiler::GetInstance().GetSortedProfiles();

	lua_createtable(L, sortedProfiles.size(), 0);

	for (size_t i = 0; i < sortedProfiles.size(); i++) {
		lua_pushnumber(L, i + 1); // key
		lua_pushsstring(L, sortedProfiles[i].first); // val
		lua_rawset(L, -3);
	}

	return 1;
}


/***
 *
 * @function Spring.GetLuaMemUsage
 *
 * @return number luaHandleAllocedMem in kilobytes
 * @return number luaHandleNumAllocs divided by 1000
 * @return number luaGlobalAllocedMem in kilobytes
 * @return number luaGlobalNumAllocs divided by 1000
 * @return number luaUnsyncedGlobalAllocedMem in kilobytes
 * @return number luaUnsyncedGlobalNumAllocs divided by 1000
 * @return number luaSyncedGlobalAllocedMem in kilobytes
 * @return number luaSyncedGlobalNumAllocs divided by 1000
 */
int LuaUnsyncedRead::GetLuaMemUsage(lua_State* L)
{
	const luaContextData* lcd = GetLuaContextData(L);

	// handle and global stats
	const SLuaAllocState* lhs = &lcd->allocState;
	      SLuaAllocState  lgs;

	spring_lua_alloc_get_stats(&lgs);

	lua_pushnumber(L, lhs->allocedBytes / 1024.0f); // (kilo)bytes, can exceed 1<<24 otherwise
	lua_pushnumber(L, lhs->numLuaAllocs / 1000.0f); // (kilo)allocs, ditto
	lua_pushnumber(L, lgs.allocedBytes / 1024.0f);
	lua_pushnumber(L, lgs.numLuaAllocs / 1000.0f);

	// [0] := unsynced, [1] := synced
	extern const spring::unsynced_set<const luaContextData*>* LUAHANDLE_CONTEXTS[2];

	// sum up the individual (unsynced and synced) state footprints
	for (bool synced: {false, true}) {
		lgs.allocedBytes = {0};
		lgs.numLuaAllocs = {0};

		for (const luaContextData* lcd: *LUAHANDLE_CONTEXTS[synced]) {
			lhs = &lcd->allocState;

			lgs.allocedBytes += lhs->allocedBytes;
			lgs.numLuaAllocs += lhs->numLuaAllocs;
		}

		lua_pushnumber(L, lgs.allocedBytes / 1024.0f);
		lua_pushnumber(L, lgs.numLuaAllocs / 1000.0f);
	}

	return 8;
}


/***
 *
 * @function Spring.GetVidMemUsage
 *
 * @return number usedMem in MB
 * @return number availableMem in MB
 */
int LuaUnsyncedRead::GetVidMemUsage(lua_State* L)
{
	int2 vidMemInfo;

	GetAvailableVideoRAM(&vidMemInfo.x, globalRenderingInfo.glVendor);

	lua_pushnumber(L, (vidMemInfo.x - vidMemInfo.y) / 1024.0f); // MB (used = total - free)
	lua_pushnumber(L, (vidMemInfo.x               ) / 1024.0f); // MB
	return 2;
}


static void PushTimer(lua_State* L, const spring_time& time, bool microseconds)
{
	// use time since Spring's epoch in MILLIseconds because that
	// is more likely to fit in a 32-bit pointer (on any platforms
	// where sizeof(void*) == 4) than time since ::chrono's epoch
	// (which can be arbitrarily large) and can be represented by
	// single-precision floats better
	//
	// 4e9millis == 4e6s == 46.3 days until overflow
	ptrdiff_t p = 0;

	if (microseconds) {
		const std::uint64_t micros = time.toMicroSecs<std::uint64_t>();

		if (sizeof(void*) == 8) {
			p = spring::SafeCast<std::uint64_t>(micros);
		}
		else {
			p = spring::SafeCast<std::uint32_t>(micros);
		}
	}
	else {
		const std::uint64_t millis = time.toMilliSecs<std::uint64_t>();

		if (sizeof(void*) == 8) {
			p = spring::SafeCast<std::uint64_t>(millis);
		}
		else {
			p = spring::SafeCast<std::uint32_t>(millis);
		}
	}

	lua_pushlightuserdata(L, reinterpret_cast<void*>(p));
}

/*** Get a timer with millisecond resolution
 *
 * @function Spring.GetTimer
 * @return integer
 */
int LuaUnsyncedRead::GetTimer(lua_State* L)
{
	PushTimer(L, spring_now(), false);
	return 1;
}


/*** Get a timer with microsecond resolution
 *
 * @function Spring.GetTimerMicros
 * @return integer
 */
int LuaUnsyncedRead::GetTimerMicros(lua_State* L)
{
	PushTimer(L, spring_now(), true);
	return 1;
}


/*** Get a timer for the start of the frame
 *
 * @function Spring.GetFrameTimer
 *
 * This should give better results for camera interpolations
 *
 * @param lastFrameTime boolean? (Default: `false`) whether to use last frame time instead of last frame start
 * @return integer
 */
int LuaUnsyncedRead::GetFrameTimer(lua_State* L)
{
	if (luaL_optboolean(L, 1, false)) {
		PushTimer(L, game->lastFrameTime, false);
	} else {
		PushTimer(L, globalRendering->lastFrameStart, false);
	}
	return 1;
}


/***
 *
 * @function Spring.DiffTimers
 * @param endTimer integer
 * @param startTimer integer
 * @param returnMs boolean? (Default: `false`) whether to return `timeAmount` in milliseconds as opposed to seconds
 * @param fromMicroSecs boolean? (Default: `false`) whether timers are in microseconds instead of milliseconds
 * @return number timeAmount
 */
int LuaUnsyncedRead::DiffTimers(lua_State* L)
{
	if (!lua_islightuserdata(L, 1) || !lua_islightuserdata(L, 2)) {
		luaL_error(L, "Incorrect arguments to DiffTimers()");
	}

	const void* p1 = lua_touserdata(L, 1);
	const void* p2 = lua_touserdata(L, 2);

	const std::uint64_t t1 = (sizeof(void*) == 8) ?
		*reinterpret_cast<std::uint64_t*>(&p1) :
		*reinterpret_cast<std::uint32_t*>(&p1);
	const std::uint64_t t2 = (sizeof(void*) == 8) ?
		*reinterpret_cast<std::uint64_t*>(&p2) :
		*reinterpret_cast<std::uint32_t*>(&p2);

	// t1 is supposed to be the most recent time-point
	assert(t1 >= t2);

	if (luaL_optboolean(L, 4, false)) {
		const spring_time dt = spring_time::fromMicroSecs(t1 - t2);

		if (luaL_optboolean(L, 3, false)) {
			lua_pushnumber(L, dt.toMilliSecsf());
		}
		else {
			lua_pushnumber(L, dt.toSecsf());
		}
	}
	else {
		const spring_time dt = spring_time::fromMilliSecs(t1 - t2);

		if (luaL_optboolean(L, 3, false)) {
			lua_pushnumber(L, dt.toMilliSecsf());
		}
		else {
			lua_pushnumber(L, dt.toSecsf());
		}
	}
	return 1;
}


/******************************************************************************
 * Screen/Rendering Info
 * @section screeninfo
******************************************************************************/


/***
 *
 * @function Spring.GetNumDisplays
 *
 * @return number numDisplays as returned by `SDL_GetNumVideoDisplays`
 */
int LuaUnsyncedRead::GetNumDisplays(lua_State* L)
{
	lua_pushnumber(L, SDL_GetNumVideoDisplays());
	return 1;
}


/*** Get main view geometry (map and game rendering)
 *
 * @function Spring.GetViewGeometry
 *
 * @return number viewSizeX in px
 * @return number viewSizeY in px
 * @return number viewPosX offset from leftmost screen left border in px
 * @return number viewPosY offset from bottommost screen bottom border in px
 */
int LuaUnsyncedRead::GetViewGeometry(lua_State* L)
{
	lua_pushnumber(L, globalRendering->viewSizeX);
	lua_pushnumber(L, globalRendering->viewSizeY);
	lua_pushnumber(L, globalRendering->viewPosX);
	lua_pushnumber(L, globalRendering->viewPosY);
	return 4;
}


/*** Get dual view geometry (minimap when enabled)
 *
 * @function Spring.GetDualViewGeometry
 *
 * @return number dualViewSizeX in px
 * @return number dualViewSizeY in px
 * @return number dualViewPosX offset from leftmost screen left border in px
 * @return number dualViewPosY offset from bottommost screen bottom border in px
 */
int LuaUnsyncedRead::GetDualViewGeometry(lua_State* L)
{
	lua_pushnumber(L, globalRendering->dualViewSizeX);
	lua_pushnumber(L, globalRendering->dualViewSizeY);
	lua_pushnumber(L, globalRendering->dualViewPosX);
	lua_pushnumber(L, globalRendering->dualViewPosY);
	return 4;
}


/*** Get main window geometry
 *
 * @function Spring.GetWindowGeometry
 *
 * @return number winSizeX in px
 * @return number winSizeY in px
 * @return number winPosX in px
 * @return number winPosY in px
 * @return number windowBorderTop in px
 * @return number windowBorderLeft in px
 * @return number windowBorderBottom in px
 * @return number windowBorderRight in px
 */
int LuaUnsyncedRead::GetWindowGeometry(lua_State* L)
{
	// origin BOTTOMLEFT
	const int winPosY_bl = globalRendering->screenSizeY - globalRendering->winSizeY - globalRendering->winPosY;

	lua_pushnumber(L, globalRendering->winSizeX);
	lua_pushnumber(L, globalRendering->winSizeY);
	lua_pushnumber(L, globalRendering->winPosX);
	lua_pushnumber(L, winPosY_bl);

	lua_pushnumber(L, globalRendering->winBorder[0]);
	lua_pushnumber(L, globalRendering->winBorder[1]);
	lua_pushnumber(L, globalRendering->winBorder[2]);
	lua_pushnumber(L, globalRendering->winBorder[3]);
	return 4 + 4;
}

/*** Get main window display mode
 *
 * @function Spring.GetWindowDisplayMode
 * @return number width in px
 * @return number height in px
 * @return number bits per pixel
 * @return number refresh rate in Hz
 */
int LuaUnsyncedRead::GetWindowDisplayMode(lua_State* L)
{
	SDL_DisplayMode dmode;
	if (!SDL_GetWindowDisplayMode(globalRendering->GetWindow(), &dmode)) {
		lua_pushnumber(L, dmode.w);
		lua_pushnumber(L, dmode.h);
		lua_pushnumber(L, SDL_BITSPERPIXEL(dmode.format));
		lua_pushnumber(L, dmode.refresh_rate);
		lua_pushstring(L, SDL_GetPixelFormatName(dmode.format));
		return 5;
	}
	return 0;
}


/*** Get screen geometry
 *
 * @function Spring.GetScreenGeometry
 *
 * @param displayIndex number? (Default: `-1`)
 * @param queryUsable boolean? (Default: `false`)
 *
 * @return number screenSizeX in px
 * @return number screenSizeY in px
 * @return number screenPosX in px
 * @return number screenPosY in px
 * @return number windowBorderTop in px
 * @return number windowBorderLeft in px
 * @return number windowBorderBottom in px
 * @return number windowBorderRight in px
 * @return number? screenUsableSizeX in px
 * @return number? screenUsableSizeY in px
 * @return number? screenUsablePosX in px
 * @return number? screenUsablePosY in px
 */
int LuaUnsyncedRead::GetScreenGeometry(lua_State* L)
{
	const int displayIndex = luaL_optint(L, 1, -1);
	const int* displayIndexPtr = (displayIndex != -1) ? &displayIndex : nullptr;
	const bool queryUsable = luaL_optboolean(L, 2, false); // whether to query usable screen size

	if (displayIndexPtr == nullptr) {
		lua_pushnumber(L, globalRendering->screenSizeX);
		lua_pushnumber(L, globalRendering->screenSizeY);
		lua_pushnumber(L, globalRendering->screenPosX);
		lua_pushnumber(L, globalRendering->screenPosY);
	}
	else {
		SDL_Rect r{};
		globalRendering->GetDisplayBounds(r, displayIndexPtr);
		lua_pushnumber(L, r.w);
		lua_pushnumber(L, r.h);
		lua_pushnumber(L, r.x);
		lua_pushnumber(L, r.y);
	}

	if (!queryUsable)
		return 4;

	{
		SDL_Rect r{};
		globalRendering->GetUsableDisplayBounds(r, displayIndexPtr);
		lua_pushnumber(L, r.w);
		lua_pushnumber(L, r.h);
		lua_pushnumber(L, r.x);
		lua_pushnumber(L, r.y);

		return 4 + 4;
	}
}


/*** Get minimap geometry
 *
 * @function Spring.GetMiniMapGeometry
 *
 * @return number minimapPosX in px
 * @return number minimapPosY in px
 * @return number minimapSizeX in px
 * @return number minimapSizeY in px
 * @return boolean minimized
 * @return boolean maximized
 */
int LuaUnsyncedRead::GetMiniMapGeometry(lua_State* L)
{
	if (minimap == nullptr)
		return 0;

	lua_pushnumber(L, minimap->GetPosX());
	lua_pushnumber(L, minimap->GetPosY());
	lua_pushnumber(L, minimap->GetSizeX());
	lua_pushnumber(L, minimap->GetSizeY());
	lua_pushboolean(L, minimap->GetMinimized());
	lua_pushboolean(L, minimap->GetMaximized());

	return 6;
}


/*** Get minimap rotation
 *
 * @function Spring.GetMiniMapRotation
 * @return number amount in radians
 */
int LuaUnsyncedRead::GetMiniMapRotation(lua_State* L)
{
	if (minimap == nullptr)
		return 0;

	lua_pushnumber(L, minimap->GetRotation());

	return 1;
}


/***
 * @function Spring.GetMiniMapDualScreen
 * @return "left"|"right"|false position `"left"` or `"right"` when dual screen is enabled, otherwise `false`.
 */
int LuaUnsyncedRead::GetMiniMapDualScreen(lua_State* L)
{
	if (minimap == nullptr)
		return 0;

	if (!globalRendering->dualScreenMode) {
		lua_pushboolean(L, false);
	} else {
		if (globalRendering->dualScreenMiniMapOnLeft) {
			lua_pushliteral(L, "left");
		} else {
			lua_pushliteral(L, "right");
		}
	}
	return 1;
}


/*** Get vertices from currently active selection box
 *
 * @function Spring.GetSelectionBox
 *
 * Returns nil when selection box is inactive
 *
 * @return number? left
 * @return number? top
 * @return number? right
 * @return number? bottom
 *
 * @see Spring.GetUnitsInScreenRectangle
 */
int LuaUnsyncedRead::GetSelectionBox(lua_State* L)
{
	float3 bl, br, tl, tr;
	if (!mouse->GetSelectionBoxVertices(bl, br, tl, tr)) {
		lua_pushnil(L);

		return 1;
	}

	const auto bottomLeft = camera->CalcViewPortCoordinates(bl);
	const auto topRight   = camera->CalcViewPortCoordinates(tr);

	lua_pushnumber(L, bottomLeft.x);
	lua_pushnumber(L, topRight.y);
	lua_pushnumber(L, topRight.x);
	lua_pushnumber(L, bottomLeft.y);

	return 4;
}


/***
 *
 * @function Spring.GetDrawSelectionInfo
 * @return boolean
 */
int LuaUnsyncedRead::GetDrawSelectionInfo(lua_State* L)
{
	lua_pushboolean(L, guihandler ? guihandler->GetDrawSelectionInfo() : 0);
	return 1;
}


/***
 *
 * @function Spring.IsAboveMiniMap
 *
 * @param x number
 * @param y number
 *
 * @return boolean isAbove
 */
int LuaUnsyncedRead::IsAboveMiniMap(lua_State* L)
{
	if (minimap == nullptr)
		return 0;

	if (minimap->GetMinimized() || game->hideInterface)
		return false;

	const int x = luaL_checkint(L, 1) + globalRendering->viewPosX;
	const int y = luaL_checkint(L, 2) + globalRendering->viewPosY;

	const int x0 = minimap->GetPosX();
	const int y0 = minimap->GetPosY();
	const int x1 = x0 + minimap->GetSizeX();
	const int y1 = y0 + minimap->GetSizeY();

	lua_pushboolean(L, (x >= x0) && (x < x1) &&
	                   (y >= y0) && (y < y1));

	return 1;
}


/***
 *
 * @function Spring.GetDrawFrame
 *
 * @return number low_16bit
 * @return number high_16bit
 */
int LuaUnsyncedRead::GetDrawFrame(lua_State* L)
{
	lua_pushnumber(L, globalRendering->drawFrame & 0xFFFF);
	lua_pushnumber(L, (globalRendering->drawFrame >> 16) & 0xFFFF);
	return 2;
}


/***
 *
 * @function Spring.GetFrameTimeOffset
 *
 * Ideally, when running 30hz sim, and 60hz rendering, the draw frames should
 * have and offset of either 0.0 frames, or 0.5 frames.
 *
 * When draw frames are not integer multiples of sim frames, some interpolation
 * happens, and this timeoffset shows how far along it is.
 *
 * @return number? offset of the current draw frame from the last sim frame, expressed in fractions of a frame
 */
int LuaUnsyncedRead::GetFrameTimeOffset(lua_State* L)
{
	lua_pushnumber(L, globalRendering->timeOffset);
	return 1;
}

/*** Gets game time for drawing purposes
 *
 * Returns the game time, taking the interpolated draw frame into account.
 *
 * @return number game time in seconds
 */
int LuaUnsyncedRead::GetGameSecondsInterpolated(lua_State* L)
{
	lua_pushnumber(L, (gs->GetLuaSimFrame() + globalRendering->timeOffset) / GAME_SPEED);
	return 1;
}

/***
 *
 * @function Spring.GetLastUpdateSeconds
 *
 * @return number? lastUpdateSeconds
 */
int LuaUnsyncedRead::GetLastUpdateSeconds(lua_State* L)
{
	lua_pushnumber(L, game->updateDeltaSeconds);
	return 1;
}


/***
 *
 * @function Spring.GetVideoCapturingMode
 *
 * @return boolean allowRecord
 */
int LuaUnsyncedRead::GetVideoCapturingMode(lua_State* L)
{
	lua_pushboolean(L, videoCapturing->AllowRecord());
	return 1;
}


/******************************************************************************
 * Unit attributes
 * @section unitattributes
******************************************************************************/


/***
 *
 * @function Spring.IsUnitAllied
 * @param unitID integer
 * @return boolean? isAllied nil with unitID cannot be parsed
 */
int LuaUnsyncedRead::IsUnitAllied(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	if (CLuaHandle::GetHandleReadAllyTeam(L) < 0) {
		// in this case handle has full-read access since unit != nullptr
		lua_pushboolean(L, unit->allyteam == gu->myAllyTeam);
	} else {
		lua_pushboolean(L, unit->allyteam == CLuaHandle::GetHandleReadAllyTeam(L));
	}

	return 1;
}


/***
 *
 * @function Spring.IsUnitSelected
 * @param unitID integer
 * @return boolean? isSelected nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::IsUnitSelected(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);
	if (unit == nullptr)
		return 0;

	const auto& selUnits = selectedUnitsHandler.selectedUnits;
	lua_pushboolean(L, selUnits.find(unit->id) != selUnits.end());
	return 1;
}


/***
 *
 * @function Spring.GetUnitLuaDraw
 * @param unitID integer
 * @return boolean? draw nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::GetUnitLuaDraw(lua_State* L)
{
	return (GetSolidObjectLuaDraw(L, ParseUnit(L, __func__, 1)));
}

/***
 *
 * @function Spring.GetUnitNoDraw
 * @param unitID integer
 * @return boolean? nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::GetUnitNoDraw(lua_State* L)
{
	return (GetSolidObjectNoDraw(L, ParseUnit(L, __func__, 1)));
}

/***
 *
 * @function Spring.GetUnitEngineDrawMask
 * @param unitID integer
 * @return boolean? nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::GetUnitEngineDrawMask(lua_State* L)
{
	return (GetSolidObjectEngineDrawMask(L, ParseUnit(L, __func__, 1)));
}

/***
 *
 * @function Spring.GetUnitAlwaysUpdateMatrix
 * @param unitID integer
 * @return boolean? nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::GetUnitAlwaysUpdateMatrix(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, unit->alwaysUpdateMat);
	return 1;
}

/***
 *
 * @function Spring.GetUnitDrawFlag
 * @param unitID integer
 * @return number? nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::GetUnitDrawFlag(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushinteger(L, unit->drawFlag);
	return 1;
}

/***
 *
 * @function Spring.GetUnitNoMinimap
 * @param unitID integer
 * @return boolean? nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::GetUnitNoMinimap(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, unit->noMinimap);
	return 1;
}

/***
 * Check if a unit is not allowed to be added to a group by a player.
 *
 * @function Spring.GetUnitNoGroup
 * @param unitID integer
 * @return boolean? noGroup `true` if the unit is not allowed to be added to a group, `false` if it is allowed to be added to a group, or `nil` when `unitID` is not valid.
 */
int LuaUnsyncedRead::GetUnitNoGroup(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, unit->noGroup);
	return 1;
}

/***
 *
 * @function Spring.GetUnitNoSelect
 * @param unitID integer
 * @return boolean? noSelect `nil` when `unitID` cannot be parsed.
 */
int LuaUnsyncedRead::GetUnitNoSelect(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, unit->noSelect);
	return 1;
}


/***
 *
 * @function Spring.UnitIconGetDraw
 * @param unitID integer
 * @return boolean? drawIcon
 * `true` if icon is being drawn, `nil` when unitID is invalid, otherwise `false`.
 */
int LuaUnsyncedRead::UnitIconGetDraw(lua_State* L) {
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, unit->drawIcon);
	return 1;
}

/*** Icon Data
 *
 * @class IconData
 */

/***
 * @class TexCoords
 * @field x0 number left coordinate in the normalized range
 * @field x1 number right coordinate in the normalized range
 * @field y0 number top coordinate in the normalized range
 * @field y1 number bottom coordinate in the normalized range
 * @field atlasIndex integer? Means the atlas page number in case the texture is arrayed or points to another sequential texture in other rare cases
 */

namespace Impl {
	template<bool full>
	void PushIconData(lua_State* L, const icon::IconData& iconData) {
		lua_createtable(L, 0, 2 + 5 * !full);

		/*** @field IconData.name string */
		LuaPushNamedString(L, "name", iconData.GetName());
		if constexpr (full) {
			/*** @field IconData.fileName string? */
			LuaPushNamedString(L, "fileName", iconData.GetFileName());
			/*** @field IconData.size number? Relative size of the icon */
			LuaPushNamedNumber(L, "size", iconData.GetSize());
			/*** @field IconData.distance number? When squared used as a icon length multiplier */
			LuaPushNamedNumber(L, "distance", iconData.GetDistance());
			/*** @field IconData.radiusAdjust boolean? Controls whether the unit radius affects the icon size */
			LuaPushNamedBool(L, "radiusAdjust", iconData.GetRadiusAdjust());

			/*** @field IconData.srcTexCoords TexCoords? */
			{
				const auto& stc = iconData.GetSrcTexCoords();
				lua_pushliteral(L, "srcTexCoords");
				lua_createtable(L, 0, 4);

				LuaPushNamedNumber(L, "x0", stc.x1);
				LuaPushNamedNumber(L, "y0", stc.y1);
				LuaPushNamedNumber(L, "x1", stc.x2);
				LuaPushNamedNumber(L, "y1", stc.y2);

				lua_rawset(L, -3);
			}
		}

		/*** @field IconData.atlasTexCoords TexCoords atlasIndex points to $icons0 or $icons1 texture */
		const auto& atc = iconData.GetTexCoords();
		{
			lua_pushliteral(L, "atlasTexCoords");
			lua_createtable(L, 0, 5);

			LuaPushNamedNumber(L, "x0", atc.x1);
			LuaPushNamedNumber(L, "y0", atc.y1);
			LuaPushNamedNumber(L, "x1", atc.x2);
			LuaPushNamedNumber(L, "y1", atc.y2);
			LuaPushNamedNumber(L, "atlasIndex", atc.pageNum);

			lua_rawset(L, -3);
		}
	}

	template<bool full>
	int GetIconDataImpl(lua_State* L, size_t iconIdx) {
		if (iconIdx == icon::INVALID_ICON_INDEX)
			return 0;

		const auto& iconData = icon::iconHandler.GetIconData(iconIdx);

		PushIconData<full>(L, iconData);
		return 1;
	}
}

/*** Get unit icon data
 *
 * @function Spring.GetUnitIconData
 * @param unitID number
 * @param fullData boolean? (Default: false) Whether additional information about the icon is returned, otherwise only `name` and `atlasTexCoords` are returned
 * @return IconData iconData
 * @see Spring.GetIconData
 */
int LuaUnsyncedRead::GetUnitIconData(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);
	const auto fullData = luaL_optboolean(L, 2, false);

	if (unit == nullptr)
		return 0;

	if (fullData)
		return Impl::GetIconDataImpl<true >(L, unit->currentIconIndex);
	else
		return Impl::GetIconDataImpl<false>(L, unit->currentIconIndex);
}

/*** Get icon data
 *
 * @function Spring.GetIconData
 * @param iconName string
 * @param fullData boolean? (Default: false) Whether additional information about the icon is returned, otherwise only `name` and `atlasTexCoords` are returned
 * @return IconData iconData
 * @see Spring.GetUnitIconData
 */
int LuaUnsyncedRead::GetIconData(lua_State* L)
{
	const auto iconName = luaL_checkstring(L, 1);
	const auto fullData = luaL_optboolean(L, 2, false);

	const auto iconIdx = icon::iconHandler.GetIconIdx(iconName);

	if (fullData)
		return Impl::GetIconDataImpl<true >(L, iconIdx);
	else
		return Impl::GetIconDataImpl<false>(L, iconIdx);
}

/*** Get icon data
 *
 * @function Spring.GetAllIconDataArray
 * @param fullData boolean? (Default: false) Whether additional information about each icon is returned, otherwise only `name` and `atlasTexCoords` are returned
 * @return IconData[] iconDataList
 * @see Spring.GetUnitIconData
 * @see Spring.GetIconData
 */
int LuaUnsyncedRead::GetAllIconDataArray(lua_State* L)
{
	const auto fullData = luaL_optboolean(L, 1, false);

	const auto& iconsData = icon::iconHandler.GetIconsData();

	lua_createtable(L, iconsData.size(), 0);
	for (size_t i = 0; i < iconsData.size(); ++i) {
		const auto& iconData = iconsData[i];
		if (fullData)
			Impl::PushIconData<true >(L, iconData);
		else
			Impl::PushIconData<false>(L, iconData);

		lua_rawseti(L, -2, i + 1);
	}

	return 1;
}

/***
 *
 * @function Spring.GetUnitSelectionVolumeData
 * @param unitID integer
 * @return number? scaleX nil when unitID cannot be parsed
 * @return number scaleY
 * @return number scaleZ
 * @return number offsetX
 * @return number offsetY
 * @return number offsetZ
 * @return number volumeType
 * @return number useContHitTest
 * @return number getPrimaryAxis
 * @return boolean ignoreHits
 */
int LuaUnsyncedRead::GetUnitSelectionVolumeData(lua_State* L)
{
	return GetSolidObjectSelectionVolume(L, ParseUnit(L, __func__, 1));
}


/******************************************************************************
 * Feature attributes
 * @section featureattributes
******************************************************************************/


/***
 *
 * @function Spring.GetFeatureLuaDraw
 * @param featureID integer
 * @return boolean? nil when featureID cannot be parsed
 */
int LuaUnsyncedRead::GetFeatureLuaDraw(lua_State* L)
{
	return (GetSolidObjectLuaDraw(L, ParseFeature(L, __func__, 1)));
}

/***
 *
 * @function Spring.GetFeatureNoDraw
 * @param featureID integer
 * @return boolean? nil when featureID cannot be parsed
 */
int LuaUnsyncedRead::GetFeatureNoDraw(lua_State* L)
{
	return (GetSolidObjectNoDraw(L, ParseFeature(L, __func__, 1)));
}

/***
 *
 * @function Spring.GetFeatureEngineDrawMask
 * @param featureID integer
 * @return boolean? nil when featureID cannot be parsed
 */
int LuaUnsyncedRead::GetFeatureEngineDrawMask(lua_State* L)
{
	return (GetSolidObjectEngineDrawMask(L, ParseFeature(L, __func__, 1)));
}

/***
 *
 * @function Spring.GetFeatureAlwaysUpdateMatrix
 * @param featureID integer
 * @return boolean? nil when featureID cannot be parsed
 */
int LuaUnsyncedRead::GetFeatureAlwaysUpdateMatrix(lua_State* L)
{
	CFeature* feature = ParseFeature(L, __func__, 1);

	if (feature == nullptr)
		return 0;

	lua_pushboolean(L, feature->alwaysUpdateMat);
	return 1;
}

/***
 *
 * @function Spring.GetFeatureDrawFlag
 * @param featureID integer
 * @return number? nil when featureID cannot be parsed
 */
int LuaUnsyncedRead::GetFeatureDrawFlag(lua_State* L)
{
	CFeature* feature = ParseFeature(L, __func__, 1);

	if (feature == nullptr)
		return 0;

	lua_pushinteger(L, feature->drawFlag);
	return 1;
}

/***
 *
 * @function Spring.GetFeatureSelectionVolumeData
 * @param featureID integer
 * @return number? scaleX nil when unitID cannot be parsed
 * @return number scaleY
 * @return number scaleZ
 * @return number offsetX
 * @return number offsetY
 * @return number offsetZ
 * @return number volumeType
 * @return number useContHitTest
 * @return number getPrimaryAxis
 * @return boolean ignoreHits
 */
int LuaUnsyncedRead::GetFeatureSelectionVolumeData(lua_State* L)
{
	return GetSolidObjectSelectionVolume(L, ParseFeature(L, __func__, 1));
}



static int GetObjectTransformMatrix(const CSolidObject* o, lua_State* L)
{
	if (o == nullptr)
		return 0;

	CMatrix44f m = o->GetTransformMatrix(false);

	if (luaL_optboolean(L, 2, false))
		m = m.InvertAffine();

	for (int i = 0; i < 16; i += 4) {
		lua_pushnumber(L, m[i + 0]);
		lua_pushnumber(L, m[i + 1]);
		lua_pushnumber(L, m[i + 2]);
		lua_pushnumber(L, m[i + 3]);
	}

	return 16;
}


/******************************************************************************
 * Misc
 * @section misc
******************************************************************************/


/***
 *
 * @function Spring.GetUnitTransformMatrix
 * @param unitID integer
 * @return number? m11 nil when unitID cannot be parsed
 * @return number m12
 * @return number m13
 * @return number m14
 * @return number m21
 * @return number m22
 * @return number m23
 * @return number m24
 * @return number m31
 * @return number m32
 * @return number m33
 * @return number m34
 * @return number m41
 * @return number m42
 * @return number m43
 * @return number m44
 */
int LuaUnsyncedRead::GetUnitTransformMatrix(lua_State* L) { return (GetObjectTransformMatrix(ParseUnit(L, __func__, 1), L)); }


/***
 *
 * @function Spring.GetFeatureTransformMatrix
 * @param featureID integer
 * @return number? m11 nil when featureID cannot be parsed
 * @return number m12
 * @return number m13
 * @return number m14
 * @return number m21
 * @return number m22
 * @return number m23
 * @return number m24
 * @return number m31
 * @return number m32
 * @return number m33
 * @return number m34
 * @return number m41
 * @return number m42
 * @return number m43
 * @return number m44
 */
int LuaUnsyncedRead::GetFeatureTransformMatrix(lua_State* L) { return (GetObjectTransformMatrix(ParseFeature(L, __func__, 1), L)); }


/******************************************************************************
 * Inview
 * @section inview
******************************************************************************/


/***
 *
 * @function Spring.IsUnitInView
 * @param unitID integer
 * @return boolean? inView nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::IsUnitInView(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, camera->InView(unit->midPos, unit->radius));
	return 1;
}


/***
 *
 * @function Spring.IsUnitVisible
 * @param unitID integer
 * @param radius number? unitRadius when not specified
 * @param checkIcon boolean
 * @return boolean? isVisible nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::IsUnitVisible(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	const float radius = luaL_optnumber(L, 2, unit->radius);
	const bool checkIcon = lua_toboolean(L, 3);

	const int readAllyTeam = CLuaHandle::GetHandleReadAllyTeam(L);

	if (readAllyTeam < 0) {
		if (!CLuaHandle::GetHandleFullRead(L)) {
			lua_pushboolean(L, false);
		} else {
			lua_pushboolean(L,
				(!checkIcon || !unit->GetIsIcon()) &&
				camera->InView(unit->midPos, radius));
		}
	}
	else {
		if ((unit->losStatus[readAllyTeam] & LOS_INLOS) == 0) {
			lua_pushboolean(L, false);
		} else {
			lua_pushboolean(L,
				(!checkIcon || !unit->GetIsIcon()) &&
				camera->InView(unit->midPos, radius));
		}
	}
	return 1;
}


/***
 *
 * @function Spring.IsUnitIcon
 * @param unitID integer
 * @return boolean? isUnitIcon nil when unitID cannot be parsed
 */
int LuaUnsyncedRead::IsUnitIcon(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	lua_pushboolean(L, unit->GetIsIcon());
	return 1;
}


/***
 *
 * @function Spring.IsAABBInView
 * @param minX number
 * @param minY number
 * @param minZ number
 * @param maxX number
 * @param maxY number
 * @param maxZ number
 * @return boolean inView
 */
int LuaUnsyncedRead::IsAABBInView(lua_State* L)
{
	float3 mins = float3(luaL_checkfloat(L, 1),
	                     luaL_checkfloat(L, 2),
	                     luaL_checkfloat(L, 3));
	float3 maxs = float3(luaL_checkfloat(L, 4),
	                     luaL_checkfloat(L, 5),
	                     luaL_checkfloat(L, 6));

	if (mins.x > maxs.x) std::swap(mins.x, maxs.x);
	if (mins.y > maxs.y) std::swap(mins.y, maxs.y);
	if (mins.z > maxs.z) std::swap(mins.z, maxs.z);

	lua_pushboolean(L, camera->InView(mins, maxs));
	return 1;
}


/***
 *
 * @function Spring.IsSphereInView
 * @param posX number
 * @param posY number
 * @param posZ number
 * @param radius number? (Default: `0`)
 * @return boolean inView
 */
int LuaUnsyncedRead::IsSphereInView(lua_State* L)
{
	const float3 pos(luaL_checkfloat(L, 1),
	                 luaL_checkfloat(L, 2),
	                 luaL_checkfloat(L, 3));
	const float radius = lua_israwnumber(L, 4) ? lua_tofloat(L, 4) : 0.0f;

	lua_pushboolean(L, camera->InView(pos, radius));
	return 1;
}


/***
 *
 * @function Spring.GetUnitViewPosition
 * @param unitID integer
 * @param midPos boolean? (Default: `false`)
 * @return number? x nil when unitID cannot be parsed
 * @return number y
 * @return number z
 */
int LuaUnsyncedRead::GetUnitViewPosition(lua_State* L)
{
	CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;

	const float3 unitPos = (luaL_optboolean(L, 2, false)) ? unit->GetObjDrawMidPos() : unit->drawPos;
	const float3 errorVec = unit->GetLuaErrorVector(CLuaHandle::GetHandleReadAllyTeam(L), CLuaHandle::GetHandleFullRead(L));

	lua_pushnumber(L, unitPos.x + errorVec.x);
	lua_pushnumber(L, unitPos.y + errorVec.y);
	lua_pushnumber(L, unitPos.z + errorVec.z);
	return 3;
}


/******************************************************************************/
/******************************************************************************/

// never instantiated directly
template<class T> class CWorldObjectQuadDrawer: public CReadMap::IQuadDrawer {
public:
	typedef std::vector<T*> ObjectList;
	typedef std::vector< const ObjectList* > ObjectVector;

	void ResetState() override {
		objectLists.clear();
		objectLists.reserve(64);

		objectCount = 0;
	}

	unsigned int GetQuadCount() const { return (objectLists.size()); }
	unsigned int GetObjectCount() const { return objectCount; }

	const ObjectVector& GetObjectLists() { return objectLists; }

	void AddObjectList(const ObjectList* objects) {
		if (objects->empty())
			return;

		objectLists.push_back(objects);
		objectCount += objects->size();
	}

protected:
	// note: stores pointers to lists, not copies
	// its size equals the number of visible quads
	ObjectVector objectLists;

	unsigned int objectCount;
};


class CVisUnitQuadDrawer: public CWorldObjectQuadDrawer<CUnit> {
public:
	void DrawQuad(int x, int y) override {
		const CQuadField::Quad& q = quadField.GetQuadAt(x, y);
		const ObjectList* o = &q.units;

		AddObjectList(o);
	}
};

class CVisFeatureQuadDrawer: public CWorldObjectQuadDrawer<CFeature> {
public:
	void DrawQuad(int x, int y) override {
		const CQuadField::Quad& q = quadField.GetQuadAt(x, y);
		const ObjectList* o = &q.features;

		AddObjectList(o);
	}
};

class CVisProjectileQuadDrawer: public CWorldObjectQuadDrawer<CProjectile> {
public:
	void DrawQuad(int x, int y) override {
		const CQuadField::Quad& q = quadField.GetQuadAt(x, y);
		const ObjectList* o = &q.projectiles;

		AddObjectList(o);
	}
};


/***
 *
 * @function Spring.GetVisibleUnits
 * @param teamID integer? (Default: `-1`)
 * @param radius number? (Default: `30`)
 * @param icons boolean? (Default: `true`)
 * @return number[]? unitIDs
 */
int LuaUnsyncedRead::GetVisibleUnits(lua_State* L)
{
	// arg 1 - teamID
	int teamID = luaL_optint(L, 1, -1);
	int allyTeamID = CLuaHandle::GetHandleReadAllyTeam(L);

	if (teamID == LuaUtils::MyUnits) {
		const int scriptTeamID = CLuaHandle::GetHandleReadTeam(L);

		if (scriptTeamID >= 0) {
			teamID = scriptTeamID;
		} else {
			teamID = LuaUtils::AllUnits;
		}
	}

	if (teamID >= 0) {
		if (!teamHandler.IsValidTeam(teamID))
			return 0;

		allyTeamID = teamHandler.AllyTeam(teamID);
	}
	if (allyTeamID < 0) {
		if (!CLuaHandle::GetHandleFullRead(L)) {
			return 0;
		}
	}

	// arg 3 - noIcons
	const bool noIcons = !luaL_optboolean(L, 3, true);

	float radiusMult = 1.0f;
	float testRadius = 0.0f;

	// arg 2 - use fixed test-value or add unit radii to it
	if (lua_israwnumber(L, 2)) {
		radiusMult = float((testRadius = lua_tofloat(L, 2)) >= 0.0f);
		testRadius = std::max(testRadius, -testRadius);
	}

	static CVisUnitQuadDrawer unitQuadIter;

	unitQuadIter.ResetState();
	readMap->GridVisibility(nullptr, &unitQuadIter, 1e9, CQuadField::BASE_QUAD_SIZE / SQUARE_SIZE);

	// Even though we're in unsynced it's ok to use gs->tempNum since its exact value
	// doesn't matter
	const int tempNum = gs->GetTempNum();
	lua_createtable(L, unitQuadIter.GetObjectCount(), 0);

	unsigned int count = 0;
	for (auto visUnitList: unitQuadIter.GetObjectLists()) {
		for (CUnit* u: *visUnitList) {
			if (u->tempNum == tempNum)
				continue;

			u->tempNum = tempNum;

			if (u->noDraw)
				continue;

			if (allyTeamID >= 0 && !(u->losStatus[allyTeamID] & LOS_INLOS))
				continue;

			if (noIcons && u->GetIsIcon())
				continue;

			if ((teamID == LuaUtils::AllyUnits)  && (allyTeamID != u->allyteam))
				continue;

			if ((teamID == LuaUtils::EnemyUnits) && (allyTeamID == u->allyteam))
				continue;

			if ((teamID >= 0) && (teamID != u->team))
				continue;

			//No check for AllUnits, since there's no need.

			if (!camera->InView(u->drawMidPos, testRadius + (u->GetDrawRadius() * radiusMult)))
				continue;

			lua_pushnumber(L, u->id);
			lua_rawseti(L, -2, ++count);
		}
	}

	return 1;
}


/***
 *
 * @function Spring.GetVisibleFeatures
 * @param teamID integer? (Default: `-1`)
 * @param radius number? (Default: `30`)
 * @param icons boolean? (Default: `true`)
 * @param geos boolean? (Default: `true`)
 * @return number[]? featureIDs
 */
int LuaUnsyncedRead::GetVisibleFeatures(lua_State* L)
{
	// arg 1 - allyTeamID
	int allyTeamID = luaL_optint(L, 1, -1);

	if (allyTeamID >= 0) {
		if (!teamHandler.ValidAllyTeam(allyTeamID)) {
			return 0;
		}
	} else {
		allyTeamID = -1;

		if (!CLuaHandle::GetHandleFullRead(L)) {
			allyTeamID = CLuaHandle::GetHandleReadAllyTeam(L);
		}
	}

	const bool noIcons = !luaL_optboolean(L, 3, true);
	const bool noGeos = !luaL_optboolean(L, 4, true);

	float radiusMult = 0.0f; // 0 or 1
	float testRadius = 0.0f;

	// arg 2 - use fixed test-value or add feature radii to it
	if (lua_israwnumber(L, 2)) {
		radiusMult = float((testRadius = lua_tofloat(L, 2)) >= 0.0f);
		testRadius = std::max(testRadius, -testRadius);
	}

	static CVisFeatureQuadDrawer featureQuadIter;

	featureQuadIter.ResetState();
	readMap->GridVisibility(nullptr, &featureQuadIter, 1e9, CQuadField::BASE_QUAD_SIZE / SQUARE_SIZE);

	// Even though we're in unsynced it's ok to use gs->tempNum since its exact value
	// doesn't matter
	const int tempNum = gs->GetTempNum();
	lua_createtable(L, featureQuadIter.GetObjectCount(), 0);

	unsigned int count = 0;
	for (auto visFeatureList: featureQuadIter.GetObjectLists()) {
		for (CFeature* f: *visFeatureList) {
			if (f->tempNum == tempNum)
				continue;

			f->tempNum = tempNum;

			if (f->noDraw)
				continue;

			if (noIcons && f->drawFlag == DrawFlags::SO_DRICON_FLAG)
				continue;

			if (noGeos && f->def->geoThermal)
				continue;

			if (!gu->spectatingFullView && !f->IsInLosForAllyTeam(allyTeamID))
				continue;

			if (!camera->InView(f->drawMidPos, testRadius + (f->GetDrawRadius() * radiusMult)))
				continue;

			lua_pushnumber(L, f->id);
			lua_rawseti(L, -2, ++count);
		}
	}


	return 1;
}


/***
 *
 * @function Spring.GetVisibleProjectiles
 * @param allyTeamID integer? (Default: `-1`)
 * @param addSyncedProjectiles boolean? (Default: `true`)
 * @param addWeaponProjectiles boolean? (Default: `true`)
 * @param addPieceProjectiles boolean? (Default: `true`)
 * @return number[]? projectileIDs
 */
int LuaUnsyncedRead::GetVisibleProjectiles(lua_State* L)
{
	int allyTeamID = luaL_optint(L, 1, -1);

	if (allyTeamID >= 0) {
		if (!teamHandler.ValidAllyTeam(allyTeamID)) {
			return 0;
		}
	} else {
		allyTeamID = -1;

		if (!CLuaHandle::GetHandleFullRead(L)) {
			allyTeamID = CLuaHandle::GetHandleReadAllyTeam(L);
		}
	}

	static CVisProjectileQuadDrawer projQuadIter;

	/*const bool addSyncedProjectiles =*/ luaL_optboolean(L, 2, true);
	const bool addWeaponProjectiles = luaL_optboolean(L, 3, true);
	const bool addPieceProjectiles = luaL_optboolean(L, 4, true);


	projQuadIter.ResetState();
	readMap->GridVisibility(nullptr, &projQuadIter, 1e9, CQuadField::BASE_QUAD_SIZE / SQUARE_SIZE);

	// Even though we're in unsynced it's ok to use gs->tempNum since its exact value
	// doesn't matter
	const int tempNum = gs->GetTempNum();
	lua_createtable(L, projQuadIter.GetObjectCount(), 0);

	unsigned int count = 0;
	for (auto visProjectileList: projQuadIter.GetObjectLists()) {
		for (CProjectile* p: *visProjectileList) {
			if (p->tempNum == tempNum)
				continue;

			p->tempNum = tempNum;


			if (allyTeamID >= 0 && !losHandler->InLos(p, allyTeamID))
				continue;

			if (!camera->InView(p->pos, p->GetDrawRadius()))
				continue;

			#if 1
			// filter out unsynced projectiles, the SyncedRead
			// projecile Get* functions accept only synced ID's
			// (specifically they interpret all ID's as synced)
			if (!p->synced)
				continue;
			#else
			if (!addSyncedProjectiles && p->synced)
				continue;
			#endif
			if (!addWeaponProjectiles && p->weapon)
				continue;
			if (!addPieceProjectiles && p->piece)
				continue;

			lua_pushnumber(L, p->id);
			lua_rawseti(L, -2, ++count);
		}
	}

	return 1;
}

namespace {
	template<typename V>
	static int GetRenderObjects(lua_State* L, const V& renderObjects, const char* func) {
		const int  drawMask = luaL_optint(L, 1, 0);
		const bool sendMask = luaL_optboolean(L, 2, false);

		lua_createtable(L, renderObjects.size(), 0);
		uint32_t count = 0;
		for (const auto renderObject : renderObjects)
		{
			if ((renderObject->drawFlag & drawMask) == 0)
				continue;

			lua_pushnumber(L, renderObject->id);
			lua_rawseti(L, -2, ++count);
		}

		if 	(!sendMask)
			return 1;

		lua_createtable(L, count, 0);
		count = 0;
		for (const auto renderObject : renderObjects)
		{
			if ((renderObject->drawFlag & drawMask) == 0)
				continue;

			lua_pushnumber(L, renderObject->drawFlag);
			lua_rawseti(L, -2, ++count);
		}

		return 2;
	}

	template<typename V>
	static int GetRenderObjectsDrawFlagChanged(lua_State* L, const V& renderObjects, const char* func) {
		const bool sendMask = luaL_optboolean(L, 1, false);

		std::vector<int> changedIds;
		changedIds.reserve(renderObjects.size());

		std::vector<uint8_t> changedDrawFlags;
		changedDrawFlags.reserve(renderObjects.size());

		for (const auto renderObject : renderObjects)
		{
			if (renderObject->previousDrawFlag == renderObject->drawFlag)
				continue;
			changedIds.push_back(renderObject->id);
			changedDrawFlags.push_back(renderObject->drawFlag);
		}

		lua_createtable(L, changedIds.size(), 0);
		uint32_t count = 0;
		for (const auto id : changedIds)
		{
			lua_pushnumber(L, id);
			lua_rawseti(L, -2, ++count);
		}

		if 	(!sendMask)
			return 1;

		lua_createtable(L, changedDrawFlags.size(), 0);
		count = 0;
		for (const auto drawFlag : changedDrawFlags)
		{
			lua_pushnumber(L, drawFlag);
			lua_rawseti(L, -2, ++count);
		}

		return 2;
	}
}

/***
  * Drawing Flags
  *
  * @alias DrawFlag
  * | 0 # No Draw
  * | 1 # Opaque Pass
  * | 2 # Alpha Pass
  * | 4 # Reflection Pass
  * | 8 # Refraction Pass
  * | 16 # Shadow pass - Opaque Objects
  * | 32 # Shadow pass - Transparent Objects
  * | 128 # Icon - Possibly Radar Icons
  */

/***
  * Bitwise mask of `DrawFlag`
  *
  * @see DrawFlag
  * @alias DrawMask integer
  */

/***
 *
 * @function Spring.GetRenderUnits
 * @param drawMask DrawMask (Default: `0`) Filter objects by their draw flags.
 * @param sendMask true Whether to send objects draw flags as second return
 * @return integer[] featureIDs
 * @return DrawFlag[] drawFlags
 */

/***
 *
 * @function Spring.GetRenderUnits
 * @param drawMask DrawMask (Default: `0`) Filter objects by their draw flags.
 * @param sendMask false? Whether to send objects draw flags as second return
 * @return integer[] featureIDs
 */
int LuaUnsyncedRead::GetRenderUnits(lua_State* L)
{
	return GetRenderObjects(L, unitDrawer->GetUnsortedUnits(), __func__);
}

/***
 * @function Spring.GetRenderUnitsDrawFlagChanged
 * Gets a list of IDs of units that have had their draw flags changed, and the corresponding flags.
 * @param sendMask true Whether to send objects draw flags as second return.
 * @return integer[] ids
 * @return DrawFlag[] unitDrawFlags
 */

/***
 * @function Spring.GetRenderUnitsDrawFlagChanged
 * Gets a list of IDs of units that have had their draw flags changed, and the corresponding flags.
 * @param sendMask false? Whether to send objects draw flags as second return.
 * @return integer[] ids
 */
int LuaUnsyncedRead::GetRenderUnitsDrawFlagChanged(lua_State* L)
{
	return GetRenderObjectsDrawFlagChanged(L, unitDrawer->GetUnsortedUnits(), __func__);
}

/***
 *
 * @function Spring.GetRenderFeatures
 * @param drawMask DrawMask (Default: `0`) Filter objects by their draw flags.
 * @param sendMask true Whether to send objects draw flags as second return
 * @return integer[] featureIDs
 * @return DrawFlag[] drawFlags
 */

/***
 *
 * @function Spring.GetRenderFeatures
 * @param drawMask DrawMask (Default: `0`) Filter objects by their draw flags.
 * @param sendMask false? Whether to send objects draw flags as second return
 * @return integer[] featureIDs
 */
int LuaUnsyncedRead::GetRenderFeatures(lua_State* L)
{
	return GetRenderObjects(L, featureDrawer->GetUnsortedFeatures(), __func__);
}

/***
 * @function Spring.GetRenderFeaturesDrawFlagChanged
 * Gets a list of IDs of features that have had their draw flags changed, and the corresponding flags.
 * @param sendMask true Whether to send objects draw flags as second return.
 * @return integer[] ids
 * @return DrawFlag[] unitDrawFlags
 */

/***
 * @function Spring.GetRenderFeaturesDrawFlagChanged
 * Gets a list of IDs of features that have had their draw flags changed, and the corresponding flags.
 * @param sendMask false? Whether to send objects draw flags as second return.
 * @return integer[] ids
 */
int LuaUnsyncedRead::GetRenderFeaturesDrawFlagChanged(lua_State* L)
{
	return GetRenderObjectsDrawFlagChanged(L, featureDrawer->GetUnsortedFeatures(), __func__);
}

/***
 *
 * @function Spring.ClearUnitsPreviousDrawFlag
 */
int LuaUnsyncedRead::ClearUnitsPreviousDrawFlag(lua_State* L)
{
	unitDrawer->ClearPreviousDrawFlags();
	return 0;
}

/***
 *
 * @function Spring.ClearFeaturesPreviousDrawFlag
 */
int LuaUnsyncedRead::ClearFeaturesPreviousDrawFlag(lua_State* L)
{
	featureDrawer->ClearPreviousDrawFlags();
	return 0;
}

/*** Get units inside a rectangle area on the map
 *
 * @function Spring.GetUnitsInScreenRectangle
 * @param left number
 * @param top number
 * @param right number
 * @param bottom number
 * @param allegiance number? (Default: `-1`) teamID when > 0, when < 0 one of AllUnits = -1, MyUnits = -2, AllyUnits = -3, EnemyUnits = -4
 * @return number[]? unitIDs
 */
int LuaUnsyncedRead::GetUnitsInScreenRectangle(lua_State* L)
{
	float l = luaL_checkfloat(L, 1);
	float t = luaL_checkfloat(L, 2);
	float r = luaL_checkfloat(L, 3);
	float b = luaL_checkfloat(L, 4);

	if (l > r) std::swap(l, r);
	if (t > b) std::swap(t, b);

	static CVisUnitQuadDrawer unitQuadIter;

	unitQuadIter.ResetState();
	readMap->GridVisibility(nullptr, &unitQuadIter, 1e9, CQuadField::BASE_QUAD_SIZE / SQUARE_SIZE);

	const int readTeam = CLuaHandle::GetHandleReadTeam(L);
	const int readATeam = CLuaHandle::GetHandleReadAllyTeam(L);

	const int allegiance = LuaUtils::ParseAllegiance(L, __func__, 5);

	std::function<bool(const CUnit*)> disqualifierFunc;

	switch (allegiance)
	{
	case LuaUtils::AllUnits:
		disqualifierFunc = [L](const CUnit* unit) -> bool { return !LuaUtils::IsUnitVisible(L, unit); };
		break;
	case LuaUtils::MyUnits:
		disqualifierFunc = [readTeam](const CUnit* unit) -> bool { return unit->team != readTeam; };
		break;
	case LuaUtils::AllyUnits:
		disqualifierFunc = [readATeam](const CUnit* unit) -> bool { return unit->allyteam != readATeam; };
		break;
	case LuaUtils::EnemyUnits:
		disqualifierFunc = [readATeam](const CUnit* unit) -> bool { return unit->allyteam == readATeam; };
		break;
	default: {
		if (LuaUtils::IsAlliedTeam(L, allegiance)) {
			disqualifierFunc = [allegiance](const CUnit* unit) -> bool { return unit->team != allegiance; };
		}
		else {
			disqualifierFunc = [allegiance, L](const CUnit* unit) -> bool {
				if (unit->team != allegiance)
					return true;

				if (!LuaUtils::IsUnitVisible(L, unit))
					return true;

				return false;
			};
		}
	} break;
	}

	// Even though we're in unsynced it's ok to use gs->tempNum since its exact value
	// doesn't matter
	const int tempNum = gs->GetTempNum();
	lua_createtable(L, unitQuadIter.GetObjectCount(), 0);

	uint32_t count = 0;
	for (auto visUnitList : unitQuadIter.GetObjectLists()) {
		for (CUnit* unit : *visUnitList) {
			if (disqualifierFunc(unit))
				continue;

			if (unit->tempNum == tempNum)
				continue;

			unit->tempNum = tempNum;

			const float3 vpPos = camera->CalcViewPortCoordinates(unit->drawPos);

			if (vpPos.x > r || vpPos.x < l)
				continue;

			if (vpPos.y > b || vpPos.y < t)
				continue;

			if (vpPos.z > 1.0f || vpPos.z < 0.0f)
				continue;

			lua_pushnumber(L, unit->id);
			lua_rawseti(L, -2, ++count);
		}
	}

	return 1;
}

/*** Get features inside a rectangle area on the map
	*
	* @function Spring.GetFeaturesInScreenRectangle
	* @param left number
	* @param top number
	* @param right number
	* @param bottom number
	* @return number[]? featureIDs
	*/
int LuaUnsyncedRead::GetFeaturesInScreenRectangle(lua_State* L)
{
	float l = luaL_checkfloat(L, 1);
	float t = luaL_checkfloat(L, 2);
	float r = luaL_checkfloat(L, 3);
	float b = luaL_checkfloat(L, 4);

	if (l > r) std::swap(l, r);
	if (t > b) std::swap(t, b);

	static CVisFeatureQuadDrawer featureQuadIter;

	featureQuadIter.ResetState();
	readMap->GridVisibility(nullptr, &featureQuadIter, 1e9, CQuadField::BASE_QUAD_SIZE / SQUARE_SIZE);

	const int tempNum = gs->GetTempNum();
	lua_createtable(L, featureQuadIter.GetObjectCount(), 0);

	uint32_t count = 0;
	for (auto visFeatureList : featureQuadIter.GetObjectLists()) {
		for ( CFeature* feature : *visFeatureList ) {
			if (feature->tempNum == tempNum)
				continue;

			feature->tempNum = tempNum;
			const float3 vpPos = camera->CalcViewPortCoordinates(feature->drawPos);

			if (vpPos.x > r || vpPos.x < l)
				continue;

			if (vpPos.y > b || vpPos.y < t)
				continue;

			if (vpPos.z > 1.0f || vpPos.z < 0.0f)
				continue;

			lua_pushnumber(L, feature->id);
			lua_rawseti(L, -2, ++count);
		}
	}

	return 1;
}

/******************************************************************************/
/******************************************************************************/

/***
 *
 * @function Spring.GetLocalPlayerID
 * @return integer playerID
 */
int LuaUnsyncedRead::GetLocalPlayerID(lua_State* L)
{
	lua_pushnumber(L, gu->myPlayerNum);
	return 1;
}


/***
 *
 * @function Spring.GetLocalTeamID
 * @return integer teamID
 */
int LuaUnsyncedRead::GetLocalTeamID(lua_State* L)
{
	lua_pushnumber(L, gu->myTeam);
	return 1;
}


/***
 *
 * @function Spring.GetLocalAllyTeamID
 * @return integer allyTeamID
 */
int LuaUnsyncedRead::GetLocalAllyTeamID(lua_State* L)
{
	lua_pushnumber(L, gu->myAllyTeam);
	return 1;
}


/***
 *
 * @function Spring.GetSpectatingState
 * @return boolean spectating
 * @return boolean spectatingFullView
 * @return boolean spectatingFullSelect
 */
int LuaUnsyncedRead::GetSpectatingState(lua_State* L)
{
	lua_pushboolean(L, gu->spectating);
	lua_pushboolean(L, gu->spectatingFullView);
	lua_pushboolean(L, gu->spectatingFullSelect);
	return 3;
}


/******************************************************************************/
/******************************************************************************/

/***
 *
 * @function Spring.GetSelectedUnits
 * @return number[] unitIDs
 */
int LuaUnsyncedRead::GetSelectedUnits(lua_State* L)
{
	PushNumberContainerAsArray(L, selectedUnitsHandler.selectedUnits);
	return 1;
}

/*** Get selected units aggregated by unitDefID
 *
 * @function Spring.GetSelectedUnitsSorted
 * @return table<number,number[]> where keys are unitDefIDs and values are unitIDs
 * @return integer the number of unitDefIDs
 */
int LuaUnsyncedRead::GetSelectedUnitsSorted(lua_State* L)
{
	const auto numDefKeys = PushUnitListSortedByDef(L, selectedUnitsHandler.selectedUnits);
	lua_pushnumber(L, numDefKeys);

	return 2;
}


/*** Get an aggregate count of selected units per unitDefID
 *
 * @function Spring.GetSelectedUnitsCounts
 *
 * @return table<number,number> unitsCounts where keys are unitDefIDs and values are counts
 * @return integer the number of unitDefIDs
 */
int LuaUnsyncedRead::GetSelectedUnitsCounts(lua_State* L)
{
	const auto numDefKeys = PushSparseUnitTallyByDef(L, selectedUnitsHandler.selectedUnits);
	lua_pushnumber(L, numDefKeys);

	return 2;
}


/*** Returns the amount of selected units
 *
 * @function Spring.GetSelectedUnitsCount
 * @return number selectedUnitsCount
 */
int LuaUnsyncedRead::GetSelectedUnitsCount(lua_State* L)
{
	lua_pushnumber(L, selectedUnitsHandler.selectedUnits.size());
	return 1;
}

/*** Get if selection box is handled by engine.
 *
 * @function Spring.GetBoxSelectionByEngine
 *
 * @return boolean isHandledByEngine `true` if the engine will select units inside selection box on release, otherwise `false`.
 *
 * @see Spring.GetSelectionBox
 * @see Spring.SetBoxSelectionByEngine
 */
int LuaUnsyncedRead::GetBoxSelectionByEngine(lua_State* L)
{
	lua_pushboolean(L, selectedUnitsHandler.GetBoxSelectionHandledByEngine());
	return 1;
}


/******************************************************************************/
/******************************************************************************/

/***
 *
 * @function Spring.IsGUIHidden
 * @return boolean
 */
int LuaUnsyncedRead::IsGUIHidden(lua_State* L)
{
	lua_pushboolean(L, game != nullptr && game->hideInterface);
	return 1;
}


/***
 *
 * @function Spring.HaveShadows
 * @return boolean shadowsLoaded
 */
int LuaUnsyncedRead::HaveShadows(lua_State* L)
{
	lua_pushboolean(L, shadowHandler.ShadowsLoaded());
	return 1;
}


/***
 *
 * @function Spring.HaveAdvShading
 * @return boolean useAdvShading
 * @return boolean groundUseAdvShading
 */
int LuaUnsyncedRead::HaveAdvShading(lua_State* L)
{
	lua_pushboolean(L, true);
	lua_pushboolean(L, readMap->GetGroundDrawer()->UseAdvShading());
	return 2;
}


/***
 *
 * @function Spring.GetWaterMode
 * @return integer waterRendererID
 * @return string waterRendererName
 * @see rts/Rendering/Env/IWater.h
 */
int LuaUnsyncedRead::GetWaterMode(lua_State* L)
{
	const auto& water = IWater::GetWater();
	lua_pushnumber(L, water->GetID());
	lua_pushstring(L, IWater::GetWaterName(water->GetID()));
	return 2;
}


/***
 *
 * @function Spring.GetMapDrawMode
 * @return "normal"|"height"|"metal"|"pathTraversability"|"los"
 */
int LuaUnsyncedRead::GetMapDrawMode(lua_State* L)
{
	using P = std::pair<const char*, const char*>;
	constexpr std::array<P, 5> modes = {
		P(        "", "normal"            ),
		P(    "path", "pathTraversability"),
		P(    "heat", "pathHeat"          ),
		P(    "flow", "pathFlow"          ),
		P("pathcost", "pathCost"          ),
	};

	const auto& mode = infoTextureHandler->GetMode();
	const auto  iter = std::find_if(modes.begin(), modes.end(), [&mode](const P& p) { return (strcmp(p.first, mode.c_str()) == 0); });

	if (iter != modes.end()) {
		lua_pushstring(L, iter->second);
	} else {
		lua_pushstring(L, mode.c_str());
	}

	return 1;
}


/***
 *
 * @function Spring.GetMapSquareTexture
 * @param texSquareX number
 * @param texSquareY number
 * @param lodMin number
 * @param luaTexName string
 * @param lodMax number? (Default: lodMin)
 * @return boolean? success
 */
int LuaUnsyncedRead::GetMapSquareTexture(lua_State* L)
{
	if (CLuaHandle::GetHandleSynced(L)) {
		return 0;
	}

	const int texSquareX = luaL_checkint(L, 1);
	const int texSquareY = luaL_checkint(L, 2);
	const int lodMin = luaL_checkint(L, 3);
	const std::string& texName = luaL_checkstring(L, 4);
	const int lodMax = luaL_optinteger(L, 5, lodMin); // should have been in pos 4 instead, but the compatibility is the king

	CBaseGroundDrawer* groundDrawer = readMap->GetGroundDrawer();
	CBaseGroundTextures* groundTextures = groundDrawer->GetGroundTextures();

	if (groundTextures == nullptr) {
		lua_pushboolean(L, false);
		return 1;
	}
	if (texName.empty()) {
		lua_pushboolean(L, false);
		return 1;
	}

	const LuaTextures& luaTextures = CLuaHandle::GetActiveTextures(L);
	const LuaTextures::Texture* luaTexture = luaTextures.GetInfo(texName);

	if (luaTexture == nullptr) {
		// not a valid texture (name)
		lua_pushboolean(L, false);
		return 1;
	}

	const int tid = luaTexture->id;
	const int txs = luaTexture->xsize;
	const int tys = luaTexture->ysize;

	if (txs != tys) {
		// square textures only
		lua_pushboolean(L, false);
		return 1;
	}

	lua_pushboolean(L, groundTextures->GetSquareLuaTexture(texSquareX, texSquareY, tid, txs, tys, lodMin, lodMax));
	return 1;
}

/***
 * @function Spring.GetLosViewColors
 * @return rgb always
 * @return rgb LOS
 * @return rgb radar
 * @return rgb jam
 * @return rgb radar2
 */
int LuaUnsyncedRead::GetLosViewColors(lua_State* L)
{
#define PACK_COLOR_VECTOR(color) \
	lua_createtable(L, 3, 0); \
	lua_pushnumber(L, color[0] / scale); lua_rawseti(L, -2, 1); \
	lua_pushnumber(L, color[1] / scale); lua_rawseti(L, -2, 2); \
	lua_pushnumber(L, color[2] / scale); lua_rawseti(L, -2, 3);

	const float scale = (float)CBaseGroundDrawer::losColorScale;
	CBaseGroundDrawer* gd = readMap->GetGroundDrawer();

	PACK_COLOR_VECTOR(gd->alwaysColor);
	PACK_COLOR_VECTOR(gd->losColor);
	PACK_COLOR_VECTOR(gd->radarColor);
	PACK_COLOR_VECTOR(gd->jamColor);
	PACK_COLOR_VECTOR(gd->radarColor2);
	return 5;
}


/***
 *
 * @function Spring.GetNanoProjectileParams
 * @return number rotVal in degrees
 * @return number rotVel in degrees
 * @return number rotAcc in degrees
 * @return number rotValRng in degrees
 * @return number rotVelRng in degrees
 * @return number rotAccRng in degrees
 */
int LuaUnsyncedRead::GetNanoProjectileParams(lua_State* L)
{
	lua_pushnumber(L, CNanoProjectile::rotVal0 * (math::RAD_TO_DEG                            ));
	lua_pushnumber(L, CNanoProjectile::rotVel0 * (math::RAD_TO_DEG * GAME_SPEED               ));
	lua_pushnumber(L, CNanoProjectile::rotAcc0 * (math::RAD_TO_DEG * (GAME_SPEED * GAME_SPEED)));

	lua_pushnumber(L, CNanoProjectile::rotValRng0 * (math::RAD_TO_DEG                            ));
	lua_pushnumber(L, CNanoProjectile::rotVelRng0 * (math::RAD_TO_DEG * GAME_SPEED               ));
	lua_pushnumber(L, CNanoProjectile::rotAccRng0 * (math::RAD_TO_DEG * (GAME_SPEED * GAME_SPEED)));

	return 6;
}


/***
 * Get available cameras.
 *
 * @function Spring.GetCameraNames
 * @return table<string, integer> indexByName Table where where keys are names and values are indices.
 */
int LuaUnsyncedRead::GetCameraNames(lua_State* L)
{
	const std::array<CCameraController*, CCameraHandler::CAMERA_MODE_LAST>& cc = camHandler->GetControllers();

	lua_createtable(L, 0, cc.size());

	for (size_t i = 0; i < cc.size(); ++i) {
		lua_pushsstring(L, cc[i]->GetName()); // key
		lua_pushnumber(L, i); // val
		lua_rawset(L, -3);
	}

	return 1;
}

/***
 * @function Spring.GetCameraState
 * @param useTable false
 * @return CameraName name
 * @return any ... depends on the current controller mode.
 */
/***
 * @function Spring.GetCameraState
 * @param useTable true? (Default: `true`) Return a table instead of multiple values.
 * @return CameraState cameraState
 */
int LuaUnsyncedRead::GetCameraState(lua_State* L)
{
	CCameraController::StateMap camState;
	camHandler->GetState(camState);

	if (!luaL_optboolean(L, 1, true)) {
		// table-less version; pushes just the name and the cam-specific values
		// use GetCamera{Position,Direction,FOV} for the common fields from the base class
		lua_pushsstring(L, camHandler->GetCurrentController().GetName());

		switch (camHandler->GetCurrentControllerNum()) {
		case CCameraHandler::CAMERA_MODE_FIRSTPERSON:
		case CCameraHandler::CAMERA_MODE_ROTOVERHEAD: // happens to have the same set of values as FPS
			lua_pushnumber(L, camState["oldHeight"]);
			return 1 + 1;

		case CCameraHandler::CAMERA_MODE_OVERHEAD:
			lua_pushnumber(L, camState["height"]);
			lua_pushnumber(L, camState["angle"]);
			lua_pushnumber(L, camState["flipped"]);
			return 1 + 3;

		case CCameraHandler::CAMERA_MODE_SPRING:
			lua_pushnumber(L, camState["rx"]);
			lua_pushnumber(L, camState["ry"]);
			lua_pushnumber(L, camState["rz"]);
			lua_pushnumber(L, camState["dist"]);
			return 1 + 4;

		case CCameraHandler::CAMERA_MODE_FREE:
			lua_pushnumber(L, camState["rx"]);
			lua_pushnumber(L, camState["ry"]);
			lua_pushnumber(L, camState["rz"]);
			lua_pushnumber(L, camState["vx"]);
			lua_pushnumber(L, camState["vy"]);
			lua_pushnumber(L, camState["vz"]);
			lua_pushnumber(L, camState["avx"]);
			lua_pushnumber(L, camState["avy"]);
			lua_pushnumber(L, camState["avz"]);
			return 1 + 9;

		case CCameraHandler::CAMERA_MODE_OVERVIEW:
		default:
			// overview has no extra values
			return 1 + 0;
		}
	}

	lua_createtable(L, 0,
			std::tuple_size<CCameraController::StateMap::ArrayMap>{});

	lua_pushliteral(L, "name");
	lua_pushsstring(L, (camHandler->GetCurrentController()).GetName());
	lua_rawset(L, -3);

	for (const auto& s: camState) {
		lua_pushsstring(L, s.first);
		lua_pushnumber(L, s.second);
		lua_rawset(L, -3);
	}

	return 1;
}


/***
 * @function Spring.GetCameraPosition
 * @return number posX
 * @return number posY
 * @return number posZ
 */
int LuaUnsyncedRead::GetCameraPosition(lua_State* L)
{
	lua_pushnumber(L, camera->GetPos().x);
	lua_pushnumber(L, camera->GetPos().y);
	lua_pushnumber(L, camera->GetPos().z);
	return 3;
}

/***
 * @function Spring.GetCameraDirection
 * @return number dirX
 * @return number dirY
 * @return number dirZ
 */
int LuaUnsyncedRead::GetCameraDirection(lua_State* L)
{
	lua_pushnumber(L, camera->GetDir().x);
	lua_pushnumber(L, camera->GetDir().y);
	lua_pushnumber(L, camera->GetDir().z);
	return 3;
}

/*** Get camera rotation in radians.
 * 
 * @function Spring.GetCameraRotation
 * @return number rotX Rotation around X axis in radians.
 * @return number rotY Rotation around Y axis in radians.
 * @return number rotZ Rotation around Z axis in radians.
 */
int LuaUnsyncedRead::GetCameraRotation(lua_State* L)
{
	lua_pushnumber(L, camera->GetRot().x);
	lua_pushnumber(L, camera->GetRot().y);
	lua_pushnumber(L, camera->GetRot().z);
	return 3;
}

/***
 * @function Spring.GetCameraFOV
 * @return number vFOV
 * @return number hFOV
 */
int LuaUnsyncedRead::GetCameraFOV(lua_State* L)
{
	lua_pushnumber(L, camera->GetVFOV());
	lua_pushnumber(L, camera->GetHFOV());
	return 2;
}

/***
 * @class CameraVectors
 * @x_helper
 * @field forward xyz
 * @field up xyz
 * @field right xyz
 * @field topFrustumPlane xyz
 * @field botFrustumPlane xyz
 * @field lftFrustumPlane xyz
 * @field rgtFrustumPlane xyz
 */

/***
 * @function Spring.GetCameraVectors
 * @return CameraVectors
 */
int LuaUnsyncedRead::GetCameraVectors(lua_State* L)
{
#define PACK_CAMERA_VECTOR(s,n) \
	HSTR_PUSH(L, #s);           \
	lua_createtable(L, 3, 0);            \
	lua_pushnumber(L, camera-> n .x); lua_rawseti(L, -2, 1); \
	lua_pushnumber(L, camera-> n .y); lua_rawseti(L, -2, 2); \
	lua_pushnumber(L, camera-> n .z); lua_rawseti(L, -2, 3); \
	lua_rawset(L, -3)

	lua_createtable(L, 0, 7);
	PACK_CAMERA_VECTOR(forward, GetDir());
	PACK_CAMERA_VECTOR(up, GetUp());
	PACK_CAMERA_VECTOR(right, GetRight());
	PACK_CAMERA_VECTOR(topFrustumPlane, GetFrustumPlane(CCamera::FRUSTUM_PLANE_TOP));
	PACK_CAMERA_VECTOR(botFrustumPlane, GetFrustumPlane(CCamera::FRUSTUM_PLANE_BOT));
	PACK_CAMERA_VECTOR(lftFrustumPlane, GetFrustumPlane(CCamera::FRUSTUM_PLANE_LFT));
	PACK_CAMERA_VECTOR(rgtFrustumPlane, GetFrustumPlane(CCamera::FRUSTUM_PLANE_RGT));

	return 1;
}


/***
 *
 * @function Spring.WorldToScreenCoords
 * @param x number
 * @param y number
 * @param z number
 * @return number viewPortX
 * @return number viewPortY
 * @return number viewPortZ
 */
int LuaUnsyncedRead::WorldToScreenCoords(lua_State* L)
{
	const float3 worldPos(luaL_checkfloat(L, 1),
	                      luaL_checkfloat(L, 2),
	                      luaL_checkfloat(L, 3));
	const float3 vpPos = camera->CalcViewPortCoordinates(worldPos);
	lua_pushnumber(L, vpPos.x);
	lua_pushnumber(L, vpPos.y);
	lua_pushnumber(L, vpPos.z);
	return 3;
}


/*** Get information about a ray traced from screen to world position
 *
 * @function Spring.TraceScreenRay
 *
 * Extended to allow a custom plane, parameters are (0, 1, 0, D=0) where D is the offset D can be specified in the third argument (if all the bools are false) or in the seventh (as shown).
 *
 * Intersection coordinates are returned in t[4],t[5],t[6] when the ray goes offmap and includeSky is true), or when no unit or feature is hit (or onlyCoords is true).
 *
 * This will only work for units & objects with the default collision sphere. Per Piece collision and custom collision objects are not supported.
 *
 * The unit must be selectable, to appear to a screen trace ray.
 *
 * @param screenX number position on x axis in mouse coordinates (origin on left border of view)
 * @param screenY number position on y axis in mouse coordinates (origin on top border of view)
 * @param onlyCoords boolean? (Default: `false`) return only description (1st return value) and coordinates (2nd return value)
 * @param useMinimap boolean? (Default: `false`) if position arguments are contained by minimap, use the minimap corresponding world position
 * @param includeSky boolean? (Default: `false`)
 * @param ignoreWater boolean? (Default: `false`)
 * @param heightOffset number? (Default: `0`)
 * @return string? description of traced position
 * @return number|string|xyz|nil unitID or feature, position triple when onlyCoords=true
 * @return number|string|nil featureID or ground
 * @return xyz? coords
 */
int LuaUnsyncedRead::TraceScreenRay(lua_State* L)
{
	// window coordinates
	const int mx = luaL_checkint(L, 1);
	const int my = luaL_checkint(L, 2);

	const int wx = mx + globalRendering->viewPosX;
	const int wy = globalRendering->viewSizeY - 1 - my;

	const int optArgIdx = 3 + lua_isnumber(L, 3); // 3 or 4
	const int newArgIdx = 3 + 4 * (optArgIdx == 3); // 7 or 3

	const bool onlyCoords  = luaL_optboolean(L, optArgIdx + 0, false);
	const bool useMiniMap  = luaL_optboolean(L, optArgIdx + 1, false);
	const bool includeSky  = luaL_optboolean(L, optArgIdx + 2, false);
	const bool ignoreWater = luaL_optboolean(L, optArgIdx + 3, false);

	if (useMiniMap && (minimap != nullptr) && !minimap->GetMinimized()) {
		const int px = minimap->GetPosX() - globalRendering->viewPosX;
		const int py = minimap->GetPosY() - globalRendering->viewPosY;
		const int sx = minimap->GetSizeX();
		const int sy = minimap->GetSizeY();

		if ((mx >= px) && (mx < (px + sx))  &&  (my >= py) && (my < (py + sy))) {
			const float3 pos = minimap->GetMapPosition(wx, wy);

			if (!onlyCoords) {
				const CUnit* unit = minimap->GetSelectUnit(pos);

				if (unit != nullptr) {
					lua_pushliteral(L, "unit");
					lua_pushnumber(L, unit->id);
					return 2;
				}
			}

			lua_pushliteral(L, "ground");
			lua_createtable(L, 3, 0);
			lua_pushnumber(L,                                      pos.x ); lua_rawseti(L, -2, 1);
			lua_pushnumber(L, CGround::GetHeightReal(pos.x, pos.z, false)); lua_rawseti(L, -2, 2);
			lua_pushnumber(L,                                      pos.z ); lua_rawseti(L, -2, 3);
			return 2;
		}
	}

	if ((mx < 0) || (mx >= globalRendering->viewSizeX))
		return 0;
	if ((my < 0) || (my >= globalRendering->viewSizeY))
		return 0;

	const CUnit* unit = nullptr;
	const CFeature* feature = nullptr;

	const float rawRange = camera->GetFarPlaneDist() * 1.4f;
	const float badRange = rawRange - 300.0f;

	const float3 camPos = camera->GetPos();
	const float3 pxlDir = camera->CalcPixelDir(wx, wy);

	// trace for player's allyteam
	const float traceDist = TraceRay::GuiTraceRay(camPos, pxlDir, rawRange, nullptr, unit, feature, true, onlyCoords, ignoreWater);
	const float planeDist = CGround::LinePlaneCol(camPos, pxlDir, rawRange, luaL_optnumber(L, newArgIdx, 0.0f));

	const float3 tracePos = camPos + (pxlDir * traceDist);
	const float3 planePos = camPos + (pxlDir * planeDist); // backup (for includeSky and onlyCoords)

	if ((traceDist < 0.0f || traceDist > badRange) && unit == nullptr && feature == nullptr) {
		// ray went into the void (or started too far above terrain)
		if (!includeSky)
			return 0;

		lua_pushliteral(L, "sky");
	} else {
		if (!onlyCoords) {
			if (unit != nullptr) {
				lua_pushliteral(L, "unit");
				lua_pushnumber(L, unit->id);
				return 2;
			}

			if (feature != nullptr) {
				lua_pushliteral(L, "feature");
				lua_pushnumber(L, feature->id);
				return 2;
			}
		}

		lua_pushliteral(L, "ground");
	}

	lua_createtable(L, 6, 0);
	lua_pushnumber(L, tracePos.x); lua_rawseti(L, -2, 1);
	lua_pushnumber(L, tracePos.y); lua_rawseti(L, -2, 2);
	lua_pushnumber(L, tracePos.z); lua_rawseti(L, -2, 3);
	lua_pushnumber(L, planePos.x); lua_rawseti(L, -2, 4);
	lua_pushnumber(L, planePos.y); lua_rawseti(L, -2, 5);
	lua_pushnumber(L, planePos.z); lua_rawseti(L, -2, 6);

	return 2;
}


/***
 *
 * @function Spring.GetPixelDir
 * @param x number
 * @param y number
 * @return number dirX
 * @return number dirY
 * @return number dirZ
 */
int LuaUnsyncedRead::GetPixelDir(lua_State* L)
{
	const int x = luaL_checkint(L, 1);
	const int y = luaL_checkint(L, 2);
	const float3 dir = camera->CalcPixelDir(x, y);
	lua_pushnumber(L, dir.x);
	lua_pushnumber(L, dir.y);
	lua_pushnumber(L, dir.z);
	return 3;
}



/******************************************************************************/

static bool AddPlayerToRoster(lua_State* L, int playerID, bool onlyActivePlayers, bool includePathingFlag)
{
#define PUSH_ROSTER_ENTRY(type, val) \
	lua_push ## type(L, val); lua_rawseti(L, -2, index++);

	const CPlayer* p = playerHandler.Player(playerID);

	if (onlyActivePlayers && !p->active)
		return false;

	int index = 1;
	lua_createtable(L, 7, 0);
	PUSH_ROSTER_ENTRY(string, p->name.c_str());
	PUSH_ROSTER_ENTRY(number, playerID);
	PUSH_ROSTER_ENTRY(number, p->team);
	PUSH_ROSTER_ENTRY(number, teamHandler.AllyTeam(p->team));
	PUSH_ROSTER_ENTRY(boolean, p->spectator);
	PUSH_ROSTER_ENTRY(number, p->cpuUsage);

	if (!includePathingFlag || p->ping != PATHING_FLAG) {
		const float pingSecs = p->ping * 0.001f;
		PUSH_ROSTER_ENTRY(number, pingSecs);
	} else {
		const float pingSecs = float(p->ping);
		PUSH_ROSTER_ENTRY(number, pingSecs);
	}

	return true;
}


/***
 *
 * @function Spring.GetTeamColor
 * @param teamID integer
 * @return number? r factor from 0 to 1
 * @return number? g factor from 0 to 1
 * @return number? b factor from 0 to 1
 * @return number? a factor from 0 to 1
 */
int LuaUnsyncedRead::GetTeamColor(lua_State* L)
{
	const int teamID = luaL_checkint(L, 1);
	if ((teamID < 0) || (teamID >= teamHandler.ActiveTeams()))
		return 0;

	const CTeam* team = teamHandler.Team(teamID);
	if (team == nullptr)
		return 0;

	lua_pushnumber(L, team->color[0] / 255.0f);
	lua_pushnumber(L, team->color[1] / 255.0f);
	lua_pushnumber(L, team->color[2] / 255.0f);
	lua_pushnumber(L, team->color[3] / 255.0f);
	return 4;
}


/***
 *
 * @function Spring.GetTeamOrigColor
 * @param teamID integer
 * @return number? r factor from 0 to 1
 * @return number? g factor from 0 to 1
 * @return number? b factor from 0 to 1
 * @return number? a factor from 0 to 1
 */
int LuaUnsyncedRead::GetTeamOrigColor(lua_State* L)
{
	const int teamID = luaL_checkint(L, 1);
	if ((teamID < 0) || (teamID >= teamHandler.ActiveTeams()))
		return 0;

	const CTeam* team = teamHandler.Team(teamID);
	if (team == nullptr)
		return 0;

	lua_pushnumber(L, team->origColor[0] / 255.0f);
	lua_pushnumber(L, team->origColor[1] / 255.0f);
	lua_pushnumber(L, team->origColor[2] / 255.0f);
	lua_pushnumber(L, team->origColor[3] / 255.0f);
	return 4;
}


/***
 *
 * @function Spring.GetDrawSeconds
 * @return integer time Time in seconds.
 */
int LuaUnsyncedRead::GetDrawSeconds(lua_State* L)
{
	lua_pushnumber(L, spring_tomsecs(globalRendering->grTime) * 0.001f);
	return 1;
}


/******************************************************************************
 * Sound
 * @section sound
******************************************************************************/

/*** Contains data about a sound device.
 * @class SoundDeviceSpec
 * @x_helper
 *
 * @field name string
 */


/***
 *
 * @function Spring.GetSoundDevices
 * @return SoundDeviceSpec[] devices Sound devices.
 */
int LuaUnsyncedRead::GetSoundDevices(lua_State* L)
{
	std::vector<std::string> devices = sound->GetSoundDevices();

	lua_createtable(L, 0, devices.size());

	for (size_t i = 0; i < devices.size(); ++i) {
		lua_createtable(L, 0, 1); // create a table for below {name, device} KV
		LuaPushNamedString(L, "name", devices[i]);
		lua_rawseti(L, -2, i + 1);
	}

	return 1;
}

/***
 *
 * @function Spring.GetSoundStreamTime
 * @return number playTime
 * @return number time
 */
int LuaUnsyncedRead::GetSoundStreamTime(lua_State* L)
{
	lua_pushnumber(L, Channels::BGMusic->StreamGetPlayTime());
	lua_pushnumber(L, Channels::BGMusic->StreamGetTime());
	return 2;
}


/***
 *
 * @function Spring.GetSoundEffectParams
 */
int LuaUnsyncedRead::GetSoundEffectParams(lua_State* L)
{
#if defined(HEADLESS) || defined(NO_SOUND)
	return 0;
#else
	if (!efx.Supported())
		return 0;

	EAXSfxProps& efxprops = efx.sfxProperties;

	lua_createtable(L, 0, 2);

	size_t n = efxprops.filter_props_f.size();

	lua_pushliteral(L, "passfilter");
	lua_createtable(L, 0, n);
	lua_rawset(L, -3);

	for (const auto& filterProp: efxprops.filter_props_f) {
		const ALuint param = filterProp.first;
		const auto fit = alFilterParamToName.find(param);

		if (fit != alFilterParamToName.end()) {
			lua_pushsstring(L, fit->second); // name
			lua_pushnumber(L, filterProp.second);
			lua_rawset(L, -3);
		}
	}


	n = efxprops.reverb_props_v.size() + efxprops.reverb_props_f.size() + efxprops.reverb_props_i.size();

	lua_pushliteral(L, "reverb");
	lua_createtable(L, 0, n);
	lua_rawset(L, -3);

	for (const auto& reverbProp: efxprops.reverb_props_f) {
		const ALuint param = reverbProp.first;
		const auto fit = alParamToName.find(param);

		if (fit != alParamToName.end()) {
			lua_pushsstring(L, fit->second); // name
			lua_pushnumber(L, reverbProp.second);
			lua_rawset(L, -3);
		}
	}
	for (const auto& reverbProp: efxprops.reverb_props_v) {
		const ALuint param = reverbProp.first;
		const auto fit = alParamToName.find(param);

		if (fit != alParamToName.end()) {
			const float3& v = reverbProp.second;

			lua_pushsstring(L, fit->second); // name
			lua_createtable(L, 3, 0);
				lua_pushnumber(L, v.x);
				lua_rawseti(L, -2, 1);
				lua_pushnumber(L, v.y);
				lua_rawseti(L, -2, 2);
				lua_pushnumber(L, v.z);
				lua_rawseti(L, -2, 3);
			lua_rawset(L, -3);
		}
	}
	for (const auto& reverbProp: efxprops.reverb_props_i) {
		const ALuint param = reverbProp.first;
		const auto fit = alParamToName.find(param);

		if (fit != alParamToName.end()) {
			lua_pushsstring(L, fit->second); // name
			lua_pushboolean(L, reverbProp.second);
			lua_rawset(L, -3);
		}
	}

	return 1;
#endif // defined(HEADLESS) || defined(NO_SOUND)
}


/******************************************************************************
 * Game Speed
 * @section gamespeed
******************************************************************************/


/***
 *
 * @function Spring.GetFPS
 * @return number fps
 */
int LuaUnsyncedRead::GetFPS(lua_State* L)
{
	assert(globalRendering != nullptr);
	// true FPS is never fractional, but the calculation averages over time
	lua_pushnumber(L, int(globalRendering->FPS));
	return 1;
}


/***
 *
 * @function Spring.GetGameSpeed
 * @return number wantedSpeedFactor
 * @return number speedFactor
 * @return boolean paused
 */
int LuaUnsyncedRead::GetGameSpeed(lua_State* L)
{
	lua_pushnumber(L, gs->wantedSpeedFactor);
	lua_pushnumber(L, gs->speedFactor);
	lua_pushboolean(L, gs->paused);
	return 3;
}

/***
 *
 * @function Spring.GetGameState
 * @param maxLatency number? (Default: `500`) used for `isSimLagging` return parameter
 * @return boolean doneLoading
 * @return boolean isSavedGame
 * @return boolean isClientPaused
 * @return boolean isSimLagging
 */
int LuaUnsyncedRead::GetGameState(lua_State* L)
{
  const float maxLatency = luaL_optfloat(L, 1, 500.0f);

	lua_pushboolean(L, game->IsDoneLoading());
	lua_pushboolean(L, game->IsSavedGame());
	lua_pushboolean(L, game->IsClientPaused()); // local state; included for demos
	lua_pushboolean(L, game->IsSimLagging(maxLatency));
	return 4;
}


/******************************************************************************
 * Commands
 * @section commands
******************************************************************************/


/***
 *
 * @function Spring.GetActiveCommand
 * @return number? cmdIndex
 * @return integer? cmdID
 * @return number? cmdType
 * @return string? cmdName
 */
int LuaUnsyncedRead::GetActiveCommand(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	const vector<SCommandDescription>& cmdDescs = guihandler->commands;
	const int cmdDescCount = (int)cmdDescs.size();

	const int inCommand = guihandler->inCommand;
	lua_pushnumber(L, inCommand + CMD_INDEX_OFFSET);

	if ((inCommand < 0) || (inCommand >= cmdDescCount))
		return 1;

	lua_pushnumber(L, cmdDescs[inCommand].id);
	lua_pushnumber(L, cmdDescs[inCommand].type);
	lua_pushsstring(L, cmdDescs[inCommand].name);
	return 4;
}


/***
 *
 * @function Spring.GetDefaultCommand
 * @return integer? cmdIndex
 * @return integer? cmdID
 * @return integer? cmdType
 * @return string? cmdName
 */
int LuaUnsyncedRead::GetDefaultCommand(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	const int defCmd = guihandler->GetDefaultCommand(mouse->lastx, mouse->lasty);

	const vector<SCommandDescription>& cmdDescs = guihandler->commands;
	const int cmdDescCount = (int)cmdDescs.size();

	lua_pushnumber(L, defCmd + CMD_INDEX_OFFSET);

	if ((defCmd < 0) || (defCmd >= cmdDescCount))
		return 1;

	lua_pushnumber(L, cmdDescs[defCmd].id);
	lua_pushnumber(L, cmdDescs[defCmd].type);
	lua_pushsstring(L, cmdDescs[defCmd].name);
	return 4;
}

/***
 *
 * @function Spring.GetActiveCmdDescs
 * @return CommandDescription[] cmdDescs
 */
int LuaUnsyncedRead::GetActiveCmdDescs(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	const vector<SCommandDescription>& cmdDescs = guihandler->commands;
	const int cmdDescCount = (int)cmdDescs.size();

	lua_checkstack(L, 1 + 2);
	// When CMD_INDEX_OFFSET is not 1, lua will resort to using the hash
	// part to index table keys as we're no longer adding keys to the table
	// following the sequence 1 to N for any N.
	lua_createtable(L,
			CMD_INDEX_OFFSET == 1 ? cmdDescCount : 0,
			CMD_INDEX_OFFSET == 1 ? 0 : cmdDescCount);

	for (int i = 0; i < cmdDescCount; i++) {
		LuaUtils::PushCommandDesc(L, cmdDescs[i]);
		lua_rawseti(L, -2, i + CMD_INDEX_OFFSET);
	}
	return 1;
}


/***
 *
 * @function Spring.GetActiveCmdDesc
 * @param cmdIndex integer
 * @return CommandDescription?
 */
int LuaUnsyncedRead::GetActiveCmdDesc(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	const int cmdIndex = luaL_checkint(L, 1) - CMD_INDEX_OFFSET;

	const vector<SCommandDescription>& cmdDescs = guihandler->commands;
	const int cmdDescCount = (int)cmdDescs.size();

	if ((cmdIndex < 0) || (cmdIndex >= cmdDescCount))
		return 0;

	LuaUtils::PushCommandDesc(L, cmdDescs[cmdIndex]);
	return 1;
}


/***
 *
 * @function Spring.GetCmdDescIndex
 * @param cmdID integer
 * @return integer? cmdDescIndex
 */
int LuaUnsyncedRead::GetCmdDescIndex(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	const int cmdId = luaL_checkint(L, 1);

	const vector<SCommandDescription>& cmdDescs = guihandler->commands;
	const int cmdDescCount = (int)cmdDescs.size();
	for (int i = 0; i < cmdDescCount; i++) {
		if (cmdId == cmdDescs[i].id) {
			lua_pushnumber(L, i + CMD_INDEX_OFFSET);
			return 1;
		}
	}
	return 0;
}


/******************************************************************************/

/***
 * Facing direction represented as an integer only.
 * 
 * @see Facing
 * 
 * @alias FacingInteger
 * | 0 # South
 * | 1 # East
 * | 2 # North
 * | 3 # West
 */

/***
 *
 * @function Spring.GetBuildFacing
 * @return FacingInteger buildFacing
 */
int LuaUnsyncedRead::GetBuildFacing(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	lua_pushnumber(L, guihandler->buildFacing);
	return 1;
}


/***
 *
 * @function Spring.GetBuildSpacing
 * @return number buildSpacing
 */
int LuaUnsyncedRead::GetBuildSpacing(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	lua_pushnumber(L, guihandler->buildSpacing);
	return 1;
}


/***
 *
 * @function Spring.GetGatherMode
 * @return number gatherMode
 */
int LuaUnsyncedRead::GetGatherMode(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	lua_pushnumber(L, guihandler->GetGatherMode());
	return 1;
}


/******************************************************************************/

/***
 *
 * @function Spring.GetActivePage
 * @return number activePage
 * @return number maxPage
 */
int LuaUnsyncedRead::GetActivePage(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	lua_pushnumber(L, guihandler->GetActivePage());
	lua_pushnumber(L, guihandler->GetMaxPage());
	return 2;
}


/******************************************************************************
 * Mouse State
 * @section mousestate
******************************************************************************/


/***
 *
 * @function Spring.GetMouseState
 * @return number x
 * @return number y
 * @return number lmbPressed left mouse button pressed
 * @return number mmbPressed middle mouse button pressed
 * @return number rmbPressed right mouse button pressed
 * @return boolean offscreen
 * @return boolean mmbScroll
 */
int LuaUnsyncedRead::GetMouseState(lua_State* L)
{
	assert(mouse != nullptr);
	assert(globalRendering != nullptr);

	lua_pushnumber(L, mouse->lastx - globalRendering->viewPosX);
	lua_pushnumber(L, globalRendering->viewSizeY - mouse->lasty - 1);

	lua_pushboolean(L, mouse->buttons[SDL_BUTTON_LEFT  ].pressed);
	lua_pushboolean(L, mouse->buttons[SDL_BUTTON_MIDDLE].pressed);
	lua_pushboolean(L, mouse->buttons[SDL_BUTTON_RIGHT ].pressed);
	lua_pushboolean(L, mouse->offscreen);
	lua_pushboolean(L, mouse->mmbScroll);
	return 7;
}


/***
 *
 * @function Spring.GetMouseCursor
 * @return string cursorName
 * @return number cursorScale
 */
int LuaUnsyncedRead::GetMouseCursor(lua_State* L)
{
	assert(mouse != nullptr);

	lua_pushsstring(L, mouse->GetCurrentCursor());
	lua_pushnumber(L, mouse->GetCurrentCursorScale());
	return 2;
}


/***
 *
 * @function Spring.GetMouseStartPosition
 * @param button number
 * @return number x
 * @return number y
 * @return number camPosX
 * @return number camPosY
 * @return number camPosZ
 * @return number dirX
 * @return number dirY
 * @return number dirZ
 */
int LuaUnsyncedRead::GetMouseStartPosition(lua_State* L)
{
	assert(mouse != nullptr);

	const int button = luaL_checkint(L, 1);

	if ((button <= 0) || (button > NUM_BUTTONS))
		return 0;

	const CMouseHandler::ButtonPressEvt& bp = mouse->buttons[button];
	lua_pushnumber(L, bp.x);
	lua_pushnumber(L, bp.y);
	lua_pushnumber(L, bp.camPos.x);
	lua_pushnumber(L, bp.camPos.y);
	lua_pushnumber(L, bp.camPos.z);
	lua_pushnumber(L, bp.dir.x);
	lua_pushnumber(L, bp.dir.y);
	lua_pushnumber(L, bp.dir.z);
	return 8;
}


/***
 *
 * @function Spring.GetMouseButtonsPressed
 *
 * Get pressed status for specific buttons.
 *
 * @param button1 integer Index of the first button.
 * @param ... integer Indices for more buttons.
 * @return boolean ... Pressed status for the buttons.
 */
int LuaUnsyncedRead::GetMouseButtonsPressed(lua_State* L)
{
	const int numArgs = lua_gettop(L);

	if (numArgs == 0) {
		luaL_error(L, "Need to pass some button indexes.");
	}

	for (int i = 1; i <= numArgs ; ++i) {
		const int button = luaL_checkint(L, i);

		if (button <= 0)
			luaL_error(L, "%d: bad button index", button);
		if (button > NUM_BUTTONS)
			lua_pushboolean(L, false);
		else
			lua_pushboolean(L, mouse->buttons[button].pressed);
	}

	return numArgs;
}


/******************************************************************************
 * Controller Input
 * @section controllerinput
******************************************************************************/

static void PushControllerInfo(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, 0, 3);
	HSTR_PUSH_NUMBER(L, "instanceId", controller.instanceId);
	HSTR_PUSH_NUMBER(L, "deviceId", controller.deviceId);
	HSTR_PUSH_STRING(L, "name", controller.name);
}

static void PushControllerButtons(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, static_cast<int>(controller.buttons.size()), 0);

	for (size_t buttonId = 0; buttonId < controller.buttons.size(); ++buttonId) {
		lua_pushnumber(L, controller.buttons[buttonId]);
		lua_rawseti(L, -2, static_cast<int>(buttonId));
	}
}

static void PushControllerAxes(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, static_cast<int>(controller.axes.size()), 0);

	for (size_t axisId = 0; axisId < controller.axes.size(); ++axisId) {
		lua_pushnumber(L, controller.axes[axisId]);
		lua_rawseti(L, -2, static_cast<int>(axisId));
	}
}

static void PushControllerState(lua_State* L, const CControllerInput::ControllerStateSnapshot& controller)
{
	lua_createtable(L, 0, 4);
	HSTR_PUSH_NUMBER(L, "instanceId", controller.instanceId);
	HSTR_PUSH_STRING(L, "name", controller.name);

	HSTR_PUSH(L, "buttons");
	PushControllerButtons(L, controller);
	lua_rawset(L, -3);

	HSTR_PUSH(L, "axes");
	PushControllerAxes(L, controller);
	lua_rawset(L, -3);
}

/***
 *
 * @function Spring.GetAvailableControllers
 * @return { instanceId: number, deviceId: number, name: string }[] controllers
 */
int LuaUnsyncedRead::GetAvailableControllers(lua_State* L)
{
	if (controllerInput == nullptr) {
		lua_createtable(L, 0, 0);
		return 1;
	}

	const auto controllers = controllerInput->GetAvailableControllers();
	lua_createtable(L, static_cast<int>(controllers.size()), 0);

	for (size_t i = 0; i < controllers.size(); ++i) {
		PushControllerInfo(L, controllers[i]);
		lua_rawseti(L, -2, static_cast<int>(i + 1));
	}

	return 1;
}

/***
 *
 * @function Spring.GetControllerState
 * @param instanceId number
 * @return table? controllerState with 0-based `buttons` and `axes` tables keyed by SDL id
 */
int LuaUnsyncedRead::GetControllerState(lua_State* L)
{
	if (controllerInput == nullptr)
		return 0;

	const int instanceId = luaL_checkint(L, 1);

	CControllerInput::ControllerStateSnapshot controller;
	if (!controllerInput->GetControllerState(instanceId, controller))
		return 0;

	PushControllerState(L, controller);
	return 1;
}


/******************************************************************************
 * Text
 * @section text
******************************************************************************/


/***
 *
 * @function Spring.GetClipboard
 * @return string text
 */
int LuaUnsyncedRead::GetClipboard(lua_State* L)
{
	char* text = SDL_GetClipboardText();
	if (text == nullptr)
		return 0;
	lua_pushstring(L, text);
	SDL_free(text);
	return 1;
}


/***
 *
 * @function Spring.IsUserWriting
 * @return boolean
 */
int LuaUnsyncedRead::IsUserWriting(lua_State* L)
{
	lua_pushboolean(L, gameTextInput.userWriting);
	return 1;
}


/******************************************************************************
 * Console
 * @section console
******************************************************************************/


/***
 *
 * @function Spring.GetLastMessagePositions
 * @return xyz[] message positions
 */
int LuaUnsyncedRead::GetLastMessagePositions(lua_State* L)
{
	lua_createtable(L, infoConsole->GetMsgPosCount(), 0);

	for (unsigned int i = 1; i <= infoConsole->GetMsgPosCount(); i++) {
		lua_createtable(L, 3, 0); {
			const float3 msgpos = infoConsole->GetMsgPos();
			lua_pushnumber(L, msgpos.x); lua_rawseti(L, -2, 1);
			lua_pushnumber(L, msgpos.y); lua_rawseti(L, -2, 2);
			lua_pushnumber(L, msgpos.z); lua_rawseti(L, -2, 3);
		}
		lua_rawseti(L, -2, i);
	}

	return 1;
}


/***
 * @function Spring.GetConsoleBuffer
 * @param maxLines number
 * @return { text: string, priority: integer }[] buffer
 */
int LuaUnsyncedRead::GetConsoleBuffer(lua_State* L)
{
	std::vector<CInfoConsole::RawLine> lines;
	infoConsole->GetRawLines(lines);

	const size_t lineCount = lines.size();
	      size_t startLine = 0;

	if (lua_gettop(L) >= 1)
		startLine = lineCount - std::min(lineCount, size_t(luaL_checkint(L, 1)));

	// table = { [1] = { text = string, zone = number}, etc... }
	lua_createtable(L, lineCount - startLine, 0);

	for (size_t i = startLine, n = 0; i < lineCount; i++) {
		lua_pushnumber(L, ++n);
		lua_createtable(L, 0, 2); {
			lua_pushliteral(L, "text");
			lua_pushsstring(L, lines[i].text);
			lua_rawset(L, -3);
			lua_pushliteral(L, "priority");
			lua_pushnumber(L, lines[i].level);
			lua_rawset(L, -3);
		}
		lua_rawset(L, -3);
	}

	return 1;
}


/***
 * @function Spring.GetCurrentTooltip
 * @return string tooltip
 */
int LuaUnsyncedRead::GetCurrentTooltip(lua_State* L)
{
	lua_pushsstring(L, mouse->GetCurrentTooltip());
	return 1;
}


/******************************************************************************
 * Key Input
 * @section keyinput
******************************************************************************/


/***
 * @function Spring.GetKeyFromScanSymbol
 * @param scanSymbol string
 * @return string keyName
 */
int LuaUnsyncedRead::GetKeyFromScanSymbol(lua_State* L)
{
	const std::string& symbol = StringToLower(luaL_optstring(L, 1, ""));

	std::string result = "";

	if (symbol.empty()) {
		lua_pushstring(L, result.c_str());
		return 1;
	}

	SDL_Scancode scanCode = (SDL_Scancode)scanCodes.GetCode(symbol);
	if (scanCode <= 0) {
		lua_pushstring(L, result.c_str());
		return 1;
	}

	SDL_Keycode keyCode = (SDL_Keycode)SDL_GetKeyFromScancode(scanCode);
	if (keyCode <= 0 || keyCode == 0x40000000) {
		lua_pushstring(L, result.c_str());
		return 1;
	}

	result = keyCodes.GetDefaultName(keyCode);

	lua_pushstring(L, result.c_str());

	return 1;
}

/***
 *
 * @function Spring.GetKeyState
 * @param keyCode number
 * @return boolean pressed
 */
int LuaUnsyncedRead::GetKeyState(lua_State* L)
{
	const int key = SDL12_keysyms(luaL_checkint(L, 1));
	lua_pushboolean(L, KeyInput::IsKeyPressed(key));
	return 1;
}


/***
 *
 * @function Spring.GetModKeyState
 * @return boolean alt
 * @return boolean ctrl
 * @return boolean meta
 * @return boolean shift
 */
int LuaUnsyncedRead::GetModKeyState(lua_State* L)
{
	lua_pushboolean(L, KeyInput::GetKeyModState(KMOD_ALT));
	lua_pushboolean(L, KeyInput::GetKeyModState(KMOD_CTRL));
	lua_pushboolean(L, KeyInput::GetKeyModState(KMOD_GUI));
	lua_pushboolean(L, KeyInput::GetKeyModState(KMOD_SHIFT));
	return 4;
}


/***
 *
 * @function Spring.GetPressedKeys
 * @return table<number|string,true> where keys are keyCodes or key names
 */
int LuaUnsyncedRead::GetPressedKeys(lua_State* L)
{
	const auto& keys = KeyInput::GetPressedKeys();

	lua_createtable(L, keys.size(), 0);

	for (auto key: keys) {
		if (!key.second)
			continue;

		const int keyCode = SDL21_keysyms(key.first);

		// [keyCode] = true
		lua_pushboolean(L, true);
		lua_rawseti(L, -2, keyCode);

		// ["keyName"] = true
		lua_pushsstring(L, keyCodes.GetName(keyCode));
		lua_pushboolean(L, true);
		lua_rawset(L, -3);
	}

	return 1;
}


/***
 *
 * @function Spring.GetPressedScans
 * @return table<number|string,true> where keys are scanCodes or scan names
 */
int LuaUnsyncedRead::GetPressedScans(lua_State* L)
{
	const auto& scans = KeyInput::GetPressedScans();

	lua_createtable(L, scans.size(), 0);

	for (auto scan: scans) {
		if (!scan.second)
			continue;

		const int scanCode = scan.first;

		// [scanCode] = true
		lua_pushboolean(L, true);
		lua_rawseti(L, -2, scanCode);

		// ["scanName"] = true
		lua_pushsstring(L, scanCodes.GetName(scanCode));
		lua_pushboolean(L, true);
		lua_rawset(L, -3);
	}

	return 1;
}


/***
 *
 * @function Spring.GetInvertQueueKey
 * @return number? queueKey
 */
int LuaUnsyncedRead::GetInvertQueueKey(lua_State* L)
{
	if (guihandler == nullptr)
		return 0;

	lua_pushboolean(L, guihandler->GetInvertQueueKey());
	return 1;
}


/***
 *
 * @function Spring.GetKeyCode
 * @param keySym string
 * @return number keyCode
 */
int LuaUnsyncedRead::GetKeyCode(lua_State* L)
{
	lua_pushnumber(L, SDL21_keysyms(keyCodes.GetCode(luaL_checksstring(L, 1))));
	return 1;
}


/***
 *
 * @function Spring.GetKeySymbol
 * @param keyCode number
 * @return string keyCodeName
 * @return string keyCodeDefaultName name when there are not aliases
 */
int LuaUnsyncedRead::GetKeySymbol(lua_State* L)
{
	const int keycode = SDL12_keysyms(luaL_checkint(L, 1));
	lua_pushsstring(L, keyCodes.GetName(keycode));
	lua_pushsstring(L, keyCodes.GetDefaultName(keycode));
	return 2;
}


/***
 *
 * @function Spring.GetScanSymbol
 * @param scanCode number
 * @return string scanCodeName
 * @return string scanCodeDefaultName name when there are not aliases
 */
int LuaUnsyncedRead::GetScanSymbol(lua_State* L)
{
	const int scanCode = luaL_checkint(L, 1);
	lua_pushsstring(L, scanCodes.GetName(scanCode));
	lua_pushsstring(L, scanCodes.GetDefaultName(scanCode));
	return 2;
}


/*** Contains data about a keybinding
 *
 * @class KeyBinding
 * @x_helper
 * @field command string
 * @field extra string
 * @field boundWith string
 */


/***
 * @function Spring.GetKeyBindings
 * @param keySet1 string? filters keybindings bound to this keyset
 * @param keySet2 string? OR bound to this keyset
 * @return KeyBinding[]
 */
int LuaUnsyncedRead::GetKeyBindings(lua_State* L)
{
	ActionList actions;
	const std::string& argument = luaL_optstring(L, 1, "");

	if (argument.empty()) {
		actions = keyBindings.GetActionList();
	} else {
		CKeySet ks;

		if (!ks.Parse(luaL_checksstring(L, 1)))
			return 0;

		CKeyChain keyChain;
		keyChain.emplace_back(ks);

		const std::string& arg2 = luaL_optstring(L, 2, "");

		if (arg2.empty()) {
			actions = keyBindings.GetActionList(keyChain);
		} else {
			if (!ks.Parse(luaL_checksstring(L, 2)))
				return 0;

			CKeyChain keyChain2;
			keyChain2.emplace_back(ks);

			actions = keyBindings.GetActionList(keyChain, keyChain2);
		}
	}

	int i = 1;
	lua_createtable(L, actions.size(), 0);
	for (const Action& action: actions) {
		lua_createtable(L, 0, 4);
			lua_pushsstring(L, action.command);
			lua_pushsstring(L, action.extra);
			lua_rawset(L, -3);
			LuaPushNamedString(L, "command",   action.command);
			LuaPushNamedString(L, "extra",     action.extra);
			LuaPushNamedString(L, "boundWith", action.boundWith);
		lua_rawseti(L, -2, i++);
	}
	return 1;
}


/***
 *
 * @function Spring.GetActionHotKeys
 * @param actionName string
 * @return string[]? hotkeys
 */
int LuaUnsyncedRead::GetActionHotKeys(lua_State* L)
{
	const CKeyBindings::HotkeyList& hotkeys = keyBindings.GetHotkeys(luaL_checksstring(L, 1));

	lua_createtable(L, 0, hotkeys.size());
	int i = 1;
	for (const std::string& hotkey: hotkeys) {
		lua_pushsstring(L, hotkey);
		lua_rawseti(L, -2, i++);
	}
	return 1;
}


/******************************************************************************
 * Unit Groups
 * @section unitgroups
******************************************************************************/


/***
 *
 * @function Spring.GetGroupList
 * @return table<number,number>? where keys are groupIDs and values are counts
 */
int LuaUnsyncedRead::GetGroupList(lua_State* L)
{
	unsigned int count = 0;

	const std::vector<CGroup>& groups = uiGroupHandlers[gu->myTeam].GetGroups();

	// not an array-table
	lua_createtable(L, 0, groups.size());

	for (const CGroup& group: groups) {
		if (group.units.empty())
			continue;

		lua_pushnumber(L, group.units.size());
		lua_rawseti(L, -2, group.id);
		count++;
	}

	lua_pushnumber(L, count);
	return 2;
}


/***
 *
 * @function Spring.GetSelectedGroup
 * @return integer groupID -1 when no group selected
 */
int LuaUnsyncedRead::GetSelectedGroup(lua_State* L)
{
	lua_pushnumber(L, selectedUnitsHandler.GetSelectedGroup());
	return 1;
}


/***
 *
 * @function Spring.GetUnitGroup
 * @param unitID integer
 * @return integer? groupID
 */
int LuaUnsyncedRead::GetUnitGroup(lua_State* L)
{
	const CUnit* unit = ParseUnit(L, __func__, 1);

	if (unit == nullptr)
		return 0;
	if (unit->team != gu->myTeam)
		return 0;

	const CGroup* group = unit->GetGroup();

	if (group == nullptr)
		return 0;

	lua_pushnumber(L, group->id);
	return 1;
}

static inline const CGroup* GetGroupFromArg(lua_State* L, int arg)
{
	const int groupID = luaL_checkint(L, arg);
	const auto& groupHandler = uiGroupHandlers[gu->myTeam];

	if (!groupHandler.HasGroup(groupID))
		return nullptr;

	return groupHandler.GetGroup(groupID);
}

/***
 *
 * @function Spring.GetGroupUnits
 * @param groupID integer
 * @return number[]? unitIDs
 */
int LuaUnsyncedRead::GetGroupUnits(lua_State* L)
{
	const auto group = GetGroupFromArg(L, 1);
	if (!group)
		return 0;

	PushNumberContainerAsArray(L, group->units);
	return 1;
}


/***
 *
 * @function Spring.GetGroupUnitsSorted
 * @param groupID integer
 * @return table<number,number[]>? where keys are unitDefIDs and values are unitIDs
 */
int LuaUnsyncedRead::GetGroupUnitsSorted(lua_State* L)
{
	const auto group = GetGroupFromArg(L, 1);
	if (!group)
		return 0;

	PushUnitListSortedByDef(L, group->units);
	return 1;
}


/***
 *
 * @function Spring.GetGroupUnitsCounts
 * @param groupID integer
 * @return table<number,number>? where keys are unitDefIDs and values are counts
 */
int LuaUnsyncedRead::GetGroupUnitsCounts(lua_State* L)
{
	const auto group = GetGroupFromArg(L, 1);
	if (!group)
		return 0;

	PushSparseUnitTallyByDef(L, group->units);
	return 1;
}


/***
 *
 * @function Spring.GetGroupUnitsCount
 * @param groupID integer
 * @return number? groupSize
 */
int LuaUnsyncedRead::GetGroupUnitsCount(lua_State* L)
{
	const auto group = GetGroupFromArg(L, 1);
	if (!group)
		return 0;

	lua_pushnumber(L, group->units.size());
	return 1;
}


/******************************************************************************
 * Team/Player Info
 * @section teamplayerinfo
******************************************************************************/


/*** Contains data about a player
 *
 * @class Roster
 * @x_helper
 * @field name string
 * @field playerID integer
 * @field teamID integer
 * @field allyTeamID integer
 * @field spectator boolean
 * @field cpuUsage number in order to find the progress, use: cpuUsage&0x1 if it's PC or BO, cpuUsage& 0xFE to get path res, (cpuUsage>>8)*1000 for the progress
 * @field pingTime number if -1, the player is pathfinding
 */


/***
 *
 * @function Spring.GetPlayerRoster
 * @param sortType number? return unsorted if unspecified. Disabled = 0, Allies = 1, TeamID = 2, PlayerName = 3, PlayerCPU = 4, PlayerPing = 5
 * @param showPathingPlayers boolean? (Default: `false`)
 * @return Roster[]? playerTable
 */
int LuaUnsyncedRead::GetPlayerRoster(lua_State* L)
{
	const PlayerRoster::SortType oldSortType = playerRoster.GetSortType();

	if (!lua_isnone(L, 1))
		playerRoster.SetSortTypeByCode((PlayerRoster::SortType) luaL_checkint(L, 1));

	const bool includePathingFlag = luaL_optboolean(L, 2, false);

	// get the sorted indices of *all* (including inactive) players
	const std::vector<int>& playerIndices = playerRoster.GetIndices(includePathingFlag);

	// revert
	playerRoster.SetSortTypeByCode(oldSortType);

	// push the active players
	lua_createtable(L, playerIndices.size(), 0);
	for (size_t i = 0, j = 1, s = playerIndices.size(); i < s; i++) {
		if (!AddPlayerToRoster(L, playerIndices[i], true, includePathingFlag))
			continue;

		// t[j] = {...}
		lua_rawseti(L, -2, j++);
	}

	return 1;
}


/***
 *
 * @function Spring.GetPlayerTraffic
 * @param playerID integer
 * @param packetID integer?
 * @return number traffic
 */
int LuaUnsyncedRead::GetPlayerTraffic(lua_State* L)
{
	const int playerID = luaL_checkint(L, 1);
	const int packetID = (int)luaL_optnumber(L, 2, -1);

	const auto& traffic = game->GetPlayerTraffic();
	const auto it = traffic.find(playerID);

	if (it == traffic.end()) {
		lua_pushnumber(L, -1);
		return 1;
	}

	// only allow viewing stats for specific packet types
	if (
		(playerID != -1) &&              // all system counts can be read
		(playerID != gu->myPlayerNum) && // all  self  counts can be read
		(packetID != -1) &&
		(packetID != NETMSG_CHAT)     &&
		(packetID != NETMSG_PAUSE)    &&
		(packetID != NETMSG_LUAMSG)   &&
		(packetID != NETMSG_STARTPOS) &&
		(packetID != NETMSG_USER_SPEED)
	) {
		lua_pushnumber(L, -1);
		return 1;
	}

	const CGame::PlayerTrafficInfo& pti = it->second;
	if (packetID == -1) {
		lua_pushnumber(L, pti.total);
		return 1;
	}

	const auto pit = pti.packets.find(packetID);
	if (pit == pti.packets.end()) {
		lua_pushnumber(L, -1);
		return 1;
	}

	lua_pushnumber(L, pit->second);
	return 1;
}


/***
 *
 * @function Spring.GetPlayerStatistics
 * @param playerID integer
 * @return number? mousePixels nil when invalid playerID
 * @return number mouseClicks
 * @return number keyPresses
 * @return number numCommands
 * @return number unitCommands
 */
int LuaUnsyncedRead::GetPlayerStatistics(lua_State* L)
{
	const int playerID = luaL_checkint(L, 1);
	if (!playerHandler.IsValidPlayer(playerID))
		return 0;

	const CPlayer* player = playerHandler.Player(playerID);
	if (player == nullptr)
		return 0;

	const PlayerStatistics& pStats = player->currentStats;

	lua_pushnumber(L, pStats.mousePixels);
	lua_pushnumber(L, pStats.mouseClicks);
	lua_pushnumber(L, pStats.keyPresses);
	lua_pushnumber(L, pStats.numCommands);
	lua_pushnumber(L, pStats.unitCommands);

	return 5;
}


/******************************************************************************
 * Configuration
 * @section configuration
******************************************************************************/


/*** Contains data about a configuration, only name and type are guaranteed
 *
 * @class Configuration
 * @x_helper
 * @field name string
 * @field type string
 * @field description string
 * @field defaultValue string
 * @field minimumValue string
 * @field maximumValue string
 * @field safemodeValue string
 * @field declarationFile string
 * @field declarationLine string
 * @field readOnly boolean
 */


/***
 *
 * @function Spring.GetConfigParams
 * @return Configuration[]
 */
int LuaUnsyncedRead::GetConfigParams(lua_State* L)
{
	ConfigVariable::MetaDataMap cfgmap = ConfigVariable::GetMetaDataMap();
	lua_createtable(L, cfgmap.size(), 0);

	int i = 1;
	for (ConfigVariable::MetaDataMap::const_iterator it = cfgmap.begin(); it != cfgmap.end(); ++it) {
		const ConfigVariableMetaData* meta = it->second;

		lua_createtable(L, 0, 11);

			lua_pushliteral(L, "name");
			lua_pushsstring(L, meta->GetKey());
			lua_rawset(L, -3);
			if (meta->GetDescription().IsSet()) {
				lua_pushliteral(L, "description");
				lua_pushsstring(L, meta->GetDescription().ToString());
				lua_rawset(L, -3);
			}
			lua_pushliteral(L, "type");
			lua_pushsstring(L, meta->GetType());
			lua_rawset(L, -3);
			if (meta->GetDefaultValue().IsSet()) {
				lua_pushliteral(L, "defaultValue");
				lua_pushsstring(L, meta->GetDefaultValue().ToString());
				lua_rawset(L, -3);
			}
			if (meta->GetMinimumValue().IsSet()) {
				lua_pushliteral(L, "minimumValue");
				lua_pushsstring(L, meta->GetMinimumValue().ToString());
				lua_rawset(L, -3);
			}
			if (meta->GetMaximumValue().IsSet()) {
				lua_pushliteral(L, "maximumValue");
				lua_pushsstring(L, meta->GetMaximumValue().ToString());
				lua_rawset(L, -3);
			}
			if (meta->GetSafemodeValue().IsSet()) {
				lua_pushliteral(L, "safemodeValue");
				lua_pushsstring(L, meta->GetSafemodeValue().ToString());
				lua_rawset(L, -3);
			}
			if (meta->GetDeclarationFile().IsSet()) {
				lua_pushliteral(L, "declarationFile");
				lua_pushsstring(L, meta->GetDeclarationFile().ToString());
				lua_rawset(L, -3);
			}
			if (meta->GetDeclarationLine().IsSet()) {
				lua_pushliteral(L, "declarationLine");
				lua_pushnumber(L, meta->GetDeclarationLine().Get());
				lua_rawset(L, -3);
			}
			if (meta->GetReadOnly().IsSet()) {
				lua_pushliteral(L, "readOnly");
				lua_pushboolean(L, !!meta->GetReadOnly().Get());
				lua_rawset(L, -3);
			}
			if (meta->GetDeprecated().IsSet()) {
				lua_pushliteral(L, "readOnly");
				lua_pushboolean(L, !!meta->GetDeprecated().Get());
				lua_rawset(L, -3);
			}

		lua_rawseti(L, -2, i++);
	}
	return 1;
}


/***
 *
 * @function Spring.GetConfigInt
 * @param name string
 * @param default number? (Default: `0`)
 * @return number? configInt
 */
int LuaUnsyncedRead::GetConfigInt(lua_State* L)
{
	const auto key = luaL_checkstring(L, 1);
	if (!lua_isnoneornil(L, 2))
		lua_pushinteger(L, configHandler->GetIntSafe(key, luaL_optint(L, 2, 0)));
	else if (configHandler->IsSet(key))
		lua_pushinteger(L, configHandler->GetInt(key));
	else
		lua_pushnil(L);

	return 1;
}


/***
 *
 * @function Spring.GetConfigFloat
 * @param name string
 * @param default number? (Default: `0`)
 * @return number? configFloat
 */
int LuaUnsyncedRead::GetConfigFloat(lua_State* L)
{
	const auto key = luaL_checkstring(L, 1);
	if (!lua_isnoneornil(L, 2))
		lua_pushnumber(L, configHandler->GetFloatSafe(key, luaL_optfloat(L, 2, 0.0f)));
	else if (configHandler->IsSet(key))
		lua_pushnumber(L, configHandler->GetFloat(key));
	else
		lua_pushnil(L);

	return 1;
}


/***
 *
 * @function Spring.GetConfigString
 * @param name string
 * @param default string? (Default: `""`)
 * @return number? configString
 */
int LuaUnsyncedRead::GetConfigString(lua_State* L)
{
	const auto key = luaL_checkstring(L, 1);
	if (!lua_isnoneornil(L, 2))
		lua_pushsstring(L, configHandler->GetStringSafe(key, luaL_optstring(L, 2, "")));
	else if (configHandler->IsSet(key))
		lua_pushsstring(L, configHandler->GetString(key));
	else
		lua_pushnil(L);

	return 1;
}


/***
 *
 * @function Spring.GetLogSections
 * @return table<string,number> sections where keys are names and loglevel are values. E.g. `{ "KeyBindings" = LOG.INFO, "Font" = LOG.INFO, "Sound" = LOG.WARNING, ... }`
 */
int LuaUnsyncedRead::GetLogSections(lua_State* L) {
	const int numLogSections = log_filter_section_getNumRegisteredSections();

	lua_createtable(L, 0, numLogSections);
	for (int i = 0; i < numLogSections; ++i) {
		const char* sectionName = log_filter_section_getRegisteredIndex(i);
		const int logLevel = log_filter_section_getMinLevel(sectionName);

		lua_pushstring(L, sectionName);
		lua_pushnumber(L, logLevel);
		lua_rawset(L, -3);
	}

	return 1;
}


/******************************************************************************
 * Decals
 * @section decals
******************************************************************************/


/***
 *
 * @function Spring.GetAllGroundDecals
 *
 * @return number[] decalIDs
 */
int LuaUnsyncedRead::GetAllGroundDecals(lua_State* L)
{
	const auto& decals = groundDecals->GetAllDecals();

	int numValid = 0;
	for (const auto& d : decals) {
		numValid += d.IsValid();
	}

	if (numValid == 0) {
		lua_newtable(L);
		return 1;
	}

	int i = 1;
	lua_createtable(L, numValid, 0);
	for (const auto& d: decals) {
		if (!d.IsValid())
			continue;

		lua_pushnumber(L, d.info.id);
		lua_rawseti(L, -2, i++);
	}

	return 1;
}


/***
 *
 * @function Spring.GetGroundDecalMiddlePos
 * @param decalID integer
 * @return number? posX
 * @return number posZ
 */
int LuaUnsyncedRead::GetGroundDecalMiddlePos(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	const float2 midPointCurr = (decal->posTL + decal->posTR + decal->posBR + decal->posBL) * 0.25f;
	lua_pushnumber(L, midPointCurr.x);
	lua_pushnumber(L, midPointCurr.y);

	return 2;
}

/***
 *
 * @function Spring.GetGroundDecalQuadPos
 * @param decalID integer
 * @return number? posTL.x
 * @return number posTL.z
 * @return number posTR.x
 * @return number posTR.z
 * @return number posBR.x
 * @return number posBR.z
 * @return number posBL.x
 * @return number posBL.z
 */
int LuaUnsyncedRead::GetGroundDecalQuadPos(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->posTL.x);
	lua_pushnumber(L, decal->posTL.y);
	lua_pushnumber(L, decal->posTR.x);
	lua_pushnumber(L, decal->posTR.y);
	lua_pushnumber(L, decal->posBR.x);
	lua_pushnumber(L, decal->posBR.y);
	lua_pushnumber(L, decal->posBL.x);
	lua_pushnumber(L, decal->posBL.y);

	return 8;
}


/***
 *
 * @function Spring.GetGroundDecalSizeAndHeight
 * @param decalID integer
 * @return number? sizeX
 * @return number sizeY
 * @return number projCubeHeight
 */
int LuaUnsyncedRead::GetGroundDecalSizeAndHeight(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	// average and take half of it
	lua_pushnumber(L, (decal->posTL.Distance(decal->posTR) + decal->posBL.Distance(decal->posBR)) * 0.5f * 0.5f);
	lua_pushnumber(L, (decal->posTL.Distance(decal->posBL) + decal->posTR.Distance(decal->posBR)) * 0.5f * 0.5f);
	lua_pushnumber(L, decal->height);

	return 3;
}


/***
 *
 * @function Spring.GetGroundDecalRotation
 * @param decalID integer
 * @return number? rotation Rotation in radians.
 */
int LuaUnsyncedRead::GetGroundDecalRotation(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->rot);

	return 1;
}


/***
 *
 * @function Spring.GetGroundDecalTexture
 * @param decalID integer
 * @param isMainTex boolean? (Default: `true`) If `false`, return the normal/glow map.
 * @return string? texture
 */
int LuaUnsyncedRead::GetGroundDecalTexture(lua_State* L)
{
	const auto& texName = groundDecals->GetDecalTexture(luaL_checkint(L, 1), luaL_optboolean(L, 2, true));
	lua_pushsstring(L, texName);

	return 1;
}

/***
 *
 * @function Spring.GetGroundDecalTextures
 * @return string[] textureNames All textures on the atlas and available for use in `SetGroundDecalTexture`.
 * @param isMainTex boolean|nil (Default: `nil`). If `nil` - no filtering is done, if `false` - return normal/glow textures, if `true` - return main color textures.
 * @param addFilenames boolean? (Default: `false`). If `true` add the texture filenames in the second table
 * @see Spring.GetGroundDecalTexture
 */
int LuaUnsyncedRead::GetGroundDecalTextures(lua_State* L)
{
	std::optional<bool> isMainTex;
	if (!lua_isnoneornil(L, 1))
		isMainTex = luaL_checkboolean(L, 1);

	const auto pushFileNames = luaL_optboolean(L, 2, false);

	const auto& texNames = groundDecals->GetDecalTextures(isMainTex);
	LuaUtils::PushStringVector(L, texNames);

	if (!pushFileNames)
		return 1;

	const auto& texFileNames = groundDecals->GetDecalTextureFileNames(texNames);
	LuaUtils::PushStringVector(L, texFileNames);
	return 2;
}


/***
 *
 * @function Spring.SetGroundDecalTextureParams
 * @param decalID integer
 * @return number? texWrapDistance If non-zero, sets the mode to repeat the texture along the left-right direction of the decal every texWrapFactor elmos.
 * @return number texTraveledDistance Shifts the texture repetition defined by texWrapFactor so the texture of a next line in the continuous multiline can start where the previous finished. For that it should collect all elmo lengths of the previously set multiline segments.
 */
int LuaUnsyncedRead::GetGroundDecalTextureParams(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->uvWrapDistance);
	lua_pushnumber(L, decal->uvTraveledDistance);

	return 2;
}


/***
 *
 * @function Spring.GetGroundDecalAlpha
 * @param decalID integer
 * @return number? alpha Between 0 and 1
 * @return number alphaFalloff Between 0 and 1, per second
 */
int LuaUnsyncedRead::GetGroundDecalAlpha(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->alpha);
	lua_pushnumber(L, decal->alphaFalloff * GAME_SPEED);

	return 2;
}

/***
 *
 * @function Spring.GetGroundDecalNormal
 *
 * If all three equal 0, the decal follows the normals of ground at midpoint
 *
 * @param decalID integer
 * @return number? normal.x
 * @return number normal.y
 * @return number normal.z
 */
int LuaUnsyncedRead::GetGroundDecalNormal(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->forcedNormal.x);
	lua_pushnumber(L, decal->forcedNormal.y);
	lua_pushnumber(L, decal->forcedNormal.z);

	return 3;
}

/***
 *
 * @function Spring.GetGroundDecalTint
 * Gets the tint of the ground decal.
 * A color of (0.5, 0.5, 0.5, 0.5) is effectively no tint
 * @param decalID integer
 * @return number? tintR
 * @return number tintG
 * @return number tintB
 * @return number tintA
 */
int LuaUnsyncedRead::GetGroundDecalTint(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	float4 tintColor = decal->tintColor;
	lua_pushnumber(L, tintColor.r);
	lua_pushnumber(L, tintColor.g);
	lua_pushnumber(L, tintColor.b);
	lua_pushnumber(L, tintColor.a);

	return 4;
}

/***
 *
 * @function Spring.GetGroundDecalMisc
 * Returns less important parameters of a ground decal
 * @param decalID integer
 * @return number? dotElimExp
 * @return number refHeight
 * @return number minHeight
 * @return number maxHeight
 * @return number forceHeightMode
 */
int LuaUnsyncedRead::GetGroundDecalMisc(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->dotElimExp);
	lua_pushnumber(L, decal->refHeight);
	lua_pushnumber(L, decal->minHeight);
	lua_pushnumber(L, decal->maxHeight);
	lua_pushnumber(L, decal->forceHeightMode);
	return 5;
}

/***
 *
 * @function Spring.GetGroundDecalCreationFrame
 *
 * Min can be not equal to max for "gradient" style decals, e.g. unit tracks
 *
 * @param decalID integer
 * @return number? creationFrameMin
 * @return number creationFrameMax
 */
int LuaUnsyncedRead::GetGroundDecalCreationFrame(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->createFrameMin);
	lua_pushnumber(L, decal->createFrameMax);

	return 2;
}


/***
 * @function Spring.GetGroundDecalOwner
 * @param decalID integer
 * @return integer? value If owner is a unit, then this is `unitID`, if owner is
 * a feature it is `featureID + MAX_UNITS`. If there is no owner, then `nil`.
 */
int LuaUnsyncedRead::GetGroundDecalOwner(lua_State* L)
{
	const auto* so = groundDecals->GetDecalSolidObjectOwner(luaL_checkint(L, 1));
	if (so == nullptr)
		return 0;

	if (const auto* f = dynamic_cast<const CFeature*>(so); f != nullptr)
		lua_pushnumber(L, unitHandler.MaxUnits() + so->id);
	else
		lua_pushnumber(L,                          so->id);

	return 1;
}

/***
 *
 * @function Spring.GetGroundDecalGlowParams
 * Gets the glow parameters of the ground decal.
 * @param decalID integer
 * @return number? glow Between 0 and 1
 * @return number glowFalloff Between 0 and 1, per second
 */
int LuaUnsyncedRead::GetGroundDecalGlowParams(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	lua_pushnumber(L, decal->glow);
	lua_pushnumber(L, decal->glowFalloff * GAME_SPEED);

	//PushNumberContainerAsArray(L, decal->glowColorMap[0].rgba);
	//PushNumberContainerAsArray(L, decal->glowColorMap[1].rgba);

	return 2;
}

/***
 *
 * @function Spring.GetGroundDecalUserData
 * Gets the user defined decal data.
 * @param decalID integer
 * @param udQuad integer vec4 index, must be within [0;1] for now
 * @return number? x
 * @return number y
 * @return number z
 * @return number w
 */
int LuaUnsyncedRead::GetGroundDecalUserData(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal) {
		return 0;
	}

	const auto quad = static_cast<uint32_t>(luaL_checknumber(L, 2));
	if (quad >= GroundDecal::NUM_USERDATA) {
		return 0;
	}

	const float4& userData = decal->userDefined[quad];
	for (size_t i = 0; i < 4; ++i)
		lua_pushnumber(L, userData[i]);

	return 4;
}


/***
 *
 * @function Spring.GetGroundDecalType
 * @param decalID integer
 * @return "explosion"|"plate"|"lua"|"track"|"unknown"|nil type
 */
int LuaUnsyncedRead::GetGroundDecalType(lua_State* L)
{
	const auto* decal = groundDecals->GetDecalById(luaL_checkint(L, 1));
	if (!decal || decal->info.type == static_cast<uint8_t>(GroundDecal::Type::DECAL_NONE)) {
		return 0;
	}

	switch (decal->info.type)
	{
	case static_cast<uint8_t>(GroundDecal::Type::DECAL_PLATE):
		lua_pushliteral(L, "plate");
		break;
	case static_cast<uint8_t>(GroundDecal::Type::DECAL_EXPLOSION):
		lua_pushliteral(L, "explosion");
		break;
	case static_cast<uint8_t>(GroundDecal::Type::DECAL_TRACK):
		lua_pushliteral(L, "track");
		break;
	case static_cast<uint8_t>(GroundDecal::Type::DECAL_LUA):
		lua_pushliteral(L, "lua");
		break;
	default:
		lua_pushliteral(L, "unknown");
		break;
	}

	return 1;
}


/******************************************************************************
 * Misc
 * @section misc
******************************************************************************/


/***
 *
 * @function Spring.GetSyncedGCInfo
 * @param collectGC boolean? (Default: `false`) collect before returning metric
 * @return number? GC values are expressed in Kbytes: #bytes/2^10
 */
int LuaUnsyncedRead::GetSyncedGCInfo(lua_State* L) {
	if (luaRules == nullptr)
		return 0;

	lua_State* syncedL = luaRules->syncedLuaHandle.GetLuaGCState();

	if (syncedL == nullptr)
		return 0;

	auto luaLock = spring::ScopedNullResource([syncedL]() { lua_lock(syncedL); }, [syncedL]() { lua_unlock(syncedL); });

	if (luaL_optboolean(L, 1, false)) { //perform collection before returning the use metric
		lua_gc(syncedL, LUA_GCCOLLECT, 0); //mark
		lua_gc(syncedL, LUA_GCCOLLECT, 0); //sweep
		lua_gc(syncedL, LUA_GCSTOP, 0); //just in case
	}

	lua_pushnumber(L, lua_gc(syncedL, LUA_GCCOUNT, 0));
	return 1;
}

/***
 *
 * @function Spring.SolveNURBSCurve
 * @param groupID integer
 * @return number[]? unitIDs
 */
int LuaUnsyncedRead::SolveNURBSCurve(lua_State* L)
{
	int degree = luaL_checkint(L, 1);

	std::vector<float4> cpoints{};
	std::vector<float> knots{};

	LuaUtils::ParseFloat4Vector(L, 2, cpoints);
	LuaUtils::ParseFloatVector(L, 3, knots);

	int segments = luaL_checkint(L, 4);

	const auto result = NURBS::SolveNURBSCurve(degree, cpoints, knots, segments);

	lua_createtable(L, result.size(), 0);
	for (size_t i = 0; const auto &x : result) {
		lua_pushnumber(L, x.x);
		lua_rawseti(L, -2, ++i);
		lua_pushnumber(L, x.y);
		lua_rawseti(L, -2, ++i);
		lua_pushnumber(L, x.z);
		lua_rawseti(L, -2, ++i);
	}
	return 1;
}
````


### 15.7 `gui_controller_camera_test.lua`

````lua
--------------------------------------------------------------------------------
-- SECTION: Widget info and Spring/gl references
--------------------------------------------------------------------------------
local widget = widget ---@type Widget

function widget:GetInfo()
	return {
		name = "Controller Camera Test",
		desc = "Prototype Xbox controller left-stick camera panning",
		author = "Kailil / Codex",
		date = "2026-05-22",
		license = "GNU GPL, v2 or later",
		layer = 0,
		enabled = false,
	}
end

local spGetAvailableControllers = Spring.GetAvailableControllers
local spGetControllerState = Spring.GetControllerState
local spGetCameraState = Spring.GetCameraState
local spSetCameraState = Spring.SetCameraState
local spGetCameraVectors = Spring.GetCameraVectors
local spGetGroundHeight = Spring.GetGroundHeight
local spGetMouseState = Spring.GetMouseState
local spGetViewGeometry = Spring.GetViewGeometry
local spTraceScreenRay = Spring.TraceScreenRay
local spSelectUnitArray = Spring.SelectUnitArray
local spGetSelectedUnits = Spring.GetSelectedUnits
local spGiveOrderToUnit = Spring.GiveOrderToUnit
local lastIssuedCommand = "none"
--------------------------------------------------------------------------------
-- SECTION: State tables and settings defaults
--------------------------------------------------------------------------------
ControllerCameraTestCommandDebug = ControllerCameraTestCommandDebug or {
	defaultCmdIndex = "none",
	defaultCmdID = "none",
	defaultCmdType = "none",
	defaultCmdName = "none",
	isBuild = "no",
	issuedCmdID = "none",
	issuedParamsCount = 0,
	lastOptions = "none",
	lastResult = "none",
	mexSmartAvailable = "no",
	mexNearestSpot = "no",
	mexBuildingCmdID = "none",
	mexActionResult = "none",
	mexApplyPreviewPath = "no",
	mexFallbackGiveOrderPath = "no",
}
ControllerCameraTestBuildMenu = ControllerCameraTestBuildMenu or {
	open = false,
	options = {},
	selectedIndex = 1,
	optionCount = 0,
	highlightedName = "none",
	highlightedCmdID = "none",
	lastAction = "none",
	placementResult = "none",
	placementParamsCount = 0,
	radialCategories = { "Economy", "Combat", "Utility", "Build" },
	radialPage = 1,
	radialPageCount = 1,
	radialCategoryIndex = 1,
	radialCategoryName = "Economy",
	radialVisibleOptions = {},
	radialStickArmed = true,
	radialLastAngle = 0,
	radialLastAction = "none",
	factoryQueueCounts = {},
	factoryQueueProgress = {},
	factoryProgressKnown = "no",
	factoryProgressCmdID = "none",
	factoryProgressValue = "none",
	factoryProgressSource = "none",
}
ControllerCameraTestBuildPlacement = ControllerCameraTestBuildPlacement or {
	active = false,
	option = nil,
	facing = 0,
	lastResult = "none",
	lastParamsCount = 0,
	lastIssuedCount = 0,
	analogRotateArmed = true,
	queueActive = false,
	nativePreviewActive = false,
	nativeSetActiveCommandResult = "none",
	cmdDescIndex = nil,
	placementMode = "none",
	placementPattern = "single",
	placementSpacing = 0,
	queueFrontActive = false,
	gridShortcutResult = "none",
	lastConstructionShortcut = "none",
	useCustomGridFallback = true,
}
ControllerCameraTestDragCommand = ControllerCameraTestDragCommand or {
	active = false,
	mode = "none",
	cmdID = nil,
	startX = nil,
	startY = nil,
	startZ = nil,
	endX = nil,
	endY = nil,
	endZ = nil,
	radius = 0,
	shape = "none",
	lastResult = "none",
	lastMode = "none",
	previewPoints = {},
	pressStartTime = 0,
	pressActive = false,
	pressButton = nil,
	nativeRouteUsed = false,
	nativeRouteName = "unavailable",
	nativePreviewResult = "none",
	customGridFallback = "yes",
	singleUnitPathActive = false,
	singleUnitPathUnitID = nil,
	singleUnitPathPoints = {},
	singleUnitLastPointX = nil,
	singleUnitLastPointY = nil,
	singleUnitLastPointZ = nil,
	singleUnitLastIssueTime = 0,
	singleUnitPathResult = "none",
	singleUnitWaypointCount = 0,
}

ControllerCameraTestAreaSelect = ControllerCameraTestAreaSelect or {
	pressActive = false,
	active = false,
	pressStartTime = 0,
	lastTapTime = -10,
	radius = 320,
	lastCount = 0,
	lastResult = "none",
	doubleTapAction = "none",
	filterMode = "units-only",
	sameTypeTarget = "none",
	sameTypeUnitDefID = "none",
	sameTypeSource = "none",
	sameTypeCandidateCount = 0,
	sameTypeSelectedCount = 0,
}
ControllerCameraTestTacticalMenu = ControllerCameraTestTacticalMenu or {
	open = false,
	selectedIndex = 1,
	highlightedName = "none",
	lastAction = "none",
	lastResult = "none",
	radialLastAngle = 0,
}
ControllerCameraTestCycleDebug = ControllerCameraTestCycleDebug or {
	lastResult = "none",
	lastCount = 0,
	lastUnitID = "none",
	lbPressActive = false,
	lbHadPitchMotion = false,
}
ControllerCameraTestBookmarkDebug = ControllerCameraTestBookmarkDebug or {
	slots = {},
	lastResult = "none",
	lastSlot = "none",
}
ControllerCameraTestIdleCycle = ControllerCameraTestIdleCycle or {
	currentUnitID = nil,
	currentIndex = 1,
	currentTypeKey = nil,
	currentTypeIndex = 1,
	lastResult = "none",
	lastTypeName = "none",
	lastCount = 0,
	selectedAllCount = 0,
}
ControllerCameraTestControlGroups = ControllerCameraTestControlGroups or {
	slots = {},
	activeSlot = 1,
	visibleUntil = 0,
	lastAction = "none",
	lastSlot = "none",
	lastCount = 0,
	leftPressActive = false,
	leftPressStartTime = 0,
	leftHoldTriggered = false,
	leftInputState = "idle",
}
ControllerCameraTestVisualFeedback = ControllerCameraTestVisualFeedback or {
	targetX = nil,
	targetY = nil,
	targetZ = nil,
	label = "none",
	kind = "generic",
	expireTime = 0,
}
ControllerCameraTestPlacementPopup = ControllerCameraTestPlacementPopup or {
	text = "none",
	expireTime = 0,
	lastResult = "none",
}
ControllerCameraTestInputSmoothing = ControllerCameraTestInputSmoothing or {
	panX = 0,
	panY = 0,
	rotateX = 0,
	pitchY = 0,
	zoomY = 0,
	leftTrigger = 0,
}
ControllerCameraTestSelectedStatus = ControllerCameraTestSelectedStatus or {
	mode = "hidden",
	lastResult = "none",
	vanillaCommandPanelStatus = "untouched",
}
ControllerCameraTestLayerDebug = ControllerCameraTestLayerDebug or {
	commandLayerAction = "none",
	normalUtilityAction = "none",
	areaSelect = "inactive",
	modeSummary = "normal",
}
ControllerCameraTestDebugSections = ControllerCameraTestDebugSections or {
	Input = true,
	Camera = false,
	Reticle = false,
	Selection = false,
	Commands = false,
	AreaSelect = false,
	TacticalMenu = false,
	BuildMenu = true,
	Bookmarks = false,
	IdleCycle = true,
	ControlGroups = true,
	QuickGroups = false,
	Tuning = false,
}
ControllerCameraTestDebugCompact = ControllerCameraTestDebugCompact or false
ControllerCameraTestDebugSectionHitboxes = {}

local spGetUnitPosition = Spring.GetUnitPosition
local spGetUnitAllyTeam = Spring.GetUnitAllyTeam
local spGetMyAllyTeamID = Spring.GetMyAllyTeamID
local spWarpMouse = Spring.WarpMouse

local glText = gl.Text
local glRect = gl.Rect

local PAN_SPEED = 1400
local FAST_PAN_MULTIPLIER = 2.75
local FAST_ZOOM_MULTIPLIER = 3.0
local ZOOM_SPEED = 3200
local ZOOM_SCALE_SPEED = 0.9
local ROTATION_SPEED = 3.0
local PITCH_SPEED = 3.0
local MIN_SPRING_DISTANCE = 20
local MIN_OVERHEAD_HEIGHT = 60
local MIN_CAMERA_HEIGHT = 80
local MIN_CAMERA_RX = 1.0
local MAX_CAMERA_RX = 3.05
local MAX_DIRECTION_PITCH_Y = 0.98
local DEBUG_PANEL_MARGIN = 10
local DEBUG_PANEL_PADDING = 8
local DEBUG_PANEL_HEADER_HEIGHT = 22
local DEBUG_PANEL_RESIZE_HANDLE = 14
local DEBUG_PANEL_MIN_WIDTH = 280
local DEBUG_PANEL_MIN_HEIGHT = 118
local DEBUG_PANEL_DEFAULT_WIDTH = 650
local DEBUG_PANEL_DEFAULT_HEIGHT = 150

function ControllerCameraTestGetDefaultSettings()
	return {
		panSpeed = PAN_SPEED,
		fastPanMultiplier = FAST_PAN_MULTIPLIER,
		zoomSpeed = ZOOM_SPEED,
		zoomBoostMultiplier = FAST_ZOOM_MULTIPLIER,
		rotationSpeed = ROTATION_SPEED,
		pitchSpeed = PITCH_SPEED,
		stickDeadzone = 3000,
		triggerDeadzone = 3000,
		areaSelectRadius = 320,
		reticleSize = 16,
		xHoldSeconds = 0.14,
		aHoldSeconds = 0.38,
		controlGroupAssignHoldSeconds = 0.35,
		radialScale = 1,
		cameraSmoothing = 0.06,
		stickCurve = 1.175,
		triggerCurve = 1.075,
		singlePathSpacing = 96,
		singlePathInterval = 0.10,
		compactSelectedStatus = true,
		hideCompactStatusWhenRadialOpen = true,
		placementPopupEnabled = true,
		preferNativeBlueprint = true,
		debugPanelVisible = true,
		helpOverlayVisible = false,
	}
end

ControllerCameraTestSettings = ControllerCameraTestSettings or ControllerCameraTestGetDefaultSettings()
ControllerCameraTestTuning = ControllerCameraTestTuning or {
	selectedIndex = 1,
	backHeld = false,
	backComboUsed = false,
	lastAction = "none",
}
ControllerCameraTestSettingsUI = ControllerCameraTestSettingsUI or {
	open = false,
	categoryIndex = 1,
	selectedIndex = 1,
	lastAction = "none",
	lastCategory = "Camera",
}
ControllerCameraTestKeyDebug = ControllerCameraTestKeyDebug or {
	rawKey = "none",
	label = "none",
	matchedAction = "none",
	lastUIToggle = "none",
}
ControllerCameraTestBindings = ControllerCameraTestBindings or {
	actions = {},
	captureAction = nil,
	conflictAction = nil,
	lastAction = "defaults active",
	triggerDown = { LT = false, RT = false },
	triggerPressed = { LT = false, RT = false },
	triggerReleased = { LT = false, RT = false },
}
ControllerCameraTestQuickGroups = ControllerCameraTestQuickGroups or {
	slots = {},
	lastResult = "none",
	lastSlot = "none",
	currentSlot = 1,
}

function ControllerCameraTestClampSetting(name, value)
	value = tonumber(value)
	if not value then
		return ControllerCameraTestSettings[name]
	end
	local ranges = {
		panSpeed = { 500, 8000 },
		fastPanMultiplier = { 1, 6 },
		zoomSpeed = { 400, 9000 },
		zoomBoostMultiplier = { 1, 6 },
		rotationSpeed = { 0.5, 8 },
		pitchSpeed = { 0.5, 8 },
		stickDeadzone = { 0, 12000 },
		triggerDeadzone = { 0, 12000 },
		areaSelectRadius = { 120, 1200 },
		reticleSize = { 8, 36 },
		xHoldSeconds = { 0.08, 0.5 },
		aHoldSeconds = { 0.2, 0.8 },
		controlGroupAssignHoldSeconds = { 0.2, 0.8 },
		radialScale = { 0.75, 1.5 },
		cameraSmoothing = { 0.02, 0.4 },
		stickCurve = { 1, 2.2 },
		triggerCurve = { 1, 2.2 },
		singlePathSpacing = { 40, 240 },
		singlePathInterval = { 0.04, 0.3 },
	}
	local range = ranges[name]
	if not range then
		return value
	end
	return math.max(range[1], math.min(range[2], value))
end

function ControllerCameraTestApplySettingsDefaults()
	local settings = ControllerCameraTestSettings
	local defaults = ControllerCameraTestGetDefaultSettings()
	for key, value in pairs(defaults) do
		if settings[key] == nil then
			settings[key] = value
		end
	end
	settings.panSpeed = ControllerCameraTestClampSetting("panSpeed", settings.panSpeed or defaults.panSpeed)
	settings.fastPanMultiplier = ControllerCameraTestClampSetting("fastPanMultiplier", settings.fastPanMultiplier or FAST_PAN_MULTIPLIER)
	settings.zoomSpeed = ControllerCameraTestClampSetting("zoomSpeed", settings.zoomSpeed or ZOOM_SPEED)
	settings.zoomBoostMultiplier = ControllerCameraTestClampSetting("zoomBoostMultiplier", settings.zoomBoostMultiplier or FAST_ZOOM_MULTIPLIER)
	settings.rotationSpeed = ControllerCameraTestClampSetting("rotationSpeed", settings.rotationSpeed or ROTATION_SPEED)
	settings.pitchSpeed = ControllerCameraTestClampSetting("pitchSpeed", settings.pitchSpeed or PITCH_SPEED)
	settings.stickDeadzone = ControllerCameraTestClampSetting("stickDeadzone", settings.stickDeadzone or 3000)
	settings.triggerDeadzone = ControllerCameraTestClampSetting("triggerDeadzone", settings.triggerDeadzone or 3000)
	settings.areaSelectRadius = ControllerCameraTestClampSetting("areaSelectRadius", settings.areaSelectRadius or 320)
	settings.reticleSize = ControllerCameraTestClampSetting("reticleSize", settings.reticleSize or 16)
	settings.xHoldSeconds = ControllerCameraTestClampSetting("xHoldSeconds", settings.xHoldSeconds or 0.14)
	settings.aHoldSeconds = ControllerCameraTestClampSetting("aHoldSeconds", settings.aHoldSeconds or 0.38)
	settings.controlGroupAssignHoldSeconds = ControllerCameraTestClampSetting("controlGroupAssignHoldSeconds", settings.controlGroupAssignHoldSeconds or 0.35)
	settings.radialScale = ControllerCameraTestClampSetting("radialScale", settings.radialScale or 1)
	settings.cameraSmoothing = ControllerCameraTestClampSetting("cameraSmoothing", settings.cameraSmoothing or defaults.cameraSmoothing)
	settings.stickCurve = ControllerCameraTestClampSetting("stickCurve", settings.stickCurve or defaults.stickCurve)
	settings.triggerCurve = ControllerCameraTestClampSetting("triggerCurve", settings.triggerCurve or defaults.triggerCurve)
	settings.singlePathSpacing = ControllerCameraTestClampSetting("singlePathSpacing", settings.singlePathSpacing or 96)
	settings.singlePathInterval = ControllerCameraTestClampSetting("singlePathInterval", settings.singlePathInterval or 0.10)
	settings.compactSelectedStatus = settings.compactSelectedStatus ~= false
	settings.hideCompactStatusWhenRadialOpen = settings.hideCompactStatusWhenRadialOpen ~= false
	settings.placementPopupEnabled = settings.placementPopupEnabled ~= false
	settings.preferNativeBlueprint = settings.preferNativeBlueprint ~= false
	settings.debugPanelVisible = settings.debugPanelVisible ~= false
	settings.helpOverlayVisible = settings.helpOverlayVisible == true
	ControllerCameraTestAreaSelect.radius = settings.areaSelectRadius
end

function ControllerCameraTestSettingDefinitions()
	return {
		{ key = "panSpeed", label = "Pan speed", step = 100, decimals = 0 },
		{ key = "fastPanMultiplier", label = "LT pan boost", step = 0.25, decimals = 2 },
		{ key = "zoomSpeed", label = "Zoom speed", step = 100, decimals = 0 },
		{ key = "zoomBoostMultiplier", label = "LT zoom boost", step = 0.25, decimals = 2 },
		{ key = "rotationSpeed", label = "Rotate speed", step = 0.25, decimals = 2 },
		{ key = "pitchSpeed", label = "Pitch speed", step = 0.25, decimals = 2 },
		{ key = "stickDeadzone", label = "Stick deadzone", step = 500, decimals = 0 },
		{ key = "triggerDeadzone", label = "Trigger deadzone", step = 500, decimals = 0 },
		{ key = "areaSelectRadius", label = "Area radius", step = 40, decimals = 0 },
		{ key = "reticleSize", label = "Reticle size", step = 1, decimals = 0 },
		{ key = "xHoldSeconds", label = "X hold seconds", step = 0.02, decimals = 2 },
		{ key = "aHoldSeconds", label = "A hold seconds", step = 0.02, decimals = 2 },
		{ key = "controlGroupAssignHoldSeconds", label = "Group hold seconds", step = 0.02, decimals = 2 },
		{ key = "radialScale", label = "Radial scale", step = 0.05, decimals = 2 },
		{ key = "cameraSmoothing", label = "Camera smoothing", step = 0.01, decimals = 2 },
		{ key = "stickCurve", label = "Stick curve", step = 0.05, decimals = 2 },
		{ key = "triggerCurve", label = "Trigger curve", step = 0.05, decimals = 2 },
		{ key = "singlePathSpacing", label = "Path spacing", step = 8, decimals = 0 },
		{ key = "singlePathInterval", label = "Path interval", step = 0.01, decimals = 2 },
	}
end

function ControllerCameraTestCurrentSettingLabel()
	local defs = ControllerCameraTestSettingDefinitions()
	local index = ControllerCameraTestTuning.selectedIndex
	if index < 1 or index > #defs then
		ControllerCameraTestTuning.selectedIndex = 1
		index = 1
	end
	local def = defs[index]
	local value = ControllerCameraTestSettings[def.key]
	local format = def.decimals == 0 and "%s: %.0f" or "%s: %.2f"
	return string.format(format, def.label, tonumber(value) or 0)
end

function ControllerCameraTestCycleTuningSetting(delta)
	local defs = ControllerCameraTestSettingDefinitions()
	ControllerCameraTestTuning.selectedIndex = ((ControllerCameraTestTuning.selectedIndex - 1 + delta) % #defs) + 1
	ControllerCameraTestTuning.lastAction = "selected " .. ControllerCameraTestCurrentSettingLabel()
end

function ControllerCameraTestAdjustTuningSetting(delta)
	local defs = ControllerCameraTestSettingDefinitions()
	local def = defs[ControllerCameraTestTuning.selectedIndex] or defs[1]
	local settings = ControllerCameraTestSettings
	settings[def.key] = ControllerCameraTestClampSetting(def.key, (tonumber(settings[def.key]) or 0) + (def.step * delta))
	if def.key == "areaSelectRadius" then
		ControllerCameraTestAreaSelect.radius = settings.areaSelectRadius
	end
	ControllerCameraTestTuning.lastAction = "adjusted " .. ControllerCameraTestCurrentSettingLabel()
end

function ControllerCameraTestResetSettingsToDefaults()
	local settings = ControllerCameraTestSettings
	for key, value in pairs(ControllerCameraTestGetDefaultSettings()) do
		settings[key] = value
	end
	ControllerCameraTestApplySettingsDefaults()
	ControllerCameraTestTuning.lastAction = "controller settings reset to code defaults"
	ControllerCameraTestSettingsUI.lastAction = "all settings reset to code defaults"
	latchSelectionDebugMessage("Controller settings reset to code defaults")
end

ControllerCameraTestApplySettingsDefaults()


--------------------------------------------------------------------------------
-- SECTION: Input polling and button helpers
--------------------------------------------------------------------------------
local XboxController = {
	axes = {
		leftStickX = 0,
		leftStickY = 1,
		rightStickX = 2,
		rightStickY = 3,
		leftTrigger = 4,
		rightTrigger = 5,
	},
	axisLabels = {
		leftStickX = "Left Stick X",
		leftStickY = "Left Stick Y",
		rightStickX = "Right Stick X",
		rightStickY = "Right Stick Y",
		leftTrigger = "LT",
		rightTrigger = "RT",
	},
	axisOrder = {
		"leftStickX",
		"leftStickY",
		"rightStickX",
		"rightStickY",
		"leftTrigger",
		"rightTrigger",
	},
	buttons = {
		A = 0,
		a = 0,
		B = 1,
		b = 1,
		X = 2,
		x = 2,
		Y = 3,
		y = 3,
		back = 4,
		view = 4,
		["Back/View"] = 4,
		guide = 5,
		start = 6,
		menu = 6,
		["Start/Menu"] = 6,
		leftStick = 7,
		leftStickClick = 7,
		["Left Stick Click"] = 7,
		rightStick = 8,
		rightStickClick = 8,
		["Right Stick Click"] = 8,
		LB = 9,
		lb = 9,
		leftBumper = 9,
		RB = 10,
		rb = 10,
		rightBumper = 10,
		dpadUp = 11,
		["D-pad Up"] = 11,
		dpadDown = 12,
		["D-pad Down"] = 12,
		dpadLeft = 13,
		["D-pad Left"] = 13,
		dpadRight = 14,
		["D-pad Right"] = 14,
	},
	buttonLabels = {
		[0] = "A",
		[1] = "B",
		[2] = "X",
		[3] = "Y",
		[4] = "Back/View",
		[5] = "Guide",
		[6] = "Start/Menu",
		[7] = "Left Stick Click",
		[8] = "Right Stick Click",
		[9] = "LB",
		[10] = "RB",
		[11] = "D-pad Up",
		[12] = "D-pad Down",
		[13] = "D-pad Left",
		[14] = "D-pad Right",
	},
	buttonOrder = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 },
	commandLayerButtonOrder = { 0, 1, 2, 3, 9, 10, 11, 12, 13, 14 },
	previewButtonOrder = { 0, 1, 2, 3, 4, 6, 9, 10, 11, 12, 13, 14 },
	normalPreviewLabels = {
		[0] = "A = Select / hold area / double-tap same visible type",
		[1] = "B = Clear Selection",
		[2] = "X = Smart Action (Move/Build/Attack)",
		[3] = "Y = Controller Build Menu",
		[4] = "Back/View = Commander-focus modifier / reserved",
		[6] = "Start/Menu = Reserved",
		[9] = "LB = Camera pitch; LB+D-pad L/R idle type",
		[10] = "RB = Hold control-group mode",
		[11] = "D-pad Up = Camera bookmark Up",
		[12] = "D-pad Down = Camera bookmark Down",
		[13] = "D-pad Left = Previous idle unit",
		[14] = "D-pad Right = Next idle unit",
	},
	commandPreviewLabels = {
		[0] = "RT + A = Reserved / select-all disabled",
		[1] = "RT + B = Stop selected units",
		[2] = "RT + X = Attack / Attack-move",
		[3] = "RT + Y = Tactical command menu",
		[9] = "RT + LB = Previous selected unit/type",
		[10] = "RT + RB = Next selected unit/type",
		[11] = "RT + D-pad Up = Guard allied / Patrol ground",
		[12] = "RT + D-pad Down = Reclaim target/area",
		[13] = "RT + D-pad Left = Previous selection cycle",
		[14] = "RT + D-pad Right = Next selection cycle",
	},
	normalLayoutSummary = "A Select/Hold Area/Double Same-Type, B Clear, X Context, Y Build, D-pad L/R Idle, LB+D-pad Type, RB Groups",
	commandLayoutSummary = "RT+A Reserved, RT+B Stop, RT+X Attack, RT+Y Tactical, RT+LB/RB Cycle, RT+D-pad Commands",
}

apiAvailable = false
controllerName = "none"
controllerInstanceId = nil
normalizedLeftX = 0
normalizedLeftY = 0
normalizedRightX = 0
normalizedRightY = 0
normalizedLeftTrigger = 0
normalizedRightTrigger = 0
zoomSpeedMultiplier = 1
heldButtonsSummary = "none"
pressedThisFrameSummary = "none"
releasedThisFrameSummary = "none"
commandLayerPressedSummary = "none"
pressedRecentlySummary = "none"
releasedRecentlySummary = "none"
commandLayerPressedRecentlySummary = "none"
activeButtonLayoutSummary = XboxController.normalLayoutSummary
normalPreviewSummary = "none"
commandPreviewSummary = "none"
activeAxesSummary = "none"
panActive = false
zoomActive = false
rotationActive = false
pitchActive = false
fastPanActive = false
lbCameraModifierActive = false
commandLayerActive = false
rightStickYMode = "zoom"
cameraMode = "unknown"
cameraModeId = "?"
cameraFieldSummary = "camera state unavailable"
cameraPitchSummary = "pitch field unavailable"
zoomMethod = "none"
rotationMethod = "none"
pitchMethod = "none"
selectionTestActive = false
lastReticleSelectedUnitID = "none"
lastSelectionResult = "none"
lastBButtonResult = "none"
lastClearSelectionResult = "none"
selectionDebugMessage = "none"
selectionDebugExpiration = 0
controllerMode = false
reticleVisible = false
screenCenterX = 0
screenCenterY = 0
reticleTargetType = "unavailable"
reticleHasWorldTarget = false
reticleWorldX = nil
reticleWorldY = nil
reticleWorldZ = nil
reticleTargetAlignment = "none"
local viewSizeX = 0
local viewSizeY = 0
local lastMouseX = nil
local lastMouseY = nil
local lastMouseLeft = false
local lastMouseMiddle = false
local lastMouseRight = false
local mouseStateInitialized = false
local debugPanelX = DEBUG_PANEL_MARGIN
local debugPanelY = 0
local debugPanelWidth = DEBUG_PANEL_DEFAULT_WIDTH
local debugPanelHeight = DEBUG_PANEL_DEFAULT_HEIGHT
local debugPanelInitialized = false
local debugPanelDragging = false
local debugPanelResizing = false
local debugPanelDragOffsetX = 0
local debugPanelDragOffsetY = 0
local debugPanelResizeStartMouseX = 0
local debugPanelResizeStartMouseY = 0
local debugPanelResizeStartY = 0
local debugPanelResizeStartWidth = 0
local debugPanelResizeStartHeight = 0

local mapSizeX = Game and Game.mapSizeX or 0
local mapSizeZ = Game and Game.mapSizeZ or 0
local maxCameraDistance = math.max(mapSizeX, mapSizeZ, 1000) * 1.5

local previousButtonStates = {}
local currentButtonStates = {}
local pressedButtonStates = {}
local releasedButtonStates = {}
local debugEventTime = 0
local pressedRecentlyExpirations = {}
local releasedRecentlyExpirations = {}
local commandLayerPressedRecentlyExpirations = {}
local normalPreviewExpiration = 0
local commandPreviewExpiration = 0

local function clearButtonStateTracking()
	previousButtonStates = {}
	currentButtonStates = {}
	pressedButtonStates = {}
	releasedButtonStates = {}
end

local function clearDebugEventLatches()
	pressedRecentlyExpirations = {}
	releasedRecentlyExpirations = {}
	commandLayerPressedRecentlyExpirations = {}
	pressedRecentlySummary = "none"
	releasedRecentlySummary = "none"
	commandLayerPressedRecentlySummary = "none"
	normalPreviewExpiration = 0
	commandPreviewExpiration = 0
	normalPreviewSummary = "none"
	commandPreviewSummary = "none"
	selectionDebugMessage = "none"
	selectionDebugExpiration = 0
end

local resetReticleWorldTarget

local function resetControllerInputDebug()
	normalizedLeftX = 0
	normalizedLeftY = 0
	normalizedRightX = 0
	normalizedRightY = 0
	normalizedLeftTrigger = 0
	normalizedRightTrigger = 0
	zoomSpeedMultiplier = 1
	heldButtonsSummary = "none"
	pressedThisFrameSummary = "none"
	releasedThisFrameSummary = "none"
	commandLayerPressedSummary = "none"
	pressedRecentlySummary = "none"
	releasedRecentlySummary = "none"
	commandLayerPressedRecentlySummary = "none"
	activeButtonLayoutSummary = XboxController.normalLayoutSummary
	normalPreviewSummary = "none"
	commandPreviewSummary = "none"
	activeAxesSummary = "none"
	panActive = false
	zoomActive = false
	rotationActive = false
	pitchActive = false
	fastPanActive = false
	lbCameraModifierActive = false
	commandLayerActive = false
	rightStickYMode = "zoom"
	cameraPitchSummary = "pitch field unavailable"
	zoomMethod = "none"
	rotationMethod = "none"
	pitchMethod = "none"
	selectionTestActive = false
	lastBButtonResult = "none"
	lastClearSelectionResult = "none"
	lastIssuedCommand = "none"
	ControllerCameraTestBuildPlacement.active = false
	ControllerCameraTestBuildPlacement.queueActive = false
	ControllerCameraTestAreaSelect.pressActive = false
	ControllerCameraTestAreaSelect.active = false
	ControllerCameraTestTacticalMenu.open = false
	ControllerCameraTestLayerDebug.modeSummary = "normal"
	ControllerCameraTestLayerDebug.areaSelect = "inactive"
	ControllerCameraTestCommandDebug.issuedCmdID = "none"
	ControllerCameraTestCommandDebug.issuedParamsCount = 0
	ControllerCameraTestCommandDebug.lastResult = "none"
	ControllerCameraTestCommandDebug.mexSmartAvailable = "no"
	ControllerCameraTestCommandDebug.mexNearestSpot = "no"
	ControllerCameraTestCommandDebug.mexBuildingCmdID = "none"
	ControllerCameraTestCommandDebug.mexActionResult = "none"
	ControllerCameraTestCommandDebug.mexApplyPreviewPath = "no"
	ControllerCameraTestCommandDebug.mexFallbackGiveOrderPath = "no"
	clearButtonStateTracking()
	clearDebugEventLatches()
	resetReticleWorldTarget()
end

local function updateScreenCenter(vsx, vsy)
	viewSizeX = tonumber(vsx) or viewSizeX
	viewSizeY = tonumber(vsy) or viewSizeY
	screenCenterX = viewSizeX * 0.5
	screenCenterY = viewSizeY * 0.5
end

function resetReticleWorldTarget()
	reticleTargetType = "unavailable"
	reticleHasWorldTarget = false
	reticleWorldX = nil
	reticleWorldY = nil
	reticleWorldZ = nil
	reticleTargetAlignment = "none"
end

local function setControllerMode(active)
	controllerMode = active == true
	reticleVisible = controllerMode
	if not reticleVisible then
		resetReticleWorldTarget()
	end
end

local function noteControllerInput()
	setControllerMode(true)
end

local function noteMouseInput()
	setControllerMode(false)
end

local function clamp(value, minValue, maxValue)
	local mathMin, mathMax = math.min, math.max
	return mathMin(maxValue, mathMax(minValue, value))
end

local function formatNumber(value)
	if type(value) ~= "number" then
		return "-"
	end

	return string.format("%.1f", value)
end

local function normalizeAxis(value)
	local AXIS_MAX = 32767
	local mathAbs = math.abs
	value = tonumber(value) or 0

	local magnitude = mathAbs(value)
	local deadzone = tonumber(ControllerCameraTestSettings.stickDeadzone) or 3000
	if magnitude < deadzone then
		return 0
	end

	local sign = value < 0 and -1 or 1
	local normalized = (magnitude - deadzone) / (AXIS_MAX - deadzone)
	return sign * clamp(normalized, 0, 1)
end

local function normalizeTrigger(value)
	local AXIS_MAX = 32767
	value = tonumber(value) or 0

	local deadzone = tonumber(ControllerCameraTestSettings.triggerDeadzone) or 3000
	if value < deadzone then
		return 0
	end

	return clamp((value - deadzone) / (AXIS_MAX - deadzone), 0, 1)
end

local function getDebugPanelScreenSize()
	return viewSizeX > 0 and viewSizeX or 1280, viewSizeY > 0 and viewSizeY or 720
end

local function clampDebugPanelToScreen()
	local mathMax = math.max
	local screenWidth, screenHeight = getDebugPanelScreenSize()
	local maxWidth = mathMax(DEBUG_PANEL_MIN_WIDTH, screenWidth - (DEBUG_PANEL_MARGIN * 2))
	local maxHeight = mathMax(DEBUG_PANEL_MIN_HEIGHT, screenHeight - (DEBUG_PANEL_MARGIN * 2))

	debugPanelWidth = clamp(debugPanelWidth, DEBUG_PANEL_MIN_WIDTH, maxWidth)
	debugPanelHeight = clamp(debugPanelHeight, DEBUG_PANEL_MIN_HEIGHT, maxHeight)
	debugPanelX = clamp(debugPanelX, DEBUG_PANEL_MARGIN, mathMax(DEBUG_PANEL_MARGIN, screenWidth - DEBUG_PANEL_MARGIN - debugPanelWidth))
	debugPanelY = clamp(debugPanelY, DEBUG_PANEL_MARGIN, mathMax(DEBUG_PANEL_MARGIN, screenHeight - DEBUG_PANEL_MARGIN - debugPanelHeight))
end

local function resetDebugPanelToDefault()
	local mathMin, mathMax = math.min, math.max
	local screenWidth, screenHeight = getDebugPanelScreenSize()
	debugPanelWidth = mathMin(DEBUG_PANEL_DEFAULT_WIDTH, mathMax(DEBUG_PANEL_MIN_WIDTH, screenWidth - (DEBUG_PANEL_MARGIN * 2)))
	debugPanelHeight = mathMin(DEBUG_PANEL_DEFAULT_HEIGHT, mathMax(DEBUG_PANEL_MIN_HEIGHT, screenHeight - (DEBUG_PANEL_MARGIN * 2)))
	debugPanelX = DEBUG_PANEL_MARGIN
	debugPanelY = screenHeight - DEBUG_PANEL_MARGIN - debugPanelHeight
	debugPanelInitialized = true
	clampDebugPanelToScreen()
end

local function ensureDebugPanelInitialized()
	if not debugPanelInitialized then
		resetDebugPanelToDefault()
	else
		clampDebugPanelToScreen()
	end
end

local function isPointInDebugPanel(x, y)
	ensureDebugPanelInitialized()
	local height = ControllerCameraTestDebugCompact and 120 or debugPanelHeight
	return x >= debugPanelX
		and x <= debugPanelX + debugPanelWidth
		and y >= debugPanelY
		and y <= debugPanelY + height
end

local function isPointInDebugPanelHeader(x, y)
	local height = ControllerCameraTestDebugCompact and 120 or debugPanelHeight
	return isPointInDebugPanel(x, y)
		and y >= debugPanelY + height - DEBUG_PANEL_HEADER_HEIGHT
end

local function isPointInDebugPanelResizeHandle(x, y)
	if ControllerCameraTestDebugCompact then
		return false
	end
	return isPointInDebugPanel(x, y)
		and x >= debugPanelX + debugPanelWidth - DEBUG_PANEL_RESIZE_HANDLE
		and y <= debugPanelY + DEBUG_PANEL_RESIZE_HANDLE
end

local function updateDebugPanelDrag(x, y)
	debugPanelX = x - debugPanelDragOffsetX
	debugPanelY = y - debugPanelDragOffsetY
	clampDebugPanelToScreen()
end

local function updateDebugPanelResize(x, y)
	local mathMax = math.max
	local top = debugPanelResizeStartY + debugPanelResizeStartHeight
	local screenWidth = getDebugPanelScreenSize()
	local maxWidth = mathMax(DEBUG_PANEL_MIN_WIDTH, screenWidth - DEBUG_PANEL_MARGIN - debugPanelX)
	local maxHeight = mathMax(DEBUG_PANEL_MIN_HEIGHT, top - DEBUG_PANEL_MARGIN)
	debugPanelWidth = clamp(debugPanelResizeStartWidth + (x - debugPanelResizeStartMouseX), DEBUG_PANEL_MIN_WIDTH, maxWidth)
	debugPanelHeight = clamp(debugPanelResizeStartHeight - (y - debugPanelResizeStartMouseY), DEBUG_PANEL_MIN_HEIGHT, maxHeight)
	debugPanelY = top - debugPanelHeight
	clampDebugPanelToScreen()
end

local function GetAxis(state, axisId)
	if type(state) ~= "table" or type(state.axes) ~= "table" then
		return 0
	end

	return tonumber(state.axes[axisId]) or 0
end

local function GetButton(state, buttonId)
	if type(state) ~= "table" or type(state.buttons) ~= "table" then
		return false
	end

	local value = state.buttons[buttonId]
	if type(value) == "boolean" then
		return value
	end

	return (tonumber(value) or 0) ~= 0
end

local function GetNamedAxis(state, axisName)
	local axisId = XboxController.axes[axisName]
	if axisId == nil then
		return 0
	end

	return GetAxis(state, axisId)
end

local function GetNamedButton(state, buttonName)
	local buttonId = XboxController.buttons[buttonName]
	if buttonId == nil then
		return false
	end

	return GetButton(state, buttonId)
end

local function IsButtonDown(buttonName)
	local buttonId = XboxController.buttons[buttonName]
	return buttonId ~= nil and currentButtonStates[buttonId] == true
end

local function WasButtonPressed(buttonName)
	local buttonId = XboxController.buttons[buttonName]
	return buttonId ~= nil and pressedButtonStates[buttonId] == true
end

local function WasButtonReleased(buttonName)
	local buttonId = XboxController.buttons[buttonName]
	return buttonId ~= nil and releasedButtonStates[buttonId] == true
end

local function updateButtonStates(state)
	for _, buttonId in ipairs(XboxController.buttonOrder) do
		local isDown = GetButton(state, buttonId)
		local wasDown = currentButtonStates[buttonId] == true

		previousButtonStates[buttonId] = wasDown
		currentButtonStates[buttonId] = isDown
		pressedButtonStates[buttonId] = isDown and not wasDown
		releasedButtonStates[buttonId] = wasDown and not isDown
	end
end

local function getButtonLabel(buttonId)
	return XboxController.buttonLabels[buttonId] or tostring(buttonId)
end

local function getButtonStateSummary(buttonStates, buttonOrder)
	local buttons = {}

	for _, buttonId in ipairs(buttonOrder or XboxController.buttonOrder) do
		if buttonStates[buttonId] then
			buttons[#buttons + 1] = getButtonLabel(buttonId)
		end
	end

	if #buttons == 0 then
		return "none"
	end

	return table.concat(buttons, ", ")
end

local function hasButtonState(buttonStates, buttonOrder)
	for _, buttonId in ipairs(buttonOrder or XboxController.buttonOrder) do
		if buttonStates[buttonId] then
			return true
		end
	end

	return false
end

local function latchDebugButtonEvents(buttonStates, expirations, buttonOrder)
	local DEBUG_EVENT_HOLD_SECONDS = 0.45
	for _, buttonId in ipairs(buttonOrder or XboxController.buttonOrder) do
		if buttonStates[buttonId] then
			expirations[getButtonLabel(buttonId)] = debugEventTime + DEBUG_EVENT_HOLD_SECONDS
		end
	end
end

local function pruneDebugEventLatches(expirations)
	for buttonName, expirationTime in pairs(expirations) do
		if expirationTime <= debugEventTime then
			expirations[buttonName] = nil
		end
	end
end

local function getDebugLatchSummary(expirations, buttonOrder)
	local buttons = {}

	for _, buttonId in ipairs(buttonOrder or XboxController.buttonOrder) do
		local buttonName = getButtonLabel(buttonId)
		if expirations[buttonName] ~= nil then
			buttons[#buttons + 1] = buttonName
		end
	end

	if #buttons == 0 then
		return "none"
	end

	return table.concat(buttons, ", ")
end

local function updateDebugLatchSummaries()
	pruneDebugEventLatches(pressedRecentlyExpirations)
	pruneDebugEventLatches(releasedRecentlyExpirations)
	pruneDebugEventLatches(commandLayerPressedRecentlyExpirations)

	pressedRecentlySummary = getDebugLatchSummary(pressedRecentlyExpirations)
	releasedRecentlySummary = getDebugLatchSummary(releasedRecentlyExpirations)
	commandLayerPressedRecentlySummary = getDebugLatchSummary(commandLayerPressedRecentlyExpirations, XboxController.commandLayerButtonOrder)

	if normalPreviewExpiration <= debugEventTime then
		normalPreviewSummary = "none"
	end
	if commandPreviewExpiration <= debugEventTime then
		commandPreviewSummary = "none"
	end
	if selectionDebugExpiration <= debugEventTime then
		selectionDebugMessage = "none"
	end
end

local function getPreviewSummary(buttonStates, previewLabels)
	local previews = {}

	for _, buttonId in ipairs(XboxController.previewButtonOrder) do
		if buttonStates[buttonId] and previewLabels[buttonId] then
			previews[#previews + 1] = previewLabels[buttonId]
		end
	end

	if #previews == 0 then
		return nil
	end

	return table.concat(previews, "; ")
end

local function latchButtonPreview(buttonStates, previewLabels)
	local DEBUG_EVENT_HOLD_SECONDS = 0.45
	local preview = getPreviewSummary(buttonStates, previewLabels)
	if not preview then
		return nil
	end

	return preview, debugEventTime + DEBUG_EVENT_HOLD_SECONDS
end

local function getNormalizedDebugAxis(state, axisName)
	local value = GetNamedAxis(state, axisName)

	if axisName == "leftTrigger" or axisName == "rightTrigger" then
		return normalizeTrigger(value)
	end

	return normalizeAxis(value)
end

local function getActiveAxisSummary(state)
	local active = {}

	for _, axisName in ipairs(XboxController.axisOrder) do
		local value = getNormalizedDebugAxis(state, axisName)
		if value ~= 0 then
			active[#active + 1] = string.format(
				"%s=%.2f",
				XboxController.axisLabels[axisName] or axisName,
				value
			)
		end
	end

	if #active == 0 then
		return "none"
	end

	return table.concat(active, ", ")
end

local function getFirstController(controllers)
	if type(controllers) ~= "table" then
		return nil
	end

	if type(controllers[1]) == "table" then
		return controllers[1]
	end

	local _, controller = next(controllers)
	if type(controller) == "table" then
		return controller
	end

	return nil
end

local function normalizeHorizontalVector(vector)
	local mathSqrt = math.sqrt
	if type(vector) ~= "table" then
		return nil, nil
	end

	local x = tonumber(vector[1]) or 0
	local z = tonumber(vector[3]) or 0
	local length = mathSqrt((x * x) + (z * z))

	if length <= 0.001 then
		return nil, nil
	end

	return x / length, z / length
end

local function rotateVectorAroundAxis(x, y, z, axisX, axisY, axisZ, angle)
	local mathCos, mathSin = math.cos, math.sin
	local cosAmount = mathCos(angle)
	local sinAmount = mathSin(angle)
	local dot = (x * axisX) + (y * axisY) + (z * axisZ)
	local oneMinusCos = 1 - cosAmount

	return
		(x * cosAmount) + (((axisY * z) - (axisZ * y)) * sinAmount) + (axisX * dot * oneMinusCos),
		(y * cosAmount) + (((axisZ * x) - (axisX * z)) * sinAmount) + (axisY * dot * oneMinusCos),
		(z * cosAmount) + (((axisX * y) - (axisY * x)) * sinAmount) + (axisZ * dot * oneMinusCos)
end

local function normalizeDirectionWithClampedY(x, y, z)
	local mathSqrt, mathMax = math.sqrt, math.max
	y = clamp(y, -MAX_DIRECTION_PITCH_Y, MAX_DIRECTION_PITCH_Y)

	local horizontalLength = mathSqrt((x * x) + (z * z))
	if horizontalLength <= 0.001 then
		return x, y, z
	end

	local targetHorizontalLength = mathSqrt(mathMax(0, 1 - (y * y)))
	return
		(x / horizontalLength) * targetHorizontalLength,
		y,
		(z / horizontalLength) * targetHorizontalLength
end

local function getCameraPanDelta(leftX, leftY, distance)
	local cameraVectors = spGetCameraVectors and spGetCameraVectors()

	if type(cameraVectors) == "table" then
		local rightX, rightZ = normalizeHorizontalVector(cameraVectors.right)
		local forwardX, forwardZ = normalizeHorizontalVector(cameraVectors.forward)

		if rightX and forwardX then
			local forwardInput = -leftY
			return
				((leftX * rightX) + (forwardInput * forwardX)) * distance,
				((leftX * rightZ) + (forwardInput * forwardZ)) * distance
		end
	end

	return leftX * distance, leftY * distance
end

local function updateCameraDebug(cameraState)
	if type(cameraState) ~= "table" then
		cameraMode = "unknown"
		cameraModeId = "?"
		cameraFieldSummary = "camera state unavailable"
		cameraPitchSummary = "pitch field unavailable"
		return
	end

	cameraMode = tostring(cameraState.name or "unknown")
	cameraModeId = tostring(cameraState.mode or "?")
	cameraFieldSummary = string.format(
		"px=%s py=%s pz=%s dist=%s height=%s rx=%s ry=%s dx=%s dy=%s dz=%s fov=%s",
		formatNumber(cameraState.px),
		formatNumber(cameraState.py),
		formatNumber(cameraState.pz),
		formatNumber(cameraState.dist),
		formatNumber(cameraState.height),
		formatNumber(cameraState.rx),
		formatNumber(cameraState.ry),
		formatNumber(cameraState.dx),
		formatNumber(cameraState.dy),
		formatNumber(cameraState.dz),
		formatNumber(cameraState.fov)
	)

	if type(cameraState.rx) == "number" then
		cameraPitchSummary = "rx=" .. formatNumber(cameraState.rx)
	elseif type(cameraState.dy) == "number" then
		cameraPitchSummary = "dy=" .. formatNumber(cameraState.dy)
	else
		cameraPitchSummary = "pitch field unavailable"
	end
end

local function pollFirstController()
	local ok, controllers = pcall(spGetAvailableControllers)
	if not ok then
		controllerName = "GetAvailableControllers failed"
		controllerInstanceId = nil
		return nil
	end

	local controller = getFirstController(controllers)
	if not controller then
		controllerName = "none"
		controllerInstanceId = nil
		return nil
	end

	controllerName = tostring(controller.name or "unknown")
	controllerInstanceId = controller.instanceId
	return controller
end

local function pollControllerState(instanceId)
	if instanceId == nil then
		return nil
	end

	local ok, state = pcall(spGetControllerState, instanceId)
	if not ok or type(state) ~= "table" then
		return nil
	end

	return state
end

local function updateMouseInputMode()
	if type(spGetMouseState) ~= "function" then
		return
	end

	local mouseX, mouseY, leftButton, middleButton, rightButton = spGetMouseState()
	if mouseX == nil or mouseY == nil then
		return
	end

	leftButton = leftButton == true
	middleButton = middleButton == true
	rightButton = rightButton == true

	if controllerMode then
		if math.abs(mouseX - screenCenterX) > 5 or math.abs(mouseY - screenCenterY) > 5 then
			noteMouseInput()
		end
	else
		if mouseStateInitialized then
			if mouseX ~= lastMouseX
				or mouseY ~= lastMouseY
				or leftButton ~= lastMouseLeft
				or middleButton ~= lastMouseMiddle
				or rightButton ~= lastMouseRight
			then
				noteMouseInput()
			end
		else
			mouseStateInitialized = true
		end
	end

	lastMouseX = mouseX
	lastMouseY = mouseY
	lastMouseLeft = leftButton
	lastMouseMiddle = middleButton
	lastMouseRight = rightButton
end

--------------------------------------------------------------------------------
-- SECTION: Reticle/world target helpers
--------------------------------------------------------------------------------
local function updateReticleWorldTarget()
	if not reticleVisible or type(spTraceScreenRay) ~= "function" then
		resetReticleWorldTarget()
		return
	end

	-- 1. Standard trace to see what we are aiming at
	local okTarget, targetType, targetID = pcall(spTraceScreenRay, screenCenterX, screenCenterY)
	if okTarget then
		reticleTargetType = tostring(targetType or "unavailable")

		-- Check team alignment if it's a unit
		if reticleTargetType == "unit" and tonumber(targetID) then
			local unitID = tonumber(targetID)
			local myAllyTeam = (type(spGetMyAllyTeamID) == "function") and spGetMyAllyTeamID() or -1
			local unitAllyTeam = (type(spGetUnitAllyTeam) == "function") and spGetUnitAllyTeam(unitID) or -2

			if myAllyTeam == unitAllyTeam then
				reticleTargetAlignment = "ally"
			else
				reticleTargetAlignment = "enemy"
			end
		else
			reticleTargetAlignment = "none"
		end
	else
		reticleTargetType = "trace failed"
		reticleTargetAlignment = "none"
	end

	-- 2. Ground-only trace for movement coordinates
	local okGround, _, worldPosition = pcall(spTraceScreenRay, screenCenterX, screenCenterY, true)

	if okGround and type(worldPosition) == "table" then
		local worldX = tonumber(worldPosition[1])
		local worldY = tonumber(worldPosition[2])
		local worldZ = tonumber(worldPosition[3])

		if worldX and worldY and worldZ then
			reticleWorldX = worldX
			reticleWorldY = worldY
			reticleWorldZ = worldZ
			reticleHasWorldTarget = true
			return
		end
	end

	reticleWorldX = nil
	reticleWorldY = nil
	reticleWorldZ = nil
	reticleHasWorldTarget = false
end

local function latchSelectionDebugMessage(message)
	local SELECTION_DEBUG_HOLD_SECONDS = 1.2
	selectionDebugMessage = message
	selectionDebugExpiration = debugEventTime + SELECTION_DEBUG_HOLD_SECONDS
end

--------------------------------------------------------------------------------
-- SECTION: Selection and area select
--------------------------------------------------------------------------------
local function updateSelectionTestActive()
	selectionTestActive = controllerMode
		and reticleVisible
		and not commandLayerActive
		and not ControllerCameraTestBuildMenu.open
		and not ControllerCameraTestBuildPlacement.active
		and not ControllerCameraTestAreaSelect.active
		and type(spTraceScreenRay) == "function"
		and type(spSelectUnitArray) == "function"
end

local function attemptReticleSelection()
	if commandLayerActive then
		lastSelectionResult = "RT layer active"
		latchSelectionDebugMessage("A select skipped: RT command layer active")
		return
	end
	if not controllerMode or not reticleVisible then
		lastSelectionResult = "unavailable"
		latchSelectionDebugMessage("A select skipped: reticle inactive")
		return
	end
	if type(spTraceScreenRay) ~= "function" or type(spSelectUnitArray) ~= "function" then
		lastSelectionResult = "unavailable"
		latchSelectionDebugMessage("A select unavailable")
		return
	end

	local ok, targetType, targetID = pcall(spTraceScreenRay, screenCenterX, screenCenterY)
	if not ok then
		lastSelectionResult = "unavailable"
		latchSelectionDebugMessage("A select trace failed")
		return
	end

	if targetType ~= "unit" or tonumber(targetID) == nil then
		lastSelectionResult = "no unit"
		latchSelectionDebugMessage("A select: no unit under reticle")
		return
	end

	local unitID = tonumber(targetID)
	local selectOk = pcall(spSelectUnitArray, { unitID }, false)
	if not selectOk then
		lastSelectionResult = "unavailable"
		latchSelectionDebugMessage("A select failed")
		return
	end

	lastReticleSelectedUnitID = tostring(unitID)
	lastSelectionResult = "selected"
	latchSelectionDebugMessage("A selected unit " .. tostring(unitID))
end

local function attemptClearSelection()
	if commandLayerActive then
		lastBButtonResult = "RT active"
		latchSelectionDebugMessage("B ignored: RT command layer active")
		return
	end

	if type(spSelectUnitArray) ~= "function" then
		lastBButtonResult = "unavailable"
		lastClearSelectionResult = "failed"
		latchSelectionDebugMessage("B clear: select API unavailable")
		return
	end

	local selectOk = pcall(spSelectUnitArray, {})
	if selectOk then
		lastBButtonResult = "cleared"
		lastClearSelectionResult = "success"
		latchSelectionDebugMessage("B: selection cleared")
	else
		lastBButtonResult = "failed"
		lastClearSelectionResult = "failed"
		latchSelectionDebugMessage("B clear: API call failed")
	end
end

--------------------------------------------------------------------------------
-- SECTION: Binding system
--------------------------------------------------------------------------------
function ControllerCameraTestBindingDefinitions()
	return {
		{ action = "select", label = "Select / Area Select", default = "A", group = "Core" },
		{ action = "cancel", label = "Cancel / Clear", default = "B", group = "Core" },
		{ action = "smartAction", label = "Smart Action", default = "X", group = "Core" },
		{ action = "buildRadial", label = "Build / Factory Radial", default = "Y", group = "Core" },
		{ action = "commandLayer", label = "Command Layer", default = "RT", group = "Modifiers" },
		{ action = "queueModifier", label = "Queue Modifier", default = "LT", group = "Modifiers" },
		{ action = "controlGroupModifier", label = "Group Modifier", default = "RB", group = "Modifiers" },
		{ action = "pitchModifier", label = "Pitch / Idle Type Modifier", default = "LB", group = "Modifiers" },
		{ action = "radialSelect", label = "Radial Select", default = "A", group = "Radials" },
		{ action = "radialCancel", label = "Radial Cancel", default = "B", group = "Radials" },
		{ action = "radialQuick", label = "Radial Quick Place", default = "X", group = "Radials" },
		{ action = "radialClose", label = "Radial Close", default = "Y", group = "Radials" },
		{ action = "radialPrevPage", label = "Radial Previous Page", default = "LB", group = "Radials" },
		{ action = "radialNextPage", label = "Radial Next Page", default = "RB", group = "Radials" },
		{ action = "place", label = "Place / Confirm", default = "A", group = "Placement" },
		{ action = "placeStay", label = "Place and Stay", default = "X", group = "Placement" },
		{ action = "cancelPlacement", label = "Cancel Placement", default = "B", group = "Placement" },
		{ action = "rotateBuildingLeft", label = "Rotate Building Left", default = "dpadLeft", group = "Placement" },
		{ action = "rotateBuildingRight", label = "Rotate Building Right", default = "dpadRight", group = "Placement" },
		{ action = "spacingUp", label = "Increase Spacing", default = "dpadUp", group = "Placement" },
		{ action = "spacingDown", label = "Decrease Spacing", default = "dpadDown", group = "Placement" },
		{ action = "patternPrev", label = "Previous Pattern", default = "LB", group = "Placement" },
		{ action = "patternNext", label = "Next Pattern", default = "RB", group = "Placement" },
		{ action = "tacticalSelect", label = "Tactical Select", default = "A", group = "Tactical" },
		{ action = "tacticalCancel", label = "Tactical Cancel", default = "B", group = "Tactical" },
		{ action = "tacticalClose", label = "Tactical Close", default = "Y", group = "Tactical" },
		{ action = "commandUp", label = "Command Guard / Patrol", default = "dpadUp", group = "Tactical" },
		{ action = "commandDown", label = "Command Reclaim", default = "dpadDown", group = "Tactical" },
		{ action = "commandLeft", label = "Command Cycle Previous", default = "dpadLeft", group = "Tactical" },
		{ action = "commandRight", label = "Command Cycle Next", default = "dpadRight", group = "Tactical" },
		{ action = "idlePrev", label = "Previous Idle Unit", default = "dpadLeft", group = "Idle / Groups" },
		{ action = "idleNext", label = "Next Idle Unit", default = "dpadRight", group = "Idle / Groups" },
		{ action = "groupSlotUp", label = "Next Group Slot", default = "dpadUp", group = "Idle / Groups" },
		{ action = "groupSlotDown", label = "Previous Group Slot", default = "dpadDown", group = "Idle / Groups" },
		{ action = "groupRecallOrAssign", label = "Recall / Assign Group", default = "dpadLeft", group = "Idle / Groups" },
		{ action = "groupClear", label = "Clear Group", default = "B", group = "Idle / Groups" },
	}
end

function ControllerCameraTestEnsureBindings()
	local bindings = ControllerCameraTestBindings
	bindings.defaults = bindings.defaults or {}
	bindings.actions = bindings.actions or {}
	for _, def in ipairs(ControllerCameraTestBindingDefinitions()) do
		bindings.defaults[def.action] = def.default
		if type(bindings.actions[def.action]) ~= "string" then
			bindings.actions[def.action] = def.default
		end
	end
end

function ControllerCameraTestGetBinding(actionName)
	ControllerCameraTestEnsureBindings()
	return ControllerCameraTestBindings.actions[actionName] or ControllerCameraTestBindings.defaults[actionName]
end

function ControllerCameraTestBindingLabel(buttonName)
	local labels = {
		back = "Back/View",
		start = "Start/Menu",
		dpadUp = "D-pad Up",
		dpadDown = "D-pad Down",
		dpadLeft = "D-pad Left",
		dpadRight = "D-pad Right",
	}
	return labels[buttonName] or tostring(buttonName or "Unbound")
end

function ControllerCameraTestSetBinding(actionName, buttonName)
	ControllerCameraTestEnsureBindings()
	local conflict = nil
	for otherAction, assigned in pairs(ControllerCameraTestBindings.actions) do
		if otherAction ~= actionName and assigned == buttonName then
			conflict = otherAction
			break
		end
	end
	ControllerCameraTestBindings.actions[actionName] = buttonName
	ControllerCameraTestBindings.conflictAction = conflict
	ControllerCameraTestBindings.lastAction = "bound " .. tostring(actionName) .. " to "
		.. ControllerCameraTestBindingLabel(buttonName)
		.. (conflict and ("; shared with " .. tostring(conflict)) or "")
	latchSelectionDebugMessage(ControllerCameraTestBindings.lastAction)
end

function ControllerCameraTestResetBinding(actionName)
	ControllerCameraTestEnsureBindings()
	ControllerCameraTestBindings.actions[actionName] = ControllerCameraTestBindings.defaults[actionName]
	ControllerCameraTestBindings.lastAction = "reset " .. tostring(actionName) .. " to "
		.. ControllerCameraTestBindingLabel(ControllerCameraTestBindings.actions[actionName])
	latchSelectionDebugMessage(ControllerCameraTestBindings.lastAction)
end

function ControllerCameraTestResetAllBindings()
	ControllerCameraTestEnsureBindings()
	for actionName, buttonName in pairs(ControllerCameraTestBindings.defaults) do
		ControllerCameraTestBindings.actions[actionName] = buttonName
	end
	ControllerCameraTestBindings.captureAction = nil
	ControllerCameraTestBindings.conflictAction = nil
	ControllerCameraTestBindings.lastAction = "all bindings reset to defaults"
	latchSelectionDebugMessage(ControllerCameraTestBindings.lastAction)
end

function ControllerCameraTestUpdateBindingTriggerEdges()
	local state = ControllerCameraTestBindings
	local nowLT = (normalizedLeftTrigger or 0) > 0.35
	local nowRT = (normalizedRightTrigger or 0) > 0.35
	state.triggerPressed.LT = nowLT and not state.triggerDown.LT
	state.triggerPressed.RT = nowRT and not state.triggerDown.RT
	state.triggerReleased.LT = state.triggerDown.LT and not nowLT
	state.triggerReleased.RT = state.triggerDown.RT and not nowRT
	state.triggerDown.LT = nowLT
	state.triggerDown.RT = nowRT
end

function ControllerCameraTestBindingDown(buttonName)
	if buttonName == "LT" or buttonName == "RT" then
		return ControllerCameraTestBindings.triggerDown[buttonName] == true
	end
	return IsButtonDown(buttonName)
end

function ControllerCameraTestBindingPressed(buttonName)
	if buttonName == "LT" or buttonName == "RT" then
		return ControllerCameraTestBindings.triggerPressed[buttonName] == true
	end
	return WasButtonPressed(buttonName)
end

function ControllerCameraTestBindingReleased(buttonName)
	if buttonName == "LT" or buttonName == "RT" then
		return ControllerCameraTestBindings.triggerReleased[buttonName] == true
	end
	return WasButtonReleased(buttonName)
end

function ControllerCameraTestActionDown(actionName)
	return ControllerCameraTestBindingDown(ControllerCameraTestGetBinding(actionName))
end

function ControllerCameraTestActionPressed(actionName)
	return ControllerCameraTestBindingPressed(ControllerCameraTestGetBinding(actionName))
end

function ControllerCameraTestActionReleased(actionName)
	return ControllerCameraTestBindingReleased(ControllerCameraTestGetBinding(actionName))
end

--------------------------------------------------------------------------------
-- SECTION: Settings UI
--------------------------------------------------------------------------------
function ControllerCameraTestGetSettingsUICategories()
	return {
		{ key = "Camera", items = {
			{ key = "panSpeed", label = "Pan speed", step = 50, decimals = 0 },
			{ key = "fastPanMultiplier", label = "LT pan boost", step = 0.25, decimals = 2 },
			{ key = "zoomSpeed", label = "Zoom speed", step = 100, decimals = 0 },
			{ key = "zoomBoostMultiplier", label = "LT zoom boost", step = 0.25, decimals = 2 },
			{ key = "rotationSpeed", label = "Rotation speed", step = 0.25, decimals = 2 },
			{ key = "pitchSpeed", label = "Pitch speed", step = 0.25, decimals = 2 },
			{ key = "cameraSmoothing", label = "Camera smoothing", step = 0.01, decimals = 2 },
			{ key = "stickCurve", label = "Stick curve", step = 0.025, decimals = 3 },
			{ key = "triggerCurve", label = "Trigger curve", step = 0.025, decimals = 3 },
		} },
		{ key = "Input", items = {
			{ key = "stickDeadzone", label = "Stick deadzone", step = 250, decimals = 0 },
			{ key = "triggerDeadzone", label = "Trigger deadzone", step = 250, decimals = 0 },
			{ key = "xHoldSeconds", label = "X hold seconds", step = 0.01, decimals = 2 },
			{ key = "aHoldSeconds", label = "A hold seconds", step = 0.01, decimals = 2 },
			{ key = "controlGroupAssignHoldSeconds", label = "Group assign hold", step = 0.01, decimals = 2 },
			{ key = "singlePathSpacing", label = "Path waypoint spacing", step = 8, decimals = 0 },
			{ key = "singlePathInterval", label = "Path issue interval", step = 0.01, decimals = 2 },
		} },
		{ key = "Radials", items = {
			{ key = "radialScale", label = "Radial scale", step = 0.05, decimals = 2 },
			{ key = "compactSelectedStatus", label = "Compact status panel", type = "bool" },
			{ key = "hideCompactStatusWhenRadialOpen", label = "Hide status with radial", type = "bool" },
		} },
		{ key = "Selection", items = {
			{ key = "areaSelectRadius", label = "Area select radius", step = 40, decimals = 0 },
		} },
		{ key = "Placement", items = {
			{ key = "placementPopupEnabled", label = "Placement popup", type = "bool" },
			{ key = "preferNativeBlueprint", label = "Prefer native blueprint", type = "bool" },
		} },
		{ key = "UI", items = {
			{ key = "reticleSize", label = "Reticle size", step = 1, decimals = 0 },
			{ key = "debugPanelVisible", label = "Debug panel visible", type = "bool" },
			{ key = "helpOverlayVisible", label = "Help overlay visible", type = "bool" },
		} },
		{ key = "Bindings", bindings = true, items = ControllerCameraTestBindingDefinitions() },
	}
end

function ControllerCameraTestGetSettingsUICategory()
	local ui = ControllerCameraTestSettingsUI
	local categories = ControllerCameraTestGetSettingsUICategories()
	ui.categoryIndex = math.max(1, math.min(#categories, tonumber(ui.categoryIndex) or 1))
	local category = categories[ui.categoryIndex]
	ui.selectedIndex = math.max(1, math.min(#category.items, tonumber(ui.selectedIndex) or 1))
	ui.lastCategory = category.key
	return category
end

function ControllerCameraTestToggleSettingsUI(forceOpen)
	local ui = ControllerCameraTestSettingsUI
	ui.open = forceOpen == nil and not ui.open or forceOpen
	ui.bindingCaptureAction = nil
	ControllerCameraTestBindings.captureAction = nil
	ui.lastAction = ui.open and "settings opened" or "settings closed"
	if ui.open then
		ControllerCameraTestEnsureBindings()
		ControllerCameraTestCycleDebug.lbPressActive = false
		ControllerCameraTestCycleDebug.lbHadPitchMotion = false
		ControllerCameraTestControlGroups.leftPressActive = false
		if ControllerCameraTestDragCommand.active then
			ControllerCameraTestCancelDrag("cancelled by settings")
		end
		if ControllerCameraTestAreaSelect.pressActive or ControllerCameraTestAreaSelect.active then
			ControllerCameraTestCancelAreaSelect("cancelled by settings")
		end
	end
	latchSelectionDebugMessage(ui.lastAction)
end

function ControllerCameraTestAdjustSettingFromUI(settingKey, delta, step)
	local current = ControllerCameraTestSettings[settingKey]
	if type(current) == "boolean" then
		ControllerCameraTestSettings[settingKey] = not current
	else
		ControllerCameraTestSettings[settingKey] = ControllerCameraTestClampSetting(settingKey, (tonumber(current) or 0) + ((step or 1) * delta))
	end
	ControllerCameraTestApplySettingsDefaults()
	ControllerCameraTestSettingsUI.lastAction = "changed " .. tostring(settingKey)
end

function ControllerCameraTestResetSettingToDefault(settingKey)
	local defaults = ControllerCameraTestGetDefaultSettings()
	if defaults[settingKey] ~= nil then
		ControllerCameraTestSettings[settingKey] = defaults[settingKey]
		ControllerCameraTestApplySettingsDefaults()
		ControllerCameraTestSettingsUI.lastAction = "reset " .. tostring(settingKey)
	end
end

function ControllerCameraTestResetSettingsCategory(category)
	if category.bindings then
		ControllerCameraTestResetAllBindings()
	else
		for _, item in ipairs(category.items) do
			ControllerCameraTestResetSettingToDefault(item.key)
		end
	end
	ControllerCameraTestSettingsUI.lastAction = "reset " .. tostring(category.key)
end

function ControllerCameraTestGetPressedBindingInput()
	for _, buttonName in ipairs({ "A", "X", "Y", "back", "start", "LB", "RB", "dpadUp", "dpadDown", "dpadLeft", "dpadRight" }) do
		if WasButtonPressed(buttonName) then
			return buttonName
		end
	end
	if ControllerCameraTestBindings.triggerPressed.LT then return "LT" end
	if ControllerCameraTestBindings.triggerPressed.RT then return "RT" end
	return nil
end

function ControllerCameraTestHandleSettingsUIInput()
	local ui = ControllerCameraTestSettingsUI
	if not ui.open then
		return false
	end
	local category = ControllerCameraTestGetSettingsUICategory()
	if ControllerCameraTestBindings.captureAction then
		if WasButtonPressed("B") then
			ControllerCameraTestBindings.captureAction = nil
			ui.lastAction = "binding capture cancelled"
		else
			local captured = ControllerCameraTestGetPressedBindingInput()
			if captured then
				ControllerCameraTestSetBinding(ControllerCameraTestBindings.captureAction, captured)
				ControllerCameraTestBindings.captureAction = nil
				ui.lastAction = ControllerCameraTestBindings.lastAction
			end
		end
		return true
	end
	if WasButtonPressed("B") then
		ControllerCameraTestToggleSettingsUI(false)
	elseif WasButtonPressed("LB") then
		ui.categoryIndex = ((ui.categoryIndex - 2) % #ControllerCameraTestGetSettingsUICategories()) + 1
		ui.selectedIndex = 1
	elseif WasButtonPressed("RB") then
		ui.categoryIndex = (ui.categoryIndex % #ControllerCameraTestGetSettingsUICategories()) + 1
		ui.selectedIndex = 1
	elseif WasButtonPressed("dpadUp") then
		ui.selectedIndex = ((ui.selectedIndex - 2) % #category.items) + 1
	elseif WasButtonPressed("dpadDown") then
		ui.selectedIndex = (ui.selectedIndex % #category.items) + 1
	elseif WasButtonPressed("dpadLeft") and not category.bindings then
		local item = category.items[ui.selectedIndex]
		ControllerCameraTestAdjustSettingFromUI(item.key, -1, item.step)
	elseif WasButtonPressed("dpadRight") and not category.bindings then
		local item = category.items[ui.selectedIndex]
		ControllerCameraTestAdjustSettingFromUI(item.key, 1, item.step)
	elseif WasButtonPressed("A") then
		local item = category.items[ui.selectedIndex]
		if category.bindings then
			ControllerCameraTestBindings.captureAction = item.action
			ui.lastAction = "press a controller input for " .. tostring(item.label)
		elseif item.type == "bool" then
			ControllerCameraTestAdjustSettingFromUI(item.key, 1, 1)
		end
	elseif WasButtonPressed("X") then
		local item = category.items[ui.selectedIndex]
		if category.bindings then
			ControllerCameraTestResetBinding(item.action)
		else
			ControllerCameraTestResetSettingToDefault(item.key)
		end
	elseif WasButtonPressed("Y") then
		ControllerCameraTestResetSettingsCategory(category)
	end
	return true
end

--------------------------------------------------------------------------------
-- SECTION: Command issuing
--------------------------------------------------------------------------------
function ControllerCameraTestIsQueueModifierActive()
	return ControllerCameraTestActionDown("queueModifier")
end

function ControllerCameraTestGetCommandOptions(extraOptions)
	local opts = {}
	if ControllerCameraTestIsQueueModifierActive() then
		opts[#opts + 1] = "shift"
	end
	if type(extraOptions) == "table" then
		for _, opt in ipairs(extraOptions) do
			opts[#opts + 1] = opt
		end
	end
	return opts
end

function ControllerCameraTestCommandOptionsSummary(options)
	if type(options) ~= "table" or #options == 0 then
		return "none"
	end
	return table.concat(options, ",")
end

local function issueOrderToSelection(cmdID, params, cmdName, targetName, options)
	-- 1. Check if we actually have units selected
	local selectedUnits = type(Spring.GetSelectedUnits) == "function" and Spring.GetSelectedUnits() or {}
	local paramsCount = type(params) == "table" and #params or 0
	local orderOptions = type(options) == "table" and options or ControllerCameraTestGetCommandOptions()
	ControllerCameraTestCommandDebug.issuedCmdID = tostring(cmdID)
	ControllerCameraTestCommandDebug.issuedParamsCount = paramsCount
	ControllerCameraTestCommandDebug.lastOptions = ControllerCameraTestCommandOptionsSummary(orderOptions)
	if #selectedUnits == 0 then
		lastIssuedCommand = "none"
		ControllerCameraTestCommandDebug.lastResult = "no selected units"
		latchSelectionDebugMessage(tostring(cmdName) .. " skipped: no units selected")
		return
	end

	-- 2. Use the universally safe LuaUI GiveOrder API
	if type(Spring.GiveOrder) == "function" then
		local orderOk, orderResult = pcall(Spring.GiveOrder, cmdID, params, orderOptions)
		if not orderOk or orderResult == false then
			lastIssuedCommand = "none"
			ControllerCameraTestCommandDebug.lastResult = "GiveOrder failed"
			latchSelectionDebugMessage("Command failed: GiveOrder call failed")
			return
		end
		lastIssuedCommand = tostring(cmdName) .. " (" .. tostring(targetName) .. ")"
		ControllerCameraTestCommandDebug.lastResult = "issued via GiveOrder"
		latchSelectionDebugMessage(tostring(cmdName) .. " ordered to " .. #selectedUnits .. " units")
		if type(params) == "table" and type(params[1]) == "number" and type(params[2]) == "number" and type(params[3]) == "number" then
			ControllerCameraTestSetCommandMarker(params[1], params[2], params[3], cmdName)
		end
	else
		lastIssuedCommand = "none"
		ControllerCameraTestCommandDebug.lastResult = "GiveOrder unavailable"
		latchSelectionDebugMessage("Command failed: GiveOrder API unavailable")
	end
end

function ControllerCameraTestResetMexCommandDebug()
	ControllerCameraTestCommandDebug.mexSmartAvailable = "no"
	ControllerCameraTestCommandDebug.mexNearestSpot = "no"
	ControllerCameraTestCommandDebug.mexBuildingCmdID = "none"
	ControllerCameraTestCommandDebug.mexActionResult = "not attempted"
	ControllerCameraTestCommandDebug.mexApplyPreviewPath = "no"
	ControllerCameraTestCommandDebug.mexFallbackGiveOrderPath = "no"
end

function ControllerCameraTestAttemptMexBuildSmartAction(x, y, z, forceShift)
	ControllerCameraTestResetMexCommandDebug()

	local builder = WG and WG.resource_spot_builder
	local finder = WG and WG["resource_spot_finder"]
	if type(builder) ~= "table" or type(finder) ~= "table" then
		ControllerCameraTestCommandDebug.mexActionResult = "WG mex APIs unavailable"
		return false
	end
	if finder.isMetalMap then
		ControllerCameraTestCommandDebug.mexActionResult = "metal map disabled"
		return false
	end
	if type(builder.GetMexConstructors) ~= "function"
		or type(builder.GetMexBuildings) ~= "function"
		or type(builder.GetBestExtractorFromBuilders) ~= "function"
		or type(builder.PreviewExtractorCommand) ~= "function"
	then
		ControllerCameraTestCommandDebug.mexActionResult = "builder API incomplete"
		return false
	end
	if type(finder.GetClosestMexSpot) ~= "function" or type(finder.metalSpotsList) ~= "table" then
		ControllerCameraTestCommandDebug.mexActionResult = "finder API incomplete"
		return false
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		ControllerCameraTestCommandDebug.mexActionResult = "no selected units"
		return false
	end

	local mexConstructors = builder.GetMexConstructors()
	local mexBuildings = builder.GetMexBuildings()
	local selectedMex = builder.GetBestExtractorFromBuilders(selectedUnits, mexConstructors, mexBuildings)
	if not selectedMex then
		ControllerCameraTestCommandDebug.mexSmartAvailable = "no"
		ControllerCameraTestCommandDebug.mexActionResult = "selected units cannot build mex"
		return false
	end

	ControllerCameraTestCommandDebug.mexSmartAvailable = "yes"
	ControllerCameraTestCommandDebug.mexBuildingCmdID = tostring(-selectedMex)

	local nearestSpot = finder.GetClosestMexSpot(x, z)
	if not nearestSpot then
		ControllerCameraTestCommandDebug.mexActionResult = "no nearest spot"
		return false
	end
	ControllerCameraTestCommandDebug.mexNearestSpot = "yes"

	local controllerMexTriggerRadius = 80

local spotX = nearestSpot.x or nearestSpot[1]
local spotZ = nearestSpot.z or nearestSpot[3] or nearestSpot[2]

if not spotX or not spotZ then
	ControllerCameraTestCommandDebug.mexNearestSpot = "no"
	ControllerCameraTestCommandDebug.mexActionResult = "mex spot position unavailable, falling back to Move"
	return false
end

local dx = spotX - x
local dz = spotZ - z
local distSq = (dx * dx) + (dz * dz)
local maxDistSq = controllerMexTriggerRadius * controllerMexTriggerRadius

if distSq > maxDistSq then
	ControllerCameraTestCommandDebug.mexNearestSpot = "no"
	ControllerCameraTestCommandDebug.mexActionResult = string.format(
		"not close enough to metal spot %.0f > %d, falling back to Move",
		math.sqrt(distSq),
		controllerMexTriggerRadius
	)
	return false
end

	if type(builder.ExtractorCanBeBuiltOnSpot) == "function" and not builder.ExtractorCanBeBuiltOnSpot(nearestSpot, selectedMex) then
		ControllerCameraTestCommandDebug.mexActionResult = "spot unavailable"
		return false
	end

	local buildCmd = builder.PreviewExtractorCommand({ x, y, z }, selectedMex, nearestSpot)
	if not buildCmd or #buildCmd == 0 then
		ControllerCameraTestCommandDebug.mexActionResult = "preview failed"
		return false
	end

	local cmdID = -buildCmd[1]
	local params = { buildCmd[2], buildCmd[3], buildCmd[4], buildCmd[5] }
	ControllerCameraTestCommandDebug.issuedCmdID = tostring(cmdID)
	ControllerCameraTestCommandDebug.issuedParamsCount = #params
	ControllerCameraTestCommandDebug.lastOptions = forceShift and "shift" or "none"

	if type(builder.ApplyPreviewCmds) == "function" then
		local _, _, _, shift = Spring.GetModKeyState()
		shift = forceShift or shift
		local applyOk = pcall(builder.ApplyPreviewCmds, { buildCmd }, mexConstructors, shift)
		if applyOk then
			lastIssuedCommand = "Mex Build (" .. tostring(cmdID) .. ")"
			ControllerCameraTestCommandDebug.mexApplyPreviewPath = "yes"
			ControllerCameraTestCommandDebug.lastResult = "mex via ApplyPreviewCmds"
			ControllerCameraTestCommandDebug.mexActionResult = "issued via ApplyPreviewCmds"
			latchSelectionDebugMessage("X mex build: " .. tostring(cmdID))
			return true
		end
	end

	if type(spGiveOrderToUnit) ~= "function" then
		ControllerCameraTestCommandDebug.mexActionResult = "fallback GiveOrderToUnit unavailable"
		return false
	end

	local issuedCount = 0
	local orderOptions = forceShift and { "shift" } or {}
	for _, unitID in ipairs(selectedUnits) do
		if mexConstructors[unitID] then
			local orderOk = pcall(spGiveOrderToUnit, unitID, cmdID, params, orderOptions)
			if orderOk then
				issuedCount = issuedCount + 1
			end
		end
	end

	if issuedCount > 0 then
		lastIssuedCommand = "Mex Build (" .. tostring(cmdID) .. ")"
		ControllerCameraTestCommandDebug.mexFallbackGiveOrderPath = "yes"
		ControllerCameraTestCommandDebug.lastResult = "mex via GiveOrderToUnit"
		ControllerCameraTestCommandDebug.mexActionResult = "issued via GiveOrderToUnit"
		latchSelectionDebugMessage("X mex build fallback: " .. tostring(cmdID))
		return true
	end

	ControllerCameraTestCommandDebug.mexActionResult = "no selected mex constructors"
	return false
end

local function ControllerCameraTestIssueBuildOrders(builders, unitDefID, buildPositions, useQueue, useQueueFront)
	local cmdInsert = CMD.INSERT or 140
	local firstOpts = useQueue and { "shift" } or {}
	ControllerCameraTestCommandDebug.lastOptions = useQueueFront and "queue-front" or ControllerCameraTestCommandOptionsSummary(firstOpts)
	local restOpts = { "shift" }

	if useQueueFront then
		for i = #buildPositions, 1, -1 do
			local bp = buildPositions[i]
			local bx, by, bz, bfacing = bp[1], bp[2], bp[3], bp[4] or 0
			for _, unitID in ipairs(builders) do
				pcall(spGiveOrderToUnit, unitID, cmdInsert, { 0, -unitDefID, 0, bx, by, bz, bfacing }, { "alt" })
			end
		end
		return true
	end

	if type(Spring.GiveOrderArrayToUnitArray) == "function" then
		local orders = {}
		for i, bp in ipairs(buildPositions) do
			local bx, by, bz, bfacing = bp[1], bp[2], bp[3], bp[4] or 0
			local opts = (i == 1 and not useQueue) and {} or { "shift" }
			table.insert(orders, { -unitDefID, { bx, by, bz, bfacing }, opts })
		end
		local ok, err = pcall(Spring.GiveOrderArrayToUnitArray, builders, orders, false)
		if ok then
			return true
		end
	end

	for i, bp in ipairs(buildPositions) do
		local bx, by, bz, bfacing = bp[1], bp[2], bp[3], bp[4] or 0
		local opts = (i == 1 and not useQueue) and {} or { "shift" }
		for _, unitID in ipairs(builders) do
			pcall(spGiveOrderToUnit, unitID, -unitDefID, { bx, by, bz, bfacing }, opts)
		end
	end
	return true
end

function ControllerCameraTestClearNativeBlueprintPreview()
	local api = WG and WG["api_blueprint"]
	if type(api) ~= "table" then
		return
	end
	if type(api.setActiveBlueprint) == "function" then
		pcall(api.setActiveBlueprint, nil)
	end
	if type(api.setBlueprintPositions) == "function" then
		pcall(api.setBlueprintPositions, {})
	end
end

function ControllerCameraTestGetSelectedMobileUnits()
	local mobileUnits = {}
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	for _, unitID in ipairs(selectedUnits) do
		local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
		if type(unitDef) == "table" and not unitDef.isBuilding and not unitDef.isFactory then
			mobileUnits[#mobileUnits + 1] = unitID
		end
	end
	return mobileUnits
end

--------------------------------------------------------------------------------
-- SECTION: Drag/path commands
--------------------------------------------------------------------------------
function ControllerCameraTestIssueSingleUnitPathPoint(isFirst)
	local drag = ControllerCameraTestDragCommand
	if not drag.singleUnitPathActive or not drag.singleUnitPathUnitID
		or not reticleHasWorldTarget or not reticleWorldX or not reticleWorldY or not reticleWorldZ
	then
		return false
	end
	if not isFirst then
		local dx = reticleWorldX - (drag.singleUnitLastPointX or reticleWorldX)
		local dz = reticleWorldZ - (drag.singleUnitLastPointZ or reticleWorldZ)
		local spacing = ControllerCameraTestSettings.singlePathSpacing or 96
		local interval = ControllerCameraTestSettings.singlePathInterval or 0.10
		if ((dx * dx) + (dz * dz)) < (spacing * spacing)
			or (debugEventTime - (drag.singleUnitLastIssueTime or 0)) < interval
		then
			return false
		end
	end
	if type(spGiveOrderToUnit) ~= "function" or not CMD or type(CMD.MOVE) ~= "number" then
		drag.singleUnitPathResult = "move API unavailable"
		return false
	end

	local options = {}
	if not isFirst or ControllerCameraTestIsQueueModifierActive() then
		options = { "shift" }
	end
	local ok, result = pcall(spGiveOrderToUnit, drag.singleUnitPathUnitID, CMD.MOVE, { reticleWorldX, reticleWorldY, reticleWorldZ }, options)
	if not ok or result == false then
		drag.singleUnitPathResult = "waypoint rejected"
		return false
	end

	drag.singleUnitPathPoints[#drag.singleUnitPathPoints + 1] = { reticleWorldX, reticleWorldY, reticleWorldZ }
	drag.previewPoints = drag.singleUnitPathPoints
	drag.singleUnitLastPointX, drag.singleUnitLastPointY, drag.singleUnitLastPointZ = reticleWorldX, reticleWorldY, reticleWorldZ
	drag.singleUnitLastIssueTime = debugEventTime
	drag.singleUnitWaypointCount = #drag.singleUnitPathPoints
	drag.singleUnitPathResult = "recording " .. tostring(drag.singleUnitWaypointCount) .. " waypoints"
	ControllerCameraTestCommandDebug.issuedCmdID = tostring(CMD.MOVE)
	ControllerCameraTestCommandDebug.issuedParamsCount = 3
	ControllerCameraTestCommandDebug.lastOptions = ControllerCameraTestCommandOptionsSummary(options)
	ControllerCameraTestCommandDebug.lastResult = "single path waypoint accepted"
	return true
end

function ControllerCameraTestStartSingleUnitPath(unitID)
	local drag = ControllerCameraTestDragCommand
	drag.active = true
	drag.mode = "singleMovePath"
	drag.singleUnitPathActive = true
	drag.singleUnitPathUnitID = unitID
	drag.singleUnitPathPoints = {}
	drag.singleUnitLastPointX, drag.singleUnitLastPointY, drag.singleUnitLastPointZ = nil, nil, nil
	drag.singleUnitLastIssueTime = -10
	drag.singleUnitWaypointCount = 0
	drag.singleUnitPathResult = "started"
	drag.previewPoints = drag.singleUnitPathPoints
	drag.startX, drag.startY, drag.startZ = reticleWorldX, reticleWorldY, reticleWorldZ
	drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
	ControllerCameraTestIssueSingleUnitPathPoint(true)
	latchSelectionDebugMessage("Single-unit move path started")
end

function ControllerCameraTestUpdateSingleUnitPath()
	local drag = ControllerCameraTestDragCommand
	if drag.singleUnitPathActive then
		drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
		ControllerCameraTestIssueSingleUnitPathPoint(false)
	end
end

function ControllerCameraTestFinishSingleUnitPath()
	local drag = ControllerCameraTestDragCommand
	local count = drag.singleUnitWaypointCount or 0
	drag.singleUnitPathActive = false
	drag.active = false
	drag.pressActive = false
	drag.lastMode = "singleMovePath"
	drag.lastResult = "single path issued " .. tostring(count) .. " waypoints"
	drag.singleUnitPathResult = drag.lastResult
	lastIssuedCommand = drag.lastResult
	latchSelectionDebugMessage(drag.lastResult)
end

function ControllerCameraTestUpdateDragPreview()
	local drag = ControllerCameraTestDragCommand
	if not drag.active then
		ControllerCameraTestClearNativeBlueprintPreview()
		drag.previewPoints = {}
		return
	end

	if drag.mode == "singleMovePath" then
		ControllerCameraTestUpdateSingleUnitPath()
		return
	end

	local startX, startY, startZ = drag.startX, drag.startY, drag.startZ
	local endX, endY, endZ = reticleWorldX, reticleWorldY, reticleWorldZ
	if not endX or not startX then return end

	drag.endX, drag.endY, drag.endZ = endX, endY, endZ

	if drag.mode == "moveLine" or drag.mode == "fightLine" or drag.mode == "attackLine" then
		local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
		local mobileUnits = {}
		for _, unitID in ipairs(selectedUnits) do
			local unitDefID = Spring.GetUnitDefID(unitID)
			local unitDef = unitDefID and UnitDefs[unitDefID]
			if unitDef and not unitDef.isBuilding and not unitDef.isFactory then
				table.insert(mobileUnits, unitID)
			end
		end

		local N = #mobileUnits
		local pts = {}
		if N == 1 then
			table.insert(pts, { endX, endY, endZ })
		elseif N > 1 then
			for i = 1, N do
				local t = (i - 1) / (N - 1)
				local x = startX + t * (endX - startX)
				local z = startZ + t * (endZ - startZ)
				local y = Spring.GetGroundHeight(x, z)
				table.insert(pts, { x, y, z })
			end
		end
		drag.previewPoints = pts

	elseif drag.mode == "buildLine" or drag.mode == "buildGrid" or drag.mode == "buildBorder" then
		local option = ControllerCameraTestBuildPlacement.option
		if option and type(option.cmdID) == "number" and option.cmdID < 0 then
			local unitDefID = -option.cmdID
			local facing = ControllerCameraTestBuildPlacement.facing or 0
			local spacing = ControllerCameraTestBuildPlacement.placementSpacing or 0

			local bp = {
				facing = facing,
				units = {
					{
						blueprintUnitID = 1,
						unitDefID = unitDefID,
						position = { 0, 0, 0 },
						facing = 0
					}
				}
			}

			local startPos = { startX, startY, startZ }
			local endPos = { endX, endY, endZ }

			local api = type(WG) == "table" and WG["api_blueprint"] or nil
			local nativeModes = type(api) == "table" and api.BUILD_MODES or nil
			local modeMap = nativeModes and {
				buildLine = nativeModes.LINE,
				buildGrid = nativeModes.GRID,
				buildBorder = nativeModes.BOX,
				buildSplit = nativeModes.SPLIT,
			} or {}
			local apiMode = modeMap[drag.mode]
			local buildPositions = {}

			drag.nativeRouteUsed = false
			drag.nativeRouteName = "unavailable"
			drag.nativePreviewResult = "not attempted"
			drag.customGridFallback = "yes"
			if ControllerCameraTestSettings.preferNativeBlueprint ~= false and apiMode and type(api.calculateBuildPositions) == "function" then
				local ok, res = pcall(api.calculateBuildPositions, bp, apiMode, startPos, endPos, spacing)
				if ok and type(res) == "table" and #res > 0 then
					buildPositions = res
					drag.nativeRouteUsed = true
					drag.nativeRouteName = "api_blueprint.calculateBuildPositions"
					drag.nativePreviewResult = "positions calculated"
					drag.customGridFallback = "no"
					if type(api.setActiveBlueprint) == "function"
						and type(api.setBlueprintPositions) == "function"
					then
						local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
						if type(api.setActiveBuilders) == "function" then
							pcall(api.setActiveBuilders, selectedUnits)
						end
						local previewOk = pcall(api.setActiveBlueprint, bp)
						local posOk = pcall(api.setBlueprintPositions, buildPositions)
						if previewOk and posOk then
							drag.nativePreviewResult = "native preview active"
						end
					end
				end
			end
			if not drag.nativeRouteUsed then
				ControllerCameraTestClearNativeBlueprintPreview()
			end

			if #buildPositions == 0 then
				local unitDef = UnitDefs[unitDefID]
				if unitDef then
					local sizeX = unitDef.xsize * 8
					local sizeZ = unitDef.zsize * 8
					local bw, bh
					if facing % 2 == 1 then bw, bh = sizeZ, sizeX else bw, bh = sizeX, sizeZ end

					if drag.mode == "buildLine" then
						local dx = endX - startX
						local dz = endZ - startZ
						local dist = math.sqrt(dx*dx + dz*dz)
						local stepSize = math.max(bw, bh) + spacing * 16
						if dist < 2 then
							table.insert(buildPositions, { startX, startY, startZ, facing })
						else
							local vx, vz = dx / dist, dz / dist
							local numBuildings = math.floor(dist / stepSize) + 1
							if numBuildings > 100 then numBuildings = 100 end
							for i = 0, numBuildings - 1 do
								local x = startX + i * stepSize * vx
								local z = startZ + i * stepSize * vz
								local y = Spring.GetGroundHeight(x, z)
								table.insert(buildPositions, { x, y, z, facing })
							end
						end
					elseif drag.mode == "buildGrid" then
						local dx = endX - startX
						local dz = endZ - startZ
						local stepX = bw + spacing * 16
						local stepZ = bh + spacing * 16
						local numX = math.floor(math.abs(dx) / stepX) + 1
						local numZ = math.floor(math.abs(dz) / stepZ) + 1
						if numX * numZ > 100 then
							numX = 10
							numZ = 10
						end
						local signX = dx >= 0 and 1 or -1
						local signZ = dz >= 0 and 1 or -1
						for ix = 0, numX - 1 do
							for iz = 0, numZ - 1 do
								local x = startX + ix * stepX * signX
								local z = startZ + iz * stepZ * signZ
								local y = Spring.GetGroundHeight(x, z)
								table.insert(buildPositions, { x, y, z, facing })
							end
						end
					elseif drag.mode == "buildBorder" or drag.mode == "buildSplit" then
						table.insert(buildPositions, { startX, startY, startZ, facing })
						table.insert(buildPositions, { endX, endY, endZ, facing })
					end
				end
			end

			drag.previewPoints = buildPositions
		end
	end
end

function ControllerCameraTestConfirmDragCommand(exitMode)
	local drag = ControllerCameraTestDragCommand
	if not drag.active then return end

	local startX, startY, startZ = drag.startX, drag.startY, drag.startZ
	local endX, endY, endZ = drag.endX or reticleWorldX, drag.endY or reticleWorldY, drag.endZ or reticleWorldZ

	if not endX or not startX then
		drag.active = false
		drag.lastResult = "failed: no world target"
		return
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		drag.active = false
		drag.lastResult = "failed: no selected units"
		latchSelectionDebugMessage("Drag failed: no units selected")
		return
	end

	local isQueue = ControllerCameraTestIsQueueModifierActive()
	local isQueueFront = IsButtonDown("RT") or (normalizedRightTrigger and normalizedRightTrigger > 0.1)
	local orderOptions = isQueue and ControllerCameraTestGetCommandOptions() or {}
	ControllerCameraTestCommandDebug.lastOptions = ControllerCameraTestCommandOptionsSummary(orderOptions)

	if drag.mode == "moveLine" or drag.mode == "fightLine" or drag.mode == "attackLine" then
		local mobileUnits = {}
		for _, unitID in ipairs(selectedUnits) do
			local unitDefID = Spring.GetUnitDefID(unitID)
			local unitDef = unitDefID and UnitDefs[unitDefID]
			if unitDef and not unitDef.isBuilding and not unitDef.isFactory then
				table.insert(mobileUnits, unitID)
			end
		end

		local N = #mobileUnits
		if N == 0 then
			drag.active = false
			drag.lastResult = "failed: no selected mobile units"
			latchSelectionDebugMessage("Drag failed: no mobile units")
			return
		end

		local dx = endX - startX
		local dz = endZ - startZ
		local dist = math.sqrt(dx*dx + dz*dz)
		if dist > 0.1 then
			local vx, vz = dx / dist, dz / dist
			local sortedUnits = {}
			for _, unitID in ipairs(mobileUnits) do
				local ux, uy, uz = Spring.GetUnitPosition(unitID)
				if ux and uz then
					local proj = (ux - startX) * vx + (uz - startZ) * vz
					table.insert(sortedUnits, { unitID = unitID, proj = proj })
				else
					table.insert(sortedUnits, { unitID = unitID, proj = 0 })
				end
			end
			table.sort(sortedUnits, function(a, b) return a.proj < b.proj end)
			mobileUnits = {}
			for _, item in ipairs(sortedUnits) do
				table.insert(mobileUnits, item.unitID)
			end
		end

		local points = {}
		if N == 1 then
			table.insert(points, { endX, endY, endZ })
		else
			for i = 1, N do
				local t = (i - 1) / (N - 1)
				local px = startX + t * (endX - startX)
				local pz = startZ + t * (endZ - startZ)
				local py = Spring.GetGroundHeight(px, pz)
				table.insert(points, { px, py, pz })
			end
		end

		local cmdID = CMD.MOVE
		local cmdName = "Move Line"
		if drag.mode == "fightLine" then
			cmdID = CMD.FIGHT
			cmdName = "Fight Line"
		elseif drag.mode == "attackLine" then
			cmdID = CMD.ATTACK
			cmdName = "Attack Line"
		end

		local cmdInsert = CMD.INSERT or 140
		if isQueueFront then
			for i = #points, 1, -1 do
				local pt = points[i]
				local unitID = mobileUnits[i]
				pcall(spGiveOrderToUnit, unitID, cmdInsert, { 0, cmdID, 0, pt[1], pt[2], pt[3] }, { "alt" })
			end
		else
			for i, pt in ipairs(points) do
				local unitID = mobileUnits[i]
				pcall(spGiveOrderToUnit, unitID, cmdID, { pt[1], pt[2], pt[3] }, orderOptions)
			end
		end

		drag.lastResult = "issued " .. cmdName .. " to " .. tostring(N) .. " units"
		latchSelectionDebugMessage(cmdName .. " confirmed!")
		ControllerCameraTestSetCommandMarker(endX, endY, endZ, cmdName, "build")

	elseif drag.mode == "reclaimArea" or drag.mode == "repairArea" or drag.mode == "attackArea" then
		local dx = endX - startX
		local dz = endZ - startZ
		local r = math.sqrt(dx*dx + dz*dz)
		if r < 10 then r = 120 end

		local cmdID = CMD.RECLAIM
		local cmdName = "Reclaim Area"
		if drag.mode == "repairArea" then
			cmdID = CMD.REPAIR
			cmdName = "Repair Area"
		elseif drag.mode == "attackArea" then
			cmdID = CMD.ATTACK
			cmdName = "Attack Area"
		end

		local params = { startX, startY, startZ, r }
		local issued = 0

		if isQueueFront then
			local cmdInsert = CMD.INSERT or 140
			for _, unitID in ipairs(selectedUnits) do
				local ok, err = pcall(spGiveOrderToUnit, unitID, cmdInsert, { 0, cmdID, 0, startX, startY, startZ, r }, { "alt" })
				if ok then issued = issued + 1 end
			end
		else
			for _, unitID in ipairs(selectedUnits) do
				local ok, err = pcall(spGiveOrderToUnit, unitID, cmdID, params, orderOptions)
				if ok then issued = issued + 1 end
			end
		end

		drag.lastResult = "issued " .. cmdName .. " to " .. tostring(issued) .. " units"
		latchSelectionDebugMessage(cmdName .. " confirmed!")
		ControllerCameraTestSetCommandMarker(startX, startY, startZ, cmdName, "build")
	end

	drag.lastMode = drag.mode
	drag.active = false
	ControllerCameraTestClearNativeBlueprintPreview()
end

function ControllerCameraTestConfirmDragBuild(exitMode)
	local drag = ControllerCameraTestDragCommand
	if not drag.active then return end

	local startX, startY, startZ = drag.startX, drag.startY, drag.startZ
	local endX, endY, endZ = drag.endX or reticleWorldX, drag.endY or reticleWorldY, drag.endZ or reticleWorldZ

	if not endX or not startX then
		drag.active = false
		drag.lastResult = "failed: no world target"
		return
	end

	local placement = ControllerCameraTestBuildPlacement
	if not placement.option or type(placement.option.cmdID) ~= "number" then
		drag.active = false
		drag.lastResult = "failed: no build option"
		return
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		drag.active = false
		drag.lastResult = "failed: no selected units"
		latchSelectionDebugMessage("Build drag failed: no builders")
		return
	end

	if drag.mode == "buildBorder" and not (WG["api_blueprint"] and WG["api_blueprint"].calculateBuildPositions) then
		drag.active = false
		drag.lastResult = "border unavailable: native route not found"
		latchSelectionDebugMessage("Border build unavailable natively")
		return
	elseif drag.mode == "buildSplit" then
		drag.active = false
		drag.lastResult = "split unavailable: native route not found"
		latchSelectionDebugMessage("Split build unavailable natively")
		return
	end

	ControllerCameraTestUpdateDragPreview()
	local points = drag.previewPoints or {}
	if #points == 0 then
		drag.active = false
		drag.lastResult = "failed: no points"
		latchSelectionDebugMessage("Build drag failed: no positions")
		return
	end

	local unitDefID = -placement.option.cmdID
	local useQueue = placement.queueActive
	local useQueueFront = placement.queueFrontActive

	ControllerCameraTestIssueBuildOrders(selectedUnits, unitDefID, points, useQueue, useQueueFront)

	drag.lastResult = "placed " .. tostring(#points) .. " buildings"
	latchSelectionDebugMessage("Placed " .. tostring(#points) .. " " .. placement.option.name)

	drag.lastMode = drag.mode
	drag.active = false
	ControllerCameraTestClearNativeBlueprintPreview()

	if exitMode then
		ControllerCameraTestCancelPlacement("placed and exited")
	end
end

function ControllerCameraTestCancelDrag(reason)
	local drag = ControllerCameraTestDragCommand
	if drag.singleUnitPathActive then
		drag.singleUnitPathResult = reason or "single path cancelled"
	end
	drag.active = false
	drag.pressActive = false
	drag.singleUnitPathActive = false
	drag.singleUnitPathUnitID = nil
	drag.lastResult = reason or "cancelled"
	drag.previewPoints = {}
	ControllerCameraTestClearNativeBlueprintPreview()
	latchSelectionDebugMessage("Drag cancelled")
end

local function attemptContextCommand()
	local cmdID = 10 -- Fallback to Move (CMD.MOVE)
	local cmdName = "Move"

	ControllerCameraTestResetMexCommandDebug()
	ControllerCameraTestCommandDebug.defaultCmdIndex = "none"
	ControllerCameraTestCommandDebug.defaultCmdID = "none"
	ControllerCameraTestCommandDebug.defaultCmdType = "none"
	ControllerCameraTestCommandDebug.defaultCmdName = "none"
	ControllerCameraTestCommandDebug.issuedCmdID = "none"
	ControllerCameraTestCommandDebug.issuedParamsCount = 0
	ControllerCameraTestCommandDebug.lastResult = "pending"

	if type(Spring.GetDefaultCommand) == "function" then
		local cmdIndex, defaultCmdID, defaultCmdType, defaultCmdName = Spring.GetDefaultCommand()
		ControllerCameraTestCommandDebug.defaultCmdIndex = tostring(cmdIndex)
		ControllerCameraTestCommandDebug.defaultCmdID = tostring(defaultCmdID)
		ControllerCameraTestCommandDebug.defaultCmdType = tostring(defaultCmdType)
		ControllerCameraTestCommandDebug.defaultCmdName = tostring(defaultCmdName)

		if type(defaultCmdID) == "number" then
			cmdID = defaultCmdID
			cmdName = defaultCmdName or "Smart Action"
		end
	end

	local isBuild = type(cmdID) == "number" and cmdID < 0
	ControllerCameraTestCommandDebug.isBuild = isBuild and "yes" or "no"

	local ok, targetType, targetID = pcall(Spring.TraceScreenRay, screenCenterX, screenCenterY)
	local params = {}
	local targetString = "unknown"

	if isBuild then
		if not reticleHasWorldTarget or not reticleWorldX or not reticleWorldY or not reticleWorldZ then
			ControllerCameraTestCommandDebug.lastResult = "build failed: no world target"
			latchSelectionDebugMessage("X build failed: no world target")
			return
		end

		local facing = 0
		if type(Spring.GetBuildFacing) == "function" then
			local facingOk, buildFacing = pcall(Spring.GetBuildFacing)
			if facingOk and type(buildFacing) == "number" then
				facing = buildFacing
			end
		end
		params = { reticleWorldX, reticleWorldY, reticleWorldZ, facing }
		targetString = "build pos"
	elseif cmdID == 10 and reticleHasWorldTarget and reticleWorldX and reticleWorldY and reticleWorldZ
		and ControllerCameraTestAttemptMexBuildSmartAction(reticleWorldX, reticleWorldY, reticleWorldZ, ControllerCameraTestIsQueueModifierActive())
	then
		return
	elseif ok and (targetType == "unit" or targetType == "feature") and tonumber(targetID) then
		params = { tonumber(targetID) }
		targetString = targetType .. " " .. tostring(targetID)
	elseif reticleHasWorldTarget and reticleWorldX and reticleWorldY and reticleWorldZ then
		params = { reticleWorldX, reticleWorldY, reticleWorldZ }
		targetString = "ground"
	else
		ControllerCameraTestCommandDebug.lastResult = "context failed: no target"
		latchSelectionDebugMessage("X context failed: no target")
		return
	end

	issueOrderToSelection(cmdID, params, cmdName, targetString)
end

local function attemptAttackCommand()
	if type(spTraceScreenRay) ~= "function" then
		latchSelectionDebugMessage("Attack failed: API unavailable")
		return
	end
	local ok, targetType, targetID = pcall(spTraceScreenRay, screenCenterX, screenCenterY)
	if not ok then
		latchSelectionDebugMessage("Attack failed: trace failed")
		return
	end

	if targetType == "unit" and tonumber(targetID) then
		local unitID = tonumber(targetID)
		issueOrderToSelection(CMD.ATTACK, { unitID }, "Attack", "unit " .. tostring(unitID))
	else
		if not reticleHasWorldTarget or not reticleWorldX or not reticleWorldY or not reticleWorldZ then
			latchSelectionDebugMessage("Attack skipped: no world target")
			return
		end
		local params = { reticleWorldX, reticleWorldY, reticleWorldZ }
		local targetName = string.format("x=%.1f, y=%.1f, z=%.1f", reticleWorldX, reticleWorldY, reticleWorldZ)
		issueOrderToSelection(CMD.ATTACK, params, "Attack-Move", targetName)
	end
end

local function attemptStopCommand()
	issueOrderToSelection(CMD.STOP, {}, "Stop", "none", {})
end

function ControllerCameraTestSetCommandMarker(x, y, z, label, kind)
	local marker = ControllerCameraTestVisualFeedback
	marker.targetX = x
	marker.targetY = y
	marker.targetZ = z
	marker.label = label or "command"
	marker.kind = kind or string.lower(tostring(label or "generic"))
	marker.expireTime = debugEventTime + 1.0
end

--------------------------------------------------------------------------------
-- SECTION: Selection utilities and allied target helpers
--------------------------------------------------------------------------------
function ControllerCameraTestGetReticleTargetInfo()
	local info = {
		targetType = reticleTargetType,
		targetID = nil,
		x = reticleWorldX,
		y = reticleWorldY,
		z = reticleWorldZ,
		hasWorld = reticleHasWorldTarget,
	}

	if type(spTraceScreenRay) == "function" then
		local ok, targetType, targetID = pcall(spTraceScreenRay, screenCenterX, screenCenterY)
		if ok then
			info.targetType = tostring(targetType or "unavailable")
			info.targetID = tonumber(targetID)
		end
	end
	return info
end

function ControllerCameraTestFeatureCommandID(featureID)
	if not featureID then
		return nil
	end
	if Engine and Engine.FeatureSupport and Engine.FeatureSupport.noOffsetForFeatureID then
		return featureID
	end
	return featureID + (Game.maxUnits or 32000)
end

function ControllerCameraTestIsAlliedUnit(unitID)
	if not unitID or type(Spring.GetUnitTeam) ~= "function" then
		return false
	end

	local unitTeam = Spring.GetUnitTeam(unitID)
	local myTeam = type(Spring.GetMyTeamID) == "function" and Spring.GetMyTeamID()
		or (type(Spring.GetLocalTeamID) == "function" and Spring.GetLocalTeamID() or nil)
	if not unitTeam or not myTeam then
		return false
	end
	if type(Spring.AreTeamsAllied) == "function" then
		return Spring.AreTeamsAllied(myTeam, unitTeam)
	end
	return unitTeam == myTeam
end

function ControllerCameraTestGetUnitDef(unitID)
	if not unitID or type(Spring.GetUnitDefID) ~= "function" then
		return nil, nil
	end
	local unitDefID = Spring.GetUnitDefID(unitID)
	if not unitDefID or not UnitDefs then
		return unitDefID, nil
	end
	return unitDefID, UnitDefs[unitDefID]
end

function ControllerCameraTestIsMobileUnitDef(unitDef)
	if type(unitDef) ~= "table" then
		return true
	end
	if unitDef.isBuilding then
		return false
	end
	if type(unitDef.speed) == "number" then
		return unitDef.speed > 0
	end
	return true
end

function ControllerCameraTestIsCombatUnitDef(unitDef)
	if type(unitDef) ~= "table" then
		return false
	end
	if unitDef.canAttack then
		return true
	end
	return type(unitDef.weapons) == "table" and #unitDef.weapons > 0
end

function ControllerCameraTestGetVisibleAlliedUnits()
	if type(Spring.GetVisibleUnits) ~= "function" then
		return {}
	end

	local visibleUnits = Spring.GetVisibleUnits()
	local alliedUnits = {}
	if type(visibleUnits) ~= "table" then
		return alliedUnits
	end

	for _, unitID in ipairs(visibleUnits) do
		if ControllerCameraTestIsAlliedUnit(unitID) then
			alliedUnits[#alliedUnits + 1] = unitID
		end
	end
	table.sort(alliedUnits)
	return alliedUnits
end

function ControllerCameraTestSelectUnits(units, label)
	if type(spSelectUnitArray) ~= "function" then
		lastSelectionResult = "select API unavailable"
		latchSelectionDebugMessage(tostring(label or "Select") .. " failed: API unavailable")
		return false
	end
	if type(units) ~= "table" or #units == 0 then
		lastSelectionResult = "no units"
		latchSelectionDebugMessage(tostring(label or "Select") .. ": no units")
		return false
	end

	local ok = pcall(spSelectUnitArray, units, false)
	if not ok then
		lastSelectionResult = "select failed"
		latchSelectionDebugMessage(tostring(label or "Select") .. " failed")
		return false
	end

	lastSelectionResult = tostring(label or "selected") .. " " .. tostring(#units)
	lastReticleSelectedUnitID = tostring(units[1])
	latchSelectionDebugMessage(tostring(label or "Selected") .. ": " .. tostring(#units) .. " units")
	return true
end

--------------------------------------------------------------------------------
-- SECTION: Selection orders and issuing utility
--------------------------------------------------------------------------------
function ControllerCameraTestIssueOrderToSelectedUnits(cmdID, params, cmdName, targetName, options)
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	params = type(params) == "table" and params or {}
	options = type(options) == "table" and options or ControllerCameraTestGetCommandOptions()

	ControllerCameraTestCommandDebug.issuedCmdID = tostring(cmdID)
	ControllerCameraTestCommandDebug.issuedParamsCount = #params
	ControllerCameraTestCommandDebug.lastOptions = ControllerCameraTestCommandOptionsSummary(options)
	if type(cmdID) ~= "number" then
		ControllerCameraTestCommandDebug.lastResult = "command unavailable"
		latchSelectionDebugMessage(tostring(cmdName) .. " unavailable")
		return false, 0
	end
	if #selectedUnits == 0 then
		ControllerCameraTestCommandDebug.lastResult = "no selected units"
		latchSelectionDebugMessage(tostring(cmdName) .. " skipped: no units selected")
		return false, 0
	end
	if type(spGiveOrderToUnit) ~= "function" then
		ControllerCameraTestCommandDebug.lastResult = "GiveOrderToUnit unavailable"
		latchSelectionDebugMessage(tostring(cmdName) .. " failed: order API unavailable")
		return false, 0
	end

	local issuedCount = 0
	for _, unitID in ipairs(selectedUnits) do
		local ok, result = pcall(spGiveOrderToUnit, unitID, cmdID, params, options)
		if ok and result ~= false then
			issuedCount = issuedCount + 1
		end
	end

	if issuedCount > 0 then
		lastIssuedCommand = tostring(cmdName) .. " (" .. tostring(targetName or "target") .. ")"
		ControllerCameraTestCommandDebug.lastResult = "issued to " .. tostring(issuedCount) .. " units"
		latchSelectionDebugMessage(tostring(cmdName) .. " ordered to " .. tostring(issuedCount) .. " units")
		if type(params[1]) == "number" and type(params[2]) == "number" and type(params[3]) == "number" then
			ControllerCameraTestSetCommandMarker(params[1], params[2], params[3], cmdName)
		elseif type(params[1]) == "number" and type(Spring.GetUnitPosition) == "function" then
			local x, y, z = Spring.GetUnitPosition(params[1])
			if not x and params[1] > (Game.maxUnits or 32000) and type(Spring.GetFeaturePosition) == "function" then
				x, y, z = Spring.GetFeaturePosition(params[1] - (Game.maxUnits or 32000))
			end
			if x and y and z then
				ControllerCameraTestSetCommandMarker(x, y, z, cmdName)
			end
		end
		return true, issuedCount
	end

	ControllerCameraTestCommandDebug.lastResult = "no orders accepted"
	latchSelectionDebugMessage(tostring(cmdName) .. " failed: no orders accepted")
	return false, 0
end

function ControllerCameraTestSelectVisibleCombatUnits()
	ControllerCameraTestCycleDebug.lastResult = "visible select disabled"
	ControllerCameraTestLayerDebug.commandLayerAction = "RT+A select-all disabled"
	latchSelectionDebugMessage("Visible select-all is disabled")
	return false
end

function ControllerCameraTestSelectSameTypeAtReticleOrCombat()
	return ControllerCameraTestSelectSameTypeFromReticle(false)
end

function ControllerCameraTestIsOwnUnit(unitID)
	if not unitID or type(Spring.GetUnitTeam) ~= "function" then
		return false
	end
	local myTeam = type(Spring.GetMyTeamID) == "function" and Spring.GetMyTeamID()
		or (type(Spring.GetLocalTeamID) == "function" and Spring.GetLocalTeamID() or nil)
	if not myTeam then
		return false
	end
	local ok, unitTeam = pcall(Spring.GetUnitTeam, unitID)
	return ok and unitTeam == myTeam
end

function ControllerCameraTestGetAllOwnedUnitsOfType(unitDefID)
	local units = {}
	if not unitDefID then
		return units
	end
	for _, unitID in ipairs(ControllerCameraTestGetOwnTeamUnits()) do
		local ok, candidateDefID = pcall(Spring.GetUnitDefID, unitID)
		if ok and candidateDefID == unitDefID then
			units[#units + 1] = unitID
		end
	end
	return ControllerCameraTestFilterValidUnits(units)
end

function ControllerCameraTestGetReticleAlliedUnitAndDef()
	local target = ControllerCameraTestGetReticleTargetInfo()
	if target.targetType ~= "unit" or not target.targetID or not ControllerCameraTestIsAlliedUnit(target.targetID) then
		return nil, nil, nil
	end
	local unitDefID, unitDef = ControllerCameraTestGetUnitDef(target.targetID)
	return target.targetID, unitDefID, unitDef
end

function ControllerCameraTestUnitIsOnScreen(unitID)
	if type(Spring.WorldToScreenCoords) ~= "function" then
		return true
	end
	if (viewSizeX or 0) <= 0 or (viewSizeY or 0) <= 0 then
		return true
	end
	local x, y, z
	if type(Spring.GetUnitViewPosition) == "function" then
		local ok
		ok, x, y, z = pcall(Spring.GetUnitViewPosition, unitID)
		if not ok then
			x, y, z = nil, nil, nil
		end
	end
	if not x and type(spGetUnitPosition) == "function" then
		local ok
		ok, x, y, z = pcall(spGetUnitPosition, unitID)
		if not ok then
			x, y, z = nil, nil, nil
		end
	end
	if not x or not z then
		return false
	end
	local ok, sx, sy = pcall(Spring.WorldToScreenCoords, x, y or 0, z)
	if not ok or type(sx) ~= "number" or type(sy) ~= "number" then
		return true
	end
	local margin = 24
	return sx >= -margin and sx <= (viewSizeX + margin) and sy >= -margin and sy <= (viewSizeY + margin)
end

function ControllerCameraTestCollectSameTypeCandidates(unitDefID, includeOffscreen)
	local candidates = {}
	local seen = {}
	local source = includeOffscreen and "owned" or "visible+owned-screen"
	local function addCandidate(unitID)
		if unitID and not seen[unitID] then
			seen[unitID] = true
			candidates[#candidates + 1] = unitID
		end
	end

	if includeOffscreen then
		for _, unitID in ipairs(ControllerCameraTestGetOwnTeamUnits()) do
			addCandidate(unitID)
		end
	else
		if type(Spring.GetVisibleUnits) == "function" then
			local ok, visibleUnits = pcall(Spring.GetVisibleUnits)
			if ok and type(visibleUnits) == "table" then
				for _, unitID in ipairs(visibleUnits) do
					addCandidate(unitID)
				end
			else
				source = "owned-screen"
			end
		else
			source = "owned-screen"
		end
		for _, unitID in ipairs(ControllerCameraTestGetOwnTeamUnits()) do
			addCandidate(unitID)
		end
	end

	local units = {}
	for _, unitID in ipairs(candidates) do
		local ok, candidateDefID = pcall(Spring.GetUnitDefID, unitID)
		if ok and candidateDefID == unitDefID and (includeOffscreen or ControllerCameraTestUnitIsOnScreen(unitID)) then
			if includeOffscreen then
				if ControllerCameraTestIsOwnUnit(unitID) then
					units[#units + 1] = unitID
				end
			elseif ControllerCameraTestIsAlliedUnit(unitID) then
				units[#units + 1] = unitID
			end
		end
	end
	table.sort(units)
	return ControllerCameraTestFilterValidUnits(units), source
end

function ControllerCameraTestUpdateSameTypeDebug(unitDefID, source, candidates, selected, action)
	ControllerCameraTestAreaSelect.sameTypeUnitDefID = tostring(unitDefID or "none")
	ControllerCameraTestAreaSelect.sameTypeTarget = ControllerCameraTestUnitTypeName(unitDefID)
	ControllerCameraTestAreaSelect.sameTypeSource = tostring(source or "none")
	ControllerCameraTestAreaSelect.sameTypeCandidateCount = candidates or 0
	ControllerCameraTestAreaSelect.sameTypeSelectedCount = selected or 0
	ControllerCameraTestAreaSelect.doubleTapAction = tostring(action or "none")
end

function ControllerCameraTestSelectSameTypeFromReticle(includeOffscreen)
	local targetID, unitDefID, unitDef = ControllerCameraTestGetReticleAlliedUnitAndDef()
	if not targetID or not unitDefID then
		ControllerCameraTestUpdateSameTypeDebug(nil, "none", 0, 0, "no reticle unit")
		return false
	end
	if unitDef and unitDef.isBuilding and not includeOffscreen then
		ControllerCameraTestUpdateSameTypeDebug(unitDefID, "reticle building", 0, 0, "building requires LT")
		latchSelectionDebugMessage("Double-tap same-type: hold LT for buildings")
		return false
	end

	local units, source = ControllerCameraTestCollectSameTypeCandidates(unitDefID, includeOffscreen)
	local label = includeOffscreen and "LT+A double-tap all type" or "A double-tap visible type"

	if ControllerCameraTestSelectUnits(units, label) then
		ControllerCameraTestAreaSelect.lastCount = #units
		ControllerCameraTestAreaSelect.lastResult = (includeOffscreen and "same owned type " or "same visible type ") .. tostring(#units)
		ControllerCameraTestUpdateSameTypeDebug(unitDefID, source, #units, #units, includeOffscreen and "same owned type selected" or "same visible type selected")
		if includeOffscreen then
			ControllerCameraTestFocusUnitsCenter(units, "Same type")
		end
		return true
	end
	ControllerCameraTestUpdateSameTypeDebug(unitDefID, source, #units, 0, includeOffscreen and "same owned type none" or "same visible type none")
	return false
end

function ControllerCameraTestSelectVisibleSameTypeUnderReticle()
	return ControllerCameraTestSelectSameTypeFromReticle(false)
end

function ControllerCameraTestSelectAllOwnedSameTypeUnderReticle()
	return ControllerCameraTestSelectSameTypeFromReticle(true)
end

function ControllerCameraTestFocusCameraAt(x, y, z, label)
	if not x or not z then
		return false
	end
	local focusY = y
	if not focusY and type(spGetGroundHeight) == "function" then
		focusY = spGetGroundHeight(x, z)
	end
	focusY = focusY or 0
	if type(Spring.SetCameraTarget) == "function" then
		local ok = pcall(Spring.SetCameraTarget, x, focusY, z, 0.35)
		if ok then
			ControllerCameraTestSetCommandMarker(x, focusY, z, label or "Focus", "generic")
			return true
		end
	end
	if type(spGetCameraState) == "function" and type(spSetCameraState) == "function" then
		local cameraState = spGetCameraState()
		if type(cameraState) == "table" then
			cameraState.px = x
			cameraState.pz = z
			if cameraState.py == nil then
				cameraState.py = focusY + 600
			end
			local ok = pcall(spSetCameraState, cameraState, 0.25)
			if ok then
				ControllerCameraTestSetCommandMarker(x, focusY, z, label or "Focus", "generic")
				return true
			end
		end
	end
	return false
end

function ControllerCameraTestFocusAndSelectUnit(unitID, label)
	if not unitID then
		return false
	end
	local selected = ControllerCameraTestSelectUnits({ unitID }, label or "Select unit")
	if type(spGetUnitPosition) == "function" then
		local ok, x, y, z = pcall(spGetUnitPosition, unitID)
		if ok and x and z then
			ControllerCameraTestFocusCameraAt(x, y, z, label or "Focus unit")
		end
	end
	return selected
end

function ControllerCameraTestFocusUnitsCenter(units, label)
	if type(units) ~= "table" or #units == 0 or type(spGetUnitPosition) ~= "function" then
		return false
	end
	local sx, sy, sz, count = 0, 0, 0, 0
	for _, unitID in ipairs(units) do
		local ok, x, y, z = pcall(spGetUnitPosition, unitID)
		if ok and x and z then
			sx, sy, sz = sx + x, sy + (y or 0), sz + z
			count = count + 1
		end
	end
	if count <= 0 then
		return false
	end
	return ControllerCameraTestFocusCameraAt(sx / count, sy / count, sz / count, label or "Focus group")
end

function ControllerCameraTestGetOwnTeamUnits()
	local teamID = type(Spring.GetMyTeamID) == "function" and Spring.GetMyTeamID()
		or (type(Spring.GetLocalTeamID) == "function" and Spring.GetLocalTeamID() or nil)
	if teamID and type(Spring.GetTeamUnits) == "function" then
		local ok, units = pcall(Spring.GetTeamUnits, teamID)
		if ok and type(units) == "table" then
			table.sort(units)
			return units
		end
	end
	return ControllerCameraTestGetVisibleAlliedUnits()
end

function ControllerCameraTestIsCommanderUnit(unitID)
	local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
	if type(unitDef) ~= "table" then
		return false
	end
	local cp = unitDef.customParams or {}
	if cp.iscommander or cp.commtype or cp.level == "commander" then
		return true
	end
	local name = string.lower(tostring(unitDef.name or "") .. " " .. tostring(unitDef.humanName or "") .. " " .. tostring(unitDef.translatedHumanName or ""))
	return string.find(name, "commander", 1, true) ~= nil
end

function ControllerCameraTestFocusCommander()
	for _, unitID in ipairs(ControllerCameraTestGetOwnTeamUnits()) do
		if ControllerCameraTestIsCommanderUnit(unitID) then
			if type(spGetUnitPosition) ~= "function" then
				ControllerCameraTestIdleCycle.lastResult = "commander focus failed: position API unavailable"
				latchSelectionDebugMessage(ControllerCameraTestIdleCycle.lastResult)
				return false
			end
			local ok, x, y, z = pcall(spGetUnitPosition, unitID)
			if ok and x and z and ControllerCameraTestFocusCameraAt(x, y, z, "Commander") then
				ControllerCameraTestIdleCycle.currentUnitID = unitID
				ControllerCameraTestIdleCycle.lastResult = "focused Commander " .. tostring(unitID)
				ControllerCameraTestLayerDebug.normalUtilityAction = "Double-tap A Commander focus"
				latchSelectionDebugMessage("Focused Commander")
				return true
			end
		end
	end
	ControllerCameraTestIdleCycle.lastResult = "Commander focus failed: no commander found"
	ControllerCameraTestLayerDebug.normalUtilityAction = ControllerCameraTestIdleCycle.lastResult
	latchSelectionDebugMessage(ControllerCameraTestIdleCycle.lastResult)
	return false
end

function ControllerCameraTestUnitIsIdle(unitID)
	if type(Spring.GetCommandQueue) == "function" then
		local ok, queue = pcall(Spring.GetCommandQueue, unitID, 1)
		if ok and type(queue) == "table" then
			return #queue == 0
		end
	end
	if type(Spring.GetUnitCommands) == "function" then
		local ok, queue = pcall(Spring.GetUnitCommands, unitID, 1)
		if ok and type(queue) == "table" then
			return #queue == 0
		end
	end
	return false
end

function ControllerCameraTestUnitIsFinished(unitID)
	if type(Spring.GetUnitHealth) ~= "function" then
		return true
	end
	local ok, health, maxHealth, paralyzeDamage, captureProgress, buildProgress = pcall(Spring.GetUnitHealth, unitID)
	if not ok then
		return true
	end
	return not (type(buildProgress) == "number" and buildProgress < 1)
end

function ControllerCameraTestIsIdleCycleCandidate(unitID)
	local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
	if type(unitDef) ~= "table" then
		return false, false
	end
	if unitDef.isBuilding or unitDef.isFactory then
		return false, false
	end
	if not ControllerCameraTestIsMobileUnitDef(unitDef) then
		return false, false
	end
	if not ControllerCameraTestUnitIsFinished(unitID) then
		return false, false
	end
	if not ControllerCameraTestUnitIsIdle(unitID) then
		return false, false
	end
	local isBuilder = unitDef.isBuilder or unitDef.canBuild or (type(unitDef.buildOptions) == "table" and #unitDef.buildOptions > 0)
	return true, isBuilder
end

function ControllerCameraTestGetIdleCycleUnits()
	local builders, fallback = {}, {}
	for _, unitID in ipairs(ControllerCameraTestGetOwnTeamUnits()) do
		local ok, isBuilder = ControllerCameraTestIsIdleCycleCandidate(unitID)
		if ok then
			if isBuilder then
				builders[#builders + 1] = unitID
			else
				fallback[#fallback + 1] = unitID
			end
		end
	end
	local units = (#builders > 0) and builders or fallback
	table.sort(units)
	ControllerCameraTestIdleCycle.lastCount = #units
	return units
end

function ControllerCameraTestUnitTypeName(unitDefID)
	local unitDef = unitDefID and UnitDefs and UnitDefs[unitDefID]
	if not unitDef then
		return tostring(unitDefID or "unknown")
	end
	return unitDef.translatedHumanName or unitDef.humanName or unitDef.name or tostring(unitDefID)
end

--------------------------------------------------------------------------------
-- SECTION: Idle cycling
--------------------------------------------------------------------------------
function ControllerCameraTestCycleIdleUnit(delta)
	local units = ControllerCameraTestGetIdleCycleUnits()
	if #units == 0 then
		ControllerCameraTestIdleCycle.lastResult = "no idle units"
		ControllerCameraTestIdleCycle.currentUnitID = nil
		latchSelectionDebugMessage("Idle cycle: no idle units")
		return false
	end

	local currentIndex = 0
	for i, unitID in ipairs(units) do
		if unitID == ControllerCameraTestIdleCycle.currentUnitID then
			currentIndex = i
			break
		end
	end
	local nextIndex = ((currentIndex - 1 + delta) % #units) + 1
	local unitID = units[nextIndex]
	local unitDefID = type(Spring.GetUnitDefID) == "function" and Spring.GetUnitDefID(unitID) or nil
	ControllerCameraTestIdleCycle.currentIndex = nextIndex
	ControllerCameraTestIdleCycle.currentUnitID = unitID
	ControllerCameraTestIdleCycle.currentTypeKey = unitDefID
	ControllerCameraTestIdleCycle.lastTypeName = ControllerCameraTestUnitTypeName(unitDefID)
	if ControllerCameraTestFocusAndSelectUnit(unitID, "Idle unit") then
		ControllerCameraTestIdleCycle.lastResult = "idle unit " .. tostring(nextIndex) .. "/" .. tostring(#units)
		ControllerCameraTestLayerDebug.normalUtilityAction = "Idle cycle " .. ControllerCameraTestIdleCycle.lastResult
		return true
	end
	return false
end

function ControllerCameraTestGetIdleUnitTypeBuckets()
	local bucketsByDef = {}
	local buckets = {}
	for _, unitID in ipairs(ControllerCameraTestGetIdleCycleUnits()) do
		local unitDefID = type(Spring.GetUnitDefID) == "function" and Spring.GetUnitDefID(unitID) or nil
		if unitDefID then
			local bucket = bucketsByDef[unitDefID]
			if not bucket then
				bucket = { unitDefID = unitDefID, name = ControllerCameraTestUnitTypeName(unitDefID), units = {} }
				bucketsByDef[unitDefID] = bucket
				buckets[#buckets + 1] = bucket
			end
			bucket.units[#bucket.units + 1] = unitID
		end
	end
	table.sort(buckets, function(a, b)
		if a.name == b.name then
			return a.unitDefID < b.unitDefID
		end
		return a.name < b.name
	end)
	return buckets
end

function ControllerCameraTestSelectRepresentativeFromIdleTypeBucket(bucket)
	if type(bucket) ~= "table" or type(bucket.units) ~= "table" or #bucket.units == 0 then
		return false
	end
	local unitID = bucket.units[1]
	ControllerCameraTestIdleCycle.currentUnitID = unitID
	ControllerCameraTestIdleCycle.currentTypeKey = bucket.unitDefID
	ControllerCameraTestIdleCycle.lastTypeName = bucket.name
	ControllerCameraTestIdleCycle.lastCount = #bucket.units
	return ControllerCameraTestFocusAndSelectUnit(unitID, "Idle type " .. tostring(bucket.name))
end

function ControllerCameraTestCycleIdleUnitType(delta)
	local buckets = ControllerCameraTestGetIdleUnitTypeBuckets()
	if #buckets == 0 then
		ControllerCameraTestIdleCycle.lastResult = "no idle type buckets"
		latchSelectionDebugMessage("Idle type cycle: no idle units")
		return false
	end
	local currentIndex = 0
	for i, bucket in ipairs(buckets) do
		if bucket.unitDefID == ControllerCameraTestIdleCycle.currentTypeKey then
			currentIndex = i
			break
		end
	end
	local nextIndex = ((currentIndex - 1 + delta) % #buckets) + 1
	local bucket = buckets[nextIndex]
	ControllerCameraTestIdleCycle.currentTypeIndex = nextIndex
	if ControllerCameraTestSelectRepresentativeFromIdleTypeBucket(bucket) then
		ControllerCameraTestIdleCycle.lastResult = "idle type " .. tostring(nextIndex) .. "/" .. tostring(#buckets)
		ControllerCameraTestLayerDebug.normalUtilityAction = "Idle type " .. tostring(bucket.name) .. " x" .. tostring(#bucket.units)
		return true
	end
	return false
end

function ControllerCameraTestSelectAllIdleUnitsInCurrentTypeBucket()
	local buckets = ControllerCameraTestGetIdleUnitTypeBuckets()
	if #buckets == 0 then
		ControllerCameraTestIdleCycle.selectedAllCount = 0
		ControllerCameraTestIdleCycle.lastResult = "no idle units for type-select"
		latchSelectionDebugMessage("LT+A double-tap: no idle units")
		return false
	end
	local bucket = buckets[1]
	for _, candidate in ipairs(buckets) do
		if candidate.unitDefID == ControllerCameraTestIdleCycle.currentTypeKey then
			bucket = candidate
			break
		end
	end
	if ControllerCameraTestSelectUnits(bucket.units, "Idle type group") then
		ControllerCameraTestIdleCycle.currentTypeKey = bucket.unitDefID
		ControllerCameraTestIdleCycle.lastTypeName = bucket.name
		ControllerCameraTestIdleCycle.selectedAllCount = #bucket.units
		ControllerCameraTestIdleCycle.lastResult = "selected idle type x" .. tostring(#bucket.units)
		ControllerCameraTestFocusUnitsCenter(bucket.units, "Idle type group")
		return true
	end
	return false
end

function ControllerCameraTestCycleSelection(delta)
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	local candidates = {}
	local selectedUnitID = selectedUnits[1]
	local selectedDefID = selectedUnitID and type(Spring.GetUnitDefID) == "function" and Spring.GetUnitDefID(selectedUnitID)

	if #selectedUnits > 1 then
		for _, unitID in ipairs(selectedUnits) do
			candidates[#candidates + 1] = unitID
		end
	elseif selectedDefID then
		for _, unitID in ipairs(ControllerCameraTestGetVisibleAlliedUnits()) do
			local unitDefID = type(Spring.GetUnitDefID) == "function" and Spring.GetUnitDefID(unitID)
			if unitDefID == selectedDefID then
				candidates[#candidates + 1] = unitID
			end
		end
	else
		for _, unitID in ipairs(ControllerCameraTestGetVisibleAlliedUnits()) do
			local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
			if ControllerCameraTestIsMobileUnitDef(unitDef) then
				candidates[#candidates + 1] = unitID
			end
		end
	end

	table.sort(candidates)
	if #candidates == 0 then
		ControllerCameraTestCycleDebug.lastResult = "no cycle candidates"
		ControllerCameraTestCycleDebug.lastCount = 0
		latchSelectionDebugMessage("Cycle selection: no candidates")
		return
	end

	local currentIndex = 0
	for i, unitID in ipairs(candidates) do
		if unitID == selectedUnitID then
			currentIndex = i
			break
		end
	end
	local nextIndex = ((currentIndex - 1 + delta) % #candidates) + 1
	local nextUnitID = candidates[nextIndex]
	if ControllerCameraTestSelectUnits({ nextUnitID }, "Cycle selection") then
		ControllerCameraTestCycleDebug.lastResult = "selected " .. tostring(nextUnitID)
		ControllerCameraTestCycleDebug.lastCount = #candidates
		ControllerCameraTestCycleDebug.lastUnitID = tostring(nextUnitID)
	end
end

function ControllerCameraTestStoreCameraBookmark(slot)
	if type(spGetCameraState) ~= "function" then
		ControllerCameraTestBookmarkDebug.lastResult = "camera API unavailable"
		return
	end
	local cameraState = spGetCameraState()
	if type(cameraState) ~= "table" then
		ControllerCameraTestBookmarkDebug.lastResult = "camera state unavailable"
		return
	end

	local copy = {}
	for key, value in pairs(cameraState) do
		copy[key] = value
	end
	ControllerCameraTestBookmarkDebug.slots[slot] = copy
	ControllerCameraTestBookmarkDebug.lastSlot = slot
	ControllerCameraTestBookmarkDebug.lastResult = "stored " .. tostring(slot)
	latchSelectionDebugMessage("Camera bookmark stored: " .. tostring(slot))
end

function ControllerCameraTestRecallCameraBookmark(slot)
	local cameraState = ControllerCameraTestBookmarkDebug.slots[slot]
	if type(cameraState) ~= "table" then
		ControllerCameraTestBookmarkDebug.lastSlot = slot
		ControllerCameraTestBookmarkDebug.lastResult = "empty " .. tostring(slot)
		latchSelectionDebugMessage("Camera bookmark empty: " .. tostring(slot))
		return
	end
	if type(spSetCameraState) ~= "function" then
		ControllerCameraTestBookmarkDebug.lastResult = "SetCameraState unavailable"
		return
	end

	local ok = pcall(spSetCameraState, cameraState, 0.25)
	ControllerCameraTestBookmarkDebug.lastSlot = slot
	ControllerCameraTestBookmarkDebug.lastResult = ok and ("recalled " .. tostring(slot)) or "recall failed"
	latchSelectionDebugMessage("Camera bookmark " .. (ok and "recalled: " or "failed: ") .. tostring(slot))
end

function ControllerCameraTestHandleBookmarkButton(slot)
	if fastPanActive then
		ControllerCameraTestStoreCameraBookmark(slot)
	else
		ControllerCameraTestRecallCameraBookmark(slot)
	end
	ControllerCameraTestLayerDebug.normalUtilityAction = "Bookmark " .. tostring(ControllerCameraTestBookmarkDebug.lastResult)
end

function ControllerCameraTestFilterValidUnits(units)
	local validUnits = {}
	if type(units) ~= "table" then
		return validUnits
	end
	for _, unitID in ipairs(units) do
		local isValid = true
		if type(Spring.GetUnitIsDead) == "function" and Spring.GetUnitIsDead(unitID) then
			isValid = false
		end
		if type(Spring.GetUnitDefID) == "function" and not Spring.GetUnitDefID(unitID) then
			isValid = false
		end
		if isValid then
			validUnits[#validUnits + 1] = unitID
		end
	end
	return validUnits
end

function ControllerCameraTestStoreQuickGroup(slot)
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	local units = ControllerCameraTestFilterValidUnits(selectedUnits)
	ControllerCameraTestQuickGroups.currentSlot = slot
	ControllerCameraTestQuickGroups.lastSlot = tostring(slot)
	if #units == 0 then
		ControllerCameraTestQuickGroups.lastResult = "store failed: no selected units"
		ControllerCameraTestTuning.lastAction = "quick group " .. tostring(slot) .. " store failed"
		latchSelectionDebugMessage("Quick group " .. tostring(slot) .. ": no selected units")
		return
	end

	ControllerCameraTestQuickGroups.slots[slot] = units
	ControllerCameraTestQuickGroups.lastResult = "stored " .. tostring(#units) .. " units"
	ControllerCameraTestTuning.lastAction = "quick group " .. tostring(slot) .. " stored"
	latchSelectionDebugMessage("Quick group " .. tostring(slot) .. " stored: " .. tostring(#units))
end

function ControllerCameraTestRecallQuickGroup(slot)
	local units = ControllerCameraTestFilterValidUnits(ControllerCameraTestQuickGroups.slots[slot])
	ControllerCameraTestQuickGroups.currentSlot = slot
	ControllerCameraTestQuickGroups.lastSlot = tostring(slot)
	if #units == 0 then
		ControllerCameraTestQuickGroups.slots[slot] = nil
		ControllerCameraTestQuickGroups.lastResult = "empty"
		ControllerCameraTestTuning.lastAction = "quick group " .. tostring(slot) .. " empty"
		latchSelectionDebugMessage("Quick group " .. tostring(slot) .. " empty")
		return false
	end

	ControllerCameraTestQuickGroups.slots[slot] = units
	ControllerCameraTestQuickGroups.lastResult = "recalled " .. tostring(#units) .. " units"
	ControllerCameraTestTuning.lastAction = "quick group " .. tostring(slot) .. " recalled"
	ControllerCameraTestSelectUnits(units, "Quick group " .. tostring(slot))
	return true
end

function ControllerCameraTestCycleQuickGroup(delta)
	local startSlot = ControllerCameraTestQuickGroups.currentSlot or 1
	for i = 1, 4 do
		local slot = ((startSlot - 1 + (delta * i)) % 4) + 1
		if ControllerCameraTestRecallQuickGroup(slot) then
			ControllerCameraTestLayerDebug.commandLayerAction = "Quick group " .. tostring(slot)
			return true
		end
	end
	ControllerCameraTestQuickGroups.lastResult = "no stored groups"
	latchSelectionDebugMessage("No stored quick groups")
	return false
end

--------------------------------------------------------------------------------
-- SECTION: Control groups
--------------------------------------------------------------------------------
function ControllerCameraTestNormalizeControlGroupSlot(slot)
	slot = tonumber(slot) or 1
	slot = ((slot - 1) % 10) + 1
	return slot
end

function ControllerCameraTestGetControlGroupDisplaySlot(slot)
	slot = ControllerCameraTestNormalizeControlGroupSlot(slot)
	return slot == 10 and "0" or tostring(slot)
end

function ControllerCameraTestShowControlGroupOverlay(seconds)
	ControllerCameraTestControlGroups.visibleUntil = debugEventTime + (seconds or 1.5)
end

function ControllerCameraTestPruneDeadUnitsFromControlGroup(slot)
	slot = ControllerCameraTestNormalizeControlGroupSlot(slot)
	local groups = ControllerCameraTestControlGroups
	local entry = groups.slots[slot]
	if type(entry) ~= "table" then
		return {}
	end
	local units = ControllerCameraTestFilterValidUnits(entry.units)
	entry.units = units
	entry.count = #units
	if #units == 0 and not entry.autoAddUnitDefID then
		groups.slots[slot] = nil
	end
	return units
end

function ControllerCameraTestSetControlGroupAction(action, slot, count)
	local groups = ControllerCameraTestControlGroups
	groups.lastAction = action
	groups.lastSlot = ControllerCameraTestGetControlGroupDisplaySlot(slot)
	groups.lastCount = count or 0
	ControllerCameraTestShowControlGroupOverlay(1.5)
	ControllerCameraTestLayerDebug.normalUtilityAction = "Group " .. tostring(groups.lastSlot) .. ": " .. tostring(action)
	latchSelectionDebugMessage("Group " .. tostring(groups.lastSlot) .. ": " .. tostring(action))
end

function ControllerCameraTestGetControlGroupSourceUnitDefID()
	local targetID, unitDefID, unitDef = ControllerCameraTestGetReticleAlliedUnitAndDef()
	if unitDefID and ControllerCameraTestIsOwnUnit(targetID) then
		return unitDefID, unitDef, "reticle"
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if selectedUnits[1] then
		local selectedDefID, selectedDef = ControllerCameraTestGetUnitDef(selectedUnits[1])
		if selectedDefID then
			return selectedDefID, selectedDef, "selection"
		end
	end

	if ControllerCameraTestIdleCycle.currentUnitID then
		local idleDefID, idleDef = ControllerCameraTestGetUnitDef(ControllerCameraTestIdleCycle.currentUnitID)
		if idleDefID then
			return idleDefID, idleDef, "idle"
		end
	end
	return nil, nil, "none"
end

function ControllerCameraTestAssignControlGroup(slot)
	slot = ControllerCameraTestNormalizeControlGroupSlot(slot)
	local groups = ControllerCameraTestControlGroups
	local unitDefID, unitDef, source = ControllerCameraTestGetControlGroupSourceUnitDefID()
	if not unitDefID then
		ControllerCameraTestSetControlGroupAction("assign failed: no source unit", slot, 0)
		return false
	end
	local units = ControllerCameraTestGetAllOwnedUnitsOfType(unitDefID)
	if #units == 0 then
		ControllerCameraTestSetControlGroupAction("assign failed: no owned type", slot, 0)
		return false
	end
	table.sort(units)
	groups.slots[slot] = {
		units = units,
		unitDefID = unitDefID,
		autoAddUnitDefID = unitDefID,
		typeName = ControllerCameraTestUnitTypeName(unitDefID),
		count = #units,
		lastAssignedTime = debugEventTime,
	}
	groups.activeSlot = slot
	ControllerCameraTestSetControlGroupAction("assigned " .. ControllerCameraTestUnitTypeName(unitDefID) .. " x" .. tostring(#units) .. " AUTO via " .. tostring(source), slot, #units)
	return true
end

function ControllerCameraTestRecallControlGroup(slot)
	slot = ControllerCameraTestNormalizeControlGroupSlot(slot)
	local groups = ControllerCameraTestControlGroups
	local units = ControllerCameraTestPruneDeadUnitsFromControlGroup(slot)
	groups.activeSlot = slot
	if #units == 0 then
		ControllerCameraTestSetControlGroupAction("empty", slot, 0)
		return false
	end
	if ControllerCameraTestSelectUnits(units, "Control group " .. ControllerCameraTestGetControlGroupDisplaySlot(slot)) then
		ControllerCameraTestFocusUnitsCenter(units, "Control group")
		local entry = groups.slots[slot]
		local typeName = entry and entry.typeName or (entry and ControllerCameraTestUnitTypeName(entry.unitDefID) or "units")
		ControllerCameraTestSetControlGroupAction("recalled " .. tostring(typeName) .. " x" .. tostring(#units), slot, #units)
		return true
	end
	ControllerCameraTestSetControlGroupAction("recall failed", slot, #units)
	return false
end

function ControllerCameraTestClearControlGroup(slot)
	slot = ControllerCameraTestNormalizeControlGroupSlot(slot)
	ControllerCameraTestControlGroups.slots[slot] = nil
	ControllerCameraTestControlGroups.activeSlot = slot
	ControllerCameraTestSetControlGroupAction("cleared", slot, 0)
	return true
end

function ControllerCameraTestChangeControlGroupSlot(delta)
	local groups = ControllerCameraTestControlGroups
	groups.activeSlot = ControllerCameraTestNormalizeControlGroupSlot((groups.activeSlot or 1) + delta)
	ControllerCameraTestSetControlGroupAction("active slot", groups.activeSlot, groups.slots[groups.activeSlot] and (groups.slots[groups.activeSlot].count or 0) or 0)
end

function ControllerCameraTestStartControlGroupLeftPress()
	local groups = ControllerCameraTestControlGroups
	groups.leftPressActive = true
	groups.leftPressStartTime = debugEventTime
	groups.leftHoldTriggered = false
	groups.leftInputState = "left tap pending"
	ControllerCameraTestShowControlGroupOverlay(0.4)
end

function ControllerCameraTestResolveControlGroupLeftPress()
	local groups = ControllerCameraTestControlGroups
	if not groups.leftPressActive then
		return false
	end

	local holdSeconds = ControllerCameraTestSettings.controlGroupAssignHoldSeconds or 0.35
	local elapsed = debugEventTime - (groups.leftPressStartTime or debugEventTime)
	if not groups.leftHoldTriggered and elapsed >= holdSeconds then
		ControllerCameraTestAssignControlGroup(groups.activeSlot)
		groups.leftInputState = "assigned hold"
	elseif not groups.leftHoldTriggered then
		ControllerCameraTestRecallControlGroup(groups.activeSlot)
		groups.leftInputState = "recalled tap"
	else
		groups.leftInputState = "assigned hold"
	end

	groups.leftPressActive = false
	groups.leftPressStartTime = 0
	groups.leftHoldTriggered = false
	return true
end

function ControllerCameraTestUpdateControlGroupLeftHold()
	local groups = ControllerCameraTestControlGroups
	if not groups.leftPressActive then
		return false
	end

	if not ControllerCameraTestActionDown("controlGroupModifier") or not ControllerCameraTestActionDown("groupRecallOrAssign") then
		return ControllerCameraTestResolveControlGroupLeftPress()
	end

	local holdSeconds = ControllerCameraTestSettings.controlGroupAssignHoldSeconds or 0.35
	if not groups.leftHoldTriggered and (debugEventTime - (groups.leftPressStartTime or debugEventTime)) >= holdSeconds then
		ControllerCameraTestAssignControlGroup(groups.activeSlot)
		groups.leftHoldTriggered = true
		groups.leftInputState = "assigned hold"
	else
		groups.leftInputState = groups.leftHoldTriggered and "assigned hold" or "holding left"
	end
	return true
end

function ControllerCameraTestHandleControlGroupInput()
	local groups = ControllerCameraTestControlGroups
	if not (ControllerCameraTestActionDown("controlGroupModifier") or ControllerCameraTestActionPressed("controlGroupModifier") or groups.leftPressActive) then
		return false
	end

	groups.activeSlot = ControllerCameraTestNormalizeControlGroupSlot(groups.activeSlot or 1)
	ControllerCameraTestShowControlGroupOverlay(ControllerCameraTestActionDown("controlGroupModifier") and 0.2 or 1.5)

	if groups.leftPressActive then
		ControllerCameraTestUpdateControlGroupLeftHold()
		if groups.leftPressActive or not ControllerCameraTestActionDown("controlGroupModifier") then
			return true
		end
	end

	if ControllerCameraTestActionDown("controlGroupModifier") then
		if ControllerCameraTestActionPressed("groupSlotUp") then
			ControllerCameraTestChangeControlGroupSlot(1)
		elseif ControllerCameraTestActionPressed("groupSlotDown") then
			ControllerCameraTestChangeControlGroupSlot(-1)
		elseif ControllerCameraTestActionPressed("groupRecallOrAssign") then
			ControllerCameraTestStartControlGroupLeftPress()
		elseif ControllerCameraTestActionReleased("groupRecallOrAssign") and groups.leftPressActive then
			ControllerCameraTestResolveControlGroupLeftPress()
		elseif WasButtonPressed("dpadRight") then
			ControllerCameraTestSetControlGroupAction("RB+D-pad Right disabled", groups.activeSlot, groups.slots[groups.activeSlot] and (groups.slots[groups.activeSlot].count or 0) or 0)
			groups.leftInputState = "right disabled"
		elseif ControllerCameraTestActionPressed("groupClear") then
			ControllerCameraTestClearControlGroup(groups.activeSlot)
		elseif ControllerCameraTestActionPressed("select") then
			ControllerCameraTestSetControlGroupAction("RB+A disabled", groups.activeSlot, 0)
			groups.leftInputState = "A disabled"
		elseif ControllerCameraTestActionPressed("smartAction") then
			ControllerCameraTestSetControlGroupAction("RB+X disabled", groups.activeSlot, 0)
			groups.leftInputState = "X disabled"
		else
			ControllerCameraTestLayerDebug.normalUtilityAction = "Control group mode"
		end
	end
	return true
end

function ControllerCameraTestAutoAddFinishedUnitToGroups(unitID, unitDefID, unitTeam)
	if not unitID or not unitDefID then
		return
	end
	local myTeam = type(Spring.GetMyTeamID) == "function" and Spring.GetMyTeamID()
		or (type(Spring.GetLocalTeamID) == "function" and Spring.GetLocalTeamID() or nil)
	if not unitTeam and type(Spring.GetUnitTeam) == "function" then
		local teamOk, detectedTeam = pcall(Spring.GetUnitTeam, unitID)
		if teamOk then
			unitTeam = detectedTeam
		end
	end
	if myTeam and unitTeam ~= myTeam then
		return
	end
	local groups = ControllerCameraTestControlGroups
	for slot, entry in pairs(groups.slots) do
		if type(entry) == "table" and entry.autoAddUnitDefID == unitDefID then
			local exists = false
			for _, existingID in ipairs(entry.units or {}) do
				if existingID == unitID then
					exists = true
					break
				end
			end
			if not exists then
				entry.units = entry.units or {}
				entry.units[#entry.units + 1] = unitID
				table.sort(entry.units)
				entry.count = #entry.units
				entry.unitDefID = unitDefID
				entry.typeName = entry.typeName or ControllerCameraTestUnitTypeName(unitDefID)
				groups.lastAction = "auto-added " .. tostring(entry.typeName)
				groups.lastSlot = ControllerCameraTestGetControlGroupDisplaySlot(slot)
				groups.lastCount = entry.count
			end
		end
	end
end

function ControllerCameraTestRemoveUnitFromControlGroups(unitID)
	if not unitID then
		return
	end
	for slot, entry in pairs(ControllerCameraTestControlGroups.slots) do
		if type(entry) == "table" and type(entry.units) == "table" then
			local filtered = {}
			for _, existingID in ipairs(entry.units) do
				if existingID ~= unitID then
					filtered[#filtered + 1] = existingID
				end
			end
			entry.units = filtered
			entry.count = #filtered
			if #filtered == 0 and not entry.autoAddUnitDefID then
				ControllerCameraTestControlGroups.slots[slot] = nil
			end
		end
	end
end

function ControllerCameraTestTacticalCommandAvailable(cmdID)
	if type(cmdID) ~= "number" then
		return true
	end
	if cmdID == CMD.STOP or cmdID == CMD.WAIT or cmdID == CMD.REPEAT then
		return true
	end
	if type(Spring.GetActiveCmdDescs) ~= "function" then
		return true
	end
	local ok, descs = pcall(Spring.GetActiveCmdDescs)
	if not ok or type(descs) ~= "table" then
		return true
	end
	for _, desc in ipairs(descs) do
		if desc and desc.id == cmdID then
			return true
		end
	end
	return false
end

function ControllerCameraTestAppendTacticalCommand(commands, option)
	if type(option) ~= "table" then
		return
	end
	if option.cmdID ~= nil and not ControllerCameraTestTacticalCommandAvailable(option.cmdID) then
		return
	end
	commands[#commands + 1] = option
end

--------------------------------------------------------------------------------
-- SECTION: Tactical radial
--------------------------------------------------------------------------------
function ControllerCameraTestGetTacticalCommands()
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	local isFactory = ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits)

	if isFactory then
		return {
			{ name = "Clear Queue", kind = "factory_clear" },
			{ name = "Repeat Toggle", kind = "factory_repeat" },
			{ name = "Stop", cmdID = CMD.STOP, kind = "none" },
		}
	end

	local commands = {}
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Stop", cmdID = CMD.STOP, kind = "none" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Wait", cmdID = CMD.WAIT, kind = "none" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Repeat", cmdID = CMD.REPEAT, kind = "repeat_toggle" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Move Line", cmdID = CMD.MOVE, kind = "drag_line", dragMode = "moveLine" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Fight Line", cmdID = CMD.FIGHT, kind = "drag_line", dragMode = "fightLine" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Attack Line", cmdID = CMD.ATTACK, kind = "drag_line", dragMode = "attackLine" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Reclaim Area", cmdID = CMD.RECLAIM, kind = "drag_area", dragMode = "reclaimArea" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Repair Area", cmdID = CMD.REPAIR, kind = "drag_area", dragMode = "repairArea" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Attack Area", cmdID = CMD.ATTACK, kind = "drag_area", dragMode = "attackArea" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Patrol", cmdID = CMD.PATROL, kind = "ground" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Guard", cmdID = CMD.GUARD, kind = "alliedUnit" })
	ControllerCameraTestAppendTacticalCommand(commands, { name = "Fire State", cmdID = CMD.FIRESTATE or 20, kind = "fire_state_cycle" })
	return commands
end

function ControllerCameraTestRefreshTacticalDebug()
	local menu = ControllerCameraTestTacticalMenu
	local commands = ControllerCameraTestGetTacticalCommands()
	if #commands <= 0 then
		menu.selectedIndex = 1
		menu.highlightedName = "none"
		return
	end
	if menu.selectedIndex < 1 or menu.selectedIndex > #commands then
		menu.selectedIndex = 1
	end
	local option = commands[menu.selectedIndex]
	menu.highlightedName = option and option.name or "none"
end

function ControllerCameraTestSetTacticalHighlight(index, reason)
	local menu = ControllerCameraTestTacticalMenu
	local commands = ControllerCameraTestGetTacticalCommands()
	if #commands <= 0 then
		menu.selectedIndex = 1
		menu.highlightedName = "none"
		menu.lastAction = "no tactical commands"
		return
	end
	menu.selectedIndex = ((index - 1) % #commands) + 1
	menu.lastAction = reason or "highlight changed"
	ControllerCameraTestRefreshTacticalDebug()
end

function ControllerCameraTestToggleTacticalMenu()
	local menu = ControllerCameraTestTacticalMenu
	menu.open = not menu.open
	menu.lastAction = menu.open and "opened" or "closed"
	ControllerCameraTestRefreshTacticalDebug()
	latchSelectionDebugMessage(menu.open and "RT+Y tactical menu opened" or "Tactical menu closed")
end

function ControllerCameraTestCycleTacticalCommand(delta)
	local menu = ControllerCameraTestTacticalMenu
	local commands = ControllerCameraTestGetTacticalCommands()
	if #commands <= 0 then
		menu.lastAction = "no tactical commands"
		menu.highlightedName = "none"
		return
	end
	ControllerCameraTestSetTacticalHighlight(menu.selectedIndex + delta, "highlight changed")
	latchSelectionDebugMessage("Tactical: " .. tostring(menu.highlightedName))
end

function ControllerCameraTestUpdateTacticalStickSelection()
	local menu = ControllerCameraTestTacticalMenu
	if not menu.open then
		return
	end

	local commands = ControllerCameraTestGetTacticalCommands()
	local count = #commands
	if count <= 0 then
		ControllerCameraTestRefreshTacticalDebug()
		return
	end

	local aimX = normalizedLeftX
	local aimY = -normalizedLeftY
	local magnitude = math.sqrt(aimX * aimX + aimY * aimY)
	if magnitude <= 0.5 then
		return
	end

	local angle = math.atan2(aimX, aimY)
	if angle < 0 then
		angle = angle + 2 * math.pi
	end
	menu.radialLastAngle = angle

	local segment = 2 * math.pi / count
	local adjustedAngle = angle + (segment / 2)
	if adjustedAngle >= 2 * math.pi then
		adjustedAngle = adjustedAngle - 2 * math.pi
	end

	local newIndex = math.floor(adjustedAngle / segment) + 1
	if newIndex ~= menu.selectedIndex then
		ControllerCameraTestSetTacticalHighlight(newIndex, "stick select")
	end
end

function ControllerCameraTestExecuteTacticalCommand(option)
	if type(option) ~= "table" then
		ControllerCameraTestTacticalMenu.lastResult = "no tactical option"
		return
	end

	if option.kind == "drag_line" or option.kind == "drag_area" then
		local drag = ControllerCameraTestDragCommand
		drag.active = true
		drag.mode = option.dragMode
		drag.startX, drag.startY, drag.startZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.pressActive = false
		drag.pressButton = nil
		ControllerCameraTestTacticalMenu.lastResult = "started drag: " .. tostring(option.name)
		latchSelectionDebugMessage(option.name .. " started")
		ControllerCameraTestTacticalMenu.open = false
		return
	elseif option.kind == "repeat_toggle" then
		local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
		if #selectedUnits > 0 then
			local firstUnit = selectedUnits[1]
			local states = type(Spring.GetUnitStates) == "function" and Spring.GetUnitStates(firstUnit)
			local currentRepeat = states and states["repeat"]
			local nextVal = currentRepeat and 0 or 1
			local ok, count = ControllerCameraTestIssueOrderToSelectedUnits(CMD.REPEAT, { nextVal }, "Repeat", nextVal == 1 and "ON" or "OFF", {})
			ControllerCameraTestTacticalMenu.lastResult = ok and ("toggled for " .. tostring(count)) or "failed"
		end
		ControllerCameraTestTacticalMenu.open = false
		return
	elseif option.kind == "fire_state_cycle" then
		local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
		if #selectedUnits > 0 then
			local firstUnit = selectedUnits[1]
			local states = type(Spring.GetUnitStates) == "function" and Spring.GetUnitStates(firstUnit)
			local currentFireState = states and states.firestate or 2
			local nextVal = (currentFireState + 1) % 3
			local labels = { [0] = "Hold Fire", [1] = "Return Fire", [2] = "Fire At Will" }
			local ok, count = ControllerCameraTestIssueOrderToSelectedUnits(CMD.FIRESTATE or 20, { nextVal }, "Fire State", labels[nextVal] or tostring(nextVal), {})
			ControllerCameraTestTacticalMenu.lastResult = ok and (labels[nextVal] .. " for " .. tostring(count)) or "failed"
		end
		ControllerCameraTestTacticalMenu.open = false
		return
	elseif option.kind == "factory_clear" then
		local ok, count = ControllerCameraTestIssueOrderToSelectedUnits(CMD.STOP, {}, "Clear Queue", "factory", {})
		ControllerCameraTestTacticalMenu.lastResult = ok and ("cleared " .. tostring(count) .. " factories") or "failed"
		ControllerCameraTestTacticalMenu.open = false
		return
	elseif option.kind == "factory_repeat" then
		local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
		if #selectedUnits > 0 then
			local states = type(Spring.GetUnitStates) == "function" and Spring.GetUnitStates(selectedUnits[1])
			local currentRepeat = states and states["repeat"]
			local nextVal = currentRepeat and 0 or 1
			local ok, count = ControllerCameraTestIssueOrderToSelectedUnits(CMD.REPEAT, { nextVal }, "Repeat", nextVal == 1 and "ON" or "OFF", {})
			ControllerCameraTestTacticalMenu.lastResult = ok and ("toggled repeat for " .. tostring(count)) or "failed"
		end
		ControllerCameraTestTacticalMenu.open = false
		return
	end

	if type(option.cmdID) ~= "number" then
		ControllerCameraTestTacticalMenu.lastResult = tostring(option.name) .. " unavailable"
		latchSelectionDebugMessage(tostring(option.name) .. " unavailable")
		return
	end

	local target = ControllerCameraTestGetReticleTargetInfo()
	local params = {}
	local targetName = "none"
	if option.kind == "none" then
		params = {}
	elseif option.kind == "ground" then
		if not target.hasWorld then
			ControllerCameraTestTacticalMenu.lastResult = option.name .. " failed: no ground"
			latchSelectionDebugMessage(option.name .. " failed: no ground target")
			return
		end
		params = { target.x, target.y, target.z }
		targetName = "ground"
	elseif option.kind == "attack" then
		if target.targetType == "unit" and target.targetID then
			params = { target.targetID }
			targetName = "unit " .. tostring(target.targetID)
		elseif target.hasWorld then
			params = { target.x, target.y, target.z }
			targetName = "ground"
		else
			ControllerCameraTestTacticalMenu.lastResult = "attack failed: no target"
			latchSelectionDebugMessage("Attack failed: no target")
			return
		end
	elseif option.kind == "alliedUnit" then
		if target.targetType ~= "unit" or not target.targetID or not ControllerCameraTestIsAlliedUnit(target.targetID) then
			ControllerCameraTestTacticalMenu.lastResult = option.name .. " failed: no allied unit"
			latchSelectionDebugMessage(option.name .. " failed: no allied unit target")
			return
		end
		params = { target.targetID }
		targetName = "unit " .. tostring(target.targetID)
	elseif option.kind == "reclaim" then
		if target.targetType == "feature" and target.targetID then
			params = { ControllerCameraTestFeatureCommandID(target.targetID) }
			targetName = "feature " .. tostring(target.targetID)
		elseif target.targetType == "unit" and target.targetID then
			params = { target.targetID }
			targetName = "unit " .. tostring(target.targetID)
		elseif target.hasWorld then
			params = { target.x, target.y, target.z, 120 }
			targetName = "area"
		else
			ControllerCameraTestTacticalMenu.lastResult = "reclaim failed: no target"
			latchSelectionDebugMessage("Reclaim failed: no target")
			return
		end
	elseif option.kind == "repair" then
		if target.targetType == "unit" and target.targetID and ControllerCameraTestIsAlliedUnit(target.targetID) then
			params = { target.targetID }
			targetName = "unit " .. tostring(target.targetID)
		elseif target.hasWorld then
			params = { target.x, target.y, target.z, 120 }
			targetName = "area"
		else
			ControllerCameraTestTacticalMenu.lastResult = "repair failed: no target"
			latchSelectionDebugMessage("Repair failed: no target")
			return
		end
	end

	local ok, count = ControllerCameraTestIssueOrderToSelectedUnits(option.cmdID, params, option.name, targetName)
	ControllerCameraTestTacticalMenu.lastResult = ok and ("issued to " .. tostring(count)) or "failed"
	ControllerCameraTestLayerDebug.commandLayerAction = option.name .. " " .. ControllerCameraTestTacticalMenu.lastResult
	ControllerCameraTestTacticalMenu.open = false
end

function ControllerCameraTestHandleTacticalMenuInput()
	local menu = ControllerCameraTestTacticalMenu
	if not menu.open then
		return false
	end

	ControllerCameraTestUpdateTacticalStickSelection()

	if ControllerCameraTestActionPressed("tacticalCancel") or ControllerCameraTestActionPressed("tacticalClose") then
		menu.open = false
		menu.lastAction = "cancelled"
		latchSelectionDebugMessage("Tactical menu cancelled")
	elseif WasButtonPressed("dpadUp") or WasButtonPressed("dpadLeft") or ControllerCameraTestActionPressed("radialPrevPage") then
		ControllerCameraTestCycleTacticalCommand(-1)
	elseif WasButtonPressed("dpadDown") or WasButtonPressed("dpadRight") or ControllerCameraTestActionPressed("radialNextPage") then
		ControllerCameraTestCycleTacticalCommand(1)
	elseif ControllerCameraTestActionPressed("tacticalSelect") or ControllerCameraTestActionPressed("radialQuick") then
		local commands = ControllerCameraTestGetTacticalCommands()
		ControllerCameraTestExecuteTacticalCommand(commands[menu.selectedIndex])
	end
	ControllerCameraTestRefreshTacticalDebug()
	return true
end

function ControllerCameraTestIssueGuardOrPatrol()
	local target = ControllerCameraTestGetReticleTargetInfo()
	if target.targetType == "unit" and target.targetID and ControllerCameraTestIsAlliedUnit(target.targetID) then
		ControllerCameraTestIssueOrderToSelectedUnits(CMD.GUARD, { target.targetID }, "Guard", "unit " .. tostring(target.targetID))
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+D-pad Up guard"
	elseif target.hasWorld then
		ControllerCameraTestIssueOrderToSelectedUnits(CMD.PATROL, { target.x, target.y, target.z }, "Patrol", "ground")
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+D-pad Up patrol"
	else
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+D-pad Up failed: no target"
		latchSelectionDebugMessage("Guard/Patrol failed: no target")
	end
end

function ControllerCameraTestIssueReclaimOrStop()
	local option = { name = "Reclaim", cmdID = CMD.RECLAIM, kind = "reclaim" }
	ControllerCameraTestExecuteTacticalCommand(option)
	ControllerCameraTestLayerDebug.commandLayerAction = "RT+D-pad Down reclaim"
end

function ControllerCameraTestRefreshBuildMenuDebug()
	local menu = ControllerCameraTestBuildMenu
	local options = type(menu.options) == "table" and menu.options or {}
	local option = options[menu.selectedIndex]
	menu.optionCount = #options
	if option then
		menu.highlightedName = option.name or "unnamed"
		menu.highlightedCmdID = tostring(option.cmdID)
	else
		menu.highlightedName = "none"
		menu.highlightedCmdID = "none"
	end
end

function ControllerCameraTestGetBuildOptionSummary()
	local menu = ControllerCameraTestBuildMenu
	local options = type(menu.options) == "table" and menu.options or {}
	if #options == 0 then
		return "none"
	end

	local labels = {}
	for i, option in ipairs(options) do
		local marker = (i == menu.selectedIndex) and ">" or ""
		labels[#labels + 1] = marker .. tostring(i) .. ":" .. tostring(option.name) .. " (" .. tostring(option.cmdID) .. ")"
		if i >= 12 and i < #options then
			labels[#labels + 1] = "...+" .. tostring(#options - i)
			break
		end
	end
	return table.concat(labels, ", ")
end

function ControllerCameraTestBuildOptionName(cmdID, desc)
	local unitDefID = (type(cmdID) == "number") and -cmdID or nil
	local unitDef = unitDefID and UnitDefs and UnitDefs[unitDefID]
	if unitDef then
		return unitDef.translatedHumanName or unitDef.humanName or unitDef.name or tostring(desc and desc.name or cmdID)
	end
	if desc and desc.name and desc.name ~= "" then
		return desc.name
	end
	if desc and desc.action and desc.action ~= "" then
		return desc.action
	end
	return "Build " .. tostring(unitDefID or cmdID)
end

function ControllerCameraTestClassifyBuildOption(unitDef, name)
	if not unitDef then
		return "Build"
	end

	local nameLower = string.lower(name or "")

	-- Economy Heuristic
	local isEco = unitDef.isExtractor
		or (unitDef.energyMake and unitDef.energyMake > 0)
		or (unitDef.metalMake and unitDef.metalMake > 0)
		or (unitDef.energyStorage and unitDef.energyStorage > 0)
		or (unitDef.metalStorage and unitDef.metalStorage > 0)
		or (unitDef.customParams and (unitDef.customParams.energyprod or unitDef.customParams.metalprod))
		or string.find(nameLower, "solar")
		or string.find(nameLower, "wind")
		or string.find(nameLower, "generator")
		or string.find(nameLower, "fusion")
		or string.find(nameLower, "converter")
		or string.find(nameLower, "mex")
		or string.find(nameLower, "extractor")
		or string.find(nameLower, "storage")
		or string.find(nameLower, "tidal")
		or string.find(nameLower, "geothermal")
	if isEco then
		return "Economy"
	end

	-- Combat Heuristic
	local isCombat = (unitDef.weapons and #unitDef.weapons > 0)
		or unitDef.canAttack
		or string.find(nameLower, "turret")
		or string.find(nameLower, "laser")
		or string.find(nameLower, "cannon")
		or string.find(nameLower, "artillery")
		or string.find(nameLower, "anti")
		or string.find(nameLower, "defense")
		or string.find(nameLower, "fortification")
		or string.find(nameLower, "mine")
		or string.find(nameLower, "missile")
	if isCombat then
		return "Combat"
	end

	-- Utility Heuristic
	local isUtility = (unitDef.radarRadius and unitDef.radarRadius > 0)
		or (unitDef.jammerRadius and unitDef.jammerRadius > 0)
		or (unitDef.sonarRadius and unitDef.sonarRadius > 0)
		or (unitDef.shieldRadius and unitDef.shieldRadius > 0)
		or unitDef.canRepair
		or unitDef.canRestore
		or unitDef.canTransport
		or string.find(nameLower, "radar")
		or string.find(nameLower, "jammer")
		or string.find(nameLower, "sonar")
		or string.find(nameLower, "shield")
		or string.find(nameLower, "repair")
		or string.find(nameLower, "juno")
		or string.find(nameLower, "support")
		or string.find(nameLower, "transport")
		or string.find(nameLower, "targeting")
		or string.find(nameLower, "beacon")
	if isUtility then
		return "Utility"
	end

	-- Build Heuristic
	local isBuild = unitDef.builder
		or string.find(nameLower, "lab")
		or string.find(nameLower, "factory")
		or string.find(nameLower, "gantry")
		or string.find(nameLower, "hub")
		or string.find(nameLower, "builder")
		or string.find(nameLower, "con ")
		or string.find(nameLower, "construction")
	if isBuild then
		return "Build"
	end

	return "Build"
end

function ControllerCameraTestGatherBuildOptions()
	local menu = ControllerCameraTestBuildMenu
	menu.options = {}
	menu.optionCount = 0
	menu.highlightedName = "none"
	menu.highlightedCmdID = "none"

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		menu.lastAction = "no selected units"
		ControllerCameraTestRefreshBuildMenuDebug()
		return 0
	end

	if type(Spring.GetActiveCmdDescs) ~= "function" then
		menu.lastAction = "GetActiveCmdDescs unavailable"
		ControllerCameraTestRefreshBuildMenuDebug()
		return 0
	end

	local cmdDescs = Spring.GetActiveCmdDescs()
	if type(cmdDescs) ~= "table" then
		menu.lastAction = "no active command descriptions"
		ControllerCameraTestRefreshBuildMenuDebug()
		return 0
	end

	local seen = {}
	for index, desc in ipairs(cmdDescs) do
		if type(desc) == "table" and not desc.disabled then
			local cmdID = tonumber(desc.id or desc.cmdID)
			if cmdID and cmdID < 0 and not seen[cmdID] then
				local action = tostring(desc.action or "")
				if action == "" or string.sub(action, 1, 10) == "buildunit_" or (UnitDefs and UnitDefs[-cmdID]) then
					seen[cmdID] = true
					local unitDef = UnitDefs and UnitDefs[-cmdID]
					local name = ControllerCameraTestBuildOptionName(cmdID, desc)
					local cat = ControllerCameraTestClassifyBuildOption(unitDef, name)
					menu.options[#menu.options + 1] = {
						cmdID = cmdID,
						name = name,
						index = index,
						cmdDescIndex = index,
						type = desc.type or "unknown",
						action = action,
						tooltip = desc.tooltip or "",
						unitDefID = -cmdID,
						unitDefName = unitDef and unitDef.name or "unknown",
						buildPicName = unitDef and unitDef.buildPicName or nil,
						iconTexture = "#" .. tostring(-cmdID),
						metalCost = unitDef and unitDef.metalCost or 0,
						energyCost = unitDef and unitDef.energyCost or 0,
						category = cat,
					}
				end
			end
		end
	end

	local hasEco, hasCombat, hasUtility, hasBuild = false, false, false, false
	for _, opt in ipairs(menu.options) do
		if opt.category == "Economy" then hasEco = true
		elseif opt.category == "Combat" then hasCombat = true
		elseif opt.category == "Utility" then hasUtility = true
		elseif opt.category == "Build" then hasBuild = true
		end
	end

	local cats = {}
	if hasEco then cats[#cats + 1] = "Economy" end
	if hasCombat then cats[#cats + 1] = "Combat" end
	if hasUtility then cats[#cats + 1] = "Utility" end
	if hasBuild then cats[#cats + 1] = "Build" end

	if #cats == 0 then
		cats[#cats + 1] = "Build"
	end

	menu.radialCategories = cats

	if menu.selectedIndex < 1 then
		menu.selectedIndex = 1
	elseif menu.selectedIndex > #menu.options then
		menu.selectedIndex = #menu.options
	end
	if menu.selectedIndex < 1 then
		menu.selectedIndex = 1
	end

	ControllerCameraTestRefreshBuildMenuDebug()
	return #menu.options
end

function ControllerCameraTestRefreshRadialVisibleOptions()
	local menu = ControllerCameraTestBuildMenu
	menu.radialVisibleOptions = {}

	local filterCat = menu.radialCategoryName or (menu.radialCategories and menu.radialCategories[1]) or "Build"
	local filtered = {}
	for i, option in ipairs(menu.options) do
		if option.category == filterCat then
			filtered[#filtered + 1] = option
			option.menuIndex = i
		end
	end

	if #filtered == 0 then
		filterCat = (menu.radialCategories and menu.radialCategories[1]) or "Build"
		menu.radialCategoryIndex = 1
		menu.radialCategoryName = filterCat
		for i, option in ipairs(menu.options) do
			if option.category == filterCat then
				filtered[#filtered + 1] = option
				option.menuIndex = i
			end
		end
	end

	local maxPerPage = 8
	local totalFiltered = #filtered
	menu.radialPageCount = math.max(1, math.ceil(totalFiltered / maxPerPage))

	if menu.radialPage < 1 then
		menu.radialPage = 1
	elseif menu.radialPage > menu.radialPageCount then
		menu.radialPage = menu.radialPageCount
	end

	local startIndex = (menu.radialPage - 1) * maxPerPage + 1
	local endIndex = math.min(startIndex + maxPerPage - 1, totalFiltered)

	for i = startIndex, endIndex do
		menu.radialVisibleOptions[#menu.radialVisibleOptions + 1] = filtered[i]
	end

	local currentVisibleSelected = nil
	for i, option in ipairs(menu.radialVisibleOptions) do
		if option.menuIndex == menu.selectedIndex then
			currentVisibleSelected = i
			break
		end
	end

	if not currentVisibleSelected then
		if #menu.radialVisibleOptions > 0 then
			menu.selectedIndex = menu.radialVisibleOptions[1].menuIndex
		end
	end

	ControllerCameraTestRefreshBuildMenuDebug()
end

--------------------------------------------------------------------------------
-- SECTION: Factory radial helpers
--------------------------------------------------------------------------------
function ControllerCameraTestGetFactoryQueueCounts()
	local counts = {}
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		return counts
	end

	for _, unitID in ipairs(selectedUnits) do
		local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
		if type(unitDef) == "table" and unitDef.isFactory then
			local q = type(Spring.GetFactoryCommands) == "function" and Spring.GetFactoryCommands(unitID, -1)
			if type(q) == "table" then
				for i = 1, #q do
					local cmd = q[i]
					if cmd and type(cmd.id) == "number" and cmd.id < 0 then
						counts[cmd.id] = (counts[cmd.id] or 0) + 1
					end
				end
			end
		end
	end
	return counts
end

function ControllerCameraTestRefreshFactoryQueueCounts()
	ControllerCameraTestBuildMenu.factoryQueueCounts = ControllerCameraTestGetFactoryQueueCounts()
end

function ControllerCameraTestGetFactoryQueueProgress()
	local progressByCmdID = {}
	local menu = ControllerCameraTestBuildMenu
	menu.factoryProgressKnown = "no"
	menu.factoryProgressCmdID = "none"
	menu.factoryProgressValue = "none"
	menu.factoryProgressSource = "none"
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		return progressByCmdID
	end

	for _, unitID in ipairs(selectedUnits) do
		local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
		if type(unitDef) == "table" and unitDef.isFactory then
			local unitBuildID = type(Spring.GetUnitIsBuilding) == "function" and Spring.GetUnitIsBuilding(unitID)
			if unitBuildID then
				local buildUnitDefID = type(Spring.GetUnitDefID) == "function" and Spring.GetUnitDefID(unitBuildID)
				if buildUnitDefID then
					local progress = nil
					if type(Spring.GetUnitHealth) == "function" then
						local ok, health, maxHealth, paralyzeDamage, captureProgress, buildProgress = pcall(Spring.GetUnitHealth, unitBuildID)
						if ok and type(buildProgress) == "number" then
							progress = buildProgress
							menu.factoryProgressSource = "GetUnitIsBuilding/GetUnitHealth"
						elseif ok and type(health) == "number" and type(maxHealth) == "number" and maxHealth > 0 then
							progress = health / maxHealth
							menu.factoryProgressSource = "health fallback"
						end
					end
					if progress and progress >= 0.0 and progress <= 1.0 then
						local cmdID = -buildUnitDefID
						if not progressByCmdID[cmdID] or progress > progressByCmdID[cmdID] then
							progressByCmdID[cmdID] = progress
						end
						menu.factoryProgressKnown = "yes"
						menu.factoryProgressCmdID = tostring(cmdID)
						menu.factoryProgressValue = string.format("%.2f", progress)
					end
				end
			end
		end
	end
	return progressByCmdID
end

function ControllerCameraTestRefreshFactoryQueueProgress()
	ControllerCameraTestBuildMenu.factoryQueueProgress = ControllerCameraTestGetFactoryQueueProgress()
end

function ControllerCameraTestCanAffordBuildOption(option)
	if not option then
		return false, false, false, "no option"
	end
	if type(Spring.GetMyTeamID) ~= "function" or type(Spring.GetTeamResources) ~= "function" then
		return true, true, true, "no api"
	end

	local myTeamID = Spring.GetMyTeamID()
	local metalOk, metalLevel = pcall(Spring.GetTeamResources, myTeamID, "metal")
	local energyOk, energyLevel = pcall(Spring.GetTeamResources, myTeamID, "energy")

	local currentMetal = (metalOk and type(metalLevel) == "number") and metalLevel or 0
	local currentEnergy = (energyOk and type(energyLevel) == "number") and energyLevel or 0

	local mCost = option.metalCost or 0
	local eCost = option.energyCost or 0

	local metalAffordable = currentMetal >= mCost
	local energyAffordable = currentEnergy >= eCost
	local affordable = metalAffordable and energyAffordable

	local reason = ""
	if not metalAffordable and not energyAffordable then
		reason = "both"
	elseif not metalAffordable then
		reason = "metal"
	elseif not energyAffordable then
		reason = "energy"
	end

	return affordable, metalAffordable, energyAffordable, reason
end

function ControllerCameraTestGetRadialCurrentOption()
	local menu = ControllerCameraTestBuildMenu
	if type(menu.radialVisibleOptions) == "table" and #menu.radialVisibleOptions > 0 then
		for _, option in ipairs(menu.radialVisibleOptions) do
			if option.menuIndex == menu.selectedIndex then
				return option
			end
		end
		return menu.radialVisibleOptions[1]
	end
	return type(menu.options) == "table" and menu.options[menu.selectedIndex] or nil
end

function ControllerCameraTestSetRadialHighlight(localIndex, reason)
	local menu = ControllerCameraTestBuildMenu
	local count = #menu.radialVisibleOptions
	if count <= 0 then
		return
	end

	localIndex = ((localIndex - 1) % count) + 1
	local option = menu.radialVisibleOptions[localIndex]
	if option and option.menuIndex then
		menu.selectedIndex = option.menuIndex
		menu.lastAction = reason or "radial highlight changed"
		menu.radialLastAction = reason or "radial highlight changed"
		ControllerCameraTestRefreshBuildMenuDebug()
	end
end

function ControllerCameraTestUpdateRadialStickSelection()
	local menu = ControllerCameraTestBuildMenu
	if not menu.open then
		return
	end
	if ControllerCameraTestBuildPlacement.active then
		return
	end

	local aimX = normalizedLeftX
	local aimY = -normalizedLeftY
	local magnitude = math.sqrt(aimX * aimX + aimY * aimY)
	local visibleOptions = menu.radialVisibleOptions or {}
	local visibleCount = #visibleOptions

	if visibleCount <= 0 then
		return
	end

	if magnitude > 0.5 then
		local angle = math.atan2(aimX, aimY)
		if angle < 0 then
			angle = angle + 2 * math.pi
		end
		menu.radialLastAngle = angle

		local segment = 2 * math.pi / visibleCount
		local adjustedAngle = angle + (segment / 2)
		if adjustedAngle >= 2 * math.pi then
			adjustedAngle = adjustedAngle - 2 * math.pi
		end

		local newIndex = math.floor(adjustedAngle / segment) + 1
		local option = visibleOptions[newIndex]
		if option and option.menuIndex and menu.selectedIndex ~= option.menuIndex then
			menu.selectedIndex = option.menuIndex
			menu.lastAction = "stick select"
			menu.radialLastAction = "stick select"
			ControllerCameraTestRefreshBuildMenuDebug()
		end
	end
end

--------------------------------------------------------------------------------
-- SECTION: Build radial
--------------------------------------------------------------------------------
function ControllerCameraTestOpenBuildMenu()
	local menu = ControllerCameraTestBuildMenu
	local count = ControllerCameraTestGatherBuildOptions()
	if count <= 0 then
		menu.open = false
		menu.lastAction = "no build options"
		menu.placementResult = "none"
		latchSelectionDebugMessage("Y build menu: no build options")
		ControllerCameraTestRefreshBuildMenuDebug()
		return
	end

	menu.open = true
	menu.radialCategoryIndex = 1
	menu.radialCategoryName = menu.radialCategories[1] or "Build"
	menu.radialPage = 1
	menu.radialStickArmed = true
	menu.radialLastAngle = 0
	menu.radialLastAction = "none"

	ControllerCameraTestRefreshRadialVisibleOptions()
	ControllerCameraTestRefreshFactoryQueueCounts()
	ControllerCameraTestRefreshFactoryQueueProgress()

	menu.lastAction = "opened"
	menu.placementResult = "none"
	activeButtonLayoutSummary = "Build radial: LS/D-pad select | LB/RB page/category | A place | X quick-place | B/Y close"
	latchSelectionDebugMessage("Y build menu opened: " .. tostring(count) .. " options")
	ControllerCameraTestRefreshBuildMenuDebug()
end

function ControllerCameraTestCloseBuildMenu(reason)
	local menu = ControllerCameraTestBuildMenu
	menu.open = false
	menu.lastAction = reason or "closed"
	activeButtonLayoutSummary = commandLayerActive
		and XboxController.commandLayoutSummary
		or XboxController.normalLayoutSummary
	latchSelectionDebugMessage("Build menu closed")
	ControllerCameraTestRefreshBuildMenuDebug()
end

function ControllerCameraTestToggleBuildMenu()
	if ControllerCameraTestBuildMenu.open then
		ControllerCameraTestCloseBuildMenu("closed by Y")
	else
		ControllerCameraTestOpenBuildMenu()
	end
end

function ControllerCameraTestCycleBuildOption(delta)
	local menu = ControllerCameraTestBuildMenu
	local count = #menu.options
	if count <= 0 then
		menu.lastAction = "no options to navigate"
		ControllerCameraTestRefreshBuildMenuDebug()
		return
	end

	menu.selectedIndex = ((menu.selectedIndex - 1 + delta) % count) + 1
	menu.lastAction = "highlight changed"
	ControllerCameraTestRefreshBuildMenuDebug()
	latchSelectionDebugMessage("Build option: " .. tostring(menu.highlightedName))
end

function ControllerCameraTestGetBuildFacing()
	if type(Spring.GetBuildFacing) ~= "function" then
		return 0
	end
	local facingOk, facing = pcall(Spring.GetBuildFacing)
	if facingOk and type(facing) == "number" then
		return facing
	end
	return 0
end

function ControllerCameraTestGetSnappedBuildPosition(cmdID, x, y, z, facing)
	if type(Spring.Pos2BuildPos) ~= "function" or type(cmdID) ~= "number" then
		return x, y, z
	end

	local unitDefID = -cmdID
	local snapOk, sx, sy, sz = pcall(Spring.Pos2BuildPos, unitDefID, x, y, z, facing)
	if snapOk and type(sx) == "number" and type(sy) == "number" and type(sz) == "number" then
		return sx, sy, sz
	end
	return x, y, z
end

function ControllerCameraTestIsMexBuildCommand(cmdID)
	local builder = WG and WG.resource_spot_builder
	if type(builder) ~= "table" or type(builder.GetMexBuildings) ~= "function" then
		return false
	end

	local mexBuildings = builder.GetMexBuildings()
	return type(mexBuildings) == "table" and mexBuildings[-cmdID] ~= nil
end

function ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits)
	if type(selectedUnits) ~= "table" then
		return false
	end
	for _, unitID in ipairs(selectedUnits) do
		local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
		if type(unitDef) == "table" and unitDef.isFactory then
			return true
		end
	end
	return false
end

function ControllerCameraTestTrySetNativeBuildCommand(option)
	local placement = ControllerCameraTestBuildPlacement
	if not option or not option.cmdDescIndex then
		placement.nativeSetActiveCommandResult = "failed: invalid option or cmdDescIndex"
		return false
	end
	if type(Spring.SetActiveCommand) ~= "function" then
		placement.nativeSetActiveCommandResult = "failed: SetActiveCommand API missing"
		return false
	end

	local ok, res = pcall(Spring.SetActiveCommand, option.cmdDescIndex, 1)
	if ok then
		placement.nativeSetActiveCommandResult = "success"
		placement.cmdDescIndex = option.cmdDescIndex
		return true
	else
		placement.nativeSetActiveCommandResult = "failed: " .. tostring(res)
		return false
	end
end

function ControllerCameraTestClearNativeBuildCommand()
	if type(Spring.SetActiveCommand) ~= "function" then
		return false
	end
	local ok, res = pcall(Spring.SetActiveCommand, 0)
	if not ok then
		pcall(Spring.SetActiveCommand, nil)
	end
	return true
end

function ControllerCameraTestSetPlacementOption(option)
	local placement = ControllerCameraTestBuildPlacement
	if type(option) ~= "table" or type(option.cmdID) ~= "number" or option.cmdID >= 0 then
		placement.active = false
		placement.option = nil
		placement.lastResult = "no highlighted build option"
		latchSelectionDebugMessage("Placement failed: no highlighted option")
		return false
	end

	placement.active = true
	placement.option = option
	placement.facing = ControllerCameraTestGetBuildFacing() % 4
	if type(Spring.SetBuildFacing) == "function" then
		pcall(Spring.SetBuildFacing, placement.facing)
	end
	placement.analogRotateArmed = true
	placement.placementSpacing = (type(Spring.GetBuildSpacing) == "function" and Spring.GetBuildSpacing()) or 0
	placement.placementPattern = "single"
	placement.queueFrontActive = false
	placement.lastConstructionShortcut = "none"
	placement.gridShortcutResult = "none"
	placement.lastResult = "placing " .. tostring(option.name)
	latchSelectionDebugMessage("Placement: " .. tostring(option.name))
	return true
end

function ControllerCameraTestCancelPlacement(reason)
	local placement = ControllerCameraTestBuildPlacement
	if placement.nativePreviewActive then
		ControllerCameraTestClearNativeBuildCommand()
		placement.nativePreviewActive = false
	end
	placement.active = false
	placement.option = nil
	placement.lastResult = reason or "cancelled"
	placement.lastParamsCount = 0
	placement.lastIssuedCount = 0
	placement.queueActive = false
	placement.placementMode = "none"
	placement.cmdDescIndex = nil
	placement.nativeSetActiveCommandResult = "none"
	latchSelectionDebugMessage("Placement cancelled")
end

function ControllerCameraTestRotatePlacementFacing(delta)
	local placement = ControllerCameraTestBuildPlacement
	-- Flip delta sign to fix inverted placement rotation
	local correctedDelta = -delta
	placement.facing = ((placement.facing or 0) + correctedDelta) % 4
	if type(Spring.SetBuildFacing) == "function" then
		pcall(Spring.SetBuildFacing, placement.facing)
	end
	placement.lastResult = "facing " .. tostring(placement.facing)
	latchSelectionDebugMessage("Build facing: " .. tostring(placement.facing))
end

function ControllerCameraTestTryConstructionShortcut(actionName, direction)
	local placement = ControllerCameraTestBuildPlacement
	if not placement.active then
		return false
	end

	if actionName == "spacing" then
		if direction == "inc" then
			local ok = pcall(Spring.SendCommands, "buildspacing inc")
			if ok then
				if type(Spring.GetBuildSpacing) == "function" then
					placement.placementSpacing = Spring.GetBuildSpacing() or 0
				end
				placement.lastConstructionShortcut = "spacing inc"
				placement.gridShortcutResult = "success"
				ControllerCameraTestShowPlacementPatternPopup(placement.placementPattern, "spacing")
				return true
			end
		elseif direction == "dec" then
			local ok = pcall(Spring.SendCommands, "buildspacing dec")
			if ok then
				if type(Spring.GetBuildSpacing) == "function" then
					placement.placementSpacing = Spring.GetBuildSpacing() or 0
				end
				placement.lastConstructionShortcut = "spacing dec"
				placement.gridShortcutResult = "success"
				ControllerCameraTestShowPlacementPatternPopup(placement.placementPattern, "spacing")
				return true
			end
		end
	elseif actionName == "pattern" then
		local patterns = { "single", "line", "grid", "border", "split" }
		local currentIdx = 1
		for idx, pat in ipairs(patterns) do
			if pat == placement.placementPattern then
				currentIdx = idx
				break
			end
		end

		if direction == "next" then
			currentIdx = (currentIdx % #patterns) + 1
		elseif direction == "prev" then
			currentIdx = ((currentIdx - 2) % #patterns) + 1
		end

		placement.placementPattern = patterns[currentIdx]
		placement.lastConstructionShortcut = "pattern " .. direction
		placement.gridShortcutResult = "pattern selected"
		ControllerCameraTestShowPlacementPatternPopup(placement.placementPattern, "pattern")
		return true
	end

	return false
end

function ControllerCameraTestDragModeForPlacementPattern(pattern)
	if pattern == "line" then
		return "buildLine"
	elseif pattern == "grid" then
		return "buildGrid"
	elseif pattern == "border" then
		return "buildBorder"
	elseif pattern == "split" then
		return "buildSplit"
	end
	return "buildLine"
end

function ControllerCameraTestPlacementPatternLabel(pattern)
	local labels = {
		single = "Single",
		line = "Line",
		grid = "Grid",
		border = "Border",
		split = "Split",
	}
	return labels[pattern] or tostring(pattern or "Single")
end

function ControllerCameraTestShowPlacementPatternPopup(pattern, reason)
	if ControllerCameraTestSettings.placementPopupEnabled == false then
		return
	end
	local placement = ControllerCameraTestBuildPlacement
	local label = ControllerCameraTestPlacementPatternLabel(pattern)
	local text = "Placement: " .. label
	if reason == "drag" then
		text = "Build " .. label
	elseif reason == "spacing" then
		text = "Spacing: " .. tostring(placement.placementSpacing or 0) .. " (" .. label .. ")"
	end
	ControllerCameraTestPlacementPopup.text = text
	ControllerCameraTestPlacementPopup.lastResult = text
	ControllerCameraTestPlacementPopup.expireTime = debugEventTime + 1.25
end

function ControllerCameraTestUpdatePlacementAnalog()
	local placement = ControllerCameraTestBuildPlacement
	if not placement.active then
		return
	end

	-- Right stick remains camera control during placement; facing is explicit on D-pad L/R.
	placement.analogRotateArmed = true
end

function ControllerCameraTestPlaceBuildOption(option, exitPlacement, source)
	local menu = ControllerCameraTestBuildMenu
	local queueActive = ControllerCameraTestIsQueueModifierActive()
	local orderOptions = ControllerCameraTestGetCommandOptions()
	ControllerCameraTestBuildPlacement.queueActive = queueActive
	ControllerCameraTestCommandDebug.lastOptions = ControllerCameraTestCommandOptionsSummary(orderOptions)
	if not option or type(option.cmdID) ~= "number" or option.cmdID >= 0 then
		menu.placementResult = "no highlighted build option"
		menu.placementParamsCount = 0
		ControllerCameraTestBuildPlacement.lastResult = "no highlighted build option"
		menu.lastAction = "place failed"
		latchSelectionDebugMessage("Build place failed: no highlighted option")
		ControllerCameraTestRefreshBuildMenuDebug()
		return false
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		menu.placementResult = "no selected units"
		menu.placementParamsCount = 0
		ControllerCameraTestBuildPlacement.lastResult = "no selected units"
		menu.lastAction = "place failed"
		latchSelectionDebugMessage("Build place failed: no units selected")
		ControllerCameraTestRefreshBuildMenuDebug()
		return false
	end

	if ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits) then
		local queueFrontActive = ControllerCameraTestBuildPlacement.active and ControllerCameraTestBuildPlacement.queueFrontActive
		local cmdToIssue = option.cmdID
		local paramsToIssue = {}
		local optionsToIssue = orderOptions

		if queueFrontActive then
			cmdToIssue = CMD.INSERT or 140
			paramsToIssue = { 0, option.cmdID, 0 }
			optionsToIssue = { "alt" }
		end

		local ok, issuedCount = ControllerCameraTestIssueOrderToSelectedUnits(cmdToIssue, paramsToIssue, "Factory queue " .. tostring(option.name), "queue", optionsToIssue)
		menu.placementParamsCount = #paramsToIssue
		ControllerCameraTestBuildPlacement.lastParamsCount = #paramsToIssue
		ControllerCameraTestBuildPlacement.lastIssuedCount = issuedCount
		if ok then
			menu.placementResult = queueFrontActive and ("factory prepended to " .. tostring(issuedCount)) or ("factory queued to " .. tostring(issuedCount))
			menu.lastAction = source or "factory queued"
			ControllerCameraTestBuildPlacement.lastResult = menu.placementResult
			if exitPlacement then
				if ControllerCameraTestBuildPlacement.nativePreviewActive then
					ControllerCameraTestClearNativeBuildCommand()
					ControllerCameraTestBuildPlacement.nativePreviewActive = false
				end
				ControllerCameraTestBuildPlacement.active = false
				ControllerCameraTestBuildPlacement.placementMode = "none"
				ControllerCameraTestBuildPlacement.cmdDescIndex = nil
				ControllerCameraTestBuildPlacement.nativeSetActiveCommandResult = "none"
			end
		else
			menu.placementResult = "factory queue failed"
			menu.lastAction = "queue failed"
			ControllerCameraTestBuildPlacement.lastResult = menu.placementResult
		end
		ControllerCameraTestRefreshBuildMenuDebug()
		return ok
	end

	if not reticleHasWorldTarget or not reticleWorldX or not reticleWorldY or not reticleWorldZ then
		menu.placementResult = "no world target"
		menu.placementParamsCount = 0
		ControllerCameraTestBuildPlacement.lastResult = "no world target"
		menu.lastAction = "place failed"
		latchSelectionDebugMessage("Build place failed: no world target")
		ControllerCameraTestRefreshBuildMenuDebug()
		return false
	end

	if ControllerCameraTestIsMexBuildCommand(option.cmdID)
		and ControllerCameraTestAttemptMexBuildSmartAction(reticleWorldX, reticleWorldY, reticleWorldZ, queueActive)
	then
		menu.placementResult = "mex smart action"
		menu.placementParamsCount = 4
		menu.lastAction = source or "placed mex via BAR snap"
		ControllerCameraTestBuildPlacement.lastResult = "mex smart action"
		ControllerCameraTestBuildPlacement.lastParamsCount = 4
		ControllerCameraTestBuildPlacement.lastIssuedCount = #selectedUnits
		if exitPlacement then
			if ControllerCameraTestBuildPlacement.nativePreviewActive then
				ControllerCameraTestClearNativeBuildCommand()
				ControllerCameraTestBuildPlacement.nativePreviewActive = false
			end
			ControllerCameraTestBuildPlacement.active = false
			ControllerCameraTestBuildPlacement.placementMode = "none"
			ControllerCameraTestBuildPlacement.cmdDescIndex = nil
			ControllerCameraTestBuildPlacement.nativeSetActiveCommandResult = "none"
		end
		ControllerCameraTestRefreshBuildMenuDebug()
		return true
	end

	if type(spGiveOrderToUnit) ~= "function" then
		menu.placementResult = "GiveOrderToUnit unavailable"
		menu.placementParamsCount = 0
		ControllerCameraTestBuildPlacement.lastResult = "GiveOrderToUnit unavailable"
		menu.lastAction = "place failed"
		latchSelectionDebugMessage("Build place failed: order API unavailable")
		ControllerCameraTestRefreshBuildMenuDebug()
		return false
	end

	local facing = ControllerCameraTestBuildPlacement.active and ControllerCameraTestBuildPlacement.facing or ControllerCameraTestGetBuildFacing()
	local x, y, z = ControllerCameraTestGetSnappedBuildPosition(option.cmdID, reticleWorldX, reticleWorldY, reticleWorldZ, facing)
	local params = { x, y, z, facing }
	local issuedCount = 0

	local useQueueFront = ControllerCameraTestBuildPlacement.active and ControllerCameraTestBuildPlacement.queueFrontActive
	local cmdInsert = CMD.INSERT or 140

	for _, unitID in ipairs(selectedUnits) do
		local orderOk, orderResult
		if useQueueFront then
			orderOk, orderResult = pcall(spGiveOrderToUnit, unitID, cmdInsert, { 0, option.cmdID, 0, x, y, z, facing }, { "alt" })
		else
			orderOk, orderResult = pcall(spGiveOrderToUnit, unitID, option.cmdID, params, orderOptions)
		end
		if orderOk and orderResult ~= false then
			issuedCount = issuedCount + 1
		end
	end

	if useQueueFront then
		ControllerCameraTestCommandDebug.issuedCmdID = tostring(cmdInsert) .. " (inserting " .. tostring(option.cmdID) .. ")"
		ControllerCameraTestCommandDebug.issuedParamsCount = 7
	else
		ControllerCameraTestCommandDebug.issuedCmdID = tostring(option.cmdID)
		ControllerCameraTestCommandDebug.issuedParamsCount = #params
	end
	menu.placementParamsCount = useQueueFront and 7 or #params
	ControllerCameraTestBuildPlacement.lastParamsCount = useQueueFront and 7 or #params
	ControllerCameraTestBuildPlacement.lastIssuedCount = issuedCount
	if issuedCount > 0 then
		lastIssuedCommand = useQueueFront and ("Build menu prepend: " .. tostring(option.name)) or ("Build menu: " .. tostring(option.name))
		menu.placementResult = useQueueFront and ("prepended to " .. tostring(issuedCount) .. " units") or ("issued to " .. tostring(issuedCount) .. " units")
		menu.lastAction = source or "placed"
		ControllerCameraTestBuildPlacement.lastResult = menu.placementResult
		ControllerCameraTestCommandDebug.lastResult = "build menu GiveOrderToUnit"
		latchSelectionDebugMessage(useQueueFront and ("Build prepended: " .. tostring(option.name)) or ("Build placed: " .. tostring(option.name)))
		ControllerCameraTestSetCommandMarker(x, y, z, "Build", "build")
		if exitPlacement then
			if ControllerCameraTestBuildPlacement.nativePreviewActive then
				ControllerCameraTestClearNativeBuildCommand()
				ControllerCameraTestBuildPlacement.nativePreviewActive = false
			end
			ControllerCameraTestBuildPlacement.active = false
			ControllerCameraTestBuildPlacement.placementMode = "none"
			ControllerCameraTestBuildPlacement.cmdDescIndex = nil
			ControllerCameraTestBuildPlacement.nativeSetActiveCommandResult = "none"
		end
		ControllerCameraTestRefreshBuildMenuDebug()
		return true
	else
		menu.placementResult = "no orders accepted"
		menu.lastAction = "place failed"
		ControllerCameraTestBuildPlacement.lastResult = "no orders accepted"
		ControllerCameraTestCommandDebug.lastResult = "build menu failed"
		latchSelectionDebugMessage("Build place failed: no orders accepted")
	end
	ControllerCameraTestRefreshBuildMenuDebug()
	return false
end

function ControllerCameraTestPlaceHighlightedBuildOption(exitPlacement, source)
	local menu = ControllerCameraTestBuildMenu
	local option = type(menu.options) == "table" and menu.options[menu.selectedIndex] or nil
	return ControllerCameraTestPlaceBuildOption(option, exitPlacement, source)
end

function ControllerCameraTestDequeueFactoryBuildOption(option)
	local menu = ControllerCameraTestBuildMenu
	if not option or type(option.cmdID) ~= "number" or option.cmdID >= 0 then
		menu.lastAction = "dequeue failed: invalid option"
		menu.radialLastAction = "dequeue failed: invalid option"
		return false
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if #selectedUnits == 0 then
		menu.lastAction = "dequeue failed: no selected units"
		menu.radialLastAction = "dequeue failed: no selected units"
		return false
	end

	if not ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits) then
		menu.lastAction = "dequeue failed: not a factory"
		menu.radialLastAction = "dequeue failed: not a factory"
		return false
	end

	local queueActive = ControllerCameraTestIsQueueModifierActive()
	local optionsToIssue = { "right" }
	if queueActive then
		optionsToIssue = { "right", "shift" }
	end

	local ok, issuedCount = ControllerCameraTestIssueOrderToSelectedUnits(option.cmdID, {}, "Factory dequeue " .. tostring(option.name), "queue", optionsToIssue)
	if ok then
		menu.lastAction = queueActive and "factory dequeued 5 (B)" or "factory dequeued (B)"
		menu.radialLastAction = menu.lastAction
		ControllerCameraTestRefreshFactoryQueueCounts()
		ControllerCameraTestRefreshFactoryQueueProgress()
		return true
	else
		menu.lastAction = "factory dequeue failed"
		menu.radialLastAction = "factory dequeue failed"
		return false
	end
end

function ControllerCameraTestEnterPlacementFromHighlight()
	local menu = ControllerCameraTestBuildMenu
	local option = type(menu.options) == "table" and menu.options[menu.selectedIndex] or nil
	if not option then
		menu.lastAction = "placement failed: no option"
		ControllerCameraTestRefreshBuildMenuDebug()
		return
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	if ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits) then
		local placement = ControllerCameraTestBuildPlacement
		placement.placementMode = "factory-queue"
		ControllerCameraTestPlaceBuildOption(option, true, "factory queued from menu")
		return
	end

	-- Try native placement first for buildings/structures (non-mobile units)
	local placement = ControllerCameraTestBuildPlacement
	placement.nativePreviewActive = false

	local tryNative = false
	local unitDef = option.unitDefID and UnitDefs and UnitDefs[option.unitDefID]
	if unitDef and not unitDef.isMobile then
		tryNative = true
	end

	if tryNative then
		if ControllerCameraTestTrySetNativeBuildCommand(option) then
			placement.active = true
			placement.option = option
			placement.facing = ControllerCameraTestGetBuildFacing() % 4
			if type(Spring.SetBuildFacing) == "function" then
				pcall(Spring.SetBuildFacing, placement.facing)
			end
			placement.analogRotateArmed = true
			placement.nativePreviewActive = true
			placement.lastResult = "native placement active"
			placement.placementMode = "native"
			placement.placementSpacing = (type(Spring.GetBuildSpacing) == "function" and Spring.GetBuildSpacing()) or 0
			placement.placementPattern = "single"
			placement.queueFrontActive = false
			placement.lastConstructionShortcut = "none"
			placement.gridShortcutResult = "none"
			menu.lastAction = "entered native placement"
			latchSelectionDebugMessage("Placement: " .. tostring(option.name) .. " (native)")
			ControllerCameraTestRefreshBuildMenuDebug()
			return
		end
	end

	-- Fallback to existing custom placement logic
	if ControllerCameraTestSetPlacementOption(option) then
		placement.nativePreviewActive = false
		placement.placementMode = "custom"
		placement.placementSpacing = (type(Spring.GetBuildSpacing) == "function" and Spring.GetBuildSpacing()) or 0
		placement.placementPattern = "single"
		placement.queueFrontActive = false
		placement.lastConstructionShortcut = "none"
		placement.gridShortcutResult = "none"
		menu.lastAction = "entered custom placement"
	else
		menu.lastAction = "placement failed"
	end
	ControllerCameraTestRefreshBuildMenuDebug()
end

function ControllerCameraTestHandlePlacementInput(dt)
	local placement = ControllerCameraTestBuildPlacement
	if not placement.active then
		return false
	end

	placement.queueActive = ControllerCameraTestIsQueueModifierActive()
	placement.queueFrontActive = normalizedRightTrigger > 0
	ControllerCameraTestUpdatePlacementAnalog()

	local drag = ControllerCameraTestDragCommand

	if ControllerCameraTestActionPressed("cancelPlacement") then
		if drag.active then
			ControllerCameraTestCancelDrag("cancelled by B")
		else
			ControllerCameraTestCancelPlacement("cancelled by B")
		end
	elseif ControllerCameraTestActionPressed("place") or ControllerCameraTestActionPressed("placeStay") then
		local button = ControllerCameraTestActionPressed("place") and "place" or "placeStay"
		local isExit = (button == "place")
		if placement.placementPattern == "single" then
			ControllerCameraTestPlaceBuildOption(placement.option, isExit, "placed and " .. (isExit and "exited" or "remained"))
		else
			if drag.active then
				ControllerCameraTestConfirmDragBuild(isExit)
			else
				drag.active = true
				drag.pressActive = true
				drag.pressStartTime = debugEventTime
				drag.pressButton = button
				drag.mode = ControllerCameraTestDragModeForPlacementPattern(placement.placementPattern)
				drag.startX, drag.startY, drag.startZ = reticleWorldX, reticleWorldY, reticleWorldZ
				drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
				drag.previewPoints = {}
				ControllerCameraTestShowPlacementPatternPopup(placement.placementPattern, "drag")
				latchSelectionDebugMessage(placement.placementPattern:gsub("^%l", string.upper) .. " drag build started")
			end
		end
	end

	if drag.active and drag.pressActive and (drag.pressButton == "place" or drag.pressButton == "placeStay") then
		local btn = drag.pressButton
		if ControllerCameraTestActionDown(btn) then
			ControllerCameraTestUpdateDragPreview()
		end
		if ControllerCameraTestActionReleased(btn) then
			if (debugEventTime - drag.pressStartTime) >= 0.35 then
				local isExit = (btn == "place")
				ControllerCameraTestConfirmDragBuild(isExit)
			end
			drag.pressActive = false
		end
	elseif drag.active then
		ControllerCameraTestUpdateDragPreview()
	end

	if drag.active then
		local changed = false
		if ControllerCameraTestActionPressed("rotateBuildingLeft") then
			ControllerCameraTestRotatePlacementFacing(-1)
			changed = true
		elseif ControllerCameraTestActionPressed("rotateBuildingRight") then
			ControllerCameraTestRotatePlacementFacing(1)
			changed = true
		elseif ControllerCameraTestActionPressed("patternPrev") then
			changed = ControllerCameraTestTryConstructionShortcut("pattern", "prev")
		elseif ControllerCameraTestActionPressed("patternNext") then
			changed = ControllerCameraTestTryConstructionShortcut("pattern", "next")
		elseif ControllerCameraTestActionPressed("spacingUp") then
			changed = ControllerCameraTestTryConstructionShortcut("spacing", "inc")
		elseif ControllerCameraTestActionPressed("spacingDown") then
			changed = ControllerCameraTestTryConstructionShortcut("spacing", "dec")
		end
		if changed then
			drag.mode = ControllerCameraTestDragModeForPlacementPattern(placement.placementPattern)
			ControllerCameraTestUpdateDragPreview()
		end
	end

	if not drag.active then
		if ControllerCameraTestActionPressed("rotateBuildingLeft") then
			ControllerCameraTestRotatePlacementFacing(-1)
		elseif ControllerCameraTestActionPressed("rotateBuildingRight") then
			ControllerCameraTestRotatePlacementFacing(1)
		elseif ControllerCameraTestActionPressed("radialClose") then
			ControllerCameraTestCancelPlacement("cancelled by Y")
		elseif ControllerCameraTestActionPressed("patternPrev") then
			ControllerCameraTestTryConstructionShortcut("pattern", "prev")
		elseif ControllerCameraTestActionPressed("patternNext") then
			ControllerCameraTestTryConstructionShortcut("pattern", "next")
		elseif ControllerCameraTestActionPressed("spacingUp") then
			ControllerCameraTestTryConstructionShortcut("spacing", "inc")
		elseif ControllerCameraTestActionPressed("spacingDown") then
			ControllerCameraTestTryConstructionShortcut("spacing", "dec")
		end
	end

	if drag.active then
		activeButtonLayoutSummary = "Drag Build: A/X confirm, B cancel, RS X camera, D-pad L/R facing, U/D spacing, LB/RB pattern"
	else
		activeButtonLayoutSummary = "Placement: A place+exit, X place again, B cancel, RS X camera, D-pad L/R facing, U/D spacing, LB/RB pattern"
	end
	return true
end

function ControllerCameraTestHandleBuildMenuInput()
	local menu = ControllerCameraTestBuildMenu
	if not menu.open then
		return false
	end

	if ControllerCameraTestBuildPlacement.active then
		return false
	end

	local currentLocalIndex = 1
	for idx, option in ipairs(menu.radialVisibleOptions or {}) do
		if option.menuIndex == menu.selectedIndex then
			currentLocalIndex = idx
			break
		end
	end

	local categories = menu.radialCategories or { "Economy", "Combat", "Utility", "Build" }

	if ControllerCameraTestActionPressed("radialCancel") then
		local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
		if ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits) then
			local option = type(menu.options) == "table" and menu.options[menu.selectedIndex] or nil
			if option then
				ControllerCameraTestDequeueFactoryBuildOption(option)
			else
				menu.lastAction = "factory dequeue failed: no option"
				menu.radialLastAction = "factory dequeue failed: no option"
			end
		else
			ControllerCameraTestCloseBuildMenu("closed by B")
		end
	elseif ControllerCameraTestActionPressed("radialClose") then
		ControllerCameraTestCloseBuildMenu("closed by Y")
	elseif ControllerCameraTestActionPressed("radialSelect") then
		local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
		if ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits) then
			local option = type(menu.options) == "table" and menu.options[menu.selectedIndex] or nil
			if option then
				local queueActive = ControllerCameraTestIsQueueModifierActive()
				local queueFrontActive = normalizedRightTrigger > 0
				local orderOptions = ControllerCameraTestGetCommandOptions()

				local cmdToIssue = option.cmdID
				local paramsToIssue = {}
				local optionsToIssue = orderOptions

				if queueFrontActive then
					cmdToIssue = CMD.INSERT or 140
					paramsToIssue = { 0, option.cmdID, 0 }
					optionsToIssue = { "alt" }
				end

				ControllerCameraTestBuildPlacement.queueActive = queueActive
				ControllerCameraTestBuildPlacement.queueFrontActive = queueFrontActive
				local ok, issuedCount = ControllerCameraTestIssueOrderToSelectedUnits(cmdToIssue, paramsToIssue, "Factory queue " .. tostring(option.name), "queue", optionsToIssue)
				if ok then
					menu.lastAction = queueFrontActive and "factory prepended (A)" or "factory queued (A)"
					menu.radialLastAction = menu.lastAction
					ControllerCameraTestRefreshFactoryQueueCounts()
					ControllerCameraTestRefreshFactoryQueueProgress()
				else
					menu.lastAction = "factory queue failed (A)"
					menu.radialLastAction = "factory queue failed (A)"
				end
			end
		else
			ControllerCameraTestEnterPlacementFromHighlight()
			ControllerCameraTestCloseBuildMenu("entered placement")
		end
	elseif ControllerCameraTestActionPressed("radialQuick") then
		ControllerCameraTestPlaceHighlightedBuildOption(false, "quick placed from radial")
	elseif WasButtonPressed("dpadDown") or WasButtonPressed("dpadRight") then
		ControllerCameraTestSetRadialHighlight(currentLocalIndex + 1, "dpad next")
	elseif WasButtonPressed("dpadUp") or WasButtonPressed("dpadLeft") then
		ControllerCameraTestSetRadialHighlight(currentLocalIndex - 1, "dpad prev")
	elseif ControllerCameraTestActionPressed("radialPrevPage") then
		if menu.radialPage > 1 then
			menu.radialPage = menu.radialPage - 1
			ControllerCameraTestRefreshRadialVisibleOptions()
		else
			menu.radialCategoryIndex = ((menu.radialCategoryIndex - 2) % #categories) + 1
			menu.radialCategoryName = categories[menu.radialCategoryIndex]
			menu.radialPage = 1
			ControllerCameraTestRefreshRadialVisibleOptions()
			if #menu.radialVisibleOptions > 0 then
				menu.selectedIndex = menu.radialVisibleOptions[1].menuIndex
			end
		end
		menu.lastAction = "category/page prev"
	elseif ControllerCameraTestActionPressed("radialNextPage") then
		if menu.radialPage < menu.radialPageCount then
			menu.radialPage = menu.radialPage + 1
			ControllerCameraTestRefreshRadialVisibleOptions()
		else
			menu.radialCategoryIndex = (menu.radialCategoryIndex % #categories) + 1
			menu.radialCategoryName = categories[menu.radialCategoryIndex]
			menu.radialPage = 1
			ControllerCameraTestRefreshRadialVisibleOptions()
			if #menu.radialVisibleOptions > 0 then
				menu.selectedIndex = menu.radialVisibleOptions[1].menuIndex
			end
		end
		menu.lastAction = "category/page next"
	end

	activeButtonLayoutSummary = "Build radial: LS/D-pad select | LB/RB page/category | A place | X quick-place | B/Y close"
	ControllerCameraTestRefreshBuildMenuDebug()
	return true
end

function ControllerCameraTestCancelAreaSelect(reason)
	local area = ControllerCameraTestAreaSelect
	area.pressActive = false
	area.active = false
	area.lastResult = reason or "cancelled"
	ControllerCameraTestLayerDebug.areaSelect = area.lastResult
end

function ControllerCameraTestUpdateAreaRadius(dt)
	local area = ControllerCameraTestAreaSelect
	local radiusDelta = 0
	if normalizedRightY ~= 0 then
		radiusDelta = radiusDelta + (-normalizedRightY * 520 * (dt or 0))
	end
	if WasButtonPressed("dpadUp") or WasButtonPressed("dpadRight") then
		radiusDelta = radiusDelta + 80
	elseif WasButtonPressed("dpadDown") or WasButtonPressed("dpadLeft") then
		radiusDelta = radiusDelta - 80
	end
	if radiusDelta ~= 0 then
		area.radius = clamp(area.radius + radiusDelta, 120, 1200)
		ControllerCameraTestSettings.areaSelectRadius = area.radius
	end
end

function ControllerCameraTestSelectAreaUnits()
	local area = ControllerCameraTestAreaSelect
	if not reticleHasWorldTarget or not reticleWorldX or not reticleWorldZ then
		area.lastResult = "no world target"
		area.lastCount = 0
		ControllerCameraTestLayerDebug.areaSelect = area.lastResult
		latchSelectionDebugMessage("Area select failed: no world target")
		return
	end
	if type(spGetUnitPosition) ~= "function" then
		area.lastResult = "unit position API unavailable"
		area.lastCount = 0
		ControllerCameraTestLayerDebug.areaSelect = area.lastResult
		latchSelectionDebugMessage("Area select failed: position API unavailable")
		return
	end

	local radiusSq = area.radius * area.radius
	local units = {}
	for _, unitID in ipairs(ControllerCameraTestGetVisibleAlliedUnits()) do
		local x, _, z = spGetUnitPosition(unitID)
		if x and z then
			local dx = x - reticleWorldX
			local dz = z - reticleWorldZ
			if ((dx * dx) + (dz * dz)) <= radiusSq then
				units[#units + 1] = unitID
			end
		end
	end

	local includeBuildings = ControllerCameraTestIsQueueModifierActive()
	local filteredUnits = ControllerCameraTestFilterAreaSelection(units, includeBuildings)
	area.filterMode = includeBuildings and "include buildings" or "units-first"
	area.lastCount = #filteredUnits
	if ControllerCameraTestSelectUnits(filteredUnits, "Area select") then
		area.lastResult = "selected " .. tostring(#filteredUnits) .. " (" .. tostring(area.filterMode) .. ")"
	else
		area.lastResult = "no units selected"
	end
	ControllerCameraTestLayerDebug.areaSelect = area.lastResult
end

function ControllerCameraTestFilterAreaSelection(unitIDs, includeBuildings)
	if type(unitIDs) ~= "table" then
		return {}
	end
	if includeBuildings then
		return ControllerCameraTestFilterValidUnits(unitIDs)
	end

	local mobileUnits = {}
	local buildingUnits = {}
	for _, unitID in ipairs(unitIDs) do
		local _, unitDef = ControllerCameraTestGetUnitDef(unitID)
		if ControllerCameraTestIsMobileUnitDef(unitDef) then
			mobileUnits[#mobileUnits + 1] = unitID
		else
			buildingUnits[#buildingUnits + 1] = unitID
		end
	end

	if #mobileUnits > 0 then
		return ControllerCameraTestFilterValidUnits(mobileUnits)
	end
	return ControllerCameraTestFilterValidUnits(buildingUnits)
end

function ControllerCameraTestHandleNormalXInput(dt)
	local drag = ControllerCameraTestDragCommand
	local HOLD_SECONDS = ControllerCameraTestSettings.xHoldSeconds or 0.14

	if drag.active and ControllerCameraTestActionPressed("cancel") then
		ControllerCameraTestCancelDrag("cancelled by B")
		return true
	end

	if ControllerCameraTestActionPressed("smartAction") then
		drag.pressActive = true
		drag.pressStartTime = debugEventTime
		drag.pressButton = "smartAction"
		drag.startX, drag.startY, drag.startZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.active = false
		drag.singleUnitPathActive = false
		drag.singleUnitPathUnitID = nil
	end

	if drag.pressActive and drag.pressButton == "smartAction" and ControllerCameraTestActionDown("smartAction") then
		if not drag.active and (debugEventTime - drag.pressStartTime) >= HOLD_SECONDS then
			local mobileUnits = ControllerCameraTestGetSelectedMobileUnits()
			local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
			if #selectedUnits == 1 and #mobileUnits == 1 and reticleHasWorldTarget then
				ControllerCameraTestStartSingleUnitPath(mobileUnits[1])
			else
				drag.active = true
				drag.mode = "moveLine"
				drag.lastResult = "active"
				latchSelectionDebugMessage("Move Line Drag started")
			end
		end
		if drag.active and drag.mode ~= "singleMovePath" then
			ControllerCameraTestUpdateDragPreview()
		end
	end

	if ControllerCameraTestActionReleased("smartAction") and drag.pressActive and drag.pressButton == "smartAction" then
		if drag.singleUnitPathActive then
			ControllerCameraTestFinishSingleUnitPath()
		elseif drag.active then
			ControllerCameraTestConfirmDragCommand(false)
		else
			attemptContextCommand()
		end
		drag.pressActive = false
	end

	return drag.pressActive or drag.active
end

function ControllerCameraTestHandleCommandLayerDragInputs(dt)
	local drag = ControllerCameraTestDragCommand
	local X_HOLD_SECONDS = ControllerCameraTestSettings.xHoldSeconds or 0.14
	local A_HOLD_SECONDS = 0.35

	if drag.active and ControllerCameraTestActionPressed("cancel") then
		ControllerCameraTestCancelDrag("cancelled by B")
		return true
	end

	if ControllerCameraTestActionPressed("smartAction") then
		drag.pressActive = true
		drag.pressStartTime = debugEventTime
		drag.pressButton = "RT+X"
		drag.startX, drag.startY, drag.startZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.active = false
	end

	if drag.pressActive and drag.pressButton == "RT+X" and ControllerCameraTestActionDown("smartAction") then
		if not drag.active and (debugEventTime - drag.pressStartTime) >= X_HOLD_SECONDS then
			drag.active = true
			drag.mode = "fightLine"
			drag.lastResult = "active"
			latchSelectionDebugMessage("Fight Line Drag started")
		end
		if drag.active then
			ControllerCameraTestUpdateDragPreview()
		end
	end

	if ControllerCameraTestActionReleased("smartAction") and drag.pressActive and drag.pressButton == "RT+X" then
		if drag.active then
			ControllerCameraTestConfirmDragCommand(false)
		else
			attemptAttackCommand()
		end
		drag.pressActive = false
	end

	if ControllerCameraTestActionPressed("select") then
		drag.pressActive = true
		drag.pressStartTime = debugEventTime
		drag.pressButton = "RT+A"
		drag.startX, drag.startY, drag.startZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.endX, drag.endY, drag.endZ = reticleWorldX, reticleWorldY, reticleWorldZ
		drag.active = false
	end

	if drag.pressActive and drag.pressButton == "RT+A" and ControllerCameraTestActionDown("select") then
		if not drag.active and (debugEventTime - drag.pressStartTime) >= A_HOLD_SECONDS then
			drag.active = true
			drag.mode = "attackLine"
			drag.lastResult = "active"
			latchSelectionDebugMessage("Attack Line Drag started")
		end
		if drag.active then
			ControllerCameraTestUpdateDragPreview()
		end
	end

	if ControllerCameraTestActionReleased("select") and drag.pressActive and drag.pressButton == "RT+A" then
		if drag.active then
			ControllerCameraTestConfirmDragCommand(false)
		else
			ControllerCameraTestLayerDebug.commandLayerAction = "RT+A select-all disabled"
			ControllerCameraTestCycleDebug.lastResult = "RT+A select-all disabled"
			latchSelectionDebugMessage("RT+A reserved: select-all disabled")
		end
		drag.pressActive = false
	end

	return drag.pressActive or drag.active
end

function ControllerCameraTestHandleNormalAInput(dt)
	local area = ControllerCameraTestAreaSelect
	local HOLD_SECONDS = ControllerCameraTestSettings.aHoldSeconds or 0.38

	if ControllerCameraTestActionPressed("select") then
		area.pressActive = true
		area.active = false
		area.pressStartTime = debugEventTime
		area.lastResult = "press started"
		ControllerCameraTestLayerDebug.areaSelect = area.lastResult
	end

	if area.pressActive and ControllerCameraTestActionDown("select") then
		if not area.active and (debugEventTime - area.pressStartTime) >= HOLD_SECONDS then
			area.active = true
			area.lastResult = "active"
			ControllerCameraTestLayerDebug.areaSelect = "active radius " .. tostring(math.floor(area.radius))
			latchSelectionDebugMessage("Area select active")
		end
		if area.active then
			ControllerCameraTestUpdateAreaRadius(dt)
			ControllerCameraTestLayerDebug.areaSelect = "active radius " .. tostring(math.floor(area.radius))
		end
	end

	if ControllerCameraTestActionReleased("select") and area.pressActive then
		if area.active then
			ControllerCameraTestSelectAreaUnits()
		elseif (debugEventTime - (area.lastTapTime or -10)) <= 0.35 then
			local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
			local targetID = ControllerCameraTestGetReticleAlliedUnitAndDef()
			if targetID and ControllerCameraTestIsQueueModifierActive() then
				ControllerCameraTestSelectAllOwnedSameTypeUnderReticle()
			elseif targetID then
				ControllerCameraTestSelectVisibleSameTypeUnderReticle()
			elseif IsButtonDown("back") then
				if ControllerCameraTestFocusCommander() then
					ControllerCameraTestAreaSelect.doubleTapAction = "Back+double-tap commander focused"
				else
					ControllerCameraTestAreaSelect.doubleTapAction = "Back+double-tap commander failed"
				end
			elseif ControllerCameraTestIsQueueModifierActive() then
				ControllerCameraTestSelectAllIdleUnitsInCurrentTypeBucket()
				ControllerCameraTestAreaSelect.doubleTapAction = ControllerCameraTestIdleCycle.lastResult
			elseif #selectedUnits == 0 then
				ControllerCameraTestAreaSelect.lastResult = "double tap empty ignored"
				ControllerCameraTestAreaSelect.doubleTapAction = "empty ignored"
				ControllerCameraTestLayerDebug.normalUtilityAction = "Double-tap empty ignored"
				latchSelectionDebugMessage("Double-tap A empty: no action")
			else
				ControllerCameraTestAreaSelect.lastResult = "double tap ignored: units selected"
				ControllerCameraTestAreaSelect.doubleTapAction = "ignored: units selected"
				ControllerCameraTestLayerDebug.normalUtilityAction = "Double-tap A ignored"
				latchSelectionDebugMessage("Double-tap A ignored: units already selected")
			end
			area.lastTapTime = -10
		else
			attemptReticleSelection()
			area.lastTapTime = debugEventTime
		end
		area.pressActive = false
		area.active = false
	end

	return area.pressActive or area.active
end

local function attemptBuildMenu()
	ControllerCameraTestToggleBuildMenu()
end

function ControllerCameraTestSetLayerAction(message)
	ControllerCameraTestLayerDebug.commandLayerAction = message
	lastIssuedCommand = message
	latchSelectionDebugMessage(message)
end

local function attemptCommandWheel()
	ControllerCameraTestToggleTacticalMenu()
end

function ControllerCameraTestSetNormalUtilityAction(message)
	ControllerCameraTestLayerDebug.normalUtilityAction = message
	lastIssuedCommand = message
	latchSelectionDebugMessage(message)
end

function ControllerCameraTestHandleCommandLayerInput(dt)
	if ControllerCameraTestHandleTacticalMenuInput() then
		return
	end

	if ControllerCameraTestHandleCommandLayerDragInputs(dt) then
		return
	end

	if ControllerCameraTestActionPressed("select") then
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+A select-all disabled"
		ControllerCameraTestCycleDebug.lastResult = "RT+A select-all disabled"
		latchSelectionDebugMessage("RT+A reserved: select-all disabled")
	elseif ControllerCameraTestActionPressed("cancel") then
		attemptStopCommand()
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+B stop"
	elseif ControllerCameraTestActionPressed("smartAction") then
		attemptAttackCommand()
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+X attack/attack-move"
	elseif ControllerCameraTestActionPressed("buildRadial") then
		ControllerCameraTestToggleTacticalMenu()
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+Y tactical menu"
	elseif ControllerCameraTestActionPressed("commandUp") then
		ControllerCameraTestIssueGuardOrPatrol()
	elseif ControllerCameraTestActionPressed("commandDown") then
		ControllerCameraTestIssueReclaimOrStop()
	elseif ControllerCameraTestActionPressed("commandLeft") then
		if not ControllerCameraTestCycleQuickGroup(-1) then
			ControllerCameraTestCycleSelection(-1)
			ControllerCameraTestLayerDebug.commandLayerAction = "RT+D-pad Left cycle selection"
		end
	elseif ControllerCameraTestActionPressed("commandRight") then
		if not ControllerCameraTestCycleQuickGroup(1) then
			ControllerCameraTestCycleSelection(1)
			ControllerCameraTestLayerDebug.commandLayerAction = "RT+D-pad Right cycle selection"
		end
	elseif ControllerCameraTestActionPressed("pitchModifier") then
		ControllerCameraTestCycleSelection(-1)
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+LB previous selection"
	elseif ControllerCameraTestActionPressed("controlGroupModifier") then
		ControllerCameraTestCycleSelection(1)
		ControllerCameraTestLayerDebug.commandLayerAction = "RT+RB next selection"
	end
end

function ControllerCameraTestUpdateLBTapState()
	if commandLayerActive
		or ControllerCameraTestBuildMenu.open
		or ControllerCameraTestBuildPlacement.active
		or ControllerCameraTestAreaSelect.active
	then
		ControllerCameraTestCycleDebug.lbPressActive = false
		ControllerCameraTestCycleDebug.lbHadPitchMotion = false
		return
	end

	if ControllerCameraTestActionPressed("pitchModifier") then
		ControllerCameraTestCycleDebug.lbPressActive = true
		ControllerCameraTestCycleDebug.lbHadPitchMotion = false
	end
	if ControllerCameraTestActionDown("pitchModifier") and math.abs(normalizedRightY) > 0.2 then
		ControllerCameraTestCycleDebug.lbHadPitchMotion = true
	end
end

function ControllerCameraTestCanUseTuningControls()
	return not commandLayerActive
		and not ControllerCameraTestBuildMenu.open
		and not ControllerCameraTestBuildPlacement.active
		and not ControllerCameraTestTacticalMenu.open
		and not ControllerCameraTestAreaSelect.active
		and not ControllerCameraTestAreaSelect.pressActive
end

function ControllerCameraTestHandleBackViewControls()
	if WasButtonPressed("back") then
		ControllerCameraTestTuning.backHeld = true
		ControllerCameraTestTuning.backComboUsed = false
		ControllerCameraTestTuning.lastAction = "Back/View reserved for gameplay"
		ControllerCameraTestLayerDebug.normalUtilityAction = "Back/View modifier ready"
	end
	if WasButtonReleased("back") and ControllerCameraTestTuning.backHeld then
		ControllerCameraTestTuning.backHeld = false
		ControllerCameraTestTuning.backComboUsed = false
	end
	return false
end

function ControllerCameraTestHandleNormalUtilityInput()
	if ControllerCameraTestHandleControlGroupInput() then
		return true
	elseif ControllerCameraTestActionDown("pitchModifier") and ControllerCameraTestActionPressed("idlePrev") then
		ControllerCameraTestCycleDebug.lbHadPitchMotion = true
		ControllerCameraTestCycleIdleUnitType(-1)
	elseif ControllerCameraTestActionDown("pitchModifier") and ControllerCameraTestActionPressed("idleNext") then
		ControllerCameraTestCycleDebug.lbHadPitchMotion = true
		ControllerCameraTestCycleIdleUnitType(1)
	elseif ControllerCameraTestActionReleased("pitchModifier") and ControllerCameraTestCycleDebug.lbPressActive then
		if not ControllerCameraTestCycleDebug.lbHadPitchMotion then
			ControllerCameraTestCycleSelection(-1)
			ControllerCameraTestLayerDebug.normalUtilityAction = "LB tap cycle selection"
		end
		ControllerCameraTestCycleDebug.lbPressActive = false
		ControllerCameraTestCycleDebug.lbHadPitchMotion = false
	elseif WasButtonPressed("dpadUp") then
		ControllerCameraTestHandleBookmarkButton("up")
	elseif WasButtonPressed("dpadDown") then
		ControllerCameraTestHandleBookmarkButton("down")
	elseif ControllerCameraTestActionPressed("idlePrev") then
		ControllerCameraTestCycleIdleUnit(-1)
	elseif ControllerCameraTestActionPressed("idleNext") then
		ControllerCameraTestCycleIdleUnit(1)
	elseif WasButtonPressed("start") then
		ControllerCameraTestSetNormalUtilityAction("Start/Menu reserved")
	end
	return false
end

function ControllerCameraTestGetModeSummary()
	if ControllerCameraTestSettingsUI.open then
		return "settings"
	end
	if commandLayerActive then
		if ControllerCameraTestTacticalMenu.open then
			return "tactical menu"
		end
		return "command layer"
	end
	if ControllerCameraTestBuildPlacement.active then
		return "placement"
	end
	if ControllerCameraTestBuildMenu.open then
		return "build menu"
	end
	if ControllerCameraTestAreaSelect.active then
		return "area select"
	end
	if ControllerCameraTestTuning.backHeld then
		return "back modifier"
	end
	if ControllerCameraTestActionDown("controlGroupModifier") then
		return "control groups"
	end
	if ControllerCameraTestSettings.helpOverlayVisible then
		return "help overlay"
	end
	if controllerMode then
		return "normal"
	end
	return "mouse"
end


local function applySpringZoom(cameraState, zoomInput, dt)
	if type(cameraState.dist) ~= "number" then
		return false
	end

	local scale = 1 - (zoomInput * ZOOM_SCALE_SPEED * (dt or 0))
	cameraState.dist = clamp(cameraState.dist * scale, MIN_SPRING_DISTANCE, maxCameraDistance)
	zoomMethod = "spring dist"
	return true
end

local function applyOverheadZoom(cameraState, zoomInput, dt)
	if type(cameraState.height) ~= "number" then
		return false
	end

	local scale = 1 - (zoomInput * ZOOM_SCALE_SPEED * (dt or 0))
	cameraState.height = clamp(cameraState.height * scale, MIN_OVERHEAD_HEIGHT, maxCameraDistance)
	zoomMethod = "overhead height"
	return true
end

local function applyFallbackHeightZoom(cameraState, zoomInput, dt)
	local mathMax = math.max
	if type(cameraState.py) ~= "number" then
		return false
	end

	cameraState.py = cameraState.py - (zoomInput * ControllerCameraTestSettings.zoomSpeed * (dt or 0))

	if spGetGroundHeight and type(cameraState.px) == "number" and type(cameraState.pz) == "number" then
		local groundHeight = spGetGroundHeight(cameraState.px, cameraState.pz)
		cameraState.py = mathMax(cameraState.py, groundHeight + MIN_CAMERA_HEIGHT)
	end

	zoomMethod = "py fallback"
	return true
end

local function applyZoom(cameraState, zoomInput, zoomMultiplier, dt)
	if zoomInput == 0 then
		zoomMethod = "none"
		return
	end

	zoomInput = zoomInput * (zoomMultiplier or 1)

	if cameraState.mode == 2 or cameraState.name == "spring" then
		if applySpringZoom(cameraState, zoomInput, dt) then
			return
		end
	end

	if cameraState.mode == 1 or cameraState.name == "ta" then
		if applyOverheadZoom(cameraState, zoomInput, dt) then
			return
		end
	end

	if not applyFallbackHeightZoom(cameraState, zoomInput, dt) then
		zoomMethod = "unsupported"
	end
end

local function applyRotation(cameraState, rotationInput, dt)
	local mathCos, mathSin = math.cos, math.sin
	if rotationInput == 0 then
		rotationMethod = "none"
		return
	end

	local rotationAmount = rotationInput * ControllerCameraTestSettings.rotationSpeed * (dt or 0)

	if type(cameraState.ry) == "number" then
		cameraState.ry = cameraState.ry + rotationAmount
		rotationMethod = "ry"
		return true
	end

	if cameraState.name == "rot" and type(cameraState.dx) == "number" and type(cameraState.dz) == "number" then
		local cosAmount = mathCos(rotationAmount)
		local sinAmount = mathSin(rotationAmount)
		local dx = cameraState.dx
		local dz = cameraState.dz

		cameraState.dx = (dx * cosAmount) - (dz * sinAmount)
		cameraState.dz = (dx * sinAmount) + (dz * cosAmount)
		rotationMethod = "rot direction"
		return true
	end

	rotationMethod = "unsupported"
	return false
end

local function applyPitch(cameraState, pitchInput, dt)
	local mathCos, mathSin = math.cos, math.sin
	if pitchInput == 0 then
		pitchMethod = "none"
		return
	end

	local pitchAmount = pitchInput * ControllerCameraTestSettings.pitchSpeed * (dt or 0)

	if type(cameraState.rx) == "number" then
		cameraState.rx = clamp(cameraState.rx + pitchAmount, MIN_CAMERA_RX, MAX_CAMERA_RX)
		pitchMethod = "rx"
		return true
	end

	if cameraState.name == "rot"
		and type(cameraState.dx) == "number"
		and type(cameraState.dy) == "number"
		and type(cameraState.dz) == "number"
	then
		local rightX, rightZ = normalizeHorizontalVector({ cameraState.dx, cameraState.dy, cameraState.dz })
		if not rightX then
			pitchMethod = "unsupported"
			return false
		end

		local newDx, newDy, newDz = rotateVectorAroundAxis(
			cameraState.dx,
			cameraState.dy,
			cameraState.dz,
			rightZ,
			0,
			-rightX,
			pitchAmount
		)

		cameraState.dx, cameraState.dy, cameraState.dz = normalizeDirectionWithClampedY(newDx, newDy, newDz)
		pitchMethod = "rot direction"
		return true
	end

	pitchMethod = "unsupported"
	return false
end

local function applyCameraInput(leftX, leftY, zoomInput, rotationInput, pitchInput, panMultiplier, zoomMultiplier, dt)
	local cameraState = spGetCameraState and spGetCameraState()
	if type(cameraState) ~= "table" or cameraState.px == nil or cameraState.pz == nil then
		updateCameraDebug(cameraState)
		return
	end

	local distance = ControllerCameraTestSettings.panSpeed * (panMultiplier or 1) * (dt or 0)
	local deltaX, deltaZ = getCameraPanDelta(leftX, leftY, distance)

	cameraState.px = cameraState.px + deltaX
	cameraState.pz = cameraState.pz + deltaZ

	applyZoom(cameraState, zoomInput, zoomMultiplier, dt)
	applyRotation(cameraState, rotationInput, dt)
	applyPitch(cameraState, pitchInput, dt)

	if mapSizeX > 0 then
		cameraState.px = clamp(cameraState.px, 0, mapSizeX)
	end
	if mapSizeZ > 0 then
		cameraState.pz = clamp(cameraState.pz, 0, mapSizeZ)
	end

	spSetCameraState(cameraState, 0)
	updateCameraDebug(cameraState)
end

local function drawReticleCircle(cx, cy, radius)
	local RETICLE_SEGMENTS = 28
	local mathCos, mathSin, mathPi = math.cos, math.sin, math.pi
	gl.BeginEnd(GL.LINE_LOOP, function()
		for i = 0, RETICLE_SEGMENTS - 1 do
			local angle = (i / RETICLE_SEGMENTS) * mathPi * 2
			gl.Vertex(cx + (mathCos(angle) * radius), cy + (mathSin(angle) * radius))
		end
	end)
end

local function drawReticleLines(cx, cy)
	local RETICLE_GAP = 5
	local RETICLE_LINE_LENGTH = 11
	gl.BeginEnd(GL.LINES, function()
		gl.Vertex(cx - RETICLE_GAP - RETICLE_LINE_LENGTH, cy)
		gl.Vertex(cx - RETICLE_GAP, cy)
		gl.Vertex(cx + RETICLE_GAP, cy)
		gl.Vertex(cx + RETICLE_GAP + RETICLE_LINE_LENGTH, cy)
		gl.Vertex(cx, cy - RETICLE_GAP - RETICLE_LINE_LENGTH)
		gl.Vertex(cx, cy - RETICLE_GAP)
		gl.Vertex(cx, cy + RETICLE_GAP)
		gl.Vertex(cx, cy + RETICLE_GAP + RETICLE_LINE_LENGTH)
	end)
end

local function drawControllerReticle()
	if not reticleVisible then
		return
	end

	local RETICLE_RADIUS = ControllerCameraTestSettings.reticleSize

	gl.LineWidth(4)
	gl.Color(0, 0, 0, 0.42)
	drawReticleCircle(screenCenterX, screenCenterY, RETICLE_RADIUS)
	drawReticleLines(screenCenterX, screenCenterY)

	gl.LineWidth(2)

	-- Apply colors based on unit alignment
	if reticleTargetAlignment == "enemy" then
		gl.Color(1.0, 0.2, 0.2, 0.9) -- Red for Enemies
	elseif reticleTargetAlignment == "ally" then
		gl.Color(0.2, 1.0, 0.2, 0.9) -- Green for Allies & Self
	else
		gl.Color(0.65, 0.92, 1.0, 0.78) -- Default Blue/White for Ground
	end

	drawReticleCircle(screenCenterX, screenCenterY, RETICLE_RADIUS)
	drawReticleLines(screenCenterX, screenCenterY)

	gl.LineWidth(1)
	gl.Color(1, 1, 1, 1)
end

function widget:Initialize()
	apiAvailable = type(spGetAvailableControllers) == "function" and type(spGetControllerState) == "function"
	ControllerCameraTestEnsureBindings()
	updateScreenCenter(spGetViewGeometry())
	ensureDebugPanelInitialized()
end

function widget:ViewResize(vsx, vsy)
	updateScreenCenter(vsx, vsy)
	ensureDebugPanelInitialized()
end

function ControllerCameraTestBeginControllerUpdate(dt)
	debugEventTime = debugEventTime + (dt or 0)
	updateMouseInputMode()
	panActive = false
	zoomActive = false
	rotationActive = false
	pitchActive = false

	if not apiAvailable then
		resetControllerInputDebug()
		return
	end

	local controller = pollFirstController()
	if not controller then
		resetControllerInputDebug()
		return
	end

	local state = pollControllerState(controller.instanceId)
	if not state or type(state.axes) ~= "table" then
		resetControllerInputDebug()
		return nil
	end

	return state
end

function ControllerCameraTestUpdateControllerAxesAndButtons(state)
	normalizedLeftX = normalizeAxis(GetNamedAxis(state, "leftStickX"))
	normalizedLeftY = normalizeAxis(GetNamedAxis(state, "leftStickY"))
	normalizedRightX = normalizeAxis(GetNamedAxis(state, "rightStickX"))
	normalizedRightY = normalizeAxis(GetNamedAxis(state, "rightStickY"))
	normalizedLeftTrigger = normalizeTrigger(GetNamedAxis(state, "leftTrigger"))
	normalizedRightTrigger = normalizeTrigger(GetNamedAxis(state, "rightTrigger"))
	updateButtonStates(state)
	ControllerCameraTestUpdateBindingTriggerEdges()
	heldButtonsSummary = getButtonStateSummary(currentButtonStates)
	pressedThisFrameSummary = getButtonStateSummary(pressedButtonStates)
	releasedThisFrameSummary = getButtonStateSummary(releasedButtonStates)
	activeAxesSummary = getActiveAxisSummary(state)
	if normalizedLeftX ~= 0
		or normalizedLeftY ~= 0
		or normalizedRightX ~= 0
		or normalizedRightY ~= 0
		or normalizedLeftTrigger ~= 0
		or normalizedRightTrigger ~= 0
		or hasButtonState(pressedButtonStates)
		or hasButtonState(releasedButtonStates)
	then
		noteControllerInput()
	end
	latchDebugButtonEvents(pressedButtonStates, pressedRecentlyExpirations)
	latchDebugButtonEvents(releasedButtonStates, releasedRecentlyExpirations)
end

function ControllerCameraTestUpdateControllerModeAndCommandLayer(dt)
	fastPanActive = normalizedLeftTrigger > 0
	lbCameraModifierActive = ControllerCameraTestActionDown("pitchModifier")
	commandLayerActive = ControllerCameraTestActionDown("commandLayer") and not ControllerCameraTestBuildPlacement.active
	if ControllerCameraTestSettingsUI.open then
		commandLayerActive = false
		ControllerCameraTestHandleSettingsUIInput()
		ControllerCameraTestLayerDebug.modeSummary = "settings"
		activeButtonLayoutSummary = "Settings: D-pad adjust, LB/RB category, A edit, B close, X/Y reset"
		return
	end
	if not commandLayerActive and ControllerCameraTestTacticalMenu.open then
		ControllerCameraTestTacticalMenu.open = false
		ControllerCameraTestTacticalMenu.lastAction = "closed: RT released"
	end
	ControllerCameraTestUpdateLBTapState()
	updateSelectionTestActive()

	if commandLayerActive then
		if ControllerCameraTestAreaSelect.pressActive or ControllerCameraTestAreaSelect.active then
			ControllerCameraTestCancelAreaSelect("cancelled by RT layer")
		end
		ControllerCameraTestHandleCommandLayerInput(dt)
	elseif ControllerCameraTestHandlePlacementInput(dt) then
		if ControllerCameraTestAreaSelect.pressActive or ControllerCameraTestAreaSelect.active then
			ControllerCameraTestCancelAreaSelect("cancelled by placement")
		end
	elseif ControllerCameraTestHandleBuildMenuInput() then
		-- Build-menu input consumes normal A/B/Y/D-pad actions while it is open.
		if ControllerCameraTestAreaSelect.pressActive or ControllerCameraTestAreaSelect.active then
			ControllerCameraTestCancelAreaSelect("cancelled by build menu")
		end
	elseif ControllerCameraTestHandleBackViewControls() then
		if ControllerCameraTestAreaSelect.pressActive or ControllerCameraTestAreaSelect.active then
			ControllerCameraTestCancelAreaSelect("cancelled by Back/View")
		end
	else
		if ControllerCameraTestHandleControlGroupInput() then
			if ControllerCameraTestAreaSelect.pressActive or ControllerCameraTestAreaSelect.active then
				ControllerCameraTestCancelAreaSelect("cancelled by control group")
			end
		else
			local areaBusy = ControllerCameraTestHandleNormalAInput(dt)
			local xBusy = false
			if not areaBusy then
				xBusy = ControllerCameraTestHandleNormalXInput(dt)
			end

			if areaBusy and ControllerCameraTestActionPressed("cancel") then
				ControllerCameraTestCancelAreaSelect("cancelled by B")
			elseif xBusy and ControllerCameraTestActionPressed("cancel") then
				-- Handled inside X handler
			elseif not areaBusy and not xBusy and ControllerCameraTestActionPressed("cancel") then
				attemptClearSelection()
			end

			if not areaBusy and not xBusy and ControllerCameraTestActionPressed("buildRadial") then
				attemptBuildMenu()
			end
			if not areaBusy and not xBusy then
				ControllerCameraTestHandleNormalUtilityInput()
			end
		end
	end

	ControllerCameraTestLayerDebug.modeSummary = ControllerCameraTestGetModeSummary()
	if commandLayerActive then
		activeButtonLayoutSummary = ControllerCameraTestTacticalMenu.open and "Tactical: A/X confirm, B/Y cancel, D-pad/LB/RB choose"
			or XboxController.commandLayoutSummary
	elseif ControllerCameraTestBuildPlacement.active then
		activeButtonLayoutSummary = "Placement: A place+exit, X place again, B cancel, RS X camera, D-pad L/R facing"
	elseif ControllerCameraTestBuildMenu.open then
		activeButtonLayoutSummary = "Build menu: A placement, X quick-place, B/Y close, D-pad/LB/RB navigate"
	elseif ControllerCameraTestAreaSelect.active then
		activeButtonLayoutSummary = "Area select: release A to select, RS Y/D-pad changes radius"
	elseif ControllerCameraTestActionDown("controlGroupModifier") then
		activeButtonLayoutSummary = "Control Groups: RB+D-pad U/D slot, tap L recall, hold L type-assign, B clear, R/A/X reserved"
	else
		activeButtonLayoutSummary = XboxController.normalLayoutSummary
	end
	commandLayerPressedSummary = commandLayerActive
		and getButtonStateSummary(pressedButtonStates, XboxController.commandLayerButtonOrder)
		or "none"
	if commandLayerActive then
		latchDebugButtonEvents(pressedButtonStates, commandLayerPressedRecentlyExpirations, XboxController.commandLayerButtonOrder)
		local commandPreview, commandExpiration = latchButtonPreview(pressedButtonStates, XboxController.commandPreviewLabels)
		if commandPreview then
			commandPreviewSummary = commandPreview
			commandPreviewExpiration = commandExpiration
		end
	else
		local normalPreview, normalExpiration = latchButtonPreview(pressedButtonStates, XboxController.normalPreviewLabels)
		if normalPreview then
			normalPreviewSummary = normalPreview
			normalPreviewExpiration = normalExpiration
		end
	end
end

function ControllerCameraTestApplyInputCurve(value, exponent)
	value = tonumber(value) or 0
	exponent = tonumber(exponent) or 1
	if value == 0 then
		return 0
	end
	local sign = value < 0 and -1 or 1
	return sign * (math.abs(value) ^ exponent)
end

function ControllerCameraTestSmoothAxis(current, target, dt)
	local response = math.max(0.01, tonumber(ControllerCameraTestSettings.cameraSmoothing) or 0.06)
	local alpha = 1 - math.exp(-math.max(0, dt or 0) / response)
	local value = (tonumber(current) or 0) + ((tonumber(target) or 0) - (tonumber(current) or 0)) * alpha
	return math.abs(value) < 0.001 and 0 or value
end

function ControllerCameraTestUpdateSmoothedCameraInputs(dt, menuOpen, areaActive)
	local smooth = ControllerCameraTestInputSmoothing
	if menuOpen then
		smooth.panX, smooth.panY, smooth.rotateX, smooth.pitchY, smooth.zoomY = 0, 0, 0, 0, 0
	else
		local curve = ControllerCameraTestSettings.stickCurve or 1.175
		smooth.panX = ControllerCameraTestSmoothAxis(smooth.panX, ControllerCameraTestApplyInputCurve(normalizedLeftX, curve), dt)
		smooth.panY = ControllerCameraTestSmoothAxis(smooth.panY, ControllerCameraTestApplyInputCurve(normalizedLeftY, curve), dt)
		smooth.rotateX = ControllerCameraTestSmoothAxis(smooth.rotateX, ControllerCameraTestApplyInputCurve(normalizedRightX, curve), dt)
		local yInput = ControllerCameraTestApplyInputCurve(-normalizedRightY, curve)
		smooth.pitchY = ControllerCameraTestSmoothAxis(smooth.pitchY, (lbCameraModifierActive and not areaActive) and yInput or 0, dt)
		smooth.zoomY = ControllerCameraTestSmoothAxis(smooth.zoomY, (not lbCameraModifierActive and not areaActive) and yInput or 0, dt)
	end
	local triggerInput = ControllerCameraTestApplyInputCurve(normalizedLeftTrigger or 0, ControllerCameraTestSettings.triggerCurve or 1.075)
	smooth.leftTrigger = ControllerCameraTestSmoothAxis(smooth.leftTrigger, triggerInput, dt)
end

function ControllerCameraTestUpdateCameraControls(dt)
	local placementActive = ControllerCameraTestBuildPlacement.active
	local menuOpen = (ControllerCameraTestBuildMenu.open and not placementActive) or ControllerCameraTestTacticalMenu.open or ControllerCameraTestSettingsUI.open
	local areaActive = ControllerCameraTestAreaSelect.active
	ControllerCameraTestUpdateSmoothedCameraInputs(dt, menuOpen, areaActive)
	local smooth = ControllerCameraTestInputSmoothing
	panActive = (not menuOpen) and (smooth.panX ~= 0 or smooth.panY ~= 0)
	rightStickYMode = areaActive and "area radius" or (lbCameraModifierActive and "pitch" or "zoom")
	local zoomInput = menuOpen and 0 or smooth.zoomY
	local pitchInput = menuOpen and 0 or smooth.pitchY
	local rotationInput = menuOpen and 0 or smooth.rotateX
	zoomActive = zoomInput ~= 0
	rotationActive = rotationInput ~= 0
	pitchActive = pitchInput ~= 0

	local boostInput = smooth.leftTrigger or 0
	local panMultiplier = 1 + (((ControllerCameraTestSettings.fastPanMultiplier or 1) - 1) * boostInput)
	zoomSpeedMultiplier = 1 + (((ControllerCameraTestSettings.zoomBoostMultiplier or 1) - 1) * boostInput)
	if panActive or zoomActive or rotationActive or pitchActive then
		applyCameraInput(menuOpen and 0 or smooth.panX, menuOpen and 0 or smooth.panY, zoomInput, rotationInput, pitchInput, panMultiplier, zoomSpeedMultiplier, dt)
	elseif spGetCameraState then
		zoomMethod = "none"
		rotationMethod = "none"
		pitchMethod = "none"
		updateCameraDebug(spGetCameraState())
	end
end

function ControllerCameraTestUpdateControllerFrame(dt)
	local state = ControllerCameraTestBeginControllerUpdate(dt)
	if not state then
		return
	end

	ControllerCameraTestUpdateControllerAxesAndButtons(state)
	ControllerCameraTestUpdateControllerModeAndCommandLayer(dt)
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestBuildMenu.open then
		ControllerCameraTestUpdateRadialStickSelection()
	end
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestTacticalMenu.open then
		ControllerCameraTestUpdateTacticalStickSelection()
	end
	ControllerCameraTestUpdateCameraControls(dt)
	updateReticleWorldTarget()
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestDragCommand.active then
		pcall(ControllerCameraTestUpdateDragPreview)
	end
	if controllerMode and reticleVisible and type(spWarpMouse) == "function" then spWarpMouse(screenCenterX, screenCenterY) end
end

function widget:Update(dt)
	ControllerCameraTestUpdateControllerFrame(dt)
end

function ControllerCameraTestNormalizeKeyName(value)
	return string.lower(tostring(value or "")):gsub("[%s_%-]", "")
end

function ControllerCameraTestKeyMatches(key, label, candidates)
	local normalizedLabel = ControllerCameraTestNormalizeKeyName(label)
	for _, candidate in ipairs(candidates or {}) do
		if type(candidate) == "number" and key == candidate then
			return true
		end
		local candidateText = tostring(candidate)
		local normalizedCandidate = ControllerCameraTestNormalizeKeyName(candidateText)
		if normalizedLabel ~= "" and normalizedLabel == normalizedCandidate then
			return true
		end
		if type(KEYSYMS) == "table" then
			local keySym = KEYSYMS[candidateText] or KEYSYMS[string.upper(candidateText)]
			if keySym ~= nil and key == keySym then
				return true
			end
		end
		if type(Spring.GetKeyCode) == "function" then
			local ok, keyCode = pcall(Spring.GetKeyCode, candidateText)
			if ok and keyCode ~= nil and key == keyCode then
				return true
			end
		end
	end
	return false
end

function ControllerCameraTestRecordKeyAction(key, label, action)
	ControllerCameraTestKeyDebug.rawKey = tostring(key or "nil")
	ControllerCameraTestKeyDebug.label = tostring(label or "")
	ControllerCameraTestKeyDebug.matchedAction = tostring(action or "none")
end

function ControllerCameraTestRecordUIToggleAction(action)
	ControllerCameraTestKeyDebug.lastUIToggle = tostring(action)
	ControllerCameraTestTuning.lastAction = tostring(action)
	latchSelectionDebugMessage(tostring(action))
end

function ControllerCameraTestToggleDebugPanel(source)
	ControllerCameraTestSettings.debugPanelVisible = not ControllerCameraTestSettings.debugPanelVisible
	ControllerCameraTestRecordUIToggleAction(tostring(source) .. " debug panel "
		.. (ControllerCameraTestSettings.debugPanelVisible and "shown" or "hidden"))
end

function ControllerCameraTestToggleHelpOverlay(source)
	ControllerCameraTestSettings.helpOverlayVisible = not ControllerCameraTestSettings.helpOverlayVisible
	ControllerCameraTestRecordUIToggleAction(tostring(source) .. " help overlay "
		.. (ControllerCameraTestSettings.helpOverlayVisible and "shown" or "hidden"))
end

function ControllerCameraTestToggleSettingsFromInput(source)
	ControllerCameraTestToggleSettingsUI()
	ControllerCameraTestRecordUIToggleAction(tostring(source) .. " settings "
		.. (ControllerCameraTestSettingsUI.open and "shown" or "hidden"))
end

function ControllerCameraTestResetSettingsFromInput(source)
	ControllerCameraTestResetSettingsToDefaults()
	ControllerCameraTestRecordUIToggleAction(tostring(source) .. " reset settings defaults")
end

function widget:KeyPress(key, mods, isRepeat, label, unicode)
	ControllerCameraTestRecordKeyAction(key, label, isRepeat and "repeat ignored" or "unmatched")
	if isRepeat then
		return false
	end

	if ControllerCameraTestKeyMatches(key, label, { "END", "End", "end", 279 }) then
		ControllerCameraTestRecordKeyAction(key, label, "toggle settings")
		ControllerCameraTestToggleSettingsFromInput("End")
		return true
	elseif ControllerCameraTestKeyMatches(key, label, { "PAGEUP", "PageUp", "pageup", "PGUP", "pgup", "PRIOR", "prior", 280 }) then
		ControllerCameraTestRecordKeyAction(key, label, "toggle debug")
		ControllerCameraTestToggleDebugPanel("Page Up")
		return true
	elseif ControllerCameraTestKeyMatches(key, label, { "PAGEDOWN", "PageDown", "pagedown", "PGDN", "pgdn", "NEXT", "next", 281 }) then
		ControllerCameraTestRecordKeyAction(key, label, "toggle help")
		ControllerCameraTestToggleHelpOverlay("Page Down")
		return true
	elseif ControllerCameraTestKeyMatches(key, label, { "HOME", "Home", "home", 278 }) then
		ControllerCameraTestRecordKeyAction(key, label, "reset settings")
		ControllerCameraTestResetSettingsFromInput("Home")
		return true
	end

	if ControllerCameraTestSettingsUI.open then
		local ui = ControllerCameraTestSettingsUI
		local category = ControllerCameraTestGetSettingsUICategory()
		if ControllerCameraTestKeyMatches(key, label, { "ESCAPE", "Escape", "escape", "ESC", "esc", 27 }) then
			ControllerCameraTestRecordKeyAction(key, label, "close settings")
			if ControllerCameraTestBindings.captureAction then
				ControllerCameraTestBindings.captureAction = nil
				ui.lastAction = "binding capture cancelled"
				ControllerCameraTestRecordUIToggleAction("Escape binding capture cancelled")
			else
				ControllerCameraTestToggleSettingsUI(false)
				ControllerCameraTestRecordUIToggleAction("Escape settings hidden")
			end
			return true
		elseif ControllerCameraTestKeyMatches(key, label, { "UP", "Up", "up", 273 }) then
			ControllerCameraTestRecordKeyAction(key, label, "settings up")
			ui.selectedIndex = ((ui.selectedIndex - 2) % #category.items) + 1
			return true
		elseif ControllerCameraTestKeyMatches(key, label, { "DOWN", "Down", "down", 274 }) then
			ControllerCameraTestRecordKeyAction(key, label, "settings down")
			ui.selectedIndex = (ui.selectedIndex % #category.items) + 1
			return true
		elseif ControllerCameraTestKeyMatches(key, label, { "LEFT", "Left", "left", 276 }) and not category.bindings then
			ControllerCameraTestRecordKeyAction(key, label, "settings decrease")
			local item = category.items[ui.selectedIndex]
			ControllerCameraTestAdjustSettingFromUI(item.key, -1, item.step)
			return true
		elseif ControllerCameraTestKeyMatches(key, label, { "RIGHT", "Right", "right", 275 }) and not category.bindings then
			ControllerCameraTestRecordKeyAction(key, label, "settings increase")
			local item = category.items[ui.selectedIndex]
			ControllerCameraTestAdjustSettingFromUI(item.key, 1, item.step)
			return true
		elseif ControllerCameraTestKeyMatches(key, label, { "TAB", "Tab", "tab", 9 }) then
			ControllerCameraTestRecordKeyAction(key, label, "settings category")
			local delta = mods and mods.shift and -1 or 1
			local categories = ControllerCameraTestGetSettingsUICategories()
			ui.categoryIndex = ((ui.categoryIndex - 1 + delta) % #categories) + 1
			ui.selectedIndex = 1
			return true
		elseif ControllerCameraTestKeyMatches(key, label, { "RETURN", "Return", "return", "ENTER", "Enter", "enter", "KP_ENTER", "kpenter", 13, 271 }) then
			ControllerCameraTestRecordKeyAction(key, label, "settings confirm")
			local item = category.items[ui.selectedIndex]
			if category.bindings then
				ControllerCameraTestBindings.captureAction = item.action
				ui.lastAction = "press a controller input for " .. tostring(item.label)
			elseif item.type == "bool" then
				ControllerCameraTestAdjustSettingFromUI(item.key, 1, 1)
			end
			return true
		end
	end
	return false
end

function widget:TextCommand(command)
	local normalized = ControllerCameraTestNormalizeKeyName(command)
	if normalized == "cctdebug" then
		ControllerCameraTestRecordKeyAction("text", command, "toggle debug")
		ControllerCameraTestToggleDebugPanel("/luaui cct_debug")
		return true
	elseif normalized == "ccthelp" then
		ControllerCameraTestRecordKeyAction("text", command, "toggle help")
		ControllerCameraTestToggleHelpOverlay("/luaui cct_help")
		return true
	elseif normalized == "cctsettings" then
		ControllerCameraTestRecordKeyAction("text", command, "toggle settings")
		ControllerCameraTestToggleSettingsFromInput("/luaui cct_settings")
		return true
	elseif normalized == "cctresetsettings" then
		ControllerCameraTestRecordKeyAction("text", command, "reset settings")
		ControllerCameraTestResetSettingsFromInput("/luaui cct_reset_settings")
		return true
	end
	return false
end

function widget:MouseMove(x, y)
	noteMouseInput()

	if debugPanelDragging then
		updateDebugPanelDrag(x, y)
		return true
	end
	if debugPanelResizing then
		updateDebugPanelResize(x, y)
		return true
	end
end

function widget:MousePress(x, y, button)
	noteMouseInput()

	if button ~= 1 then
		return
	end
	if not ControllerCameraTestSettings.debugPanelVisible then
		return
	end

	ensureDebugPanelInitialized()

	-- 1. Compact / Full toggle button hit detection in header
	local panelHeight = ControllerCameraTestDebugCompact and 120 or debugPanelHeight
	local headerHeight = 22
	local compX1 = debugPanelX + debugPanelWidth - 85
	local compX2 = debugPanelX + debugPanelWidth - 15
	local compY1 = debugPanelY + panelHeight - headerHeight + 2
	local compY2 = debugPanelY + panelHeight - 2
	if x >= compX1 and x <= compX2 and y >= compY1 and y <= compY2 then
		ControllerCameraTestDebugCompact = not ControllerCameraTestDebugCompact
		latchSelectionDebugMessage("Debug compact mode: " .. (ControllerCameraTestDebugCompact and "ON" or "OFF"))
		return true
	end

	-- 2. Section headers click hit detection (only in full mode)
	if not ControllerCameraTestDebugCompact then
		for _, hb in ipairs(ControllerCameraTestDebugSectionHitboxes or {}) do
			if x >= hb.x1 and x <= hb.x2 and y >= hb.y1 and y <= hb.y2 then
				ControllerCameraTestDebugSections[hb.key] = not ControllerCameraTestDebugSections[hb.key]
				latchSelectionDebugMessage("Section " .. tostring(hb.key) .. ": " .. (ControllerCameraTestDebugSections[hb.key] and "Expanded" or "Collapsed"))
				return true
			end
		end
	end

	if isPointInDebugPanelResizeHandle(x, y) then
		debugPanelResizing = true
		debugPanelResizeStartMouseX = x
		debugPanelResizeStartMouseY = y
		debugPanelResizeStartY = debugPanelY
		debugPanelResizeStartWidth = debugPanelWidth
		debugPanelResizeStartHeight = debugPanelHeight
		return true
	end

	if isPointInDebugPanelHeader(x, y) then
		debugPanelDragging = true
		debugPanelDragOffsetX = x - debugPanelX
		debugPanelDragOffsetY = y - debugPanelY
		return true
	end
end

function widget:MouseRelease()
	noteMouseInput()

	if debugPanelDragging or debugPanelResizing then
		debugPanelDragging = false
		debugPanelResizing = false
		return true
	end
end

function ControllerCameraTestDrawCircle2D(x, y, r, segments)
	segments = segments or 32
	gl.BeginEnd(GL.TRIANGLE_FAN, function()
		gl.Vertex(x, y)
		for i = 0, segments do
			local theta = i * (2 * math.pi / segments)
			gl.Vertex(x + r * math.cos(theta), y + r * math.sin(theta))
		end
	end)
end

function ControllerCameraTestDrawTacticalRadial()
	local menu = ControllerCameraTestTacticalMenu
	if not menu.open then
		return
	end

	local commands = ControllerCameraTestGetTacticalCommands()
	local n = #commands
	local cx = screenCenterX > 0 and screenCenterX or (viewSizeX / 2)
	local cy = screenCenterY > 0 and screenCenterY or (viewSizeY / 2)
	local minView = math.min(viewSizeX, viewSizeY)
	local radialScale = ControllerCameraTestSettings.radialScale or 1
	local radius = math.min(430, math.max(160, minView * 0.22 * radialScale))
	local itemW = math.min(180, math.max(86, minView * 0.11 * radialScale))
	local itemH = 40 * radialScale

	gl.Color(0, 0, 0, 0.46)
	ControllerCameraTestDrawCircle2D(cx, cy, radius * 1.28, 42)
	gl.Color(0.95, 0.32, 0.24, 0.74)
	gl.LineWidth(2.5)
	gl.BeginEnd(GL.LINE_LOOP, function()
		for i = 0, 44 do
			local theta = i * (2 * math.pi / 44)
			gl.Vertex(cx + radius * math.cos(theta), cy + radius * math.sin(theta))
		end
	end)

	if n <= 0 then
		gl.Color(1, 1, 1, 1)
		gl.Text("No tactical commands", cx, cy, 16, "oc")
		return
	end

	for i, option in ipairs(commands) do
		local angle = ((i - 1) * (2 * math.pi / n)) - (math.pi / 2)
		local x = cx + radius * math.cos(angle)
		local y = cy - radius * math.sin(angle)
		local selected = (i == menu.selectedIndex)
		local label = tostring(option.name or "Command")
		if #label > 18 then
			label = string.sub(label, 1, 16) .. ".."
		end

		if selected then
			gl.Color(0.95, 0.36, 0.26, 0.88)
		else
			gl.Color(0.10, 0.12, 0.15, 0.74)
		end
		gl.Rect(x - itemW / 2, y - itemH / 2, x + itemW / 2, y + itemH / 2)
		gl.Color(selected and 1 or 0.55, selected and 0.92 or 0.7, selected and 0.62 or 0.78, selected and 1 or 0.88)
		gl.LineWidth(selected and 2.5 or 1.2)
		gl.BeginEnd(GL.LINE_LOOP, function()
			gl.Vertex(x - itemW / 2, y - itemH / 2)
			gl.Vertex(x + itemW / 2, y - itemH / 2)
			gl.Vertex(x + itemW / 2, y + itemH / 2)
			gl.Vertex(x - itemW / 2, y + itemH / 2)
		end)

		gl.Color(1, 1, 1, selected and 1 or 0.82)
		gl.Text(label, x, y - 5, selected and 13 or 11, "oc")
	end

	local current = commands[menu.selectedIndex]
	gl.Color(0.08, 0.10, 0.13, 0.76)
	ControllerCameraTestDrawCircle2D(cx, cy, radius * 0.36, 30)
	gl.Color(1, 0.92, 0.72, 1)
	gl.Text(current and current.name or "Tactical", cx, cy + 22, 15, "oc")
	gl.Color(1, 1, 1, 0.86)
	gl.Text("A select  B/Y close", cx, cy - 2, 11, "oc")
	if ControllerCameraTestIsQueueModifierActive() then
		gl.Color(0.35, 0.95, 0.65, 1)
		gl.Text("LT QUEUE", cx, cy - 20, 11, "oc")
	end
	gl.Color(1, 1, 1, 1)
	gl.LineWidth(1)
end

function ControllerCameraTestDrawQueueIndicator()
	if not ControllerCameraTestIsQueueModifierActive() then
		return
	end
	if not (ControllerCameraTestBuildPlacement.active
		or ControllerCameraTestBuildMenu.open
		or ControllerCameraTestTacticalMenu.open
		or ControllerCameraTestDragCommand.active
		or commandLayerActive)
	then
		return
	end

	local cx = screenCenterX > 0 and screenCenterX or (viewSizeX / 2)
	local cy = screenCenterY > 0 and screenCenterY or (viewSizeY / 2)
	gl.Color(0.02, 0.12, 0.06, 0.74)
	gl.Rect(cx - 38, cy + 30, cx + 38, cy + 50)
	gl.Color(0.35, 1.0, 0.62, 0.95)
	gl.LineWidth(1.5)
	gl.BeginEnd(GL.LINE_LOOP, function()
		gl.Vertex(cx - 38, cy + 30)
		gl.Vertex(cx + 38, cy + 30)
		gl.Vertex(cx + 38, cy + 50)
		gl.Vertex(cx - 38, cy + 50)
	end)
	gl.Color(0.8, 1, 0.86, 1)
	gl.Text("QUEUE", cx, cy + 35, 12, "oc")
	gl.LineWidth(1)
	gl.Color(1, 1, 1, 1)
end

function ControllerCameraTestDrawPlacementPatternPopup()
	local popup = ControllerCameraTestPlacementPopup
	if not popup or (popup.expireTime or 0) <= debugEventTime then
		return
	end
	local cx = screenCenterX > 0 and screenCenterX or (viewSizeX / 2)
	local cy = screenCenterY > 0 and screenCenterY or (viewSizeY / 2)
	local alpha = math.min(1, math.max(0, (popup.expireTime - debugEventTime) * 2))
	local width = math.max(150, (#tostring(popup.text) * 8) + 28)
	local bottom = math.max(38, cy - 116)
	gl.Color(0.02, 0.04, 0.06, 0.84 * alpha)
	gl.Rect(cx - (width / 2), bottom, cx + (width / 2), bottom + 30)
	gl.Color(0.58, 0.84, 1, 0.88 * alpha)
	gl.LineWidth(1.5)
	gl.BeginEnd(GL.LINE_LOOP, function()
		gl.Vertex(cx - (width / 2), bottom)
		gl.Vertex(cx + (width / 2), bottom)
		gl.Vertex(cx + (width / 2), bottom + 30)
		gl.Vertex(cx - (width / 2), bottom + 30)
	end)
	gl.Color(0.92, 0.97, 1, alpha)
	gl.Text(tostring(popup.text), cx, bottom + 9, 13, "oc")
	gl.Color(1, 1, 1, 1)
	gl.LineWidth(1)
end

function ControllerCameraTestGetReadableUnitName(unitDef)
	if type(unitDef) ~= "table" then
		return "Unit"
	end
	return unitDef.translatedHumanName or unitDef.humanName or unitDef.name or "Unit"
end

function ControllerCameraTestGetSelectedPrimaryUnitInfo()
	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	local constructorInfo = nil
	for _, unitID in ipairs(selectedUnits) do
		local unitDefID, unitDef = ControllerCameraTestGetUnitDef(unitID)
		if type(unitDef) == "table" then
			local info = {
				unitID = unitID,
				unitDefID = unitDefID,
				unitDef = unitDef,
				name = ControllerCameraTestGetReadableUnitName(unitDef),
			}
			if unitDef.isFactory then
				info.mode = "factory"
				return info
			end
			if not constructorInfo and (unitDef.isBuilder or unitDef.builder or unitDef.canAssist
				or (type(unitDef.buildOptions) == "table" and #unitDef.buildOptions > 0))
			then
				info.mode = "constructor"
				constructorInfo = info
			end
		end
	end
	return constructorInfo
end

--------------------------------------------------------------------------------
-- SECTION: Compact selected status panel
--------------------------------------------------------------------------------
function ControllerCameraTestBuildCompactSelectedStatus()
	local status = ControllerCameraTestSelectedStatus
	status.mode = "hidden"
	if not controllerMode or ControllerCameraTestSettingsUI.open or ControllerCameraTestSettings.compactSelectedStatus == false then
		status.lastResult = "hidden: mouse mode or disabled"
		return nil
	end
	if ControllerCameraTestSettings.hideCompactStatusWhenRadialOpen
		and (ControllerCameraTestBuildMenu.open or ControllerCameraTestTacticalMenu.open)
	then
		status.lastResult = "hidden: radial open"
		return nil
	end
	local info = ControllerCameraTestGetSelectedPrimaryUnitInfo()
	if not info then
		status.lastResult = "none selected"
		return nil
	end
	status.mode = info.mode
	status.unitID = info.unitID
	status.unitDefID = info.unitDefID
	status.name = info.name
	status.vanillaCommandPanelStatus = "untouched"

	if info.mode == "factory" then
		if status.refreshUnitID ~= info.unitID or debugEventTime >= (status.nextRefreshTime or 0) then
			ControllerCameraTestRefreshFactoryQueueCounts()
			ControllerCameraTestRefreshFactoryQueueProgress()
			status.refreshUnitID = info.unitID
			status.nextRefreshTime = debugEventTime + 0.12
		end
		status.progress = tonumber(ControllerCameraTestBuildMenu.factoryProgressValue)
		status.currentCmdID = tonumber(ControllerCameraTestBuildMenu.factoryProgressCmdID)
		status.repeatState = "unknown"
		if type(Spring.GetUnitStates) == "function" then
			local ok, states = pcall(Spring.GetUnitStates, info.unitID)
			if ok and type(states) == "table" and states["repeat"] ~= nil then
				status.repeatState = states["repeat"] and "on" or "off"
			end
		end
		status.queueItems = {}
		for cmdID, count in pairs(ControllerCameraTestBuildMenu.factoryQueueCounts or {}) do
			local unitDef = UnitDefs and UnitDefs[-cmdID]
			status.queueItems[#status.queueItems + 1] = {
				cmdID = cmdID,
				unitDefID = -cmdID,
				name = ControllerCameraTestGetReadableUnitName(unitDef),
				count = count,
			}
		end
		table.sort(status.queueItems, function(a, b)
			return tostring(a.name) < tostring(b.name)
		end)
		status.lastResult = "factory"
	else
		status.progress = nil
		status.currentCmdID = nil
		status.queueItems = nil
		status.currentAction = "idle"
		if type(Spring.GetCommandQueue) == "function" then
			local ok, queue = pcall(Spring.GetCommandQueue, info.unitID, 1)
			if ok and type(queue) == "table" and queue[1] then
				status.currentAction = "command " .. tostring(queue[1].id or "active")
			end
		end
		status.lastResult = "constructor"
	end
	return status
end

function ControllerCameraTestDrawCompactSelectedStatusPanel()
	local status = ControllerCameraTestBuildCompactSelectedStatus()
	if not status then
		return
	end
	local screenWidth = viewSizeX > 0 and viewSizeX or 1280
	local left = math.max(14, screenWidth - 310)
	local right = screenWidth - 16
	local bottom = 50
	local top = status.mode == "factory" and 154 or 124
	gl.Color(0.02, 0.04, 0.06, 0.82)
	gl.Rect(left, bottom, right, top)
	gl.Color(0.56, 0.84, 1, 0.7)
	gl.LineWidth(1)
	gl.BeginEnd(GL.LINE_LOOP, function()
		gl.Vertex(left, bottom)
		gl.Vertex(right, bottom)
		gl.Vertex(right, top)
		gl.Vertex(left, top)
	end)
	gl.Color(0.82, 0.94, 1, 1)
	gl.Text(status.mode == "factory" and "Factory Status" or "Constructor Status", left + 12, top - 19, 13, "o")
	gl.Color(1, 1, 1, 0.96)
	gl.Text(tostring(status.name), left + 12, top - 39, 13, "o")

	if status.mode == "factory" then
		local currentDefID = status.currentCmdID and -status.currentCmdID or nil
		local currentDef = currentDefID and UnitDefs and UnitDefs[currentDefID] or nil
		local buildText = currentDef and ControllerCameraTestGetReadableUnitName(currentDef) or "Idle"
		if currentDefID then
			gl.Texture("#" .. tostring(currentDefID))
			gl.Color(1, 1, 1, 0.92)
			gl.TexRect(left + 12, bottom + 25, left + 50, bottom + 63)
			gl.Texture(false)
		end
		local progressText = status.progress and (" " .. tostring(math.floor(status.progress * 100 + 0.5)) .. "%") or ""
		gl.Color(0.92, 0.96, 1, 0.95)
		gl.Text("Building: " .. buildText .. progressText, left + 58, bottom + 52, 11, "o")
		gl.Text("Repeat: " .. tostring(status.repeatState) .. "  Queue:", left + 58, bottom + 34, 10, "o")
		local iconX = left + 164
		for i = 1, math.min(3, #(status.queueItems or {})) do
			local item = status.queueItems[i]
			gl.Texture("#" .. tostring(item.unitDefID))
			gl.Color(1, 1, 1, 0.88)
			gl.TexRect(iconX, bottom + 21, iconX + 26, bottom + 47)
			gl.Texture(false)
			gl.Color(1, 0.92, 0.42, 1)
			gl.Text("x" .. tostring(item.count), iconX + 13, bottom + 10, 9, "oc")
			iconX = iconX + 34
		end
		gl.Color(0.66, 0.9, 1, 0.95)
		gl.Text("Y: Factory radial", left + 12, bottom + 7, 10, "o")
	else
		gl.Color(0.92, 0.96, 1, 0.95)
		gl.Text("Action: " .. tostring(status.currentAction or "idle"), left + 12, bottom + 38, 11, "o")
		local placementText = ControllerCameraTestBuildPlacement.active
			and ("Pattern: " .. ControllerCameraTestPlacementPatternLabel(ControllerCameraTestBuildPlacement.placementPattern)
				.. "  Space: " .. tostring(ControllerCameraTestBuildPlacement.placementSpacing or 0))
			or "Ready for construction"
		gl.Text(placementText, left + 12, bottom + 23, 11, "o")
		gl.Color(0.66, 0.9, 1, 0.95)
		gl.Text("Y: Build radial", left + 12, bottom + 7, 10, "o")
	end
	gl.Texture(false)
	gl.Color(1, 1, 1, 1)
	gl.LineWidth(1)
end

function ControllerCameraTestDrawControlGroupOverlay()
	local groups = ControllerCameraTestControlGroups
	if not (ControllerCameraTestActionDown("controlGroupModifier") or (groups.visibleUntil or 0) > debugEventTime) then
		return
	end

	local screenWidth = viewSizeX > 0 and viewSizeX or 1280
	local slotSize = 42
	local gap = 5
	local stripWidth = (slotSize * 10) + (gap * 9) + 24
	local left = math.max(12, (screenWidth - stripWidth) * 0.5)
	local bottom = 86
	local top = bottom + slotSize + 34
	local activeSlot = ControllerCameraTestNormalizeControlGroupSlot(groups.activeSlot or 1)

	gl.Color(0, 0, 0, 0.72)
	gl.Rect(left, bottom, left + stripWidth, top)
	gl.Color(0.36, 0.68, 1, 0.65)
	gl.LineWidth(1.5)
	gl.BeginEnd(GL.LINE_LOOP, function()
		gl.Vertex(left, bottom)
		gl.Vertex(left + stripWidth, bottom)
		gl.Vertex(left + stripWidth, top)
		gl.Vertex(left, top)
	end)

	gl.Color(0.82, 0.92, 1, 1)
	gl.Text("Controller Groups  RB+Dpad: U/D slot, tap L recall, hold L assign, B clear", left + 12, top - 18, 12, "o")

	for slot = 1, 10 do
		local x1 = left + 12 + ((slot - 1) * (slotSize + gap))
		local y1 = bottom + 8
		local x2 = x1 + slotSize
		local y2 = y1 + slotSize
		local entry = groups.slots[slot]
		local isActive = slot == activeSlot
		local isRecent = tostring(groups.lastSlot) == ControllerCameraTestGetControlGroupDisplaySlot(slot)

		if isActive then
			gl.Color(0.18, 0.42, 0.78, 0.88)
		elseif entry then
			gl.Color(0.10, 0.18, 0.24, 0.82)
		else
			gl.Color(0.05, 0.07, 0.09, 0.74)
		end
		gl.Rect(x1, y1, x2, y2)

		if entry and entry.unitDefID then
			gl.Texture("#" .. tostring(entry.unitDefID))
			gl.Color(1, 1, 1, isActive and 0.95 or 0.75)
			gl.TexRect(x1 + 5, y1 + 7, x2 - 5, y2 - 5)
			gl.Texture(false)
		end

		gl.Color(isActive and 1 or 0.55, isActive and 0.92 or 0.72, isActive and 0.35 or 0.82, 1)
		gl.LineWidth((isActive or isRecent) and 2.5 or 1)
		gl.BeginEnd(GL.LINE_LOOP, function()
			gl.Vertex(x1, y1)
			gl.Vertex(x2, y1)
			gl.Vertex(x2, y2)
			gl.Vertex(x1, y2)
		end)

		gl.Color(1, 1, 1, 1)
		gl.Text(ControllerCameraTestGetControlGroupDisplaySlot(slot), x1 + 4, y2 - 13, 11, "o")
		if entry and (entry.count or 0) > 0 then
			gl.Color(1, 0.92, 0.42, 1)
			gl.Text("x" .. tostring(entry.count), x2 - 4, y1 + 3, 10, "ro")
			if entry.autoAddUnitDefID then
				gl.Color(0.52, 1.0, 0.66, 0.95)
				gl.Text("AUTO", x1 + 4, y1 + 3, 8, "o")
			end
		end
	end

	gl.Color(0.92, 0.96, 1, 1)
	gl.Text("Group " .. ControllerCameraTestGetControlGroupDisplaySlot(activeSlot) .. ": " .. tostring(groups.lastAction), left + 12, bottom - 16, 12, "o")
	gl.Texture(false)
	gl.LineWidth(1)
	gl.Color(1, 1, 1, 1)
end

function ControllerCameraTestDrawBuildRadial()
	local menu = ControllerCameraTestBuildMenu
	if not menu.open then
		return
	end

	if ControllerCameraTestBuildPlacement.active then
		return
	end

	-- Throttled refresh of factory queue counts while radial is drawn
	if Spring.GetGameFrame() % 15 == 0 then
		ControllerCameraTestRefreshFactoryQueueCounts()
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	local isFactoryContext = ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits)

	if isFactoryContext then
		ControllerCameraTestRefreshFactoryQueueProgress()
	end

	local cx = screenCenterX > 0 and screenCenterX or (viewSizeX / 2)
	local cy = screenCenterY > 0 and screenCenterY or (viewSizeY / 2)

	local minView = math.min(viewSizeX, viewSizeY)
	local radialScale = ControllerCameraTestSettings.radialScale or 1
	local radius = math.min(520, math.max(200, minView * 0.28 * radialScale))

	local visibleOptions = menu.radialVisibleOptions or {}
	local n = #visibleOptions

	-- 1. Translucent backdrop (large dark circle around the reticle) - opacity halved from 0.72 to 0.36
	gl.Color(0, 0, 0, 0.36)
	local function drawCircle(x, y, r, segments)
		segments = segments or 32
		gl.BeginEnd(GL.TRIANGLE_FAN, function()
			gl.Vertex(x, y)
			for i = 0, segments do
				local theta = i * (2 * math.pi / segments)
				gl.Vertex(x + r * math.cos(theta), y + r * math.sin(theta))
			end
		end)
	end

	drawCircle(cx, cy, radius * 1.3, 40)

	-- Draw a thin ring - opacity halved from 0.45 to 0.22
	gl.LineWidth(2)
	gl.Color(0.56, 0.84, 1, 0.22)
	gl.BeginEnd(GL.LINE_LOOP, function()
		for i = 0, 36 do
			local theta = i * (2 * math.pi / 36)
			gl.Vertex(cx + radius * math.cos(theta), cy + radius * math.sin(theta))
		end
	end)

	-- 2. Draw each item
	local iconSize = math.min(145, math.max(56, minView * 0.075 * radialScale))
	for i = 1, n do
		local option = visibleOptions[i]
		local angle = ((i - 1) * (2 * math.pi / n)) - (math.pi / 2)
		local x = cx + radius * math.cos(angle)
		local y = cy - radius * math.sin(angle)

		local isSelected = (option.menuIndex == menu.selectedIndex)

		-- Check affordability
		local affordable, mAff, eAff = ControllerCameraTestCanAffordBuildOption(option)

		if isSelected then
			gl.Color(0.2, 0.6, 1, 0.85)
			gl.Rect(x - iconSize/2 - 4, y - iconSize/2 - 4, x + iconSize/2 + 4, y + iconSize/2 + 4)
			gl.Color(0.85, 0.95, 1, 1)
		else
			if affordable then
				gl.Color(0.12, 0.18, 0.23, 0.42)
			else
				gl.Color(0.32, 0.12, 0.12, 0.42) -- red background tint for unaffordable
			end
			gl.Rect(x - iconSize/2 - 2, y - iconSize/2 - 2, x + iconSize/2 + 2, y + iconSize/2 + 2)
			if affordable then
				gl.Color(0.8, 0.8, 0.8, 0.9)
			else
				gl.Color(0.68, 0.22, 0.22, 0.55) -- red border for unaffordable
			end
		end

		gl.LineWidth(isSelected and 3 or 1.5)
		gl.BeginEnd(GL.LINE_LOOP, function()
			gl.Vertex(x - iconSize/2, y - iconSize/2)
			gl.Vertex(x + iconSize/2, y - iconSize/2)
			gl.Vertex(x + iconSize/2, y + iconSize/2)
			gl.Vertex(x - iconSize/2, y + iconSize/2)
		end)

		local hasIcon = false
		if option.iconTexture then
			gl.Texture(option.iconTexture)
			local progress = isFactoryContext and option.cmdID and menu.factoryQueueProgress and menu.factoryQueueProgress[option.cmdID]
			if progress and progress >= 0.0 and progress <= 1.0 then
				-- Draw darkened base icon
				gl.Color(0.2, 0.2, 0.2, 0.5)
				gl.TexRect(x - iconSize/2, y - iconSize/2, x + iconSize/2, y + iconSize/2)

				-- Draw bright/full-color version wiped on top according to build progress
				if progress > 0 then
					gl.Scissor(x - iconSize/2, y - iconSize/2, iconSize, iconSize * progress)
					if isSelected then
						gl.Color(1, 1, 1, 1)
					else
						gl.Color(0.85, 0.85, 0.85, 0.9)
					end
					gl.TexRect(x - iconSize/2, y - iconSize/2, x + iconSize/2, y + iconSize/2)
					gl.Scissor(false)
				end
			else
				-- Standard icon drawing
				if isSelected then
					gl.Color(1, 1, 1, 1)
				elseif affordable then
					gl.Color(0.85, 0.85, 0.85, 0.9)
				else
					gl.Color(0.35, 0.3, 0.3, 0.42) -- dim texture for unaffordable
				end
				gl.TexRect(x - iconSize/2, y - iconSize/2, x + iconSize/2, y + iconSize/2)
			end
			gl.Texture(false)
			hasIcon = true
		end

		if not hasIcon then
			gl.Color(1, 1, 1, 1)
			gl.Text(string.sub(option.name, 1, 4), x, y - 6, 12, "oc")
		end

		gl.Color(1, 0.84, 0, 1)
		gl.Text(tostring(i), x - iconSize/2 + 6, y + iconSize/2 - 16, 12, "o")

		-- Draw Factory Queue badge if needed
		if isFactoryContext and option.cmdID and menu.factoryQueueCounts then
			local qCount = menu.factoryQueueCounts[option.cmdID] or 0
			if qCount > 0 then
				local badgeText = "x" .. tostring(qCount)
				local badgeW = 28
				if qCount >= 10 then
					badgeW = 36
				end
				if qCount >= 100 then
					badgeW = 44
				end
				local bx2 = x + iconSize/2 + 3
				local bx1 = bx2 - badgeW
				local by2 = y + iconSize/2 + 3
				local by1 = by2 - 18

				-- Translucent dark glassmorphism badge
				gl.Color(0.04, 0.08, 0.12, 0.88)
				gl.Rect(bx1, by1, bx2, by2)
				gl.Color(0.56, 0.84, 1, 0.7)
				gl.LineWidth(1)
				gl.BeginEnd(GL.LINE_LOOP, function()
					gl.Vertex(bx1, by1)
					gl.Vertex(bx2, by1)
					gl.Vertex(bx2, by2)
					gl.Vertex(bx1, by2)
				end)

				gl.Color(1, 0.95, 0.8, 1)
				gl.Text(badgeText, (bx1 + bx2)/2, by1 + 3, 11, "oc")
			end
		end
	end

	-- 3. Center display details
	local currentOption = ControllerCameraTestGetRadialCurrentOption()
	if currentOption then
		gl.Color(0.2, 0.6, 1, 0.08) -- opacity halved from 0.15 to 0.08
		drawCircle(cx, cy, radius * 0.45, 30)

		gl.Color(0.82, 0.94, 1, 1)
		gl.Text(currentOption.name or "unknown", cx, cy + 42, 16, "oc")

		local mCost = currentOption.metalCost or 0
		local eCost = currentOption.energyCost or 0
		local aff, mAff, eAff = ControllerCameraTestCanAffordBuildOption(currentOption)

		if mCost > 0 and eCost > 0 then
			if mAff then
				gl.Color(0.9, 0.8, 0.1, 1)
			else
				gl.Color(1, 0.25, 0.2, 1)
			end
			gl.Text("M: " .. tostring(mCost), cx - 36, cy + 22, 12, "oc")

			if eAff then
				gl.Color(0.9, 0.8, 0.1, 1)
			else
				gl.Color(1, 0.25, 0.2, 1)
			end
			gl.Text("E: " .. tostring(eCost), cx + 36, cy + 22, 12, "oc")
		elseif mCost > 0 then
			if mAff then
				gl.Color(0.9, 0.8, 0.1, 1)
			else
				gl.Color(1, 0.25, 0.2, 1)
			end
			gl.Text("M: " .. tostring(mCost), cx, cy + 22, 12, "oc")
		elseif eCost > 0 then
			if eAff then
				gl.Color(0.9, 0.8, 0.1, 1)
			else
				gl.Color(1, 0.25, 0.2, 1)
			end
			gl.Text("E: " .. tostring(eCost), cx, cy + 22, 12, "oc")
		end

		if isFactoryContext then
			local qCount = 0
			if menu.factoryQueueCounts and currentOption.cmdID then
				qCount = menu.factoryQueueCounts[currentOption.cmdID] or 0
			end
			if qCount > 0 then
				gl.Color(0.4, 0.85, 1, 1)
				gl.Text("Queued: " .. tostring(qCount), cx, cy + 4, 12, "oc")
			end
		else
			if currentOption.tooltip and currentOption.tooltip ~= "" then
				gl.Color(0.7, 0.7, 0.7, 0.8)
				local tip = string.sub(currentOption.tooltip, 1, 28)
				if #currentOption.tooltip > 28 then tip = tip .. "..." end
				gl.Text(tip, cx, cy + 4, 11, "oc")
			end
		end

		-- Draw context-specific controller hints
		if isFactoryContext then
			gl.Color(0.4, 1.0, 0.4, 0.9)
			gl.Text("[A] +1", cx - 8, cy - 12, 11, "or")
			gl.Color(0.2, 0.9, 0.7, 0.9)
			gl.Text("[LT+A] +5", cx + 8, cy - 12, 11, "ol")

			gl.Color(1.0, 0.4, 0.4, 0.9)
			gl.Text("[B] -1", cx - 8, cy - 25, 11, "or")
			gl.Color(1.0, 0.6, 0.2, 0.9)
			gl.Text("[LT+B] -5", cx + 8, cy - 25, 11, "ol")

			gl.Color(1.0, 0.9, 0.4, 0.9)
			gl.Text("[Y] Close", cx, cy - 38, 11, "oc")
		else
			gl.Color(0.4, 1.0, 0.4, 0.9)
			gl.Text("[A] Place", cx - 8, cy - 16, 11, "or")
			gl.Color(0.4, 0.8, 1.0, 0.9)
			gl.Text("[X] Stay", cx + 8, cy - 16, 11, "ol")
			gl.Color(1.0, 0.4, 0.4, 0.9)
			gl.Text("[B] Cancel", cx - 8, cy - 30, 11, "or")
			gl.Color(1.0, 0.9, 0.4, 0.9)
			gl.Text("[Y] Close", cx + 8, cy - 30, 11, "ol")
		end
	end

	-- 4. Category/Page Indicator
	gl.Color(0.56, 0.84, 1, 0.95)
	local categoryStr = string.upper(menu.radialCategoryName or "Build")
	local pageStr = "PAGE " .. tostring(menu.radialPage) .. "/" .. tostring(menu.radialPageCount)

	gl.Text(categoryStr, cx, cy + radius * 0.65, 18, "oc")
	gl.Color(0.8, 0.8, 0.8, 0.8)
	gl.Text(pageStr, cx, cy - radius * 0.65, 15, "oc")

	gl.Color(0.6, 0.6, 0.6, 0.7)
	gl.Text("LB", cx - radius * 0.4, cy + radius * 0.65, 14, "oc")
	gl.Text("RB", cx + radius * 0.4, cy + radius * 0.65, 14, "oc")

	gl.Color(1, 1, 1, 1)
	gl.Texture(false)
	gl.LineWidth(1)
end

function ControllerCameraTestFormatSettingsUIValue(item)
	if item.type == "bool" then
		return ControllerCameraTestSettings[item.key] and "ON" or "OFF"
	end
	local value = tonumber(ControllerCameraTestSettings[item.key]) or 0
	if item.decimals == 0 then
		return string.format("%.0f", value)
	end
	return string.format("%." .. tostring(item.decimals or 2) .. "f", value)
end

function ControllerCameraTestDrawSettingsUI()
	local ui = ControllerCameraTestSettingsUI
	if not ui.open then
		return
	end
	local categories = ControllerCameraTestGetSettingsUICategories()
	local category = ControllerCameraTestGetSettingsUICategory()
	local width = math.min(720, math.max(500, viewSizeX - 80))
	local height = math.min(570, math.max(420, viewSizeY - 90))
	local left = math.max(20, (viewSizeX - width) * 0.5)
	local bottom = math.max(20, (viewSizeY - height) * 0.5)
	local right = left + width
	local top = bottom + height
	local headerY = top - 34
	local rowHeight = 27

	gl.Color(0.01, 0.025, 0.04, 0.94)
	gl.Rect(left, bottom, right, top)
	gl.Color(0.07, 0.12, 0.17, 0.98)
	gl.Rect(left, headerY, right, top)
	gl.Color(0.58, 0.84, 1, 0.92)
	gl.LineWidth(1.5)
	gl.BeginEnd(GL.LINE_LOOP, function()
		gl.Vertex(left, bottom)
		gl.Vertex(right, bottom)
		gl.Vertex(right, top)
		gl.Vertex(left, top)
	end)
	gl.Color(0.84, 0.95, 1, 1)
	gl.Text("Controller Settings", left + 18, top - 23, 18, "o")
	gl.Color(0.72, 0.84, 0.92, 0.92)
	gl.Text("End/Esc close   Home reset all defaults", right - 18, top - 22, 11, "ro")

	local tabX = left + 16
	for index, cat in ipairs(categories) do
		local tabW = math.max(62, (#cat.key * 7) + 18)
		if index == ui.categoryIndex then
			gl.Color(0.16, 0.40, 0.62, 0.88)
			gl.Rect(tabX, headerY - 37, tabX + tabW, headerY - 8)
		end
		gl.Color(index == ui.categoryIndex and 1 or 0.68, index == ui.categoryIndex and 0.95 or 0.78, 1, 1)
		gl.Text(cat.key, tabX + 9, headerY - 27, 12, "o")
		tabX = tabX + tabW + 5
	end

	local listTop = headerY - 62
	local visibleRows = math.max(5, math.floor((height - 144) / rowHeight))
	local firstRow = math.max(1, math.min(ui.selectedIndex - math.floor(visibleRows / 2), #category.items - visibleRows + 1))
	local lastRow = math.min(#category.items, firstRow + visibleRows - 1)
	local drawY = listTop
	for index = firstRow, lastRow do
		local item = category.items[index]
		local selected = index == ui.selectedIndex
		if selected then
			gl.Color(0.13, 0.30, 0.44, 0.9)
			gl.Rect(left + 18, drawY - 7, right - 18, drawY + 18)
		end
		gl.Color(selected and 0.94 or 0.79, selected and 0.98 or 0.84, selected and 1 or 0.9, 1)
		gl.Text(category.bindings and item.label or item.label, left + 30, drawY, 14, "o")
		if category.bindings then
			gl.Color(0.65, 0.9, 1, 1)
			gl.Text(ControllerCameraTestBindingLabel(ControllerCameraTestGetBinding(item.action)), right - 34, drawY, 14, "ro")
		else
			local value = ControllerCameraTestFormatSettingsUIValue(item)
			gl.Color(item.type == "bool" and (ControllerCameraTestSettings[item.key] and 0.44 or 0.94) or 0.65,
				item.type == "bool" and (ControllerCameraTestSettings[item.key] and 1 or 0.62) or 0.9,
				item.type == "bool" and 0.64 or 1, 1)
			gl.Text(value, right - 34, drawY, 14, "ro")
		end
		drawY = drawY - rowHeight
	end

	local footer = category.bindings
		and "A/Enter capture  X reset binding  Y reset all bindings  B/Esc close"
		or "D-pad/arrows adjust  A toggle  X reset selected  Y reset category  LB/RB or Tab change tab"
	gl.Color(0.68, 0.84, 0.96, 0.95)
	gl.Text(footer, left + 18, bottom + 35, 12, "o")
	if ControllerCameraTestBindings.captureAction then
		gl.Color(0.10, 0.23, 0.30, 0.95)
		gl.Rect(left + 20, bottom + 55, right - 20, bottom + 91)
		gl.Color(1, 0.92, 0.48, 1)
		gl.Text("Listening: press a controller input for " .. tostring(ControllerCameraTestBindings.captureAction) .. " (B cancels)", left + 34, bottom + 69, 14, "o")
	elseif category.bindings and ControllerCameraTestBindings.conflictAction then
		gl.Color(1, 0.76, 0.36, 0.95)
		gl.Text("Shared binding warning: also used by " .. tostring(ControllerCameraTestBindings.conflictAction), left + 20, bottom + 62, 12, "o")
	end
	gl.Color(0.76, 0.86, 0.95, 0.95)
	gl.Text("Last: " .. tostring(ui.lastAction or ControllerCameraTestBindings.lastAction), left + 18, bottom + 15, 11, "o")
	gl.Color(1, 1, 1, 1)
	gl.LineWidth(1)
end

--------------------------------------------------------------------------------
-- SECTION: Debug/help UI drawing
--------------------------------------------------------------------------------
function ControllerCameraTestDrawHelpOverlay()
	local screenWidth = viewSizeX > 0 and viewSizeX or 1280
	local screenHeight = viewSizeY > 0 and viewSizeY or 720
	local width = math.min(760, math.max(300, screenWidth - 40))
	local height = math.min(430, math.max(300, screenHeight - 60))
	local left = math.max(20, (screenWidth - width) * 0.5)
	local top = math.min(screenHeight - 20, height + 20)
	local bottom = top - height
	local right = left + width
	local x = left + 18
	local y = top - 24
	local lineHeight = 17
	local maxChars = math.max(28, math.floor((width - 36) / 7.5))
	local lines = {
		"Controller Camera Test Help",
		"Camera/Move: LS pan | RS X rotate | RS Y zoom | LB+RS Y pitch | LT boost",
		"Selection: A select | A hold area-select units first | LT+A hold includes buildings",
		"Double-tap A on unit: visible same type | LT+double-tap A on unit: all owned same type | empty: no action",
		"Back/View + double-tap A: focus Commander | Start/Menu: reserved",
		"LT+double-tap A on empty reticle: select all idle units in current idle type",
		"Context Actions: X tap context | X hold one unit draw queued path | X hold many units line/spread | RT+B stop | RT+X attack/fight",
		"Combat Layers: RT+A reserved/disabled | RT+Y tactical radial | LS/Dpad choose | A confirm | B/Y close",
		"Queue Modifier: hold LT while confirming Move/Fight/Attack/Reclaim/Repair/Build to queue like Shift",
		"Constructor Radial: Y open | LS/Dpad select | LB/RB page | Y close",
		"   * A enter placement | X quick-place | B close radial",
		"Factory Radial: Y open | LS/Dpad select | LB/RB page | Y close",
		"   * A add 1 queue | LT+A add 5 queue | B remove 1 | LT+B remove 5",
		"Placement Mode: A place | X place+stay | B cancel | LT queue | RT queue front",
		"   * RS X camera rotate | Dpad L/R building facing | Dpad U/D spacing | LB/RB pattern | A/X hold Line/Grid",
		"Idle Cycling: Dpad L/R idle unit | LB+Dpad L/R idle type | Dpad U/D recall cam | LT+Dpad U/D store cam",
		"Control Groups: hold RB overlay | RB+Dpad U/D slot | RB+tap Dpad L recall | RB+hold Dpad L assign same type + auto-add",
		"Control Groups: RB+B clear | RB+Dpad R, RB+A, RB+X are reserved/disabled",
		"Status: controller mode shows compact factory/constructor activity panel; Y opens its radial",
		"System UI: End Controller Settings | Page Up Debug | Page Down Help | Home Reset Settings Defaults",
		"Fallback UI commands: /luaui cct_debug | cct_help | cct_settings | cct_reset_settings",
		"Settings UI: D-pad/arrows adjust | LB/RB or Tab categories | A/Enter select | B/Escape close | X/Y reset",
		"Bindings tab: A capture next input | B cancel capture | X reset binding | Y reset all bindings",
		"Settings: saved ControllerCameraTestSettings override edited defaults after reload; Home applies code defaults",
		"Tuning Selection: " .. ControllerCameraTestCurrentSettingLabel(),
	}

	gl.Color(0, 0, 0, 0.86)
	gl.Rect(left, bottom, right, top)
	gl.Color(0.12, 0.18, 0.23, 0.96)
	gl.Rect(left, top - 34, right, top)
	gl.Color(0.72, 0.88, 1, 0.9)
	gl.Rect(left, top - 34, right, top - 33)
	gl.Color(1, 1, 1, 1)

	for i, line in ipairs(lines) do
		local size = (i == 1) and 18 or 14
		local colorIsHeader = i == 1
		if colorIsHeader then
			gl.Color(0.72, 0.9, 1, 1)
		else
			gl.Color(1, 1, 1, 0.96)
		end
		local remaining = line
		local first = true
		while #remaining > 0 and y > bottom + 12 do
			local drawText = remaining
			if #remaining > maxChars then
				local breakAt = maxChars
				for pos = maxChars, math.max(1, math.floor(maxChars * 0.5)), -1 do
					if string.sub(remaining, pos, pos) == " " then
						breakAt = pos
						break
					end
				end
				drawText = string.sub(remaining, 1, breakAt)
				remaining = string.gsub(string.sub(remaining, breakAt + 1), "^%s+", "")
			else
				remaining = ""
			end
			gl.Text((first and "" or "  ") .. drawText, x, y, size, "o")
			y = y - lineHeight
			first = false
		end
	end
	gl.Color(1, 1, 1, 1)
end

function widget:DrawScreen()
	local mathMax, mathPi = math.max, math.pi
	updateDebugLatchSummaries()
	drawControllerReticle()
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestBuildMenu.open then
		ControllerCameraTestDrawBuildRadial()
	end
	if not ControllerCameraTestSettingsUI.open and ControllerCameraTestTacticalMenu.open then
		ControllerCameraTestDrawTacticalRadial()
	end
	if not ControllerCameraTestSettingsUI.open then
		ControllerCameraTestDrawQueueIndicator()
		ControllerCameraTestDrawPlacementPatternPopup()
	end
	ControllerCameraTestDrawCompactSelectedStatusPanel()
	if not ControllerCameraTestSettingsUI.open then
		ControllerCameraTestDrawControlGroupOverlay()
	end
	if ControllerCameraTestSettings.helpOverlayVisible then
		ControllerCameraTestDrawHelpOverlay()
	end
	ControllerCameraTestDrawSettingsUI()
	if ControllerCameraTestSettingsUI.open then
		return
	end
	if not ControllerCameraTestSettings.debugPanelVisible then
		return
	end

	local function yesNo(value)
		return value and "yes" or "no"
	end
	local function activeInactive(value)
		return value and "active" or "inactive"
	end
	local function trimText(text)
		return (tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", ""))
	end
	local function WrapDebugLine(text, maxChars)
		text = tostring(text or "")
		maxChars = mathMax(8, maxChars)
		if #text <= maxChars then
			return { text }
		end

		local lines = {}
		local remaining = text
		local firstLine = true

		while #remaining > 0 do
			local lineMaxChars = firstLine and maxChars or mathMax(8, maxChars - 2)
			if #remaining <= lineMaxChars then
				lines[#lines + 1] = (firstLine and "" or "  ") .. remaining
				break
			end

			local minBreak = mathMax(1, math.floor(lineMaxChars * 0.45))
			local breakAt = nil
			for i = lineMaxChars, minBreak, -1 do
				local char = string.sub(remaining, i, i)
				if char == " " or char == "," or char == "/" or char == ";" or char == "|" then
					breakAt = i
					break
				end
			end

			breakAt = breakAt or lineMaxChars
			local line = trimText(string.sub(remaining, 1, breakAt))
			if line == "" then
				line = string.sub(remaining, 1, lineMaxChars)
				breakAt = lineMaxChars
			end

			lines[#lines + 1] = (firstLine and "" or "  ") .. line
			remaining = trimText(string.sub(remaining, breakAt + 1))
			firstLine = false
		end

		return lines
	end
	local function drawLine(text, drawX, drawY)
		gl.Text(text, drawX, drawY, 15, "o")
	end
	local function drawSection(section, drawX, drawY, maxChars, contentBottom, columnWidth)
		if drawY < contentBottom then
			return drawY, false
		end

		local isExpanded = ControllerCameraTestDebugSections[section.key]
		if isExpanded == nil then
			isExpanded = true
		end

		local arrow = isExpanded and "▼ " or "▶ "
		local displayTitle = arrow .. section.title

		if section.key then
			table.insert(ControllerCameraTestDebugSectionHitboxes, {
				key = section.key,
				x1 = drawX,
				y1 = drawY - 3,
				x2 = drawX + columnWidth,
				y2 = drawY + 16,
			})
		end

		gl.Color(0.62, 0.86, 1, 1)
		drawLine(displayTitle, drawX, drawY)
		gl.Color(1, 1, 1, 1)
		drawY = drawY - 17

		if not isExpanded then
			return drawY - 6, true
		end

		for _, line in ipairs(section.lines) do
			for _, wrappedLine in ipairs(WrapDebugLine(line, maxChars)) do
				if drawY < contentBottom then
					return drawY, false
				end
				drawLine(wrappedLine, drawX, drawY)
				drawY = drawY - 17
			end
		end

		return drawY - 6, true
	end

	ensureDebugPanelInitialized()

	local panelLeft = debugPanelX
	local panelBottom = debugPanelY
	local panelWidth = debugPanelWidth
	local panelHeight = ControllerCameraTestDebugCompact and 120 or debugPanelHeight
	local panelRight = panelLeft + panelWidth
	local panelTop = panelBottom + panelHeight
	local padding = 8 -- Freed DEBUG_PANEL_PADDING upvalue
	local headerHeight = 22 -- Freed DEBUG_PANEL_HEADER_HEIGHT upvalue
	local useColumns = (not ControllerCameraTestDebugCompact) and (panelWidth >= 720)
	local columnGap = 12
	local columnWidth = useColumns
		and ((panelWidth - (padding * 2) - columnGap) * 0.5)
		or (panelWidth - (padding * 2))
	local maxChars = mathMax(12, math.floor(columnWidth / 7.8))
	local contentBottom = panelBottom + padding + 14 -- Freed DEBUG_PANEL_RESIZE_HANDLE upvalue
	local cameraState = spGetCameraState and spGetCameraState()
	if type(cameraState) ~= "table" then
		cameraState = {}
	end

	local reticleWorldSummary = "none"
	if reticleHasWorldTarget then
		reticleWorldSummary = string.format("x=%.1f y=%.1f z=%.1f", reticleWorldX, reticleWorldY, reticleWorldZ)
	end

	local currentLocalIndex = 1
	for idx, option in ipairs(ControllerCameraTestBuildMenu.radialVisibleOptions or {}) do
		if option.menuIndex == ControllerCameraTestBuildMenu.selectedIndex then
			currentLocalIndex = idx
			break
		end
	end

	local selectedUnits = type(spGetSelectedUnits) == "function" and spGetSelectedUnits() or {}
	local isFactoryRadialVal = ControllerCameraTestBuildMenu.open and ControllerCameraTestSelectionPrefersFactoryQueue(selectedUnits)
	local isFactoryRadial = yesNo(isFactoryRadialVal)
	local currentOption = ControllerCameraTestGetRadialCurrentOption()
	local highlightedQueueCount = 0
	if currentOption and currentOption.cmdID and ControllerCameraTestBuildMenu.factoryQueueCounts then
		highlightedQueueCount = ControllerCameraTestBuildMenu.factoryQueueCounts[currentOption.cmdID] or 0
	end
	local hasQueueCounts = "no"
	if ControllerCameraTestBuildMenu.factoryQueueCounts then
		for _, count in pairs(ControllerCameraTestBuildMenu.factoryQueueCounts) do
			if count > 0 then
				hasQueueCounts = "yes"
				break
			end
		end
	end

	local factoryProgressKnown = "no"
	local factoryProgressCmdID = "none"
	local factoryProgressValue = "none"
	local factoryProgressSource = "none"
	if isFactoryRadialVal and currentOption and currentOption.cmdID and ControllerCameraTestBuildMenu.factoryQueueProgress then
		local progress = ControllerCameraTestBuildMenu.factoryQueueProgress[currentOption.cmdID]
		if progress then
			factoryProgressKnown = "yes"
			factoryProgressCmdID = tostring(currentOption.cmdID)
			factoryProgressValue = string.format("%.2f", progress)
			factoryProgressSource = tostring(ControllerCameraTestBuildMenu.factoryProgressSource or "GetUnitIsBuilding")
		end
	end
	if factoryProgressKnown ~= "yes" and ControllerCameraTestBuildMenu.factoryProgressKnown == "yes" then
		factoryProgressKnown = "yes"
		factoryProgressCmdID = tostring(ControllerCameraTestBuildMenu.factoryProgressCmdID or "none")
		factoryProgressValue = tostring(ControllerCameraTestBuildMenu.factoryProgressValue or "none")
		factoryProgressSource = tostring(ControllerCameraTestBuildMenu.factoryProgressSource or "none")
	end
	local activeGroupSlot = ControllerCameraTestNormalizeControlGroupSlot(ControllerCameraTestControlGroups.activeSlot or 1)
	local activeGroupEntry = ControllerCameraTestControlGroups.slots[activeGroupSlot]
	local activeGroupType = activeGroupEntry and (activeGroupEntry.typeName or ControllerCameraTestUnitTypeName(activeGroupEntry.unitDefID)) or "none"
	local activeGroupAuto = activeGroupEntry and activeGroupEntry.autoAddUnitDefID and ControllerCameraTestUnitTypeName(activeGroupEntry.autoAddUnitDefID) or "none"
	local activeGroupCount = activeGroupEntry and tostring(activeGroupEntry.count or #(activeGroupEntry.units or {})) or "0"

	local controllerSections = {
		{
			key = "Input",
			title = "Input / Controller",
			lines = {
				"Widget: Controller Camera Test",
				"API: " .. yesNo(apiAvailable),
				"Name: " .. tostring(controllerName),
				"instanceId: " .. tostring(controllerInstanceId),
				"Input: " .. (controllerMode and "controller" or "mouse"),
				"Mode: " .. tostring(ControllerCameraTestLayerDebug.modeSummary),
				"Held: " .. heldButtonsSummary,
				"Pressed recent: " .. pressedRecentlySummary,
				"Released recent: " .. releasedRecentlySummary,
				string.format("LS: x=%.3f y=%.3f", normalizedLeftX, normalizedLeftY),
				string.format("RS: x=%.3f y=%.3f", normalizedRightX, normalizedRightY),
				string.format("LT: %.3f", normalizedLeftTrigger),
				string.format("RT: %.3f", normalizedRightTrigger),
				"Active axes: " .. activeAxesSummary,
			},
		},
		{
			key = "Reticle",
			title = "Reticle",
			lines = {
				"Reticle visible: " .. yesNo(reticleVisible),
				string.format("Screen: x=%.1f y=%.1f", screenCenterX, screenCenterY),
				"World: " .. reticleWorldSummary,
				"Target type: " .. reticleTargetType,
				"Has world target: " .. yesNo(reticleHasWorldTarget),
			},
		},
		{
			key = "Selection",
			title = "Selection",
			lines = {
				"Selection test: " .. yesNo(selectionTestActive),
				"Last selected unitID: " .. tostring(lastReticleSelectedUnitID),
				"Selection result: " .. lastSelectionResult,
				"Last B-button result: " .. tostring(lastBButtonResult),
				"Last clear-selection result: " .. tostring(lastClearSelectionResult),
				"Selection msg: " .. selectionDebugMessage,
				"Cycle: " .. tostring(ControllerCameraTestCycleDebug.lastResult) .. " count=" .. tostring(ControllerCameraTestCycleDebug.lastCount),
			},
		},
		{
			key = "Bookmarks",
			title = "Bookmarks",
			lines = {
				"Bookmark: " .. tostring(ControllerCameraTestBookmarkDebug.lastResult),
			},
		},
		{
			key = "IdleCycle",
			title = "Idle Unit Cycling",
			lines = {
				"Idle result: " .. tostring(ControllerCameraTestIdleCycle.lastResult),
				"Idle unitID: " .. tostring(ControllerCameraTestIdleCycle.currentUnitID or "none"),
				"Idle type: " .. tostring(ControllerCameraTestIdleCycle.lastTypeName),
				"Idle count/type count: " .. tostring(ControllerCameraTestIdleCycle.lastCount),
				"Idle selected all count: " .. tostring(ControllerCameraTestIdleCycle.selectedAllCount),
			},
		},
		{
			key = "ControlGroups",
			title = "Controller Groups",
			lines = {
				"Active group slot: " .. ControllerCameraTestGetControlGroupDisplaySlot(ControllerCameraTestControlGroups.activeSlot or 1),
				"Group active type/count: " .. tostring(activeGroupType) .. " x" .. tostring(activeGroupCount),
				"Group auto-add type: " .. tostring(activeGroupAuto),
				"Group last action: " .. tostring(ControllerCameraTestControlGroups.lastAction),
				"Group last slot: " .. tostring(ControllerCameraTestControlGroups.lastSlot),
				"Group last count: " .. tostring(ControllerCameraTestControlGroups.lastCount),
				"Group left input: " .. tostring(ControllerCameraTestControlGroups.leftInputState),
			},
		},
		{
			key = "QuickGroups",
			title = "Quick Groups",
			lines = {
				"Quick group: " .. tostring(ControllerCameraTestQuickGroups.lastResult) .. " slot=" .. tostring(ControllerCameraTestQuickGroups.lastSlot),
			},
		},
		{
			key = "Tuning",
			title = "Tuning",
			lines = {
				"Tuning: " .. ControllerCameraTestCurrentSettingLabel(),
				"Tuning action: " .. tostring(ControllerCameraTestTuning.lastAction),
				"Settings UI: End | Reset all settings: Home",
				"Settings source: saved config; Home resets code defaults",
				"Settings UI open: " .. yesNo(ControllerCameraTestSettingsUI.open),
				"Settings category: " .. tostring(ControllerCameraTestSettingsUI.lastCategory),
				"Binding capture: " .. tostring(ControllerCameraTestBindings.captureAction or "none"),
				"Binding result: " .. tostring(ControllerCameraTestBindings.lastAction),
				"Last key: key=" .. tostring(ControllerCameraTestKeyDebug.rawKey) .. " label=" .. tostring(ControllerCameraTestKeyDebug.label),
				"Last key action: " .. tostring(ControllerCameraTestKeyDebug.matchedAction),
				"Last UI toggle: " .. tostring(ControllerCameraTestKeyDebug.lastUIToggle),
				string.format("Thresholds X/A/group: %.2f / %.2f / %.2f", ControllerCameraTestSettings.xHoldSeconds, ControllerCameraTestSettings.aHoldSeconds, ControllerCameraTestSettings.controlGroupAssignHoldSeconds),
				string.format("Radial scale groundwork: %.2f", ControllerCameraTestSettings.radialScale),
			},
		},
	}
	local cameraSections = {
		{
			key = "Camera",
			title = "Camera",
			lines = {
				"Camera: " .. tostring(cameraState.name or cameraMode) .. " mode=" .. tostring(cameraState.mode or cameraModeId),
				"RS Y mode: " .. rightStickYMode,
				"LT boost pan+zoom: " .. activeInactive(fastPanActive),
				"LB camera mod: " .. activeInactive(lbCameraModifierActive),
				"Pan active: " .. yesNo(panActive),
				"Zoom active: " .. yesNo(zoomActive),
				"Rotate active: " .. yesNo(rotationActive),
				"Pitch active: " .. yesNo(pitchActive),
				string.format("Zoom speed: %.1fx", zoomSpeedMultiplier),
				string.format("Pan speed setting: %.0f", ControllerCameraTestSettings.panSpeed),
				string.format("Rotate/Pitch: %.2f / %.2f", ControllerCameraTestSettings.rotationSpeed, ControllerCameraTestSettings.pitchSpeed),
				string.format("Smoothing/curves: %.2f / %.2f / %.2f", ControllerCameraTestSettings.cameraSmoothing, ControllerCameraTestSettings.stickCurve, ControllerCameraTestSettings.triggerCurve),
				string.format("Deadzones stick/trigger: %.0f / %.0f", ControllerCameraTestSettings.stickDeadzone, ControllerCameraTestSettings.triggerDeadzone),
				"Zoom method: " .. zoomMethod,
				"Rotate method: " .. rotationMethod,
				"Pitch method: " .. pitchMethod,
				"px/py/pz: " .. formatNumber(cameraState.px) .. " / " .. formatNumber(cameraState.py) .. " / " .. formatNumber(cameraState.pz),
				"dist: " .. formatNumber(cameraState.dist),
				"height/old: " .. formatNumber(cameraState.height) .. " / " .. formatNumber(cameraState.oldHeight),
				"rx/ry/rz: " .. formatNumber(cameraState.rx) .. " / " .. formatNumber(cameraState.ry) .. " / " .. formatNumber(cameraState.rz),
				"dx/dy/dz: " .. formatNumber(cameraState.dx) .. " / " .. formatNumber(cameraState.dy) .. " / " .. formatNumber(cameraState.dz),
				"fov: " .. formatNumber(cameraState.fov),
				"Pitch field: " .. cameraPitchSummary,
			},
		},
		{
			key = "Commands",
			title = "Commands",
			lines = {
				"RT command layer: " .. activeInactive(commandLayerActive),
				"Layout: " .. activeButtonLayoutSummary,
				"Normal preview: " .. normalPreviewSummary,
				"Command preview: " .. commandPreviewSummary,
				"Command action: " .. tostring(ControllerCameraTestLayerDebug.commandLayerAction),
				"Normal utility: " .. tostring(ControllerCameraTestLayerDebug.normalUtilityAction),
				"Queue modifier active: " .. yesNo(ControllerCameraTestIsQueueModifierActive()),
				"Single path active: " .. yesNo(ControllerCameraTestDragCommand.singleUnitPathActive),
				"Single path waypoints: " .. tostring(ControllerCameraTestDragCommand.singleUnitWaypointCount or 0),
				"Single path result: " .. tostring(ControllerCameraTestDragCommand.singleUnitPathResult),
				"Default cmd index: " .. tostring(ControllerCameraTestCommandDebug.defaultCmdIndex),
				"Default cmd ID: " .. tostring(ControllerCameraTestCommandDebug.defaultCmdID),
				"Default cmd type: " .. tostring(ControllerCameraTestCommandDebug.defaultCmdType),
				"Default cmd name: " .. tostring(ControllerCameraTestCommandDebug.defaultCmdName),
				"Is build: " .. tostring(ControllerCameraTestCommandDebug.isBuild),
				"Issued cmd ID: " .. tostring(ControllerCameraTestCommandDebug.issuedCmdID),
				"Issued params count: " .. tostring(ControllerCameraTestCommandDebug.issuedParamsCount),
				"Last command options: " .. tostring(ControllerCameraTestCommandDebug.lastOptions),
				"Last command result: " .. tostring(ControllerCameraTestCommandDebug.lastResult),
				"Last issued command: " .. tostring(lastIssuedCommand),
				"Mex smart available: " .. tostring(ControllerCameraTestCommandDebug.mexSmartAvailable),
				"Mex nearest spot: " .. tostring(ControllerCameraTestCommandDebug.mexNearestSpot),
				"Mex building cmd ID: " .. tostring(ControllerCameraTestCommandDebug.mexBuildingCmdID),
				"Mex action result: " .. tostring(ControllerCameraTestCommandDebug.mexActionResult),
				"Mex ApplyPreviewCmds: " .. tostring(ControllerCameraTestCommandDebug.mexApplyPreviewPath),
				"Mex fallback GiveOrder: " .. tostring(ControllerCameraTestCommandDebug.mexFallbackGiveOrderPath),
			},
		},
		{
			key = "AreaSelect",
			title = "Area Select",
			lines = {
				"Area active: " .. yesNo(ControllerCameraTestAreaSelect.active),
				"Area radius: " .. tostring(math.floor(ControllerCameraTestAreaSelect.radius)),
				"Area filter: " .. tostring(ControllerCameraTestAreaSelect.filterMode),
				"Double-tap action: " .. tostring(ControllerCameraTestAreaSelect.doubleTapAction),
				"Same-type target: " .. tostring(ControllerCameraTestAreaSelect.sameTypeTarget) .. " defID=" .. tostring(ControllerCameraTestAreaSelect.sameTypeUnitDefID),
				"Same-type source/count: " .. tostring(ControllerCameraTestAreaSelect.sameTypeSource) .. " candidates=" .. tostring(ControllerCameraTestAreaSelect.sameTypeCandidateCount) .. " selected=" .. tostring(ControllerCameraTestAreaSelect.sameTypeSelectedCount),
				"Area result: " .. tostring(ControllerCameraTestAreaSelect.lastResult) .. " count=" .. tostring(ControllerCameraTestAreaSelect.lastCount),
				"Area select debug: " .. tostring(ControllerCameraTestLayerDebug.areaSelect),
			},
		},
		{
			key = "TacticalMenu",
			title = "Tactical Menu",
			lines = {
				"Tactical open: " .. yesNo(ControllerCameraTestTacticalMenu.open),
				"Tactical radial visible: " .. yesNo(ControllerCameraTestTacticalMenu.open),
				"Tactical command: " .. tostring(ControllerCameraTestTacticalMenu.highlightedName),
				"Tactical result: " .. tostring(ControllerCameraTestTacticalMenu.lastResult),
			},
		},
		{
			key = "BuildMenu",
			title = "Build Menu / Placement",
			lines = {
				"Open: " .. yesNo(ControllerCameraTestBuildMenu.open),
				"Option count: " .. tostring(ControllerCameraTestBuildMenu.optionCount),
				"Highlight index: " .. tostring(ControllerCameraTestBuildMenu.selectedIndex) .. " / " .. tostring(ControllerCameraTestBuildMenu.optionCount),
				"Highlight name: " .. tostring(ControllerCameraTestBuildMenu.highlightedName),
				"Highlight cmdID: " .. tostring(ControllerCameraTestBuildMenu.highlightedCmdID),
				"Options: " .. ControllerCameraTestGetBuildOptionSummary(),
				"Placement active: " .. yesNo(ControllerCameraTestBuildPlacement.active),
				"Placement facing: " .. tostring(ControllerCameraTestBuildPlacement.facing),
				"Queue active: " .. yesNo(ControllerCameraTestBuildPlacement.queueActive),
				"Placement result: " .. tostring(ControllerCameraTestBuildPlacement.lastResult),
				"Placement issued: " .. tostring(ControllerCameraTestBuildPlacement.lastIssuedCount),
				"Menu place result: " .. tostring(ControllerCameraTestBuildMenu.placementResult),
				"Placement params: " .. tostring(ControllerCameraTestBuildMenu.placementParamsCount),
				"Last action: " .. tostring(ControllerCameraTestBuildMenu.lastAction),
				"Radial open: " .. yesNo(ControllerCameraTestBuildMenu.open),
				"Radial category: " .. tostring(ControllerCameraTestBuildMenu.radialCategoryName),
				"Radial category count: " .. tostring(ControllerCameraTestBuildMenu.radialCategories and #ControllerCameraTestBuildMenu.radialCategories or 0),
				"Radial page: " .. tostring(ControllerCameraTestBuildMenu.radialPage) .. " / " .. tostring(ControllerCameraTestBuildMenu.radialPageCount),
				"Radial visible count: " .. tostring(ControllerCameraTestBuildMenu.radialVisibleOptions and #ControllerCameraTestBuildMenu.radialVisibleOptions or 0),
				"Radial selected local index: " .. tostring(currentLocalIndex or 1),
				"Radial highlighted name: " .. tostring(ControllerCameraTestBuildMenu.highlightedName),
				"Radial last action: " .. tostring(ControllerCameraTestBuildMenu.radialLastAction or "none"),
				"Native placement active: " .. yesNo(ControllerCameraTestBuildPlacement.nativePreviewActive),
				"Native set cmd result: " .. tostring(ControllerCameraTestBuildPlacement.nativeSetActiveCommandResult or "none"),
				"Native cmdDescIndex: " .. tostring(ControllerCameraTestBuildPlacement.cmdDescIndex or "none"),
				"Placement mode: " .. tostring(ControllerCameraTestBuildPlacement.placementMode or "none"),
				"Placement pattern: " .. tostring(ControllerCameraTestBuildPlacement.placementPattern),
				"Placement spacing: " .. tostring(ControllerCameraTestBuildPlacement.placementSpacing),
				"Placement input: RS X camera, D-pad L/R facing",
				"Placement popup: " .. tostring(ControllerCameraTestPlacementPopup.lastResult),
				"Queue front active (RT): " .. yesNo(ControllerCameraTestBuildPlacement.queueFrontActive),
				"Last construction shortcut: " .. tostring(ControllerCameraTestBuildPlacement.lastConstructionShortcut),
				"Grid shortcut result: " .. tostring(ControllerCameraTestBuildPlacement.gridShortcutResult),
				"Factory radial: " .. tostring(isFactoryRadial),
				"Highlighted queue count: " .. tostring(highlightedQueueCount),
				"Last factory queue action: " .. tostring(ControllerCameraTestBuildMenu.radialLastAction or "none"),
				"Factory queue counts known: " .. tostring(hasQueueCounts),
				"Factory progress known: " .. tostring(factoryProgressKnown),
				"Factory progress cmdID: " .. tostring(factoryProgressCmdID),
				"Factory progress value: " .. tostring(factoryProgressValue),
				"Factory progress source: " .. tostring(factoryProgressSource),
				"Drag active: " .. yesNo(ControllerCameraTestDragCommand.active),
				"Drag mode: " .. tostring(ControllerCameraTestDragCommand.mode),
				"Drag start: " .. (ControllerCameraTestDragCommand.startX and string.format("%.0f, %.0f, %.0f", ControllerCameraTestDragCommand.startX, ControllerCameraTestDragCommand.startY, ControllerCameraTestDragCommand.startZ) or "nil"),
				"Drag end: " .. (ControllerCameraTestDragCommand.endX and string.format("%.0f, %.0f, %.0f", ControllerCameraTestDragCommand.endX, ControllerCameraTestDragCommand.endY, ControllerCameraTestDragCommand.endZ) or "nil"),
				"Drag preview points count: " .. tostring(ControllerCameraTestDragCommand.previewPoints and #ControllerCameraTestDragCommand.previewPoints or 0),
				"Drag last result: " .. tostring(ControllerCameraTestDragCommand.lastResult),
				"Drag native route used: " .. yesNo(ControllerCameraTestDragCommand.nativeRouteUsed),
				"Native blueprint preview route: " .. tostring(ControllerCameraTestDragCommand.nativeRouteName),
				"Native preview result: " .. tostring(ControllerCameraTestDragCommand.nativePreviewResult),
				"Custom grid fallback: " .. tostring(ControllerCameraTestDragCommand.customGridFallback),
				"Compact selected status: " .. tostring(ControllerCameraTestSelectedStatus.mode),
				"Vanilla command panel: " .. tostring(ControllerCameraTestSelectedStatus.vanillaCommandPanelStatus),
			},
		},
	}

	gl.Color(0, 0, 0, 0.82)
	gl.Rect(panelLeft, panelBottom, panelRight, panelTop)
	gl.Color(0.06, 0.11, 0.15, 0.96)
	gl.Rect(panelLeft, panelTop - headerHeight, panelRight, panelTop)
	gl.Color(0.56, 0.84, 1, 0.62)
	gl.Rect(panelLeft, panelTop - headerHeight, panelRight, panelTop - headerHeight + 1)
	gl.Color(0.76, 0.88, 0.96, 0.95)
	gl.Rect(panelLeft, panelTop - 1, panelRight, panelTop)
	gl.Rect(panelLeft, panelBottom, panelRight, panelBottom + 1)
	gl.Rect(panelLeft, panelBottom, panelLeft + 1, panelTop)
	gl.Rect(panelRight - 1, panelBottom, panelRight, panelTop)
	gl.Color(1, 1, 1, 1)

	ControllerCameraTestDebugSectionHitboxes = {}

	local textX = panelLeft + padding
	local textY = panelTop - 15
	gl.Text("Controller Debug", textX, textY, 15, "o")

	-- Draw Toggle Button
	local btnText = ControllerCameraTestDebugCompact and " [Full] " or "[Compact]"
	gl.Color(0.2, 0.4, 0.6, 0.6)
	gl.Rect(panelRight - 85, panelTop - headerHeight + 3, panelRight - 15, panelTop - 3)
	gl.Color(1, 1, 1, 1)
	gl.Text(btnText, panelRight - 80, panelTop - 15, 12, "o")

	textY = panelTop - headerHeight - padding - 10

	if ControllerCameraTestDebugCompact then
		local compactLines = {
			"Mode: " .. tostring(ControllerCameraTestLayerDebug.modeSummary) .. " | Held: " .. heldButtonsSummary .. " | Pressed: " .. pressedRecentlySummary,
			"Idle: " .. tostring(ControllerCameraTestIdleCycle.lastTypeName) .. " x" .. tostring(ControllerCameraTestIdleCycle.lastCount) .. " | Group " .. ControllerCameraTestGetControlGroupDisplaySlot(activeGroupSlot) .. " " .. tostring(activeGroupType) .. " x" .. tostring(activeGroupCount) .. " | A2: " .. tostring(ControllerCameraTestAreaSelect.doubleTapAction),
			"Queue: " .. yesNo(ControllerCameraTestIsQueueModifierActive()) .. " | Settings: " .. yesNo(ControllerCameraTestSettingsUI.open) .. " | Tactical: " .. yesNo(ControllerCameraTestTacticalMenu.open) .. " | Build: " .. yesNo(ControllerCameraTestBuildMenu.open),
			"Key: " .. tostring(ControllerCameraTestKeyDebug.rawKey) .. " " .. tostring(ControllerCameraTestKeyDebug.label) .. " -> " .. tostring(ControllerCameraTestKeyDebug.matchedAction),
			"Radial: " .. yesNo(ControllerCameraTestBuildMenu.open) .. " | Cat: " .. tostring(ControllerCameraTestBuildMenu.radialCategoryName) .. " | Highlight: " .. tostring(ControllerCameraTestBuildMenu.highlightedName) .. " (Q:" .. tostring(highlightedQueueCount) .. (factoryProgressKnown == "yes" and " P:" .. factoryProgressValue or "") .. ")",
			"Placement: " .. tostring(ControllerCameraTestBuildPlacement.placementMode or "none") .. " | Pattern: " .. tostring(ControllerCameraTestBuildPlacement.placementPattern) .. " | Spacing: " .. tostring(ControllerCameraTestBuildPlacement.placementSpacing),
			"Drag: Act=" .. yesNo(ControllerCameraTestDragCommand.active) .. " Mode=" .. tostring(ControllerCameraTestDragCommand.mode) .. " Pts=" .. tostring(ControllerCameraTestDragCommand.previewPoints and #ControllerCameraTestDragCommand.previewPoints or 0) .. " Path=" .. tostring(ControllerCameraTestDragCommand.singleUnitWaypointCount or 0) .. " Route=" .. (ControllerCameraTestDragCommand.nativeRouteUsed and "Native" or "Fallback"),
			"Last Action: " .. tostring(ControllerCameraTestBuildMenu.lastAction or "none") .. " | Result: " .. tostring(ControllerCameraTestBuildMenu.radialLastAction or "none"),
			"Selection Msg: " .. selectionDebugMessage .. " | Last cmd: " .. tostring(lastIssuedCommand)
		}

		for _, line in ipairs(compactLines) do
			if textY < contentBottom then
				break
			end
			drawLine(line, textX, textY)
			textY = textY - 17
		end
	else
		if useColumns then
			local rightX = textX + columnWidth + columnGap
			local leftY = textY
			local rightY = textY

			for _, section in ipairs(controllerSections) do
				leftY = drawSection(section, textX, leftY, maxChars, contentBottom, columnWidth)
			end
			for _, section in ipairs(cameraSections) do
				rightY = drawSection(section, rightX, rightY, maxChars, contentBottom, columnWidth)
			end
		else
			for _, section in ipairs(controllerSections) do
				textY = drawSection(section, textX, textY, maxChars, contentBottom, columnWidth)
			end
			for _, section in ipairs(cameraSections) do
				textY = drawSection(section, textX, textY, maxChars, contentBottom, columnWidth)
			end
		end
	end

	local handleRight = panelRight - 4
	local handleBottom = panelBottom + 4
	gl.Color(0.72, 0.86, 0.94, 0.75)
	gl.Rect(handleRight - 4, handleBottom, handleRight, handleBottom + 1)
	gl.Rect(handleRight - 8, handleBottom + 4, handleRight, handleBottom + 5)
	gl.Rect(handleRight - 12, handleBottom + 8, handleRight, handleBottom + 9)
	gl.Color(1, 1, 1, 1)
end

function widget:GetConfigData()
	ensureDebugPanelInitialized()
	ControllerCameraTestEnsureBindings()
	local settings = {}
	for key, value in pairs(ControllerCameraTestSettings) do
		if type(value) ~= "table" then
			settings[key] = value
		end
	end

	local savedSections = {}
	if ControllerCameraTestDebugSections then
		for k, v in pairs(ControllerCameraTestDebugSections) do
			savedSections[k] = v
		end
	end

	return {
		panelX = debugPanelX,
		panelY = debugPanelY,
		panelWidth = debugPanelWidth,
		panelHeight = debugPanelHeight,
		settings = settings,
		debugSections = savedSections,
		debugCompact = ControllerCameraTestDebugCompact,
		bindings = ControllerCameraTestBindings.actions,
	}
end

function widget:SetConfigData(data)
	if type(data) ~= "table" then
		return
	end

	if type(data.settings) == "table" then
		for key, value in pairs(data.settings) do
			if ControllerCameraTestSettings[key] ~= nil then
				ControllerCameraTestSettings[key] = value
			end
		end
	end
	ControllerCameraTestApplySettingsDefaults()
	ControllerCameraTestEnsureBindings()
	if type(data.bindings) == "table" then
		for _, def in ipairs(ControllerCameraTestBindingDefinitions()) do
			local saved = data.bindings[def.action]
			if type(saved) == "string"
				and (saved == "LT" or saved == "RT" or XboxController.buttons[saved] ~= nil)
			then
				ControllerCameraTestBindings.actions[def.action] = saved
			end
		end
	end

	if type(data.debugSections) == "table" then
		for k, v in pairs(data.debugSections) do
			if ControllerCameraTestDebugSections[k] ~= nil then
				ControllerCameraTestDebugSections[k] = v
			end
		end
	end
	if data.debugCompact ~= nil then
		ControllerCameraTestDebugCompact = not not data.debugCompact
	end

	local panelX = tonumber(data.panelX)
	local panelY = tonumber(data.panelY)
	local panelWidth = tonumber(data.panelWidth)
	local panelHeight = tonumber(data.panelHeight)
	if not panelX or not panelY or not panelWidth or not panelHeight then
		ensureDebugPanelInitialized()
	else
		debugPanelX = panelX
		debugPanelY = panelY
		debugPanelWidth = panelWidth
		debugPanelHeight = panelHeight
		debugPanelInitialized = true
		if viewSizeX > 0 and viewSizeY > 0 then
			clampDebugPanelToScreen()
		end
	end
end

function widget:UnitFinished(unitID, unitDefID, unitTeam)
	ControllerCameraTestAutoAddFinishedUnitToGroups(unitID, unitDefID, unitTeam)
end

function widget:UnitDestroyed(unitID)
	ControllerCameraTestRemoveUnitFromControlGroups(unitID)
end

function widget:UnitTaken(unitID)
	ControllerCameraTestRemoveUnitFromControlGroups(unitID)
end

function widget:UnitGiven(unitID, unitDefID, unitTeam)
	ControllerCameraTestAutoAddFinishedUnitToGroups(unitID, unitDefID, unitTeam)
end

--------------------------------------------------------------------------------
-- SECTION: Widget lifecycle
--------------------------------------------------------------------------------
function widget:DrawWorld()
	if not controllerMode then
		return
	end

	if type(spGetSelectedUnits) == "function" and type(spGetUnitPosition) == "function" then
		local selectedUnits = spGetSelectedUnits()
		if selectedUnits and #selectedUnits > 0 then
			gl.LineWidth(2.5)
			gl.Color(0.2, 1.0, 0.2, 0.8) -- Bright green

			for i = 1, #selectedUnits do
				local unitID = selectedUnits[i]
				local x, y, z = spGetUnitPosition(unitID)
				if x and y and z then
					gl.DrawGroundCircle(x, y, z, 35, 32)
				end
			end
		end
	end

	if ControllerCameraTestAreaSelect.active and reticleHasWorldTarget then
		gl.LineWidth(2)
		gl.Color(0.25, 0.75, 1.0, 0.55)
		gl.DrawGroundCircle(reticleWorldX, reticleWorldY, reticleWorldZ, ControllerCameraTestAreaSelect.radius, 48)
	end

	if ControllerCameraTestBuildPlacement.active and reticleHasWorldTarget then
		gl.LineWidth(2.5)
		gl.Color(1.0, 0.88, 0.25, 0.7)
		gl.DrawGroundCircle(reticleWorldX, reticleWorldY, reticleWorldZ, 52, 32)
	end

	if ControllerCameraTestVisualFeedback.expireTime > debugEventTime and ControllerCameraTestVisualFeedback.targetX then
		local marker = ControllerCameraTestVisualFeedback
		local alpha = clamp(marker.expireTime - debugEventTime, 0, 1)
		if string.find(marker.kind, "attack") then
			gl.Color(1.0, 0.18, 0.12, 0.75 * alpha)
		elseif string.find(marker.kind, "build") then
			gl.Color(1.0, 0.88, 0.18, 0.75 * alpha)
		elseif string.find(marker.kind, "reclaim") or string.find(marker.kind, "repair") then
			gl.Color(0.35, 1.0, 0.45, 0.72 * alpha)
		elseif string.find(marker.kind, "guard") or string.find(marker.kind, "patrol") then
			gl.Color(0.25, 0.65, 1.0, 0.72 * alpha)
		else
			gl.Color(1.0, 1.0, 1.0, 0.62 * alpha)
		end
		gl.LineWidth(2)
		gl.DrawGroundCircle(
			marker.targetX,
			marker.targetY or 0,
			marker.targetZ,
			44 + ((1 - alpha) * 32),
			28
		)
	end

	-- Drag command previews
	local drag = ControllerCameraTestDragCommand
	if drag and drag.active and drag.startX
		and not (drag.nativeRouteUsed and drag.nativePreviewResult == "native preview active"
			and string.sub(tostring(drag.mode), 1, 5) == "build")
	then
		local startX, startY, startZ = drag.startX, drag.startY, drag.startZ
		local endX = drag.endX or reticleWorldX
		local endY = drag.endY or reticleWorldY
		local endZ = drag.endZ or reticleWorldZ

		if endX and startX then
			gl.LineWidth(3.0)
			if drag.mode == "reclaimArea" or drag.mode == "repairArea" or drag.mode == "attackArea" then
				local dx = endX - startX
				local dz = endZ - startZ
				local r = math.sqrt(dx*dx + dz*dz)
				if r < 10 then r = 120 end

				if drag.mode == "reclaimArea" then
					gl.Color(0.2, 0.8, 0.8, 0.65)
				elseif drag.mode == "repairArea" then
					gl.Color(0.2, 0.9, 0.3, 0.65)
				else
					gl.Color(1.0, 0.2, 0.2, 0.65)
				end
				gl.DrawGroundCircle(startX, startY, startZ, r, 64)
				gl.DrawGroundCircle(startX, startY, startZ, 12, 16)
			else
				if drag.mode == "moveLine" or drag.mode == "singleMovePath" then
					gl.Color(0.2, 0.8, 0.9, 0.7)
				elseif drag.mode == "fightLine" then
					gl.Color(1.0, 0.5, 0.1, 0.7)
				elseif drag.mode == "attackLine" then
					gl.Color(1.0, 0.1, 0.1, 0.8)
				else -- buildLine, buildGrid, buildBorder, buildSplit
					gl.Color(1.0, 0.85, 0.2, 0.7)
				end

				gl.BeginEnd(GL.LINE_STRIP, function()
					gl.Vertex(startX, startY, startZ)
					gl.Vertex(endX, endY, endZ)
				end)

				local pts = drag.previewPoints or {}
				for _, pt in ipairs(pts) do
					if pt[1] and pt[3] then
						local py = pt[2] or Spring.GetGroundHeight(pt[1], pt[3])
						gl.DrawGroundCircle(pt[1], py, pt[3], 24, 16)
					end
				end
			end
		end
	end

	gl.Color(1, 1, 1, 1)
	gl.LineWidth(1)
end
````


### 15.8 `Install_BAR_Controller_Support_v0.3.4_SAFE_LIVE.bat`

````bat
@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM ============================================================
REM Bootstrap: live output AND Desktop log via PowerShell Tee-Object.
REM No "press any key"; the window stays open with cmd /k.
REM ============================================================

if /I not "%~1"=="__RUN__" (
    for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "BOOT_STAMP=%%I"
    set "BOOT_LOG=%USERPROFILE%\Desktop\BAR_Controller_Install_v0.3.4_SAFE_LIVE_!BOOT_STAMP!.log"

    echo ============================================================
    echo BAR Controller Support v0.3.4 SAFE LIVE Installer
    echo ============================================================
    echo.
    echo Output will show live in this window AND save to:
    echo "!BOOT_LOG!"
    echo.
    echo This window will stay open when finished.
    echo.

    powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%~f0' __RUN__ '!BOOT_LOG!' 2>&1 | Tee-Object -FilePath '!BOOT_LOG!'; Write-Host ''; Write-Host '============================================================'; Write-Host 'LOG SAVED HERE:'; Write-Host '!BOOT_LOG!'; Write-Host '============================================================'; Write-Host ''; Write-Host 'Window will stay open. Type exit or close it manually.'; cmd /k"
    exit /b
)

set "INSTALL_LOG=%~2"
title BAR Controller Support v0.3.4 SAFE LIVE Installer

echo ============================================================
echo BAR Controller Support v0.3.4 SAFE LIVE Installer
echo ============================================================
echo.
echo This installer stages and verifies everything before replacing the active engine.
echo It also fixes the previous robocopy trailing-backslash bug.
echo.
echo Log:
echo "%INSTALL_LOG%"
echo.

REM ============================================================
REM Settings
REM ============================================================

set "BAR_ROOT=%LOCALAPPDATA%\Programs\Beyond-All-Reason"
set "BAR_DATA=%BAR_ROOT%\data"
set "ENGINE_SLOT=recoil_2025.06.19"
set "ENGINE_ROOT=%BAR_DATA%\engine"
set "DST_ENGINE=%ENGINE_ROOT%\%ENGINE_SLOT%"
set "DST_GAMES=%BAR_DATA%\games"
set "DST_BAR=%DST_GAMES%\BAR.sdd"
set "DST_CHOBBY=%DST_GAMES%\BYAR Chobby.sdd"
set "BACKUP=%BAR_DATA%\controller-support-cleaninstall-backups"

set "BAR_REPO=https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01.git"
set "BAR_BRANCH=controller-support-current-master-engine-shim"
set "CHOBBY_REPO=https://github.com/beyond-all-reason/BYAR-Chobby.git"

set "ENGINE_ASSET_NAME=recoil-controller-amd64-windows-d5c8a21e2704a4dd16c1d0e3e9abe7527dd5f5d5.zip"
set "ENGINE_URL=https://github.com/UnderarmCape/underarmcape-bar-controller-support-attempt-01/releases/download/controller-support-v0.3-working-fresh-install/%ENGINE_ASSET_NAME%"

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "STAMP=%%I"

set "WORK=%TEMP%\BAR-Controller-Support-v0.3.4-SAFE-%STAMP%"
set "ENGINE_ARCHIVE=%WORK%\%ENGINE_ASSET_NAME%"
set "ENGINE_EXTRACT=%WORK%\engine_extract"
set "LOCAL_ENGINE_ARCHIVE=%~dp0%ENGINE_ASSET_NAME%"

set "STAGE_ENGINE=%ENGINE_ROOT%\%ENGINE_SLOT%.controller-stage-%STAMP%"
set "STAGE_BAR=%DST_GAMES%\BAR.sdd.controller-stage-%STAMP%"
set "STAGE_CHOBBY=%DST_GAMES%\BYAR Chobby.sdd.controller-stage-%STAMP%"

set "ENGINE_BACKUP=%BACKUP%\%ENGINE_SLOT%_stock_before_controller_install_%STAMP%"
set "BAR_BACKUP=%BACKUP%\BAR.sdd_before_controller_install_%STAMP%"
set "CHOBBY_BACKUP=%BACKUP%\BYAR_Chobby.sdd_before_controller_install_%STAMP%"

REM ============================================================
REM Requirements
REM ============================================================

echo.
echo ============================================================
echo Checking requirements
echo ============================================================
echo.

if not exist "%BAR_ROOT%" (
    set "FAIL_MESSAGE=BAR install folder was not found: %BAR_ROOT%"
    goto FAIL
)

if not exist "%BAR_DATA%" (
    set "FAIL_MESSAGE=BAR data folder was not found: %BAR_DATA%"
    goto FAIL
)

if not exist "%ENGINE_ROOT%" (
    set "FAIL_MESSAGE=BAR engine folder was not found: %ENGINE_ROOT%"
    goto FAIL
)

if not exist "%DST_ENGINE%\spring.exe" (
    set "FAIL_MESSAGE=Expected stock BAR engine was not found: %DST_ENGINE%\spring.exe"
    goto FAIL
)

where git >nul 2>nul
if errorlevel 1 (
    set "FAIL_MESSAGE=Git was not found in PATH. Install Git for Windows first."
    goto FAIL
)

where powershell >nul 2>nul
if errorlevel 1 (
    set "FAIL_MESSAGE=PowerShell was not found. This installer needs PowerShell to extract the ZIP."
    goto FAIL
)

echo BAR root:
echo "%BAR_ROOT%"
echo.
echo BAR data:
echo "%BAR_DATA%"
echo.
echo Current engine slot:
echo "%DST_ENGINE%"
echo.
echo Engine release ZIP:
echo "%ENGINE_URL%"
echo.
echo BAR game branch:
echo %BAR_REPO%
echo %BAR_BRANCH%
echo.

REM ============================================================
REM Stop BAR/Recoil processes
REM ============================================================

echo ============================================================
echo Closing possible running BAR/Recoil processes
echo ============================================================
echo.

taskkill /IM spring.exe /F >nul 2>nul
taskkill /IM Beyond-All-Reason.exe /F >nul 2>nul
taskkill /IM pr-downloader.exe /F >nul 2>nul

REM ============================================================
REM Prepare temp/staging folders
REM ============================================================

echo ============================================================
echo Preparing temp and staging folders
echo ============================================================
echo.

rmdir /s /q "%WORK%" 2>nul

mkdir "%WORK%" 2>nul
mkdir "%ENGINE_EXTRACT%" 2>nul
mkdir "%BACKUP%" 2>nul
mkdir "%DST_GAMES%" 2>nul

if not exist "%WORK%" (
    set "FAIL_MESSAGE=Could not create temp folder: %WORK%"
    goto FAIL
)

if not exist "%BACKUP%" (
    set "FAIL_MESSAGE=Could not create backup folder: %BACKUP%"
    goto FAIL
)

REM Clean old staging folders from previous failed attempts only.
for /d %%D in ("%ENGINE_ROOT%\%ENGINE_SLOT%.controller-stage-*") do (
    echo Removing old engine staging folder: "%%~fD"
    rmdir /s /q "%%~fD" 2>nul
)

for /d %%D in ("%DST_GAMES%\BAR.sdd.controller-stage-*") do (
    echo Removing old BAR.sdd staging folder: "%%~fD"
    rmdir /s /q "%%~fD" 2>nul
)

for /d %%D in ("%DST_GAMES%\BYAR Chobby.sdd.controller-stage-*") do (
    echo Removing old BYAR Chobby staging folder: "%%~fD"
    rmdir /s /q "%%~fD" 2>nul
)

REM ============================================================
REM Get custom engine ZIP
REM ============================================================

echo ============================================================
echo Getting custom controller engine ZIP
echo ============================================================
echo.

if exist "%LOCAL_ENGINE_ARCHIVE%" (
    echo Found local engine ZIP next to installer:
    echo "%LOCAL_ENGINE_ARCHIVE%"
    echo Copying local ZIP instead of downloading...
    copy /Y "%LOCAL_ENGINE_ARCHIVE%" "%ENGINE_ARCHIVE%"
    if errorlevel 1 (
        set "FAIL_MESSAGE=Failed to copy local engine ZIP."
        goto FAIL
    )
) else (
    echo No local engine ZIP found next to installer.
    echo Downloading from GitHub Release...
    echo.
    echo URL:
    echo "%ENGINE_URL%"
    echo.
    echo Output:
    echo "%ENGINE_ARCHIVE%"
    echo.

    set "DOWNLOAD_OK=0"

    where curl.exe >nul 2>nul
    if not errorlevel 1 (
        echo Trying download with curl.exe...
        curl.exe -L --fail --retry 5 --retry-delay 3 --connect-timeout 30 --output "%ENGINE_ARCHIVE%" "%ENGINE_URL%"
        if not errorlevel 1 set "DOWNLOAD_OK=1"
    )

    if "!DOWNLOAD_OK!"=="0" (
        echo.
        echo curl.exe download did not complete. Trying PowerShell fallback...
        powershell -NoProfile -ExecutionPolicy Bypass -Command ^
          "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%ENGINE_URL%' -OutFile '%ENGINE_ARCHIVE%'"
        if not errorlevel 1 set "DOWNLOAD_OK=1"
    )

    if not "!DOWNLOAD_OK!"=="1" (
        set "FAIL_MESSAGE=Failed to download engine ZIP. Manual fallback: put %ENGINE_ASSET_NAME% next to this installer and run again."
        goto FAIL
    )
)

if not exist "%ENGINE_ARCHIVE%" (
    set "FAIL_MESSAGE=Engine ZIP was not found after download/copy: %ENGINE_ARCHIVE%"
    goto FAIL
)

for %%A in ("%ENGINE_ARCHIVE%") do set "ARCHIVE_SIZE=%%~zA"
if "%ARCHIVE_SIZE%"=="0" (
    set "FAIL_MESSAGE=Engine ZIP is 0 bytes: %ENGINE_ARCHIVE%"
    goto FAIL
)

echo Engine ZIP ready:
dir "%ENGINE_ARCHIVE%"

REM ============================================================
REM Extract and stage custom engine
REM ============================================================

echo.
echo ============================================================
echo Extracting and staging custom controller engine
echo ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; Expand-Archive -Path '%ENGINE_ARCHIVE%' -DestinationPath '%ENGINE_EXTRACT%' -Force"

if errorlevel 1 (
    set "FAIL_MESSAGE=Failed to extract engine ZIP."
    goto FAIL
)

set "SRC_ENGINE="
for /f "delims=" %%F in ('dir /s /b "%ENGINE_EXTRACT%\spring.exe" 2^>nul') do (
    if not defined SRC_ENGINE (
        if exist "%%~dpFunitsync.dll" (
            if exist "%%~dpFbase" (
                REM Use %%~dpF. to avoid a quoted robocopy source ending in a trailing backslash.
                set "SRC_ENGINE=%%~dpF."
            )
        )
    )
)

if not defined SRC_ENGINE (
    set "FAIL_MESSAGE=Could not find extracted engine folder containing spring.exe, unitsync.dll, and base\."
    goto FAIL
)

echo Extracted engine source:
echo "!SRC_ENGINE!"
echo.
echo Copying extracted custom engine to staging folder:
echo "%STAGE_ENGINE%"
echo.

mkdir "%STAGE_ENGINE%" 2>nul
robocopy "!SRC_ENGINE!" "%STAGE_ENGINE%" /E
if errorlevel 8 (
    set "FAIL_MESSAGE=Failed to copy custom engine to staging folder."
    goto FAIL
)

if not exist "%STAGE_ENGINE%\spring.exe" (
    set "FAIL_MESSAGE=Staged engine missing spring.exe."
    goto FAIL
)

if not exist "%STAGE_ENGINE%\unitsync.dll" (
    set "FAIL_MESSAGE=Staged engine missing unitsync.dll."
    goto FAIL
)

if not exist "%STAGE_ENGINE%\base" (
    set "FAIL_MESSAGE=Staged engine missing base folder."
    goto FAIL
)

echo Staged engine verified successfully.

REM ============================================================
REM Stage BAR.sdd and BYAR Chobby.sdd BEFORE touching engine
REM ============================================================

echo.
echo ============================================================
echo Staging BAR.sdd controller-support branch
echo ============================================================
echo.

cd /d "%DST_GAMES%"

git -c core.longpaths=true clone --depth 1 --branch %BAR_BRANCH% --single-branch %BAR_REPO% "%STAGE_BAR%"
if errorlevel 1 (
    set "FAIL_MESSAGE=Failed to clone BAR controller-support branch into staging folder."
    goto FAIL
)

if not exist "%STAGE_BAR%\modinfo.lua" (
    set "FAIL_MESSAGE=Staged BAR.sdd missing modinfo.lua."
    goto FAIL
)

if not exist "%STAGE_BAR%\common\constants.lua" (
    set "FAIL_MESSAGE=Staged BAR.sdd missing common\constants.lua."
    goto FAIL
)

if not exist "%STAGE_BAR%\luaui\Widgets\gui_controller_camera_test.lua" (
    set "FAIL_MESSAGE=Staged BAR.sdd missing gui_controller_camera_test.lua."
    goto FAIL
)

findstr /n /i "Controller-support engine compatibility shim" "%STAGE_BAR%\common\constants.lua"
if errorlevel 1 (
    set "FAIL_MESSAGE=Staged BAR.sdd constants.lua does not contain controller compatibility shim."
    goto FAIL
)

echo.
echo ============================================================
echo Staging BYAR Chobby.sdd
echo ============================================================
echo.

git -c core.longpaths=true clone --depth 1 --recurse-submodules --shallow-submodules %CHOBBY_REPO% "%STAGE_CHOBBY%"
if errorlevel 1 (
    set "FAIL_MESSAGE=Failed to clone BYAR Chobby.sdd into staging folder."
    goto FAIL
)

if not exist "%STAGE_CHOBBY%\modinfo.lua" (
    set "FAIL_MESSAGE=Staged BYAR Chobby.sdd missing modinfo.lua."
    goto FAIL
)

echo.
echo All staging checks passed. The stock engine has NOT been moved yet.

REM ============================================================
REM Backup current active install
REM ============================================================

echo.
echo ============================================================
echo Backing up current active install
echo ============================================================
echo.

echo Backing up current stock engine to:
echo "%ENGINE_BACKUP%"
robocopy "%DST_ENGINE%" "%ENGINE_BACKUP%" /E
if errorlevel 8 (
    set "FAIL_MESSAGE=Engine backup failed. Stock engine was not changed."
    goto FAIL
)

if exist "%DST_BAR%" (
    echo.
    echo Backing up existing BAR.sdd to:
    echo "%BAR_BACKUP%"
    robocopy "%DST_BAR%" "%BAR_BACKUP%" /E
    if errorlevel 8 (
        set "FAIL_MESSAGE=BAR.sdd backup failed. Stock engine was not changed."
        goto FAIL
    )
)

if exist "%DST_CHOBBY%" (
    echo.
    echo Backing up existing BYAR Chobby.sdd to:
    echo "%CHOBBY_BACKUP%"
    robocopy "%DST_CHOBBY%" "%CHOBBY_BACKUP%" /E
    if errorlevel 8 (
        set "FAIL_MESSAGE=BYAR Chobby.sdd backup failed. Stock engine was not changed."
        goto FAIL
    )
)

REM ============================================================
REM Install staged BAR.sdd and Chobby
REM ============================================================

echo.
echo ============================================================
echo Installing staged BAR.sdd and BYAR Chobby.sdd
echo ============================================================
echo.

if exist "%DST_BAR%" (
    rmdir /s /q "%DST_BAR%" 2>nul
    if exist "%DST_BAR%" (
        set "FAIL_MESSAGE=Could not remove old BAR.sdd. Stock engine was not changed."
        goto FAIL
    )
)

move "%STAGE_BAR%" "%DST_BAR%"
if errorlevel 1 (
    set "FAIL_MESSAGE=Could not move staged BAR.sdd into place. Stock engine was not changed."
    goto FAIL
)

if exist "%DST_CHOBBY%" (
    rmdir /s /q "%DST_CHOBBY%" 2>nul
    if exist "%DST_CHOBBY%" (
        set "FAIL_MESSAGE=Could not remove old BYAR Chobby.sdd. Stock engine was not changed."
        goto FAIL
    )
)

move "%STAGE_CHOBBY%" "%DST_CHOBBY%"
if errorlevel 1 (
    set "FAIL_MESSAGE=Could not move staged BYAR Chobby.sdd into place. Stock engine was not changed."
    goto FAIL
)

REM ============================================================
REM SAFE engine swap: move stock engine, then move staged engine.
REM ============================================================

echo.
echo ============================================================
echo SAFE engine swap
echo ============================================================
echo.

echo Moving current stock engine out of active slot:
echo "%DST_ENGINE%"
echo to:
echo "%ENGINE_BACKUP%_ACTIVE_MOVED"
echo.

if exist "%ENGINE_BACKUP%_ACTIVE_MOVED" (
    set "FAIL_MESSAGE=Active-moved engine backup already exists unexpectedly: %ENGINE_BACKUP%_ACTIVE_MOVED"
    goto FAIL
)

move "%DST_ENGINE%" "%ENGINE_BACKUP%_ACTIVE_MOVED"
if errorlevel 1 (
    set "FAIL_MESSAGE=Could not move active stock engine to backup. Engine was not replaced."
    goto FAIL
)

echo Moving staged custom engine into active engine slot:
echo "%STAGE_ENGINE%"
echo to:
echo "%DST_ENGINE%"
echo.

move "%STAGE_ENGINE%" "%DST_ENGINE%"
if errorlevel 1 (
    echo ERROR: Failed to move custom engine into active slot.
    echo Attempting to restore stock engine...
    if exist "%ENGINE_BACKUP%_ACTIVE_MOVED" (
        move "%ENGINE_BACKUP%_ACTIVE_MOVED" "%DST_ENGINE%"
    )
    set "FAIL_MESSAGE=Custom engine move failed. Attempted stock-engine restore."
    goto FAIL
)

if not exist "%DST_ENGINE%\spring.exe" (
    set "FAIL_MESSAGE=Active engine missing spring.exe after swap."
    goto FAIL
)

if not exist "%DST_ENGINE%\unitsync.dll" (
    set "FAIL_MESSAGE=Active engine missing unitsync.dll after swap."
    goto FAIL
)

if not exist "%DST_ENGINE%\base" (
    set "FAIL_MESSAGE=Active engine missing base folder after swap."
    goto FAIL
)

echo Custom engine is now active.

REM ============================================================
REM Enable dev mode and clear stale state
REM ============================================================

echo.
echo ============================================================
echo Enabling dev mode and clearing cache/state
echo ============================================================
echo.

type nul > "%BAR_DATA%\devmode.txt"

rmdir /s /q "%BAR_DATA%\cache" 2>nul
rmdir /s /q "%BAR_DATA%\fontcache" 2>nul
del /q "%BAR_DATA%\ArchiveCache*.lua" 2>nul
del /q "%BAR_DATA%\infolog.txt" 2>nul

if exist "%BAR_DATA%\LuaUI" ren "%BAR_DATA%\LuaUI" "LuaUI.controller-install-disabled-%STAMP%" 2>nul
if exist "%BAR_DATA%\LuaMenu" ren "%BAR_DATA%\LuaMenu" "LuaMenu.controller-install-disabled-%STAMP%" 2>nul
if exist "%BAR_DATA%\chobby_config.json" ren "%BAR_DATA%\chobby_config.json" "chobby_config.controller-install-disabled-%STAMP%.json" 2>nul

REM ============================================================
REM Final verification
REM ============================================================

echo.
echo ============================================================
echo Final verification
echo ============================================================
echo.

if not exist "%DST_ENGINE%\spring.exe" (
    set "FAIL_MESSAGE=Final verify failed: missing active spring.exe."
    goto FAIL
)

if not exist "%DST_BAR%\modinfo.lua" (
    set "FAIL_MESSAGE=Final verify failed: missing BAR.sdd modinfo.lua."
    goto FAIL
)

if not exist "%DST_BAR%\common\constants.lua" (
    set "FAIL_MESSAGE=Final verify failed: missing BAR.sdd constants.lua."
    goto FAIL
)

if not exist "%DST_BAR%\luaui\Widgets\gui_controller_camera_test.lua" (
    set "FAIL_MESSAGE=Final verify failed: missing controller widget."
    goto FAIL
)

if not exist "%DST_CHOBBY%\modinfo.lua" (
    set "FAIL_MESSAGE=Final verify failed: missing BYAR Chobby.sdd modinfo.lua."
    goto FAIL
)

if not exist "%BAR_DATA%\devmode.txt" (
    set "FAIL_MESSAGE=Final verify failed: missing devmode.txt."
    goto FAIL
)

cd /d "%DST_BAR%"

echo.
echo BAR.sdd branch:
git branch --show-current

echo.
echo Recent BAR.sdd commits:
git log --oneline -5

echo.
echo constants.lua shim check:
findstr /n /i "Controller-support engine compatibility shim" common\constants.lua
if errorlevel 1 (
    set "FAIL_MESSAGE=Final verify failed: constants.lua compatibility shim was not found."
    goto FAIL
)

echo.
echo Installed files:
dir "%DST_ENGINE%\spring.exe"
dir "%DST_BAR%\luaui\Widgets\gui_controller_camera_test.lua"
dir "%DST_CHOBBY%\modinfo.lua"
dir "%BAR_DATA%\devmode.txt"

echo.
echo ============================================================
echo INSTALL COMPLETE
echo ============================================================
echo.
echo Next steps:
echo   1. Plug in Xbox controller by USB.
echo   2. Launch Beyond All Reason.
echo   3. Go to Settings ^> Developer.
echo   4. Set Singleplayer to: Beyond All Reason Dev.
echo   5. Click Skirmish and start a local match.
echo.
echo Verify after match loads:
echo findstr /i "Spring Engine Version ControllerInput Xbox constants.lua Fatal" "%BAR_DATA%\infolog.txt"
echo.
echo Healthy signs:
echo   Spring Engine Version: d5c8a21 research/controller-api-2025-06-19
echo   Controller connected: Xbox ...
echo.
echo Backup folder:
echo "%BACKUP%"
echo.
exit /b 0

:FAIL
echo.
echo ============================================================
echo INSTALL FAILED
echo ============================================================
echo.
echo !FAIL_MESSAGE!
echo.
echo Stock engine should not have been deleted by this SAFE installer.
echo.
echo Active engine:
echo "%DST_ENGINE%"
echo.
echo Backup folder:
echo "%BACKUP%"
echo.
echo Work folder:
echo "%WORK%"
echo.
echo Full log:
echo "%INSTALL_LOG%"
echo.
exit /b 1
````


---

## 16. Closing Note

This bible is intended to help Recoil Engine and Beyond All Reason developers understand, review, fork, clean up, and potentially adopt the controller-support prototype. The safest interpretation is that the project proves the concept and supplies a working base, but still requires normal open-source review, refactoring, testing, and maintainer approval before any official support claim.
